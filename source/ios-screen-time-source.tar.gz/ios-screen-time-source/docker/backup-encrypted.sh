#!/usr/bin/env bash
# HIPAA-2028 encryption-at-rest, backup leg — ios-screen-time.
#
# Screenshot OCR + annotation data in a logical backup is a high-value at-rest
# leak vector. This guarantees the dump is ciphertext before it is written
# anywhere: pg_dump streams to stdout, is gzipped, and is AES-256 encrypted with
# openssl in the pipe — the plaintext never lands on disk. The object store must
# ADDITIONALLY enforce server_side_encryption (SSE-KMS) as defence in depth.
#
# Refuses to run without a key, so it can never silently emit a plaintext dump.
#
# Usage: BACKUP_ENCRYPTION_KEY=... DATABASE_URL=... ./backup-encrypted.sh [out_dir] [stamp]
set -euo pipefail

: "${BACKUP_ENCRYPTION_KEY:?refusing to write an unencrypted backup: set BACKUP_ENCRYPTION_KEY}"
: "${DATABASE_URL:?set DATABASE_URL to the database to back up}"

OUT_DIR="${1:-/var/backups/ios-screen-time}"
STAMP="${2:?pass a UTC timestamp, e.g. \$(date -u +%Y%m%dT%H%M%SZ), from the caller}"
DEST="${OUT_DIR}/screenshot_annotations_${STAMP}.sql.gz.enc"
mkdir -p "$OUT_DIR"

pg_dump --no-owner --format=plain "$DATABASE_URL" \
  | gzip -9 \
  | openssl enc -aes-256-cbc -pbkdf2 -salt -pass "env:BACKUP_ENCRYPTION_KEY" \
  > "$DEST"

chmod 600 "$DEST"
echo "[backup-encrypted] wrote ${DEST} (AES-256, salted/pbkdf2)."
echo "[backup-encrypted] upload with server_side_encryption, e.g.:"
echo "    aws s3 cp ${DEST} s3://\$BACKUP_BUCKET/ --sse aws:kms --sse-kms-key-id \$BACKUP_KMS_KEY_ID"
