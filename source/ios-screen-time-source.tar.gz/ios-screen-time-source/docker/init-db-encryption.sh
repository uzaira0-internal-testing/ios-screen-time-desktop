#!/usr/bin/env bash
# HIPAA-2028 encryption-at-rest initialiser for ios-screen-time PostgreSQL.
#
# Mirrors chronicle/docker/init-db-encryption.sh, adapted to stock postgres:16
# (pgcrypto as a contrib extension) rather than Percona pg_tde. Mounted into the
# postgres container at /docker-entrypoint-initdb.d/ (see docker-compose.tls.yml)
# so it runs on first boot; idempotent.
#
# Establishes pgcrypto in a dedicated schema for envelope-encrypting sensitive
# screenshot OCR text with pgcrypto.pgp_sym_encrypt() under a session-scoped key,
# and fails loudly if the crypto primitive is unavailable.
set -euo pipefail

PSQL=(psql -v ON_ERROR_STOP=1
      --username "${POSTGRES_USER:-screenshot}"
      --dbname "${POSTGRES_DB:-screenshot_annotations}")

"${PSQL[@]}" <<'SQL'
CREATE SCHEMA IF NOT EXISTS pgcrypto;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pgcrypto') THEN
    BEGIN
      EXECUTE 'ALTER EXTENSION pgcrypto SET SCHEMA pgcrypto';
    EXCEPTION WHEN others THEN
      NULL;
    END;
  ELSE
    EXECUTE 'CREATE EXTENSION pgcrypto SCHEMA pgcrypto';
  END IF;
END
$$;

GRANT USAGE ON SCHEMA pgcrypto TO PUBLIC;

DO $$
DECLARE ct bytea; pt text;
BEGIN
  ct := pgcrypto.pgp_sym_encrypt('hipaa-encryption-at-rest-selftest', 'init-self-test-key');
  pt := pgcrypto.pgp_sym_decrypt(ct, 'init-self-test-key');
  IF pt <> 'hipaa-encryption-at-rest-selftest' THEN
    RAISE EXCEPTION 'pgcrypto round-trip failed: encryption-at-rest is not available';
  END IF;
END
$$;
SQL

echo "[init-db-encryption] pgcrypto schema ready; envelope encryption-at-rest available."
