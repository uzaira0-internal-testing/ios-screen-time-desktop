# iOS Screen Time Screenshot Processing

An offline-first browser application for loading iOS Screen Time and Battery
screenshots, extracting hourly usage with Rust/Tesseract compiled to WebAssembly,
reviewing the result, and exporting a local research dataset.

The product ships two ways, built from the same `frontend/` code and Rust
pipeline:

- the **WASM/PWA build hosted on GitHub Pages**, which runs in the browser;
- **desktop apps** for macOS, Windows and Linux (`frontend/src-tauri/`), which
  add native folder and Save dialogs, file drops, menus and signed automatic
  updates. Installers are published from
  [ios-screen-time-desktop](https://github.com/uzaira0-internal-testing/ios-screen-time-desktop/releases)
  (see [ADR-0006](docs/adr/0006-desktop-packaging-repo-on-hosted-ci.md)).

Screenshots, OCR results, annotations, and exports stay on the user's device;
no application backend or account is required.

## Product workflow

1. Name a group and load a folder or select individual screenshots.
2. Run device detection, cropping, and OCR in the browser.
3. Review the detected grid and 24 hourly values.
4. Correct or reprocess uncertain values.
5. Export CSV/JSON or export the complete local workspace.

Exact duplicates are skipped and likely near-duplicates are retained with a
warning. Browser storage persists across reloads until the user clears site data
or resets the workspace.

## Browser architecture

```text
React 19 UI + Zustand stores
          │
          ▼
WASM service interfaces
          │
          ├── IndexedDB metadata and image records
          ├── OPFS large blobs, language packs, and workspace backups
          └── bounded Web Worker pool
                    │
                    ▼
          Rust processing crate
          compiled by Emscripten
                    │
                    ▼
          Leptonica + Tesseract OCR
```

The service worker precaches the application shell and verifies executable
pipeline assets against the generated integrity manifest. The build refuses a
partial, stale, or schema-incompatible WASM artifact.

Pure browser WASM intentionally disables the optional PHI NER/redaction stages.
Those modules are not downloaded by the GitHub Pages product.

See [System architecture](docs/architecture/ARCHITECTURE.md) and
[WASM/PWA build](docs/guides/WASM_PWA_BUILD.md) for the detailed contracts.

## Repository map

```text
frontend/src/                         React/TypeScript product
frontend/src/core/implementations/wasm Browser storage and processing services
frontend/tests/                       Playwright WASM/PWA suites
crates/processing/                    Canonical Rust processing pipeline
scripts/build-wasm-emscripten.sh      Browser pipeline build
scripts/ci.sh                         Local validation orchestrator
shared/                               Cross-language source-of-truth constants
src/ and tests/                       Retained Python/reference implementation
frontend/src-tauri/                   Desktop app shell (Tauri)
licenses/                             Third-party license texts for the apps
```

The Python server is a retained development/reference implementation, not a
deployment.

## Prerequisites

- Bun (version pinned by the repository)
- Docker for rebuilding the Emscripten pipeline
- Python/`uv` for contract and parity tests
- Rustup with the pinned toolchain for native Rust validation

Install dependencies:

```bash
uv sync --frozen
cd frontend
bun install --frozen-lockfile
```

## Development

The staged pipeline artifact must match the current Rust source. Rebuild it
after changing `crates/processing`, the Emscripten build script, or pipeline ABI:

```bash
docker build -t ios-screen-time-wasm-builder docker/wasm-build
docker run --rm -v "$PWD:/app" ios-screen-time-wasm-builder \
  bash -lc "scripts/build-wasm-emscripten.sh"
```

Run the browser app:

```bash
cd frontend
WASM_MODE=true bun run dev
```

Create the production PWA:

```bash
cd frontend
REQUIRE_PIPELINE_WASM=1 bun run build
```

For GitHub Pages, the base path is mandatory:

```bash
cd frontend
BASE_PATH=/ios-screen-time-screenshot-processing REQUIRE_PIPELINE_WASM=1 CSP_META=1 bun run build
```

## Validation

```bash
scripts/ci.sh fast
scripts/ci.sh wasm-persona
scripts/ci.sh ocr-corpus
scripts/ci.sh bundle
scripts/ci.sh persona       # Firefox + WebKit compatibility sweep
```

`wasm-persona` builds into `frontend/.cache/wasm-persona-dist`; it must not
overwrite a Pages-ready `frontend/dist`. Run the Pages build as the final action
before publishing and verify `config.js` plus `<base href>`, not only the hashed
JavaScript bundle.

## Data and privacy

- Screenshot bytes and extracted values remain in browser-managed storage
  (in the desktop app, the app's own web storage on that computer).
- There is no telemetry and no application API.
- Optional OCR language packs are fetched only when the user installs them.
- The desktop app asks GitHub for a newer version at launch and every 15
  minutes; GitHub sees the IP address and app version. Settings → Privacy turns
  this off, and Check for Updates… in the app menu still works. If the window
  fails to load at all, the app checks once so a fixed release can be
  installed.
- Workspace exports can contain participant identifiers and screenshot data;
  handle them according to the research data policy.
- Clearing browser site data deletes the local workspace unless it was exported.

Do not commit participant screenshots, workspace exports, secrets, or local
browser data.

## Generated sources

`shared/*.json` is the source of truth for constants consumed by Python,
TypeScript, and Rust. Regenerate after changing it:

```bash
python3 scripts/generate-shared-constants.py
```

The generator resolves Rustfmt through the repository's pinned Rustup toolchain,
so its output is stable even when another Rustfmt exists earlier on `PATH`.

## License

GNU Affero General Public License v3.0 or later; see [LICENSE](LICENSE).
Each desktop release publishes the source it was built from as
`ios-screen-time-source-<version>.tar.gz` (`scripts/export-source.py`), without
the real-device fixture screenshots and the data recorded from them.
Third-party license texts live in `licenses/` and in the app under Settings →
About.
