import os
import sys
from logging.config import fileConfig

from sqlalchemy import engine_from_config, pool

from alembic import context

# Add project root to path so we can import models
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# Import database models for autogenerate support
# Import workflow models so autogenerate detects them (after Base is loaded).
# Use the canonical ``screenshot_processor.*`` package path (the editable install),
# NOT a ``src.``-prefixed path: ``import src.screenshot_processor...`` resolves to the
# same source files but a SEPARATE module object, so its model class bodies re-execute
# and re-register ``workflow_execution`` on the already-populated Base.metadata —
# raising "Table 'workflow_execution' is already defined for this MetaData instance"
# whenever something (e.g. tests/conftest.py) has already imported the canonical module.
import screenshot_processor.workflows.engine.models  # noqa: F401
from screenshot_processor.web.database.models import Base

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# add your model's MetaData object here
# for 'autogenerate' support
target_metadata = Base.metadata

# Allow environment variable override for database URL
# Convert async driver to sync for Alembic migrations
DATABASE_URL = os.getenv("DATABASE_URL")
if DATABASE_URL:
    # Alembic runs synchronously, so convert asyncpg to psycopg2
    if "postgresql+asyncpg://" in DATABASE_URL:
        DATABASE_URL = DATABASE_URL.replace("postgresql+asyncpg://", "postgresql://")
    config.set_main_option("sqlalchemy.url", DATABASE_URL)

# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine
    and associate a connection with the context.

    """
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
