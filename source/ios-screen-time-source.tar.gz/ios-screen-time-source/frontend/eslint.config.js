import js from "@eslint/js";
import tseslint from "typescript-eslint";
import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";
import jsxA11y from "eslint-plugin-jsx-a11y";
import globals from "globals";

export default tseslint.config(
  { ignores: ["dist", "node_modules", "*.config.js", "*.config.ts", "server"] },
  {
    extends: [js.configs.recommended, ...tseslint.configs.recommendedTypeChecked],
    files: ["**/*.{ts,tsx}"],
    linterOptions: {
      // Surface stale eslint-disable directives so we keep the codebase tidy.
      reportUnusedDisableDirectives: "error",
    },
    languageOptions: {
      ecmaVersion: 2022,
      globals: globals.browser,
      // Type-aware lint (ts-type-aware-lint): typescript-eslint's type-checked
      // rules (no-floating-promises, no-misused-promises, no-unsafe-*,
      // await-thenable) run — the rules biome/oxlint structurally cannot provide
      // (they have no TS type graph). Points at tsconfig.eslint.json rather than
      // projectService because the app tsconfig excludes test files, and
      // projectService can only discover tsconfig.json — the lint project must
      // include every linted file or the parser errors.
      parserOptions: { project: "./tsconfig.eslint.json", tsconfigRootDir: import.meta.dirname },
    },
    plugins: {
      "react-hooks": reactHooks,
      "react-refresh": reactRefresh,
      "jsx-a11y": jsxA11y,
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
      // a11y: enforce the patterns the persona suite caught and any related ones.
      // These are the rules from jsx-a11y's "recommended" config plus stricter
      // ones we want as hard errors (control-has-associated-label, heading).
      ...jsxA11y.configs.recommended.rules,
      // All a11y rules are hard errors. The original legacy violations were
      // migrated in a single sweep alongside the persona-suite adoption.
      // New code that regresses any of these fails CI lint.
      "jsx-a11y/heading-has-content": "error",
      "jsx-a11y/control-has-associated-label": [
        "error",
        {
          labelAttributes: ["aria-label", "aria-labelledby"],
          controlComponents: [],
          ignoreElements: [],
        },
      ],
      "jsx-a11y/label-has-associated-control": "error",
      "jsx-a11y/no-noninteractive-element-interactions": "error",
      "jsx-a11y/no-autofocus": "error",
      "jsx-a11y/no-interactive-element-to-noninteractive-role": "error",
      "jsx-a11y/click-events-have-key-events": "error",
      "jsx-a11y/no-static-element-interactions": "error",
      // React Hooks v7 — all enforced.
      "react-hooks/set-state-in-effect": "error",
      "react-hooks/immutability": "error",
      "react-hooks/refs": "error",
      "react-hooks/incompatible-library": "error",
      "react-hooks/exhaustive-deps": "error",
      "react-refresh/only-export-components": "error",
      "@typescript-eslint/no-unused-vars": [
        "error",
        { argsIgnorePattern: "^_", varsIgnorePattern: "^_" },
      ],
      "@typescript-eslint/no-explicit-any": "error",
      // Production code: no stray console.* — use the logger or wrap in
      // `if (config.isDev)`. warn/error stay allowed for genuine alerts.
      "no-console": ["error", { allow: ["warn", "error"] }],
      // `require-await` is OFF by deliberate decision, not to silence noise.
      // The dual-mode DI architecture declares Promise-returning contracts
      // (IStorageService, IProcessingService, IPreprocessingService,
      // IAnnotationService); an implementation that happens to be synchronous —
      // a server-mode stub that throws "not used in server mode", a WASM shim, a
      // test double — still MUST return a Promise, and `async` is the mechanism
      // that does it. Audited over the whole tree: all 115 reports were such
      // contract implementations and not one was a forgotten `await`. The only
      // available "fix" is `() => Promise.resolve(x)` at every site, which
      // obscures the contract without catching anything. `await-thenable`,
      // `no-floating-promises` and `no-misused-promises` stay ON — those DO find
      // real async bugs here.
      "@typescript-eslint/require-await": "off",
      "no-await-in-loop": "error",
      "require-atomic-updates": "error",
      // Catch real bugs
      "no-constant-binary-expression": "error",
      "no-constructor-return": "error",
      "no-self-compare": "error",
      "no-template-curly-in-string": "warn",
      "no-unmodified-loop-condition": "error",
      "no-unreachable-loop": "error",
      "array-callback-return": "error",
      "no-promise-executor-return": "error",
      "eqeqeq": ["error", "always", { null: "ignore" }],
    },
  },
  {
    // Test-only relaxations. Both are bun-types imprecision, not real defects.
    files: ["**/*.test.{ts,tsx}", "**/__tests__/**/*.{ts,tsx}"],
    rules: {
      // `bun:test` declares `expect(x).resolves` / `.rejects` as
      // `Matchers<unknown>`, so its matcher methods are typed `void` and every
      // `await expect(p).rejects.toThrow(...)` reads as awaiting a non-thenable.
      // The await is kept regardless: it is the documented form in bun, Jest and
      // Vitest alike, and under Jest/Vitest the matcher genuinely IS a promise —
      // dropping the await there would leave the assertion unobserved. The rule
      // stays ON for application code, where it does find real bugs.
      "@typescript-eslint/await-thenable": "off",
    },
  }
);
