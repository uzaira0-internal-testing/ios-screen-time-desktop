import { defineConfig, devices } from "@playwright/test";
import { fileURLToPath } from "node:url";
import path from "node:path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Playwright config for the WASM smoke suite.
 *
 * Two targets:
 *
 *   1. REAL BUNDLE (preferred for verification). Point the suite at a running
 *      WASM Docker container — the actual nginx image (gzip, immutable cache,
 *      SPA fallback) serving the real build artifacts:
 *        WASM_BASE_URL=http://127.0.0.1:9099 \
 *          bunx playwright test --config playwright.wasm.config.ts
 *      The container must be ROOT-served (BASE_PATH="" so the app renders at
 *      "/", matching the spec's root-relative navigations), e.g.:
 *        docker run -d --rm -p 127.0.0.1:9099:80 -e BASE_PATH= \
 *          ios-screen-time-screenshot-processing-wasm
 *      When WASM_BASE_URL is set, no local web server is started.
 *
 *   2. DIST CONVENIENCE (default, no container needed). Auto-runs
 *      `python3 tests/spa-server.py 9091 dist` against the local production
 *      build so the suite runs with one command. This serves static files
 *      only — it does NOT exercise the real nginx config, so prefer target 1
 *      when verifying a deployment.
 *
 * Global setup (tests/setup/wasm-global-setup.ts) populates
 * /tmp/test-screenshots/ from tests/fixtures/images/ before the first test.
 *
 * Only runs files under tests/ that match wasm-* — the broader Playwright
 * suite (server/api/auth specs) lives in the same dir but is not relevant
 * for the WASM build.
 */
const WASM_BASE_URL = process.env.WASM_BASE_URL;

export default defineConfig({
  testDir: "./tests",
  testMatch: /wasm-smoke\.spec\.ts$/,
  fullyParallel: false,
  workers: 1,
  globalSetup: path.resolve(__dirname, "tests/setup/wasm-global-setup.ts"),
  use: {
    baseURL: WASM_BASE_URL || "http://127.0.0.1:9091",
    trace: "on-first-retry",
    screenshot: "only-on-failure",
    actionTimeout: 10_000,
    navigationTimeout: 30_000,
  },
  // Only spin up the local dist server when not targeting a real container.
  webServer: WASM_BASE_URL
    ? undefined
    : {
        command: "python3 tests/spa-server.py 9091 dist",
        url: "http://127.0.0.1:9091/",
        reuseExistingServer: !process.env.CI,
        timeout: 30_000,
        stdout: "pipe",
        stderr: "pipe",
      },
  projects: [
    {
      name: "chromium",
      use: { ...devices["Desktop Chrome"] },
    },
    {
      name: "firefox",
      use: { ...devices["Desktop Firefox"] },
    },
    {
      name: "webkit",
      use: { ...devices["Desktop Safari"] },
    },
  ],
  timeout: 30_000,
});
