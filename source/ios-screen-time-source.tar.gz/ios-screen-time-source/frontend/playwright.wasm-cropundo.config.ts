import { defineConfig, devices } from "@playwright/test";

/**
 * Playwright config for the crop undo/redo UNIT suite.
 *
 * Like the redaction/workspace unit suites, it drives the REAL WASMPreprocessingService crop
 * path (OffscreenCanvas crop + real Dexie/OPFS/IndexedDB) in real Chromium via a Bun-bundled
 * harness (tests/harness/cropundo-harness.ts), served from a real localhost origin so
 * IndexedDB/OPFS are granted. Reuses the shared build-harness builder + static SPA server.
 */
const PORT = 9099;

export default defineConfig({
  testDir: "./tests",
  testMatch: /wasm-cropundo-unit\.spec\.ts$/,
  fullyParallel: false,
  workers: 1,
  use: {
    baseURL: `http://127.0.0.1:${PORT}`,
    trace: "on-first-retry",
    screenshot: "only-on-failure",
    actionTimeout: 10_000,
    navigationTimeout: 30_000,
  },
  webServer: {
    command: `bun run tests/harness/build-harness.ts cropundo-harness.ts .dist-cropundo && python3 tests/spa-server.py ${PORT} tests/harness/.dist-cropundo`,
    url: `http://127.0.0.1:${PORT}/`,
    reuseExistingServer: !process.env.CI,
    timeout: 60_000,
    stdout: "pipe",
    stderr: "pipe",
  },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
  timeout: 30_000,
});
