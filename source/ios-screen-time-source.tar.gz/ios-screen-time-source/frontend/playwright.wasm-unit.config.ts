import { defineConfig, devices } from "@playwright/test";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Playwright config for the WASM redaction UNIT suite (roadmap #9, test B).
 *
 * Unlike the smoke suite (which drives the deployed bundle through the UI), this exercises
 * the WASM-specific redaction logic in isolation: a Bun-bundled harness (tests/harness/)
 * exposes the REAL `redactImage` + `IndexedDBStorageService` on `window`, served from a real
 * localhost origin (so IndexedDB/OPFS are granted). The test drives them directly in Chromium
 * — real OffscreenCanvas, real Dexie — without the fragility of walking the preprocessing UI.
 *
 * The webServer builds the harness, then serves it via the repo's shared static server
 * (tests/spa-server.py), as every other WASM config does. It's a single page, so that server's
 * SPA fallback simply goes unused.
 */
const PORT = 9097;

export default defineConfig({
  testDir: "./tests",
  testMatch: /wasm-redaction-unit\.spec\.ts$/,
  fullyParallel: false,
  workers: 1,
  use: {
    baseURL: `http://127.0.0.1:${PORT}`,
    trace: "on-first-retry",
    screenshot: "only-on-failure",
    actionTimeout: 10_000,
    navigationTimeout: 30_000,
  },
  webServer: {
    command: `bun run tests/harness/build-harness.ts && python3 tests/spa-server.py ${PORT} tests/harness/.dist`,
    url: `http://127.0.0.1:${PORT}/`,
    reuseExistingServer: !process.env.CI,
    timeout: 60_000,
    stdout: "pipe",
    stderr: "pipe",
  },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
  timeout: 30_000,
});
