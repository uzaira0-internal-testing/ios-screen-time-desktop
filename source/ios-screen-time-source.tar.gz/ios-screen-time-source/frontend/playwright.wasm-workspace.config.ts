import { defineConfig, devices } from "@playwright/test";

/**
 * Playwright config for the WASM workspace import/export UNIT suite (roadmap #22).
 *
 * Like the redaction unit suite, it drives REAL modules (exportWorkspace/importWorkspace +
 * real Dexie/OPFS/IndexedDB) in real Chromium via a Bun-bundled harness (tests/harness/),
 * served from a real localhost origin so IndexedDB/OPFS are granted. The shared build-harness
 * builder is parameterized with this harness entry + its own output dir; served via the repo's
 * shared static server like every other WASM config.
 */
const PORT = 9098;

export default defineConfig({
  testDir: "./tests",
  testMatch: /wasm-(workspace|needs-attention-navigation)-unit\.spec\.ts$/,
  fullyParallel: false,
  workers: 1,
  use: {
    baseURL: `http://127.0.0.1:${PORT}`,
    trace: "on-first-retry",
    screenshot: "only-on-failure",
    actionTimeout: 10_000,
    navigationTimeout: 30_000,
  },
  webServer: {
    command: `bun run tests/harness/build-harness.ts workspace-harness.ts .dist-workspace && python3 tests/spa-server.py ${PORT} tests/harness/.dist-workspace`,
    url: `http://127.0.0.1:${PORT}/`,
    reuseExistingServer: !process.env.CI,
    timeout: 60_000,
    stdout: "pipe",
    stderr: "pipe",
  },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
  timeout: 30_000,
});
