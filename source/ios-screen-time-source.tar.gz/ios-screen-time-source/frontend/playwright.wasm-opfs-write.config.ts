import { defineConfig, devices } from "@playwright/test";

/**
 * Playwright config for the OPFS write UNIT suite.
 *
 * Drives the REAL OPFS writers (tests/harness/opfs-write-harness.ts) with
 * `createWritable` removed from the page, the way Safari before 26 and the
 * macOS 13.3–15 desktop webview look, so writes must go through the
 * `createSyncAccessHandle` worker. Runs in Chromium and in WebKit, the desktop
 * app's engine. Reuses the shared build-harness builder + static SPA server.
 */
const PORT = 9101;

export default defineConfig({
  testDir: "./tests",
  testMatch: /wasm-opfs-write-unit\.spec\.ts$/,
  fullyParallel: false,
  workers: 1,
  use: {
    baseURL: `http://127.0.0.1:${PORT}`,
    trace: "on-first-retry",
    screenshot: "only-on-failure",
    actionTimeout: 10_000,
    navigationTimeout: 30_000,
  },
  webServer: {
    command: `bun run tests/harness/build-harness.ts opfs-write-harness.ts .dist-opfs-write && python3 tests/spa-server.py ${PORT} tests/harness/.dist-opfs-write`,
    url: `http://127.0.0.1:${PORT}/`,
    reuseExistingServer: !process.env.CI,
    timeout: 60_000,
    stdout: "pipe",
    stderr: "pipe",
  },
  projects: [
    { name: "chromium", use: { ...devices["Desktop Chrome"] } },
    { name: "webkit", use: { ...devices["Desktop Safari"] } },
  ],
  timeout: 30_000,
});
