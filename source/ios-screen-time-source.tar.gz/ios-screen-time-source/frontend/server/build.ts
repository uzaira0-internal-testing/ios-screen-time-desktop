/**
 * Bun production build script
 *
 * Builds the app bundle, CSS, service worker, and generates index.html + manifest.
 */

import { rm, mkdir, copyFile, readFile, readdir, stat } from "fs/promises";
import { join, relative, resolve } from "path";
import { execSync } from "child_process";

const ROOT_DIR = resolve(import.meta.dir, "..");
const SRC_DIR = join(ROOT_DIR, "src");
const DIST_DIR = process.env.DIST_DIR
  ? resolve(process.env.DIST_DIR)
  : join(ROOT_DIR, "dist");
const PUBLIC_DIR = join(ROOT_DIR, "public");
const REPO_DIR = resolve(ROOT_DIR, "..");
// Must track PIPELINE_SCHEMA_VERSION in crates/processing/src/types.rs and
// REQUIRED_PIPELINE_SCHEMA_VERSION in
// src/core/implementations/wasm/processing/emscripten/pipelineLoader.ts — three
// pins for one number, all three of which have to move together.
const REQUIRED_PIPELINE_SCHEMA_VERSION = 4;

const PIPELINE_FIXED_SOURCE_PATHS = [
  "Cargo.toml",
  "Cargo.lock",
  "rust-toolchain.toml",
  ".cargo/config.toml",
  "crates/processing/Cargo.toml",
  "crates/processing/Cargo.lock",
  "docker/wasm-build/tesseract-541-output.patch",
  "docker/wasm-build/tesseract-wasm-speed.patch",
  "scripts/build-wasm-emscripten.sh",
  "scripts/pipeline-source-fingerprint.py",
] as const;

async function pipelineSourceFingerprint(): Promise<string> {
  const paths = PIPELINE_FIXED_SOURCE_PATHS.map((path) => join(REPO_DIR, path));
  const rustGlob = new Bun.Glob("**/*.rs");
  for await (const path of rustGlob.scan(join(REPO_DIR, "crates", "processing", "src"))) {
    paths.push(join(REPO_DIR, "crates", "processing", "src", path));
  }
  const existing: string[] = [];
  for (const path of paths) {
    if (await Bun.file(path).exists()) existing.push(path);
  }
  existing.sort((a, b) => relative(REPO_DIR, a).localeCompare(relative(REPO_DIR, b)));

  const digest = new Bun.CryptoHasher("sha256");
  for (const path of existing) {
    digest.update(relative(REPO_DIR, path).split("\\").join("/"));
    digest.update(new Uint8Array([0]));
    digest.update(await Bun.file(path).bytes());
    digest.update(new Uint8Array([0]));
  }
  return digest.digest("hex");
}

async function verifyPipelineArtifact(): Promise<void> {
  const manifestPath = join(PUBLIC_DIR, "pipeline-em", "pipeline-build.json");
  const jsPath = join(PUBLIC_DIR, "pipeline-em", "IosScreenTimePipeline.js");
  const wasmPath = join(PUBLIC_DIR, "pipeline-em", "IosScreenTimePipeline.wasm");
  const tessdataPath = join(PUBLIC_DIR, "pipeline-em", "eng.traineddata");
  const allowStale = process.env.ALLOW_STALE_PIPELINE_WASM === "1";
  const requirePipeline = process.env.REQUIRE_PIPELINE_WASM === "1";
  try {
    const [hasManifest, hasJs, hasWasm, hasTessdata] = await Promise.all([
      Bun.file(manifestPath).exists(),
      Bun.file(jsPath).exists(),
      Bun.file(wasmPath).exists(),
      Bun.file(tessdataPath).exists(),
    ]);
    // Server-backed frontend images do not always ship the optional local OCR
    // engine. An entirely absent artifact is valid; a partial artifact is not.
    if (!hasManifest && !hasJs && !hasWasm && !hasTessdata && !requirePipeline) return;
    if (!hasManifest || !hasJs || !hasWasm || !hasTessdata) {
      throw new Error("pipeline-em artifact is incomplete");
    }
    const manifest = JSON.parse(await readFile(manifestPath, "utf-8")) as {
      pipeline_schema_version?: number;
      source_fingerprint?: string;
      tessdata_sha256?: string;
    };
    if (manifest.pipeline_schema_version !== REQUIRED_PIPELINE_SCHEMA_VERSION) {
      throw new Error(
        `pipeline-em artifact uses schema=${manifest.pipeline_schema_version ?? "missing"}; ` +
          `expected ${REQUIRED_PIPELINE_SCHEMA_VERSION}`,
      );
    }
    const tessdataDigest = new Bun.CryptoHasher("sha256");
    tessdataDigest.update(await Bun.file(tessdataPath).bytes());
    const actualTessdataSha256 = tessdataDigest.digest("hex");
    if (manifest.tessdata_sha256 !== actualTessdataSha256) {
      throw new Error(
        `pipeline-em tessdata hash mismatch (manifest=${manifest.tessdata_sha256 ?? "missing"}, ` +
          `actual=${actualTessdataSha256})`,
      );
    }

    // Standalone frontend Dockerfiles copy only frontend/, not the Rust source
    // tree. In a full checkout, also prove the binary was built from the exact
    // current sources; in a frontend-only context the runtime schema guard is
    // still authoritative.
    const hasPipelineSources = await Bun.file(
      join(REPO_DIR, "crates", "processing", "src", "types.rs"),
    ).exists();
    if (hasPipelineSources) {
      const currentFingerprint = await pipelineSourceFingerprint();
      if (manifest.source_fingerprint !== currentFingerprint) {
        throw new Error(
          `pipeline-em artifact is stale (source=${manifest.source_fingerprint ?? "missing"}, ` +
            `current=${currentFingerprint})`,
        );
      }
    }
  } catch (error) {
    const message =
      `${error instanceof Error ? error.message : String(error)}. ` +
      "Run `bun run wasm:build` before building the frontend.";
    if (allowStale) {
      console.warn(`\x1b[31m[build]\x1b[0m ${message} ALLOW_STALE_PIPELINE_WASM=1; continuing.`);
      return;
    }
    throw new Error(message);
  }
}

// Path alias plugin for @/ -> src/
const pathAliasPlugin: import("bun").BunPlugin = {
  name: "path-alias",
  setup(build) {
    build.onResolve({ filter: /^@\// }, async (args) => {
      const relativePath = args.path.replace(/^@\//, "");
      const basePath = join(SRC_DIR, relativePath);

      // Try different extensions
      const extensions = [".tsx", ".ts", ".js", ".jsx", ""];
      for (const ext of extensions) {
        const fullPath = basePath + ext;
        const file = Bun.file(fullPath);
        if (await file.exists()) {
          return { path: fullPath };
        }
      }

      // Try as directory with index file
      const indexExtensions = [".tsx", ".ts", ".js", ".jsx"];
      for (const ext of indexExtensions) {
        const indexPath = join(basePath, "index" + ext);
        const file = Bun.file(indexPath);
        if (await file.exists()) {
          return { path: indexPath };
        }
      }

      // Fallback to original behavior
      return { path: basePath };
    });
  },
};

// Drop CSS imports from the production JS bundle.
//
// `main.tsx` does `import "./index.css"` so the dev server applies styles via
// HMR. In the production build, though, the stylesheet is compiled SEPARATELY by
// the Tailwind CLI to `dist/assets/index.css` and `<link>`ed from index.html.
// Letting Bun.build also bundle that CSS import emitted a SECOND full copy of
// the stylesheet (`main-<hash>.css`) with every self-hosted woff2 **base64-
// inlined** (~173 KiB) — duplicating the linked `index.css`, injected again at
// runtime by main.js, and SW-precached (~142 KiB gzip of dead weight). Resolving
// `.css` to an empty module makes the JS bundle carry no CSS at all; the
// authoritative Tailwind-CLI `index.css` (which is a superset of the duplicate's
// rules) remains the single stylesheet.
const ignoreCssPlugin: import("bun").BunPlugin = {
  name: "ignore-css",
  setup(build) {
    build.onResolve({ filter: /\.css$/ }, (args) => ({
      path: args.path,
      namespace: "ignore-css",
    }));
    build.onLoad({ filter: /.*/, namespace: "ignore-css" }, () => ({
      contents: "",
      loader: "js",
    }));
  },
};

// Records every npm package the bundler actually loads, so
// third-party-licenses.txt lists what ships rather than all of node_modules
// (which also holds build tools and other platforms' binaries). Returning
// nothing from onLoad leaves loading to Bun.
const bundledPackageDirs = new Set<string>();
const NODE_MODULES_SEGMENT = /[\\/]node_modules[\\/]/;
const licenseCollectorPlugin: import("bun").BunPlugin = {
  name: "license-collector",
  setup(build) {
    build.onLoad({ filter: NODE_MODULES_SEGMENT }, (args) => {
      const at = args.path.search(/[\\/]node_modules[\\/](?!.*[\\/]node_modules[\\/])/);
      const rest = args.path.slice(at + "/node_modules/".length).split(/[\\/]/);
      const name = rest[0]?.startsWith("@") ? rest.slice(0, 2) : rest.slice(0, 1);
      bundledPackageDirs.add(join(args.path.slice(0, at), "node_modules", ...name));
      return undefined;
    });
  },
};

const LICENSE_FILE = /^(licen[cs]e|copying|notice)([.-].*)?$/i;
const RULE = "-".repeat(80);

/**
 * Writes dist/third-party-licenses.txt (shown from Settings → About): the
 * vendored native libraries and fonts in licenses/vendored.json, the Rust
 * crates in licenses/rust.txt (scripts/generate-third-party-licenses.py), and
 * every npm package in the bundle plus Tailwind, whose base styles are compiled
 * into index.css (licenses/npm.json covers packages published without a
 * license file).
 */
async function writeThirdPartyLicenses(): Promise<void> {
  const licensesDir = join(REPO_DIR, "licenses");
  const vendored = (await Bun.file(join(licensesDir, "vendored.json")).json()) as {
    name: string;
    usedFor: string;
    file: string;
  }[];
  const sections: string[] = [
    "iOS Screen Time Screenshot Processor includes the third-party software below.\n" +
      "Each entry gives the software's own license and copyright notice.\n",
    `${RULE}\nNATIVE LIBRARIES, DATA AND FONTS\n`,
  ];
  for (const entry of vendored) {
    const text = (await Bun.file(join(licensesDir, "vendored", entry.file)).text()).trim();
    sections.push(`${RULE}\n${entry.name} — ${entry.usedFor}\n\n${text}\n`);
  }

  sections.push(`${RULE}\nRUST CRATES\n`, await Bun.file(join(licensesDir, "rust.txt")).text());

  // Group npm packages by license text, like the Rust section.
  const missingLicenses = (await Bun.file(join(licensesDir, "npm.json")).json()) as Record<string, string>;
  const packageDirs = [...bundledPackageDirs, join(ROOT_DIR, "node_modules", "tailwindcss")];
  const byText = new Map<string, Set<string>>();
  for (const dir of packageDirs) {
    const pkg = (await Bun.file(join(dir, "package.json")).json()) as {
      name: string;
      version: string;
      license?: string;
    };
    const files = (await readdir(dir)).filter((f) => LICENSE_FILE.test(f)).sort();
    const paths = files.map((f) => join(dir, f));
    if (paths.length === 0) {
      // A few packages publish without their repository's license file.
      const prefix = Object.keys(missingLicenses).find((p) => pkg.name.startsWith(p));
      if (!prefix) throw new Error(`${pkg.name} ships no license file; add its text to licenses/npm.json`);
      paths.push(join(licensesDir, "npm", missingLicenses[prefix]!));
    }
    const texts: string[] = [];
    for (const path of paths) texts.push((await Bun.file(path).text()).replace(/\r\n/g, "\n").trim());
    const key = `${pkg.license ?? "see text"}\n\n${texts.join(`\n\n`)}`;
    const users = byText.get(key) ?? new Set<string>();
    users.add(`${pkg.name} ${pkg.version}`);
    byText.set(key, users);
  }
  sections.push(`${RULE}\nJAVASCRIPT PACKAGES\n`);
  const groups = [...byText].map(([key, users]) => ({ key, users: [...users].sort() }));
  groups.sort((a, b) => a.users[0]!.localeCompare(b.users[0]!));
  for (const { key, users } of groups) {
    const [spdx, ...text] = key.split("\n\n");
    sections.push(`${RULE}\n${spdx}, used by:\n${users.map((u) => ` - ${u}`).join("\n")}\n\n${text.join("\n\n")}\n`);
  }

  const out = join(DIST_DIR, "third-party-licenses.txt");
  await Bun.write(out, sections.join("\n"));
  console.log(`  \x1b[32m✓\x1b[0m third-party-licenses.txt (${packageDirs.length} npm packages)`);
}

function resolveCommitSha(): string {
  const envSha = process.env.VITE_COMMIT_SHA || process.env.GITHUB_SHA;
  if (envSha) return envSha.slice(0, 7);
  try {
    return execSync("git rev-parse --short HEAD", { cwd: ROOT_DIR, stdio: ["ignore", "pipe", "ignore"] })
      .toString()
      .trim();
  } catch {
    return "dev";
  }
}

async function build() {
  console.log("\x1b[34m[build]\x1b[0m Starting production build...\n");
  const startTime = performance.now();

  const pkg = JSON.parse(await readFile(join(ROOT_DIR, "package.json"), "utf-8"));
  const appVersion: string = pkg.version ?? "dev";
  const commitSha = resolveCommitSha();
  console.log(`\x1b[33m[build]\x1b[0m version=${appVersion} sha=${commitSha}`);

  await verifyPipelineArtifact();

  // Content-hash the compiled pipeline wasm (16-char SHA-256 prefix). The loader
  // stamps its glue/wasm/sidecar fetch URLs with `?v=<hash>` (inlined below as
  // __PIPELINE_WASM_HASH__), and the precache manifest stamps the SAME URLs, so
  // the service worker can only ever serve a JS bundle the wasm it was built
  // against — the structural fix for the JS<->wasm ABI skew. Stable while the
  // wasm is unchanged (no needless 5.9 MB re-download). Empty when the wasm
  // isn't built yet → URLs left bare.
  let pipelineWasmHash = "";
  try {
    const wasmBytes = await Bun.file(
      join(PUBLIC_DIR, "pipeline-em", "IosScreenTimePipeline.wasm"),
    ).bytes();
    const digest = await crypto.subtle.digest("SHA-256", wasmBytes);
    pipelineWasmHash = [...new Uint8Array(digest)]
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("")
      .slice(0, 16);
    console.log(`\x1b[33m[build]\x1b[0m pipeline wasm hash=${pipelineWasmHash}`);
  } catch {
    console.log("\x1b[33m[build]\x1b[0m pipeline wasm absent — asset URLs left unstamped");
  }

  // Clean dist directory
  await rm(DIST_DIR, { recursive: true, force: true });
  await mkdir(DIST_DIR, { recursive: true });
  await mkdir(join(DIST_DIR, "assets"), { recursive: true });

  // Bundle JavaScript
  console.log("\x1b[33m[build]\x1b[0m Bundling JavaScript...");

  // Pure browser WASM deliberately disables PHI/NER. Do not ship its ~879 KB
  // worker entrypoint in the public PWA; a PHI-enabled desktop package can opt
  // in explicitly when preparing its frontend dist.
  const enablePhiWorker = process.env.ENABLE_PHI_WORKER === "1";
  const workerEntrypoints = [
    join(
      SRC_DIR,
      "core/implementations/wasm/processing/workers/imageProcessor.worker.emscripten.ts",
    ),
    join(SRC_DIR, "core/implementations/wasm/preprocessing/crop.worker.ts"),
    join(SRC_DIR, "core/implementations/wasm/storage/opfsWrite.worker.ts"),
  ];
  if (enablePhiWorker) {
    workerEntrypoints.push(
      join(SRC_DIR, "core/implementations/wasm/preprocessing/nerWorker.ts"),
    );
  }

  const result = await Bun.build({
    // Multi-entrypoint: bundle main.tsx AND every Web Worker module separately
    // so `new Worker(new URL("./foo.ts", import.meta.url))` callers can load
    // them at runtime. Bun's bundler does not auto-detect those URL patterns
    // (it leaves the literal .ts path in the bundle, which 404s in dist).
    // Listing each worker file explicitly emits a hashed JS chunk that the
    // browser can load.
    entrypoints: [
      join(SRC_DIR, "main.tsx"),
      ...workerEntrypoints,
    ],
    outdir: join(DIST_DIR, "assets"),
    target: "browser",
    format: "esm",
    splitting: true,
    // Maps embed the full TS source, and the build is served publicly: opt in only.
    sourcemap: process.env.SOURCEMAP === "external" ? "external" : "none",
    minify: true,
    naming: "[name]-[hash].[ext]",
    plugins: [pathAliasPlugin, ignoreCssPlugin, licenseCollectorPlugin],
    define: {
      "process.env.NODE_ENV": JSON.stringify("production"),
      __APP_VERSION__: JSON.stringify(appVersion),
      __COMMIT_SHA__: JSON.stringify(commitSha),
      __PIPELINE_WASM_HASH__: JSON.stringify(pipelineWasmHash),
    },
  });

  if (!result.success) {
    console.error("\x1b[31m[build]\x1b[0m Build failed:");
    for (const log of result.logs) {
      console.error(log);
    }
    process.exit(1);
  }

  // Map each worker source path → its hashed output filename, then rewrite
  // every `new URL("./worker.ts", import.meta.url)` literal in the bundled JS
  // to point at the real built chunk. Without this, the runtime fetches a
  // non-existent .ts URL.
  const workerOutputMap = new Map<string, string>();
  for (const output of result.outputs) {
    const name = output.path.split(/[/\\]/).pop() || "";
    if (name.startsWith("imageProcessor.worker.emscripten") && name.endsWith(".js")) {
      workerOutputMap.set("imageProcessor.worker.emscripten.ts", `./${name}`);
    } else if (name.startsWith("nerWorker") && name.endsWith(".js")) {
      workerOutputMap.set("nerWorker.ts", `./${name}`);
    } else if (name.startsWith("crop.worker") && name.endsWith(".js")) {
      workerOutputMap.set("crop.worker.ts", `./${name}`);
    } else if (name.startsWith("opfsWrite.worker") && name.endsWith(".js")) {
      workerOutputMap.set("opfsWrite.worker.ts", `./${name}`);
    }
  }
  if (workerOutputMap.size > 0) {
    for (const output of result.outputs) {
      const name = output.path.split(/[/\\]/).pop() || "";
      if (!name.endsWith(".js") || name.endsWith(".map")) continue;
      const filePath = output.path;
      let text = await Bun.file(filePath).text();
      let changed = false;
      for (const [src, hashed] of workerOutputMap) {
        // Match: new URL("…/imageProcessor.worker.emscripten.ts", import.meta.url)
        // Replace the path arg with the hashed sibling chunk URL. Bun emits
        // both the worker chunk and the main chunk into the same /assets/ dir,
        // so a relative ./file.js works from either.
        const pattern = new RegExp(
          `(new URL\\(\\s*["'])([^"']*?)(${src.replace(/\./g, "\\.")})(["'])`,
          "g",
        );
        const next = text.replace(pattern, `$1${hashed}$4`);
        if (next !== text) {
          text = next;
          changed = true;
        }
      }
      if (changed) {
        await Bun.write(filePath, text);
        console.log(
          `  \x1b[32m✓\x1b[0m worker URL rewrite in ${output.path.split(/[/\\]/).pop()}`,
        );
      }
    }
  }

  await writeThirdPartyLicenses();

  // Get the main bundle filename
  let mainBundle = "";
  for (const output of result.outputs) {
    // Use path.basename for cross-platform compatibility (Windows uses \ not /)
    const name = output.path.split(/[/\\]/).pop() || "";
    if (name.startsWith("main-") && name.endsWith(".js") && !name.endsWith(".map")) {
      mainBundle = name;
    }
    console.log("  \x1b[32m✓\x1b[0m " + name + " (" + (output.size / 1024).toFixed(1) + " KB)");
  }

  // Build service worker
  console.log("\n\x1b[33m[build]\x1b[0m Building service worker...");
  const swResult = await Bun.build({
    entrypoints: [join(SRC_DIR, "service-worker.ts")],
    outdir: DIST_DIR,
    target: "browser",
    format: "esm",
    minify: true,
    naming: "sw.js",
    define: {
      __SW_BUILD_ID__: JSON.stringify(commitSha),
    },
  });

  if (!swResult.success) {
    console.error("\x1b[31m[build]\x1b[0m Service worker build failed:");
    for (const log of swResult.logs) {
      console.error(log);
    }
  } else {
    console.log("  \x1b[32m✓\x1b[0m sw.js");
  }

  // Build Tailwind CSS (v4) — invoke installed CLI binary directly. `bunx`
  // resolution misbehaves on Linux CI and lands on the wrong binary, which
  // rejects `-i` silently. Calling node_modules/.bin/tailwindcss avoids that.
  console.log("\n\x1b[33m[build]\x1b[0m Building CSS...");
  const tailwindBin = join(ROOT_DIR, "node_modules", ".bin", "tailwindcss");
  const cssProc = Bun.spawn(
    [
      tailwindBin,
      "--input",
      join(SRC_DIR, "index.css"),
      "--output",
      join(DIST_DIR, "assets", "index.css"),
      "--minify",
    ],
    {
      cwd: ROOT_DIR,
      stdout: "inherit",
      stderr: "inherit",
    }
  );
  const cssExitCode = await cssProc.exited;
  if (cssExitCode !== 0) {
    throw new Error(`Tailwind CLI failed with exit code ${cssExitCode}`);
  }

  // The Equal design-system tokens.css references self-hosted woff2 fonts via
  // `url(fonts/...)` relative to the emitted CSS. The Tailwind CLI does not
  // copy url() assets, so place the font directory next to assets/index.css.
  const eqFontsSrc = join(SRC_DIR, "equal-research-ui", "fonts");
  const eqFontsDest = join(DIST_DIR, "assets", "fonts");
  await mkdir(eqFontsDest, { recursive: true });
  for (const fontFile of await readdir(eqFontsSrc)) {
    await copyFile(join(eqFontsSrc, fontFile), join(eqFontsDest, fontFile));
  }
  console.log("  \x1b[32m✓\x1b[0m Equal design-system fonts → assets/fonts/");

  // Copy public files. A missing PUBLIC_DIR is benign (fresh clone, no
  // public assets yet); any per-file mkdir/copy failure must abort the
  // build so a half-populated dist never reaches deployment.
  console.log("\n\x1b[33m[build]\x1b[0m Copying public files...");
  let publicDirExists = false;
  try {
    const st = await stat(PUBLIC_DIR);
    publicDirExists = st.isDirectory();
  } catch (err) {
    if ((err as NodeJS.ErrnoException)?.code !== "ENOENT") throw err;
  }
  if (!publicDirExists) {
    console.log("  (no public files)");
  } else {
    const publicGlob = new Bun.Glob("**/*");
    const generatedFiles = new Set(["sw.js", "manifest.webmanifest"]);
    for await (const file of publicGlob.scan(PUBLIC_DIR)) {
      if (generatedFiles.has(file)) {
        console.log("  \x1b[33m-\x1b[0m " + file + " (generated by build)");
        continue;
      }
      const src = join(PUBLIC_DIR, file);
      const dest = join(DIST_DIR, file);
      await mkdir(join(DIST_DIR, file, ".."), { recursive: true });
      await copyFile(src, dest);
      console.log("  \x1b[32m✓\x1b[0m " + file);
    }
  }

  // Subpath awareness: BASE_PATH (e.g. "/ios-screen-time-screenshot-processing")
  // is set by the GitHub Pages workflow before invoking the build. Empty by
  // default for root-served deploys (Docker, local). The leading slash is
  // mandatory; trailing slash is stripped.
  const rawBase = (process.env.BASE_PATH || "").trim();
  const BASE_PATH = rawBase === "" || rawBase === "/" ? "" : rawBase.replace(/\/+$/, "");
  if (BASE_PATH) {
    console.log(`\x1b[33m[build]\x1b[0m BASE_PATH = ${BASE_PATH}`);
  }
  // Always emit a <base> tag. index.html references assets with relative
  // paths (./assets/...); without a base, those resolve against the current
  // URL — so a cold load of a depth-2 SPA route (e.g. /annotate/1) requests
  // /annotate/assets/... and 404s, blanking the page. A base of "/" (root
  // deploy) or "${BASE_PATH}/" pins relative asset URLs regardless of route.
  const baseHrefTag = `\n    <base href="${BASE_PATH ? `${BASE_PATH}/` : "/"}" />`;
  const prefix = (p: string) => `${BASE_PATH}${p.startsWith("/") ? p : "/" + p}`;

  // GitHub Pages cannot send headers, so the web build carries its
  // Content-Security-Policy in a <meta> tag (CSP_META=1: the Pages build and the
  // persona suites that test it). It matches the desktop policy in
  // src-tauri/tauri.conf.json minus the Tauri IPC schemes. Desktop builds
  // leave it out because Tauri sends its own policy; Docker server mode leaves
  // it out because config.js may point the API at another origin.
  const cspMeta = process.env.CSP_META === "1"
    ? `\n    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'wasm-unsafe-eval' blob:; style-src 'self' 'unsafe-inline'; font-src 'self' data:; img-src 'self' data: blob:; connect-src 'self' blob: data:; worker-src 'self' blob:; child-src 'self' blob:; manifest-src 'self'; object-src 'none'; base-uri 'self'; form-action 'none'" />`
    : "";

  // Generate index.html
  // Use relative paths (./assets/) so it works with any base path prefix
  console.log("\n\x1b[33m[build]\x1b[0m Generating index.html...");
  const html = `<!DOCTYPE html>
<html lang="en">
  <head>${baseHrefTag}
    <meta charset="UTF-8" />${cspMeta}
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Extract battery and screen-time usage data from iOS screenshots. Runs entirely in your browser — screenshots never leave your device." />
    <title>iOS Screen Time Screenshot Processor</title>
    <link rel="icon" type="image/svg+xml" href="./icons/icon.svg" />
    <link rel="stylesheet" href="./assets/index.css" />
    <link rel="manifest" href="./manifest.json" />
    <meta name="theme-color" content="#18181B" />
    <script src="./spa-redirect.js"></script>
  </head>
  <body>
    <div id="root"></div>
    <script src="./config.js"></script>
    <script type="module" src="./assets/${mainBundle}"></script>
  </body>
</html>`;

  await Bun.write(join(DIST_DIR, "index.html"), html);

  // SPA deep-link decoder for GitHub Pages (pairs with public/404.html). A cold
  // hit to a sub-route (e.g. /<base>/annotate) 404s on Pages — there is no such
  // file — so 404.html bounces it to /<base>/?/annotate. This restores the real
  // path via history.replaceState BEFORE the app module loads, so React Router
  // renders the intended route instead of falling back to Home. It no-ops for
  // normal URLs (search not starting with "/"), so it is inert on the Docker
  // deploy (whose nginx try_files already serves index.html for any path).
  // Emitted as an external same-origin script — covered by the strict CSP's
  // script-src 'self' — rather than inline, which would need a hash allow-list.
  console.log("\n\x1b[33m[build]\x1b[0m Generating spa-redirect.js (Pages deep-link decoder)...");
  await Bun.write(
    join(DIST_DIR, "spa-redirect.js"),
    `// Generated by frontend/server/build.ts. Decodes the GitHub Pages SPA\n` +
      `// redirect from 404.html (/<base>/?/<route>) back into the real path via\n` +
      `// history.replaceState, before the app module loads. No-ops otherwise.\n` +
      `(function (l) {\n` +
      `  if (l.search[1] === "/") {\n` +
      `    var decoded = l.search\n` +
      `      .slice(1)\n` +
      `      .split("&")\n` +
      `      .map(function (s) { return s.replace(/~and~/g, "&"); })\n` +
      `      .join("?");\n` +
      `    window.history.replaceState(null, null, l.pathname.slice(0, -1) + decoded + l.hash);\n` +
      `  }\n` +
      `})(window.location);\n`,
  );

  // Emit a default config.js so static hosts (GitHub Pages, plain nginx) don't
  // 404 the <script src="./config.js"> in index.html. The Docker entrypoint
  // overwrites this file with the runtime-injected API_BASE_URL when the
  // backend variant of the image is built.
  console.log("\n\x1b[33m[build]\x1b[0m Generating config.js (no-API default)...");
  await Bun.write(
    join(DIST_DIR, "config.js"),
    `// Generated by frontend/server/build.ts. Static-host default: WASM mode\n` +
      `// (no API). Docker entrypoint overwrites this when API_BASE_URL is set.\n` +
      `window.__CONFIG__ = ${JSON.stringify({ basePath: BASE_PATH })};\n`,
  );

  // Generate PWA manifest. Single source of truth for both deployments — the
  // older frontend/public/manifest.webmanifest is no longer copied into dist.
  // start_url / scope / shortcut/share/file URLs are all BASE_PATH-aware.
  console.log("\n\x1b[33m[build]\x1b[0m Generating manifest.json...");
  const manifest = {
    name: "iOS Screen Time Screenshot Processor",
    short_name: "iOS Screen Time",
    description:
      "Extract and analyze battery and screen time usage data from iOS screenshots — fully local OCR, no uploads.",
    start_url: prefix("/"),
    scope: prefix("/"),
    display: "standalone",
    background_color: "#ffffff",
    theme_color: "#18181B",
    orientation: "any",
    icons: [
      {
        src: prefix("/icons/icon.svg"),
        sizes: "any",
        type: "image/svg+xml",
        purpose: "any",
      },
      {
        src: prefix("/icons/icon-192.png"),
        sizes: "192x192",
        type: "image/png",
        purpose: "any",
      },
      {
        src: prefix("/icons/icon-512.png"),
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        src: prefix("/icons/icon-maskable-512.png"),
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
    screenshots: [
      {
        src: prefix("/screenshots/desktop-1280x720.png"),
        sizes: "1280x720",
        type: "image/png",
        form_factor: "wide",
        label: "iOS Screen Time Screenshot Processor — desktop view",
      },
      {
        src: prefix("/screenshots/mobile-750x1334.png"),
        sizes: "750x1334",
        type: "image/png",
        form_factor: "narrow",
        label: "iOS Screen Time Screenshot Processor — mobile view",
      },
    ],
    categories: ["productivity", "utilities", "tools"],
    shortcuts: [
      {
        name: "Upload Screenshots",
        short_name: "Upload",
        description: "Upload new screenshots for processing",
        url: prefix("/?action=upload"),
        icons: [
          {
            src: prefix("/icons/icon.svg"),
            sizes: "any",
            type: "image/svg+xml",
          },
        ],
      },
      {
        name: "View Gallery",
        short_name: "Gallery",
        description: "View all processed screenshots",
        url: prefix("/?action=gallery"),
        icons: [
          {
            src: prefix("/icons/icon.svg"),
            sizes: "any",
            type: "image/svg+xml",
          },
        ],
      },
    ],
    launch_handler: { client_mode: "focus-existing" },
    edge_side_panel: { preferred_width: 480 },
    prefer_related_applications: false,
  };
  await Bun.write(join(DIST_DIR, "manifest.json"), JSON.stringify(manifest, null, 2));

  // Service worker precache manifest. The SW reads this file on `install` and
  // populates its caches with every URL listed. This is what makes the app
  // work on a flight-mode reload — without it, only the bare HTML shell is
  // cached and the JS/WASM/tessdata chunks 404 when the network is gone.
  //
  // SEC-10 fix: each entry carries the SHA-256 of the file's bytes. The SW
  // verifies every precached asset against this digest before `cache.put`, so
  // a poisoned artifact (compromised CDN, MITM on first load) is rejected
  // instead of being persisted and executed across reloads. This must run
  // LAST — after every dist file (index.html, config.js, assets, pipeline-em)
  // has been written — so the hashes reflect the final bytes.
  console.log("\n\x1b[33m[build]\x1b[0m Generating sw-precache.json...");

  // Compute the hex-encoded SHA-256 of a file's bytes.
  const sha256Hex = async (filePath: string): Promise<string> => {
    const bytes = await Bun.file(filePath).bytes();
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return [...new Uint8Array(digest)]
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  };

  // A precache entry: public URL + integrity digest of the served bytes.
  interface PrecacheEntry {
    url: string;
    sha256: string;
  }

  // Strip BASE_PATH + a single leading slash from a prefixed URL to get the
  // path relative to DIST_DIR on disk.
  const distPathOf = (prefixedUrl: string): string => {
    let rel = BASE_PATH && prefixedUrl.startsWith(BASE_PATH)
      ? prefixedUrl.slice(BASE_PATH.length)
      : prefixedUrl;
    rel = rel.replace(/^\/+/, "");
    return join(DIST_DIR, rel);
  };

  // Build a hashed entry for a prefixed URL backed by a real dist file.
  // sourceOverride lets a virtual URL (e.g. "/") hash a concrete file.
  const hashedEntry = async (
    prefixedUrl: string,
    sourceOverride?: string,
  ): Promise<PrecacheEntry> => ({
    url: prefixedUrl,
    sha256: await sha256Hex(sourceOverride ?? distPathOf(prefixedUrl)),
  });

  const assetGlob = new Bun.Glob("**/*");
  const assetEntries: PrecacheEntry[] = [];
  for await (const file of assetGlob.scan(join(DIST_DIR, "assets"))) {
    if (file.endsWith(".map")) continue;
    // PHI-enabled desktop builds load this large worker on demand rather than
    // making it part of the application-shell install.
    if (enablePhiWorker && /^nerWorker-[A-Za-z0-9]+\.js$/.test(file)) continue;
    assetEntries.push(await hashedEntry(prefix(`/assets/${file}`)));
  }

  const pipelineEmEntries: PrecacheEntry[] = [];
  const pipelineEmDir = join(DIST_DIR, "pipeline-em");
  try {
    for await (const file of assetGlob.scan(pipelineEmDir)) {
      pipelineEmEntries.push(await hashedEntry(prefix(`/pipeline-em/${file}`)));
    }
  } catch {
    // pipeline-em not present (build script wasn't run yet) — SW will still
    // work, but the WASM pipeline won't load offline. Surface a warning.
    console.log(
      "  \x1b[31m✗\x1b[0m pipeline-em/ missing — run scripts/build-wasm-emscripten.sh first",
    );
  }

  // Stamp the ABI-coupled pipeline assets (glue + wasm + its integrity sidecar)
  // with the wasm content hash so each precache cache-key matches the loader's
  // stamped fetch URL (`?v=<hash>`). The sha256 stays computed from the bare
  // file bytes (the query is server-ignored) — only the cache key changes.
  // eng.traineddata is ABI-independent and large → left bare so a wasm change
  // doesn't force it to re-download.
  if (pipelineWasmHash) {
    for (const entry of pipelineEmEntries) {
      if (
        entry.url.endsWith("IosScreenTimePipeline.js") ||
        entry.url.endsWith("IosScreenTimePipeline.wasm") ||
        entry.url.endsWith("IosScreenTimePipeline.js.sha256")
      ) {
        entry.url += `?v=${pipelineWasmHash}`;
      }
    }
  }

  // Shell URLs: most map 1:1 to a dist file. The bare "/" route has no file
  // of its own — it is served by index.html, so hash index.html's bytes.
  const indexHtmlPath = join(DIST_DIR, "index.html");
  const shellEntries: PrecacheEntry[] = [
    await hashedEntry(prefix("/"), indexHtmlPath),
    await hashedEntry(prefix("/index.html")),
    await hashedEntry(prefix("/spa-redirect.js")),
    await hashedEntry(prefix("/manifest.json")),
    await hashedEntry(prefix("/config.js")),
    await hashedEntry(prefix("/offline.html")),
  ];

  const precache = {
    // version 3: entries changed from string[] to {url, sha256}[] for SEC-10
    // integrity verification. The SW rejects manifests it cannot parse.
    version: 3,
    basePath: BASE_PATH,
    shellAssets: shellEntries,
    appAssets: assetEntries,
    pipelineAssets: pipelineEmEntries,
  };
  await Bun.write(
    join(DIST_DIR, "sw-precache.json"),
    JSON.stringify(precache, null, 2),
  );
  console.log(
    `  \x1b[32m✓\x1b[0m sw-precache.json (${
      precache.shellAssets.length + precache.appAssets.length + precache.pipelineAssets.length
    } urls, sha256-verified)`,
  );

  const elapsed = ((performance.now() - startTime) / 1000).toFixed(2);
  console.log("\n\x1b[32m[build]\x1b[0m Build completed in " + elapsed + "s");
  console.log("\x1b[32m[build]\x1b[0m Output: " + DIST_DIR);
  console.log("\n\x1b[32m[build]\x1b[0m Service worker included at sw.js");
}

build();
