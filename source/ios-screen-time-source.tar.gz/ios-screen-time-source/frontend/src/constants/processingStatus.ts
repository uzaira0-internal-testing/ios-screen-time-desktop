/**
 * Processing statuses shown as filter buttons in the preprocessing UI.
 * This is a SUBSET of the full ProcessingStatus type from types/index.ts.
 * "processing" and "deleted" are excluded because they are transient/hidden states.
 */

export const FILTER_STATUSES = ['pending', 'completed', 'failed', 'skipped'] as const;

export type FilterStatus = typeof FILTER_STATUSES[number];

/**
 * Human-readable labels for filter statuses
 */
export const FILTER_STATUS_LABELS: Record<FilterStatus, string> = {
  pending: 'Pending',
  completed: 'Preprocessed',
  failed: 'Failed',
  skipped: 'Skipped',
};
