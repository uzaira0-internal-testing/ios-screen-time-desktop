export const FolderStructureHint = () => (
  <>
    <div className="text-xs text-eq-muted font-mono bg-eq-surface-muted rounded-eq-sm px-3 py-2 inline-block">
      <div className="text-left">
        <div>study_folder/</div>
        <div className="ml-4">participant_id/</div>
        <div className="ml-8">date_folder/</div>
        <div className="ml-12">screenshot.png</div>
      </div>
    </div>
    <p className="text-xs text-eq-muted">
      Date folders: 2024-01-15, 01.15.2024, Day_1_01.02.2025, etc.
    </p>
  </>
);
