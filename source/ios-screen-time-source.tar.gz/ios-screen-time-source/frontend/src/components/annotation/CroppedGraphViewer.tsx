import { useRef, useEffect, useState } from "react";
import type { GridCoordinates } from "@/types";
import { loadImage } from "@/utils/imageUtils";

interface CroppedGraphViewerProps {
  imageUrl: string;
  gridCoords: GridCoordinates | null;
  targetWidth?: number;
}

export const CroppedGraphViewer = ({
  imageUrl,
  gridCoords,
  targetWidth = 800,
}: CroppedGraphViewerProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  // Track which imageUrl the error belongs to; a different imageUrl implicitly
  // clears the error without an effect-driven setState.
  const [errorForUrl, setErrorForUrl] = useState<string | null>(null);
  const error = errorForUrl !== null && errorForUrl === imageUrl;

  useEffect(() => {
    if (!gridCoords || gridCoords.upper_left.x === 0 || !imageUrl) {
      return;
    }

    let cancelled = false;
    const loadAndCropImage = async () => {
      try {
        const img = await loadImage(imageUrl);
        if (cancelled) return;
        const canvas = canvasRef.current;
        const container = containerRef.current;
        if (!canvas || !container) return;

        const cropX = gridCoords.upper_left.x;
        const cropY = gridCoords.upper_left.y;
        const cropWidth = gridCoords.lower_right.x - gridCoords.upper_left.x;
        const cropHeight = gridCoords.lower_right.y - gridCoords.upper_left.y;

        if (cropWidth <= 0 || cropHeight <= 0) return;

        // Fixed height for consistency
        const graphHeight = 200;
        const containerWidth = container.clientWidth || targetWidth;

        canvas.width = containerWidth;
        canvas.height = graphHeight;

        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(
            img,
            cropX,
            cropY,
            cropWidth,
            cropHeight,
            0,
            0,
            containerWidth,
            graphHeight,
          );
        }
      } catch (err) {
        if (cancelled) return;
        console.error("Failed to load cropped image:", err);
        setErrorForUrl(imageUrl);
      }
    };

    void loadAndCropImage();
    return () => {
      cancelled = true;
    };
  }, [imageUrl, gridCoords, targetWidth]);

  if (!gridCoords || gridCoords.upper_left.x === 0) {
    return (
      <div
        className="bg-eq-surface-muted rounded-eq-sm flex items-center justify-center text-eq-muted text-sm border border-dashed border-eq-border"
        style={{ height: 200 }}
      >
        Select grid corners to see cropped graph
      </div>
    );
  }

  if (error) {
    return (
      <div
        className="bg-eq-surface-muted rounded-eq-sm flex items-center justify-center text-eq-danger text-sm border border-dashed border-eq-danger"
        style={{ height: 200 }}
      >
        Failed to load image
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      role="img"
      aria-label="Cropped view of the usage graph from screenshot"
      className="w-full overflow-hidden"
      style={{ height: 200 }}
    >
      <canvas
        ref={canvasRef}
        aria-hidden="true"
        className="block w-full h-full rounded-eq-sm object-cover"
      />
    </div>
  );
};
