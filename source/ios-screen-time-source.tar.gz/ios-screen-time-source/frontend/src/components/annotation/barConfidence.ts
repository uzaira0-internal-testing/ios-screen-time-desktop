/**
 * Per-bar review hints for the 24 hourly values.
 *
 * This is deliberately NOT a black-box "confidence score". It surfaces two
 * independent, explainable signals so the reviewer's eye goes straight to the
 * bars worth a second look — and every flag carries a plain-English reason:
 *
 *   1. Value sanity (always available): a value above the 60-minute ceiling is
 *      impossible (a single hour can't hold more than 60 minutes of usage).
 *      A value sitting AT 60 is NOT flagged — a full hour of usage is normal.
 *   2. Pixel-vs-value disagreement (when a measured fill ratio is provided):
 *      the visible bar height is measured straight off the cropped graph (by
 *      the Rust pipeline, `IProcessingService.measureColumnFills`) and
 *      compared to the stored value. Only GROSS mismatches are flagged, so a
 *      few pixels of rounding never cry wolf — and a tall bar sitting on a
 *      stored 0 (a missed bar) lights up immediately.
 */

export type BarLevel = "ok" | "check" | "risk";

export interface BarConfidence {
  level: BarLevel;
  /** Human-readable explanation, or null when the bar looks fine. */
  reason: string | null;
}

const CEILING = 60;

function fmt(v: number): string {
  const r = Math.round(v * 10) / 10;
  return r % 1 === 0 ? String(Math.round(r)) : String(r);
}

/**
 * `measuredRatio` is the fraction (0..1) of the column filled by the bar, or
 * null when it could not be measured (then only the value checks apply).
 */
export function barConfidence(
  value: number,
  measuredRatio: number | null,
  axisMaximumMinutes = CEILING,
): BarConfidence {
  if (value > CEILING) {
    return { level: "risk", reason: `Value ${fmt(value)}m is above the 60-minute maximum` };
  }

  if (measuredRatio != null && Number.isFinite(measuredRatio)) {
    const safeAxisMaximum = Number.isFinite(axisMaximumMinutes) && axisMaximumMinutes > 0
      ? axisMaximumMinutes
      : CEILING;
    const measured = measuredRatio * safeAxisMaximum;
    const diff = Math.abs(measured - value);
    if (diff > 12) {
      return { level: "risk", reason: `Bar looks like ~${Math.round(measured)}m but the value is ${fmt(value)}m` };
    }
    if (diff > 7) {
      return { level: "check", reason: `Bar height (~${Math.round(measured)}m) doesn't match the value ${fmt(value)}m` };
    }
  }

  return { level: "ok", reason: null };
}
