interface DuplicateWarningProps {
  duplicateId: number;
  duplicateStatus?: string | null;
  onSkipThis: () => void;
  onGoToDuplicate: () => void;
  isLoading?: boolean;
}

export const DuplicateWarning = ({
  duplicateId,
  duplicateStatus,
  onSkipThis,
  onGoToDuplicate,
  isLoading = false,
}: DuplicateWarningProps) => {
  const isResolved = duplicateStatus === "skipped";

  if (isResolved) {
    return (
      <div className="bg-eq-success-bg border-l-4 border-eq-success p-3 rounded-eq-md">
        <div className="flex items-start gap-2">
          <span className="w-5 h-5 rounded-full bg-eq-success text-eq-primary-ink text-xs flex items-center justify-center font-bold flex-shrink-0 mt-0.5">
            ✓
          </span>
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-semibold text-eq-success">
              Duplicate Resolved
            </h4>
            <p className="mt-1 text-sm text-eq-success">
              The duplicate screenshot <span className="font-mono font-semibold">#{duplicateId}</span> was
              already skipped. This screenshot is the one to annotate.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-eq-warning-bg border-l-4 border-eq-warning p-3 rounded-eq-md">
      <div className="flex items-start gap-2">
        <span className="w-5 h-5 rounded-full bg-eq-warning text-eq-primary-ink text-xs flex items-center justify-center font-bold flex-shrink-0 mt-0.5">
          !
        </span>
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-semibold text-eq-warning">
            Potential Duplicate Detected
          </h4>
          <p className="mt-1 text-sm text-eq-warning">
            Screenshot <span className="font-mono font-semibold">#{duplicateId}</span> has
            the same participant, date, app title, and total usage. You may want
            to skip one of them.
          </p>
          <div className="mt-2 flex gap-2 flex-wrap">
            <button
              onClick={onSkipThis}
              disabled={isLoading}
              className="px-3 py-1 text-xs font-medium bg-eq-warning text-eq-primary-ink rounded-eq-sm hover:bg-eq-warning disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Skip This One
            </button>
            <button
              onClick={onGoToDuplicate}
              disabled={isLoading}
              className="px-3 py-1 text-xs font-medium bg-eq-surface text-eq-warning border border-eq-warning rounded-eq-sm hover:bg-eq-warning-bg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Go to #{duplicateId}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
