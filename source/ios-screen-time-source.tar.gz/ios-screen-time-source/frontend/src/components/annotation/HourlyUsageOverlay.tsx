import { memo, useRef, useEffect, useState, useCallback } from "react";
import type { HourlyData, Consensus, GridCoordinates } from "@/types";
import { loadImage } from "@/utils/imageUtils";
import { barConfidence } from "./barConfidence";
import { useProcessingService } from "@/core/hooks/useServices";
import clsx from "clsx";
import { MAX_REVIEW_HOURLY_MINUTES } from "@/utils/dataQuality";

interface HourlyUsageOverlayProps {
  data: HourlyData;
  onChange: (hour: number, value: number) => void;
  imageUrl: string;
  gridCoords: GridCoordinates | null;
  consensus?: Consensus;
  readOnly?: boolean;
  axisMaximumMinutes?: number | null;
}

const HourlyUsageOverlayInner = ({
  data,
  onChange,
  imageUrl,
  gridCoords,
  consensus,
  readOnly = false,
  axisMaximumMinutes = null,
}: HourlyUsageOverlayProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [canvasReady, setCanvasReady] = useState(false);
  // Per-bar fill ratios measured off the cropped graph (review-hint heatmap).
  // Depends only on the image + grid, NOT on the editable values, so typing a
  // correction never re-runs the pixel pass.
  const [columnFills, setColumnFills] = useState<(number | null)[] | null>(null);
  const containerWidthRef = useRef(800);
  const loadedImageRef = useRef<HTMLImageElement | null>(null);
  // Keep latest gridCoords accessible to ResizeObserver / RAF callbacks without
  // tearing down the observer on every prop change. The assignment lives in an
  // effect so the ref is never written during render.
  const gridCoordsRef = useRef(gridCoords);
  useEffect(() => {
    gridCoordsRef.current = gridCoords;
  }, [gridCoords]);
  const rafRef = useRef<number | null>(null);
  // Stable boolean — only changes when gridCoords validity changes, not on every reference change
  const hasValidGrid = !!(gridCoords && gridCoords.upper_left.x !== 0);

  // Redraw canvas from cached image (stable — reads everything from refs)
  const redrawCanvas = useCallback(() => {
    const img = loadedImageRef.current;
    const canvas = canvasRef.current;
    const gc = gridCoordsRef.current;
    if (!img || !canvas || !gc || gc.upper_left.x === 0) return;

    const cropX = gc.upper_left.x;
    const cropY = gc.upper_left.y;
    const cropWidth = gc.lower_right.x - gc.upper_left.x;
    const cropHeight = gc.lower_right.y - gc.upper_left.y;
    if (cropWidth <= 0 || cropHeight <= 0) return;

    const graphHeight = 200;
    const targetWidth = containerWidthRef.current;
    canvas.width = targetWidth;
    canvas.height = graphHeight;

    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.drawImage(img, cropX, cropY, cropWidth, cropHeight, 0, 0, targetWidth, graphHeight);
    }
  }, []);

  // Handle resize — RAF-coalesced redraw, no image reload
  useEffect(() => {
    if (!containerRef.current) return;

    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        containerWidthRef.current = entry.contentRect.width;
      }
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      rafRef.current = requestAnimationFrame(() => {
        rafRef.current = null;
        redrawCanvas();
      });
    });

    observer.observe(containerRef.current);
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      observer.disconnect();
    };
  }, [redrawCanvas]);

  // Redraw when grid coords change (user drags grid on left panel)
  useEffect(() => {
    if (loadedImageRef.current && hasValidGrid) {
      redrawCanvas();
    }
  }, [gridCoords, hasValidGrid, redrawCanvas]);

  // Reset canvasReady when the load request becomes invalid (no grid, no URL).
  // Done via React's "adjusting state when a prop changes" pattern so the
  // loader effect below stays free of synchronous setState calls.
  const loadRequestKey = hasValidGrid && imageUrl ? imageUrl : null;
  const [prevLoadRequestKey, setPrevLoadRequestKey] = useState<string | null>(loadRequestKey);
  if (loadRequestKey !== prevLoadRequestKey) {
    setPrevLoadRequestKey(loadRequestKey);
    if (loadRequestKey === null) {
      setCanvasReady(false);
    }
  }

  // Load image when imageUrl changes or grid becomes valid.
  // hasValidGrid is a primitive boolean so it won't trigger on unstable object refs.
  useEffect(() => {
    let isMounted = true;

    if (!hasValidGrid || !imageUrl) {
      return;
    }

    const loadAndCropImage = async () => {
      try {
        const img = await loadImage(imageUrl);
        if (!isMounted) return;
        loadedImageRef.current = img;
        redrawCanvas();
        setCanvasReady(true);
      } catch (err) {
        console.error("Failed to load cropped image:", err);
        if (isMounted) {
          setCanvasReady(false);
        }
      }
    };

    void loadAndCropImage();

    return () => {
      isMounted = false;
      loadedImageRef.current = null;
    };
  }, [imageUrl, hasValidGrid, redrawCanvas]);

  // Measure per-bar fill ratios once the image is ready. Re-runs only when the
  // image or the grid changes — value edits don't touch the pixels. The Rust
  // pipeline measures in a worker so every browser engine reads the same
  // heights. A dragged grid settles before it is measured, and a result for a
  // grid that has since moved is dropped. Without a processing service (server
  // mode) only the value checks apply.
  const processing = useProcessingService();
  const imageBlobRef = useRef<{ url: string; blob: Promise<Blob> } | null>(null);
  useEffect(() => {
    let current = true;
    const timer = setTimeout(() => {
      if (!processing || !canvasReady || !hasValidGrid || !gridCoords) {
        setColumnFills(null);
        return;
      }
      if (imageBlobRef.current?.url !== imageUrl) {
        imageBlobRef.current = {
          url: imageUrl,
          blob: fetch(imageUrl).then((res) => {
            if (!res.ok) throw new Error(`Image fetch failed: ${res.status}`);
            return res.blob();
          }),
        };
      }
      void imageBlobRef.current.blob
        .then((blob) => processing.measureColumnFills(blob, gridCoords))
        .then(
          (fills) => {
            if (current) setColumnFills(fills);
          },
          (err: unknown) => {
            console.warn("Bar fill measurement failed:", err);
            if (imageBlobRef.current?.url === imageUrl) imageBlobRef.current = null;
            if (current) setColumnFills(null);
          },
        );
    }, 120);
    return () => {
      current = false;
      clearTimeout(timer);
    };
  }, [canvasReady, gridCoords, hasValidGrid, imageUrl, processing]);

  const handleChange = (hour: number, delta: number) => {
    const currentValue = data[hour] || 0;
    const newValue = Math.max(0, Math.min(MAX_REVIEW_HOURLY_MINUTES, currentValue + delta));
    onChange(hour, newValue);
  };

  const handleInputChange = (hour: number, value: string) => {
    // Preserve invalid aggregated-device evidence up to the API's review bound.
    const numValue = Math.max(0, Math.min(MAX_REVIEW_HOURLY_MINUTES, parseFloat(value) || 0));
    // Round to 2 decimal places to avoid floating point issues
    onChange(hour, Math.round(numValue * 100) / 100);
  };

  // Format value for display: show decimal only if meaningful
  const formatValue = (val: number): string => {
    const rounded = Math.round(val * 10) / 10;
    return rounded % 1 === 0 ? String(Math.round(rounded)) : String(rounded);
  };

  const getDisagreementLevel = (
    hour: number,
  ): "none" | "minor" | "major" | null => {
    if (!consensus) return null;
    const disagreement = consensus.disagreements.find((d) => d.hour === hour);
    if (!disagreement) return "none";
    const currentValue = data[hour] || 0;
    const diff = Math.abs(currentValue - disagreement.consensus_value);
    if (diff === 0) return "none";
    if (diff <= 5) return "minor";
    return "major";
  };

  const getCellClassName = (hour: number) => {
    const level = getDisagreementLevel(hour);
    return clsx(
      "w-full text-center text-[10px] font-medium border rounded-eq-md focus:outline-none focus:ring-2 transition-all py-0.5",
      {
        "bg-eq-success-bg border-eq-success text-eq-success": level === "none",
        "bg-eq-warning-bg border-eq-warning text-eq-warning": level === "minor",
        "bg-eq-danger-bg border-eq-danger text-eq-danger": level === "major",
        "bg-eq-surface border-eq-border text-eq-ink focus:ring-eq-focus focus:border-eq-primary":
          level === null,
        "bg-eq-surface-muted text-eq-muted cursor-not-allowed": readOnly,
      },
    );
  };

  const graphHeight = 200;
  const maxObservedMinutes = Math.max(
    ...Array.from({ length: 24 }, (_, hour) => data[hour] || 0),
  );
  const detectedChartMaximum =
    axisMaximumMinutes !== null && Number.isFinite(axisMaximumMinutes) && axisMaximumMinutes > 60
      ? Math.min(MAX_REVIEW_HOURLY_MINUTES, axisMaximumMinutes)
      : null;
  const chartMaximum = Math.max(60, maxObservedMinutes, detectedChartMaximum ?? 0);

  return (
    <div className="w-full" ref={containerRef} data-testid="hourly-editor">
      {/* Graph Area with Overlay */}
      <div
        className="relative bg-eq-surface rounded-eq-md overflow-hidden border border-eq-border"
        style={{ height: graphHeight }}
        role="img"
        aria-label="Cropped screenshot showing hourly usage graph with editable bar overlays"
      >
        {/* Background: Cropped screenshot */}
        <canvas
          ref={canvasRef}
          aria-hidden="true"
          className={`absolute inset-0 w-full h-full transition-opacity duration-300 ${
            hasValidGrid && canvasReady ? "opacity-60" : "opacity-0"
          }`}
        />

        {(!hasValidGrid || !canvasReady) && (
          <div className="absolute inset-0 w-full h-full bg-eq-surface-muted flex items-center justify-center text-eq-muted text-sm">
            {hasValidGrid ? "Loading..." : "Select grid area to view overlay"}
          </div>
        )}

        {/* Overlay: Hourly bars grid - EXACTLY 24 columns */}
        <div
          className="absolute inset-0 w-full h-full grid"
          style={{
            gridTemplateColumns: "repeat(24, 1fr)",
          }}
        >
          {Array.from({ length: 24 }, (_, i) => {
            const value = data[i] || 0;
            const heightPercentage = (value / chartMaximum) * 100;
            const conf = barConfidence(
              value,
              columnFills ? (columnFills[i] ?? null) : null,
              chartMaximum,
            );
            const barColor =
              conf.level === "risk"
                ? "bg-eq-danger"
                : conf.level === "check"
                  ? "bg-eq-warning"
                  : "bg-eq-chart-bar";

            return (
              <div
                key={i}
                className="flex flex-col h-full justify-end items-center"
                title={conf.reason ?? undefined}
              >
                {value > 0 ? (
                  <div
                    className={`w-4/5 ${barColor} opacity-70 transition-all duration-300 hover:opacity-90 rounded-t-md`}
                    style={{
                      height: `${heightPercentage}%`,
                      minHeight: "2px",
                    }}
                  />
                ) : conf.level !== "ok" ? (
                  // Stored value is 0 but a flag fired (e.g. the pixels show a
                  // bar here) — draw a thin marker so a missed bar is visible.
                  <div
                    className={`w-4/5 ${barColor} opacity-60 rounded-t-md`}
                    style={{ height: "5px" }}
                  />
                ) : null}
              </div>
            );
          })}
        </div>
      </div>

      {detectedChartMaximum !== null && (
        <div className="mt-1.5 text-[10px] text-eq-warning">
          Detected chart scale: {detectedChartMaximum} minutes
        </div>
      )}

      {/* Review-hint legend — only when at least one bar is flagged */}
      {(() => {
        const flagged = Array.from({ length: 24 }, (_, i) =>
          barConfidence(
            data[i] || 0,
            columnFills ? (columnFills[i] ?? null) : null,
            chartMaximum,
          ),
        ).filter((c) => c.level !== "ok").length;
        if (flagged === 0) return null;
        return (
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1.5 text-[10px] text-eq-muted">
            <span className="font-semibold text-eq-ink">
              {flagged} bar{flagged !== 1 ? "s" : ""} to review
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm bg-eq-warning inline-block" aria-hidden="true" /> check
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm bg-eq-danger inline-block" aria-hidden="true" /> likely error
            </span>
            <span className="opacity-70">hover a bar for the reason</span>
          </div>
        );
      })()}

      {/* Controls - EXACTLY 24 columns to match the graph above */}
      <div
        className="w-full grid gap-2 mt-4"
        style={{ gridTemplateColumns: "repeat(24, 1fr)" }}
      >
        {Array.from({ length: 24 }, (_, i) => {
          const value = data[i] || 0;

          return (
            <div key={i} className="flex flex-col items-center gap-1">
              {/* X-Axis Label */}
              <div className="text-[10px] text-eq-muted font-semibold text-center">
                {i}h
              </div>

              <button
                type="button"
                onClick={() => handleChange(i, 1)}
                disabled={readOnly}
                className="w-full h-5 flex items-center justify-center text-[10px] bg-eq-surface-muted hover:bg-eq-surface-muted hover:text-eq-primary rounded-eq-sm text-eq-muted disabled:opacity-50 transition-colors"
              >
                ▲
              </button>
              <input
                type="text"
                inputMode="decimal"
                pattern="[0-9]*\.?[0-9]*"
                value={formatValue(value)}
                onChange={(e) => handleInputChange(i, e.target.value)}
                disabled={readOnly}
                aria-label={`Usage for hour ${i === 0 ? "12 AM" : i < 12 ? `${i} AM` : i === 12 ? "12 PM" : `${i - 12} PM`}`}
                className={getCellClassName(i)}
                style={{ appearance: "textfield" }}
                data-testid={`hour-input-${i}`}
              />
              <button
                type="button"
                onClick={() => handleChange(i, -1)}
                disabled={readOnly}
                className="w-full h-5 flex items-center justify-center text-[10px] bg-eq-surface-muted hover:bg-eq-surface-muted hover:text-eq-primary rounded-eq-sm text-eq-muted disabled:opacity-50 transition-colors"
              >
                ▼
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

/** Memoized export — the workspace passes stable hourlyValues / gridCoords
 *  references via useMemo / nullish-coalesce, so React.memo's default
 *  shallow prop comparison is sufficient. Skip-rendering this is the
 *  single biggest navigation-perf win in the workspace because it owns
 *  the canvas redraw + image-load cycle. */
export const HourlyUsageOverlay = memo(HourlyUsageOverlayInner);
