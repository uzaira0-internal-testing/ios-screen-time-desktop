import { useRef, useEffect, useState, useCallback } from "react";
import { AlertTriangle } from "lucide-react";
import type { GridCoordinates } from "@/types";
import { loadImage } from "@/utils/imageUtils";

interface GridSelectorProps {
  imageUrl: string;
  onGridSelect: (coords: GridCoordinates) => void;
  initialCoords?: GridCoordinates | undefined;
  disabled?: boolean | undefined;
  // Screenshot info
  imageType?: string | undefined;
  extractedTitle?: string | null | undefined;
  onTitleChange?: ((title: string) => void) | undefined;
}

type DragMode =
  | "none"
  | "upper_left"
  | "upper_right"
  | "lower_left"
  | "lower_right"
  | "move"
  | "creating";

export const GridSelector = ({
  imageUrl,
  onGridSelect,
  initialCoords,
  disabled = false,
  imageType,
  extractedTitle,
  onTitleChange,
}: GridSelectorProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [upperLeft, setUpperLeft] = useState<{ x: number; y: number } | null>(
    initialCoords?.upper_left || null
  );
  const [lowerRight, setLowerRight] = useState<{ x: number; y: number } | null>(
    initialCoords?.lower_right || null
  );
  // Latest-coord refs so the image-load and resize effects can redraw with the
  // current selection without listing upperLeft/lowerRight as deps (which would
  // reload the image on every drag tick). Updated in an effect (not during
  // render) per the react-hooks/refs rule.
  const upperLeftRef = useRef(upperLeft);
  const lowerRightRef = useRef(lowerRight);
  useEffect(() => {
    upperLeftRef.current = upperLeft;
    lowerRightRef.current = lowerRight;
  }, [upperLeft, lowerRight]);
  // scale and cropOffset are only consumed inside event handlers, never during
  // render, so they live in refs instead of state — keeps setState out of the
  // canvas redraw effect.
  const scaleRef = useRef(1);
  const cropOffsetRef = useRef(0);
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [dragMode, setDragMode] = useState<DragMode>("none");
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(
    null,
  );
  const previousImageUrl = useRef<string>("");
  const onGridSelectRef = useRef(onGridSelect);

  // Keep ref up to date
  useEffect(() => {
    onGridSelectRef.current = onGridSelect;
  }, [onGridSelect]);

  // Handle initialCoords identity changes (when a new screenshot is loaded).
  // Following React's "adjusting state when a prop changes" pattern: compare
  // the prior prop during render and dispatch the setState calls inline. React
  // discards the in-progress render and starts over with the new state, so no
  // intermediate frame is shown.
  const [prevInitialCoords, setPrevInitialCoords] = useState(initialCoords);
  if (initialCoords !== prevInitialCoords) {
    setPrevInitialCoords(initialCoords);
    if (initialCoords?.upper_left) setUpperLeft(initialCoords.upper_left);
    if (initialCoords?.lower_right) setLowerRight(initialCoords.lower_right);
  }

  // Helper functions for canvas drawing (defined before redrawCanvas)
  const drawHandle = useCallback(
    (
      ctx: CanvasRenderingContext2D,
      x: number,
      y: number,
      size: number,
      color: string
    ) => {
      ctx.fillStyle = color;
      ctx.fillRect(x - size / 2, y - size / 2, size, size);
      ctx.strokeStyle = "white";
      ctx.lineWidth = 1;
      ctx.strokeRect(x - size / 2, y - size / 2, size, size);
    },
    []
  );

  const redrawCanvas = useCallback(
    (
      img: HTMLImageElement,
      ul: { x: number; y: number } | null,
      lr: { x: number; y: number } | null
    ) => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;

      const containerWidth = container.clientWidth || 800;
      // Always show the WHOLE screenshot (no crop), scaled to fit the width and
      // capped at the viewport height so a tall image doesn't overflow. The grid
      // handles work anywhere on the full image, including daily-total / full-page
      // screenshots whose content runs past the midpoint.
      const sourceHeight = img.naturalHeight;
      const cropY = 0;

      let imageScale = containerWidth / img.naturalWidth;
      const maxH = window.innerHeight * 0.72;
      imageScale = Math.min(imageScale, maxH / sourceHeight);
      const displayWidth = Math.round(img.naturalWidth * imageScale);
      const displayHeight = Math.round(sourceHeight * imageScale);

      canvas.width = displayWidth;
      canvas.height = displayHeight;
      scaleRef.current = imageScale;
      cropOffsetRef.current = cropY;

      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      ctx.drawImage(
        img,
        0,
        cropY,
        img.naturalWidth,
        sourceHeight,
        0,
        0,
        displayWidth,
        displayHeight
      );

      if (ul && lr) {
        const scaledUL = {
          x: ul.x * imageScale,
          y: (ul.y - cropY) * imageScale,
        };
        const scaledLR = {
          x: lr.x * imageScale,
          y: (lr.y - cropY) * imageScale,
        };

        // Selection fill
        ctx.fillStyle = "rgba(59, 130, 246, 0.1)";
        ctx.fillRect(
          scaledUL.x,
          scaledUL.y,
          scaledLR.x - scaledUL.x,
          scaledLR.y - scaledUL.y
        );

        // Selection border
        ctx.strokeStyle = "#2563EB";
        ctx.lineWidth = 2;
        ctx.strokeRect(
          scaledUL.x,
          scaledUL.y,
          scaledLR.x - scaledUL.x,
          scaledLR.y - scaledUL.y
        );

        // Corner handles
        const handleSize = 6;
        drawHandle(ctx, scaledUL.x, scaledUL.y, handleSize, "#10B981");
        drawHandle(ctx, scaledLR.x, scaledUL.y, handleSize, "#F59E0B");
        drawHandle(ctx, scaledUL.x, scaledLR.y, handleSize, "#F59E0B");
        drawHandle(ctx, scaledLR.x, scaledLR.y, handleSize, "#EF4444");
      }
    },
    [drawHandle]
  );

  useEffect(() => {
    if (!imageUrl) return;
    let cancelled = false;
    const loadAndDrawImage = async () => {
      try {
        const img = await loadImage(imageUrl);
        // Guard against out-of-order resolution: a slow load for a previous
        // screenshot must not overwrite the canvas after the user navigated on.
        if (cancelled) return;
        setImage(img);
        previousImageUrl.current = imageUrl;
        redrawCanvas(img, upperLeftRef.current, lowerRightRef.current);
      } catch (error) {
        if (!cancelled) console.error("Failed to load image:", error);
      }
    };
    void loadAndDrawImage();
    return () => { cancelled = true; };
    // upperLeft/lowerRight intentionally excluded (read via refs) — the effect
    // below redraws on coord changes; including them here forced a full image
    // reload per drag tick.
  }, [imageUrl, redrawCanvas]);

  // Redraw when state changes (redrawCanvas updates scale/cropOffset internally)

  useEffect(() => {
    if (image) {
      redrawCanvas(image, upperLeft, lowerRight);
    }
  }, [upperLeft, lowerRight, image, redrawCanvas]);

  // Recompute the canvas scale on viewport resize. redrawCanvas caps height at
  // 0.72×innerHeight; without this the canvas (and its hit-test scale) goes
  // stale on window resize / tablet rotation, so clicks land off-target.
  useEffect(() => {
    if (!image) return;
    const onResize = () => redrawCanvas(image, upperLeftRef.current, lowerRightRef.current);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [image, redrawCanvas]);

  const getMousePos = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / scaleRef.current;
    const y = (e.clientY - rect.top) / scaleRef.current + cropOffsetRef.current;
    return { x: Math.round(x), y: Math.round(y) };
  };

  const hitTest = (pos: { x: number; y: number }): DragMode => {
    if (!upperLeft || !lowerRight) return "none";

    const threshold = 10 / scaleRef.current;
    const ul = upperLeft;
    const lr = lowerRight;

    // Check corners first
    if (
      Math.abs(pos.x - ul.x) < threshold &&
      Math.abs(pos.y - ul.y) < threshold
    )
      return "upper_left";
    if (
      Math.abs(pos.x - lr.x) < threshold &&
      Math.abs(pos.y - ul.y) < threshold
    )
      return "upper_right";
    if (
      Math.abs(pos.x - ul.x) < threshold &&
      Math.abs(pos.y - lr.y) < threshold
    )
      return "lower_left";
    if (
      Math.abs(pos.x - lr.x) < threshold &&
      Math.abs(pos.y - lr.y) < threshold
    )
      return "lower_right";

    // Check if inside selection
    if (pos.x >= ul.x && pos.x <= lr.x && pos.y >= ul.y && pos.y <= lr.y)
      return "move";

    return "none";
  };

  const getCursor = (mode: DragMode): string => {
    switch (mode) {
      case "upper_left":
      case "lower_right":
        return "nwse-resize";
      case "upper_right":
      case "lower_left":
        return "nesw-resize";
      case "move":
        return "move";
      default:
        return "crosshair";
    }
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (disabled) return;

    const pos = getMousePos(e);
    if (!pos) return;

    const mode = hitTest(pos);

    if (mode !== "none") {
      setDragMode(mode);
      setDragStart(pos);
    } else {
      // Clicked outside - start new selection
      setUpperLeft(pos);
      setLowerRight(pos);
      setDragMode("creating");
      setDragStart(pos);
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const pos = getMousePos(e);
    if (!pos) return;

    // Update cursor
    const canvas = canvasRef.current;
    if (canvas) {
      if (disabled) {
        canvas.style.cursor = "not-allowed";
      } else if (dragMode !== "none") {
        canvas.style.cursor = getCursor(dragMode);
      } else {
        canvas.style.cursor = getCursor(hitTest(pos));
      }
    }

    if (disabled || dragMode === "none" || !dragStart) return;

    if (dragMode === "creating") {
      setLowerRight(pos);
    } else if (dragMode === "move" && upperLeft && lowerRight) {
      const dx = pos.x - dragStart.x;
      const dy = pos.y - dragStart.y;
      setUpperLeft({ x: upperLeft.x + dx, y: upperLeft.y + dy });
      setLowerRight({ x: lowerRight.x + dx, y: lowerRight.y + dy });
      setDragStart(pos);
    } else if (upperLeft && lowerRight) {
      // Resize handles
      let newUL = { ...upperLeft };
      let newLR = { ...lowerRight };

      switch (dragMode) {
        case "upper_left":
          newUL = pos;
          break;
        case "upper_right":
          newUL.y = pos.y;
          newLR.x = pos.x;
          break;
        case "lower_left":
          newUL.x = pos.x;
          newLR.y = pos.y;
          break;
        case "lower_right":
          newLR = pos;
          break;
      }

      // Ensure upper_left is always upper-left
      const finalUL = {
        x: Math.min(newUL.x, newLR.x),
        y: Math.min(newUL.y, newLR.y),
      };
      const finalLR = {
        x: Math.max(newUL.x, newLR.x),
        y: Math.max(newUL.y, newLR.y),
      };

      setUpperLeft(finalUL);
      setLowerRight(finalLR);
    }
  };

  const handleMouseUp = useCallback(() => {
    if (dragMode !== "none" && upperLeft && lowerRight) {
      // Normalize coordinates
      const finalUL = {
        x: Math.min(upperLeft.x, lowerRight.x),
        y: Math.min(upperLeft.y, lowerRight.y),
      };
      const finalLR = {
        x: Math.max(upperLeft.x, lowerRight.x),
        y: Math.max(upperLeft.y, lowerRight.y),
      };

      // Only save if selection has some size
      if (finalLR.x - finalUL.x > 5 && finalLR.y - finalUL.y > 5) {
        setUpperLeft(finalUL);
        setLowerRight(finalLR);
        const coords = { upper_left: finalUL, lower_right: finalLR };
        onGridSelectRef.current(coords);
      } else {
        // Too small, reset
        setUpperLeft(null);
        setLowerRight(null);
      }
    }
    setDragMode("none");
    setDragStart(null);
  }, [dragMode, upperLeft, lowerRight]);

  // Global mouse up handler for drag operations
  useEffect(() => {
    const handleGlobalMouseUp = () => {
      if (dragMode !== "none") {
        handleMouseUp();
      }
    };

    window.addEventListener("mouseup", handleGlobalMouseUp);
    return () => window.removeEventListener("mouseup", handleGlobalMouseUp);
  }, [dragMode, handleMouseUp]);

  const moveSelection = useCallback(
    (dx: number, dy: number) => {
      if (!upperLeft || !lowerRight) return;

      const newUL = { x: upperLeft.x + dx, y: upperLeft.y + dy };
      const newLR = { x: lowerRight.x + dx, y: lowerRight.y + dy };

      setUpperLeft(newUL);
      setLowerRight(newLR);
      const coords = { upper_left: newUL, lower_right: newLR };
      onGridSelectRef.current(coords);
    },
    [upperLeft, lowerRight],
  );

  const resizeSelection = useCallback(
    (dw: number, dh: number) => {
      if (!upperLeft || !lowerRight) return;

      const newLR = {
        x: Math.max(upperLeft.x + 10, lowerRight.x + dw),
        y: Math.max(upperLeft.y + 10, lowerRight.y + dh),
      };

      setLowerRight(newLR);
      const coords = { upper_left: upperLeft, lower_right: newLR };
      onGridSelectRef.current(coords);
    },
    [upperLeft, lowerRight],
  );

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // WASD works whenever there's a grid
      if (disabled || !upperLeft || !lowerRight) return;

      // Skip if typing in an input
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA") return;

      const step = e.shiftKey ? 10 : 1;
      const key = e.key.toLowerCase();

      switch (key) {
        case "w":
          e.preventDefault();
          e.stopPropagation();
          if (e.ctrlKey || e.metaKey) {
            resizeSelection(0, -step);
          } else {
            moveSelection(0, -step);
          }
          break;
        case "s":
          e.preventDefault();
          e.stopPropagation();
          if (e.ctrlKey || e.metaKey) {
            resizeSelection(0, step);
          } else {
            moveSelection(0, step);
          }
          break;
        case "a":
          e.preventDefault();
          e.stopPropagation();
          if (e.ctrlKey || e.metaKey) {
            resizeSelection(-step, 0);
          } else {
            moveSelection(-step, 0);
          }
          break;
        case "d":
          e.preventDefault();
          e.stopPropagation();
          if (e.ctrlKey || e.metaKey) {
            resizeSelection(step, 0);
          } else {
            moveSelection(step, 0);
          }
          break;
      }
    };

    window.addEventListener("keydown", handleKeyDown, true);
    return () => window.removeEventListener("keydown", handleKeyDown, true);
  }, [disabled, upperLeft, lowerRight, moveSelection, resizeSelection]);

  const handleReset = () => {
    setUpperLeft(null);
    setLowerRight(null);
    setDragMode("none");
    if (image) {
      redrawCanvas(image, null, null);
    }
    // Propagate the cleared selection so the store + persistence drop the stale
    // grid too — otherwise the canvas shows no selection while grid_coords keeps
    // the old values and auto-save/verify proceed with them. The zero sentinel
    // ({0,0},{0,0}) is what gridCoordsValid treats as "no grid".
    onGridSelectRef.current({ upper_left: { x: 0, y: 0 }, lower_right: { x: 0, y: 0 } });
  };

  const hasSelection = upperLeft && lowerRight;

  return (
    <div className="space-y-2" ref={containerRef} data-testid="grid-selector">
      {/* Controls row - Title field (centered) + Reset Grid */}
      <div className="flex items-center bg-eq-surface-muted px-3 py-2 rounded-eq-sm border border-eq-border gap-3">
        {/* Title field - for screen_time, centered */}
        {imageType === "screen_time" && (
          <div className="flex items-center gap-2 flex-1 justify-center">
            <span className="text-xs font-semibold text-eq-muted whitespace-nowrap">
              App/Title
              {!extractedTitle && <AlertTriangle className="w-4 h-4 text-eq-warning ml-1 inline" />}
            </span>
            <input
              type="text"
              value={extractedTitle || ""}
              onChange={(e) => onTitleChange?.(e.target.value)}
              placeholder="Enter app name..."
              aria-label="App or title name"
              disabled={disabled}
              className={`w-52 px-3 py-1.5 text-sm font-medium text-center border-2 rounded-eq-md shadow-sm focus:outline-none focus:ring-2 focus:ring-eq-focus focus:border-eq-primary disabled:bg-eq-surface-muted disabled:cursor-not-allowed transition-colors ${
                !extractedTitle
                  ? "border-eq-warning bg-eq-warning-bg"
                  : "border-eq-border bg-eq-surface hover:border-eq-border"
              }`}
            />
          </div>
        )}
        {/* Spacer if no title field */}
        {imageType !== "screen_time" && <div className="flex-1" />}
        {/* Reset Grid button */}
        {hasSelection && (
          <button
            onClick={handleReset}
            disabled={disabled}
            className="text-eq-danger hover:text-eq-danger text-xs font-medium px-3 py-1.5 border border-eq-danger rounded-eq-md hover:bg-eq-danger-bg disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            Reset Grid
          </button>
        )}
      </div>

      {/* Canvas — w-fit/mx-auto so the wrapper hugs the (height-capped, often
          narrower-than-panel) canvas and centers it, instead of stretching
          full width and showing a bg-eq-primary band beside a tall screenshot. */}
      <div
        className="bg-eq-primary rounded-eq-md w-fit mx-auto"
        role="application"
        aria-label="Screenshot with grid selection overlay. Use mouse or WASD keys to move; hold Shift for 10px steps; hold Ctrl to resize."
      >
        <canvas
          ref={canvasRef}
          aria-hidden="true"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          className="block"
        />
      </div>

      {/* Status indicator */}
      <div className="text-xs text-center">
        {!hasSelection && (
          <span className="text-eq-muted">Click and drag to select grid</span>
        )}
        {hasSelection && (
          <span className="text-eq-primary font-medium">
            WASD: move | Shift: 10px | Ctrl: resize
          </span>
        )}
      </div>
    </div>
  );
};
