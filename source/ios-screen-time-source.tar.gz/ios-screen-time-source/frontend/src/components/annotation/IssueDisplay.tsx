import type { ProcessingIssue } from "@/types";
import { EXPLICIT_ALL_DEVICES_REASON } from "@/utils/dataQuality";

interface IssueDisplayProps {
  issues: ProcessingIssue[];
  className?: string;
}

const getIssueStyle = (severity: "blocking" | "non_blocking") => {
  if (severity === "blocking") {
    return {
      container: "bg-eq-danger-bg border-eq-danger text-eq-danger",
      badge: "bg-eq-danger text-eq-primary-ink",
      icon: "!",
    };
  }
  return {
    container: "bg-eq-warning-bg border-eq-warning text-eq-warning",
    badge: "bg-eq-warning text-eq-primary-ink",
    icon: "?",
  };
};

const getIssueTypeName = (issueType: string, description?: string | null): string => {
  if (
    issueType === "suspected_all_devices" &&
    description?.includes(EXPLICIT_ALL_DEVICES_REASON)
  ) {
    return "All Devices Detected";
  }
  const typeMap: Record<string, string> = {
    GraphDetectionIssue: "Grid Detection Failed",
    TitleMissingIssue: "Title Missing",
    TotalNotFoundIssue: "Total Not Found",
    TotalParseErrorIssue: "Total Parse Error",
    TotalUnderestimationSmallIssue: "Minor Underestimation",
    TotalUnderestimationLargeIssue: "Large Underestimation",
    TotalOverestimationSmallIssue: "Minor Overestimation",
    TotalOverestimationLargeIssue: "Large Overestimation",
    ProcessingError: "Processing Error",
    // WASM-offline pipeline issue types (snake_case from WASMPreprocessingService).
    weekly_view_unsupported: "Weekly View Not Supported",
    grid_detection_failed: "Grid Detection Failed",
    unsupported_orientation: "Unsupported Orientation",
    ocr_extraction_failed: "OCR Extraction Failed",
    ocr_processing_failed: "OCR Engine Failed",
    ocr_stage_failed: "OCR Processing Stage Failed",
    ocr_error: "OCR Engine Error",
    no_hourly_data: "No Hourly Data",
    image_blob_missing: "Stored Image Missing",
    bar_extraction_failed: "Hourly Bar Extraction Failed",
    processing_failed: "Automated Processing Failed",
    processing_error: "Processing Error",
    suspected_all_devices: "Suspected All Devices",
  };
  return typeMap[issueType] || issueType
    .replace(/_/g, " ")
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .replace(/\b\w/g, (character) => character.toUpperCase());
};

export const IssueDisplay = ({ issues, className = "" }: IssueDisplayProps) => {
  if (!issues || issues.length === 0) {
    return null;
  }

  const blockingIssues = issues.filter((i) => i.severity === "blocking");
  const nonBlockingIssues = issues.filter((i) => i.severity === "non_blocking");

  return (
    <div className={`space-y-3 ${className}`}>
      {blockingIssues.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm font-semibold text-eq-danger flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-eq-danger text-eq-primary-ink text-xs flex items-center justify-center font-bold">
              !
            </span>
            Automated Processing Failures ({blockingIssues.length})
          </h4>
          {blockingIssues.map((issue, index) => {
            const style = getIssueStyle(issue.severity);
            return (
              <div
                key={index}
                className={`p-3 rounded-eq-md border-l-4 ${style.container}`}
              >
                <div className="flex items-start gap-2">
                  <span
                    className={`px-2 py-0.5 rounded-eq-sm text-xs font-medium ${style.badge}`}
                  >
                    {getIssueTypeName(issue.issue_type, issue.message || issue.description)}
                  </span>
                </div>
                <p className="mt-2 text-sm">
                  {issue.message || issue.description}
                </p>
              </div>
            );
          })}
        </div>
      )}

      {nonBlockingIssues.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm font-semibold text-eq-warning flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-eq-warning text-eq-primary-ink text-xs flex items-center justify-center font-bold">
              ?
            </span>
            Warnings ({nonBlockingIssues.length})
          </h4>
          {nonBlockingIssues.map((issue, index) => {
            const style = getIssueStyle(issue.severity);
            return (
              <div
                key={index}
                className={`p-3 rounded-eq-md border-l-4 ${style.container}`}
              >
                <div className="flex items-start gap-2">
                  <span
                    className={`px-2 py-0.5 rounded-eq-sm text-xs font-medium ${style.badge}`}
                  >
                    {getIssueTypeName(issue.issue_type, issue.message || issue.description)}
                  </span>
                </div>
                <p className="mt-2 text-sm">
                  {issue.message || issue.description}
                </p>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

interface ProcessingStatusBadgeProps {
  status: string;
}

export const ProcessingStatusBadge = ({
  status,
}: ProcessingStatusBadgeProps) => {
  const getStatusStyle = () => {
    switch (status) {
      case "completed":
        return "bg-eq-success-bg text-eq-success border-eq-success";
      case "skipped":
        return "bg-eq-surface-muted text-eq-ink border-eq-border";
      case "failed":
        return "bg-eq-danger-bg text-eq-danger border-eq-danger";
      case "pending":
      default:
        return "bg-eq-info-bg text-eq-info border-eq-info";
    }
  };

  const getStatusLabel = () => {
    switch (status) {
      case "completed":
        return "Auto-Processed";
      case "skipped":
        return "Skipped";
      case "failed":
        return "Failed";
      case "pending":
      default:
        return "Pending";
    }
  };

  return (
    <span
      className={`px-2 py-1 text-xs font-medium rounded-eq-sm border ${getStatusStyle()}`}
    >
      {getStatusLabel()}
    </span>
  );
};
