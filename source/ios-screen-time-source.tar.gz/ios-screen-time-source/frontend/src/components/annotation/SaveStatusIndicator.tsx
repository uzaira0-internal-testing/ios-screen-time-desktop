interface SaveStatusIndicatorProps {
  isSaving: boolean;
  lastSaved: Date | null;
  timeSinceLastSave: string;
  saveFailCount?: number;
  lastError?: string | null;
  hasUnsavedChanges?: boolean;
  onRetry?: () => void;
}

export function SaveStatusIndicator({
  isSaving,
  lastSaved,
  timeSinceLastSave,
  saveFailCount = 0,
  lastError,
  hasUnsavedChanges = false,
  onRetry,
}: SaveStatusIndicatorProps) {
  // Error state — save failed
  if (saveFailCount > 0 && lastError) {
    return (
      <div
        className="text-xs text-center py-2 px-3 rounded-eq-md bg-eq-danger-bg text-eq-danger border border-eq-danger"
        data-testid="auto-save-status"
        role="alert"
        title={lastError}
      >
        <span className="flex items-center justify-center gap-1.5">
          <svg className="w-3.5 h-3.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" />
          </svg>
          <span>
            Save failed{saveFailCount > 1 ? ` (${saveFailCount}x)` : ""}
            {onRetry && (
              <button
                onClick={onRetry}
                className="ml-1.5 underline font-medium hover:text-eq-danger"
              >
                Retry
              </button>
            )}
          </span>
        </span>
      </div>
    );
  }

  return (
    <div
      className={`text-xs text-center py-2 px-3 rounded-eq-md transition-all duration-300 ${
        isSaving
          ? "bg-eq-info-bg text-eq-info border border-eq-info"
          : lastSaved
            ? hasUnsavedChanges
              ? "bg-eq-warning-bg text-eq-warning border border-eq-warning"
              : "bg-eq-success-bg text-eq-success border border-eq-success"
            : "bg-eq-surface-muted text-eq-muted border border-eq-border"
      }`}
      data-testid="auto-save-status"
      role="status"
      aria-live="polite"
    >
      {isSaving ? (
        <span className="flex items-center justify-center gap-2">
          <div className="animate-spin h-3 w-3 border-2 border-eq-primary border-t-transparent rounded-full"></div>
          <span className="font-medium">Saving changes...</span>
        </span>
      ) : lastSaved ? (
        <span className="flex items-center justify-center gap-1">
          <svg
            className="w-4 h-4 text-eq-success"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M5 13l4 4L19 7"
            />
          </svg>
          <span className="font-medium">Saved {timeSinceLastSave}</span>
        </span>
      ) : (
        <span className="flex items-center justify-center gap-1">
          <svg
            className="w-3 h-3 text-eq-muted"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
            />
          </svg>
          Auto-save enabled
        </span>
      )}
    </div>
  );
}
