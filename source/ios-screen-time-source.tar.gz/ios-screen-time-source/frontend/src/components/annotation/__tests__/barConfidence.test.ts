/**
 * Unit tests for the per-bar review-hint rules. The pixel measurement that
 * feeds `measuredRatio` lives in Rust (`crates/processing/src/column_fills.rs`)
 * and is tested there.
 */
import { describe, it, expect } from "bun:test";
import { barConfidence } from "../barConfidence";

describe("barConfidence", () => {
  it("is ok with no pixel signal and an in-range value", () => {
    expect(barConfidence(20, null)).toEqual({ level: "ok", reason: null });
    expect(barConfidence(0, null)).toEqual({ level: "ok", reason: null });
  });

  it("flags values above the 60-minute maximum as a risk", () => {
    const c = barConfidence(75, null);
    expect(c.level).toBe("risk");
    expect(c.reason).toContain("maximum");
  });

  it("does NOT flag a value at the 60-minute ceiling — a full hour is normal", () => {
    expect(barConfidence(60, null)).toEqual({ level: "ok", reason: null });
    expect(barConfidence(59, null)).toEqual({ level: "ok", reason: null });
    expect(barConfidence(58, null)).toEqual({ level: "ok", reason: null });
  });

  it("agrees silently when the measured bar matches the value", () => {
    // value 30 ↔ ratio 0.5 → 30m measured, no disagreement
    expect(barConfidence(30, 0.5)).toEqual({ level: "ok", reason: null });
  });

  it("raises a risk when a tall bar sits on a stored zero (missed bar)", () => {
    const c = barConfidence(0, 0.8); // ~48m of bar, value 0
    expect(c.level).toBe("risk");
    expect(c.reason).toContain("48");
  });

  it("raises a risk when the value is high but the column is empty (phantom)", () => {
    const c = barConfidence(45, 0.0);
    expect(c.level).toBe("risk");
  });

  it("uses 'check' for a moderate mismatch and 'ok' for a small one", () => {
    // value 20, measured ~30m → diff 10 → check (>7, <=12)
    expect(barConfidence(20, 0.5).level).toBe("check");
    // value 20, measured ~25m → diff 5 → ok
    expect(barConfidence(20, 25 / 60).level).toBe("ok");
  });

  it("prioritises the impossible-value risk over pixel agreement", () => {
    expect(barConfidence(99, 0.5).level).toBe("risk");
  });

  it("interprets pixel height using a detected two-hour chart scale", () => {
    expect(barConfidence(60, 0.5, 120)).toEqual({ level: "ok", reason: null });
    const mismatched = barConfidence(30, 0.5, 120);
    expect(mismatched.level).toBe("risk");
    expect(mismatched.reason).toContain("60");
  });
});
