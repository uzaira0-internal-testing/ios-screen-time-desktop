import { afterAll, beforeAll, expect, test } from "bun:test";
import { Window } from "happy-dom";
import { act } from "react";
import { createRoot } from "react-dom/client";
import { MemoryRouter } from "react-router";
import { ServiceContext } from "@/core/hooks/ServiceContext";
import { ServiceContainer } from "@/core/di/Container";
import { TOKENS } from "@/core/di/tokens";
import type { IAnnotationService, IConsensusService, IScreenshotService } from "@/core/interfaces";
import type { Screenshot } from "@/types";

let AnnotationWorkspace: typeof import("../AnnotationWorkspace").AnnotationWorkspace;
const descriptors = new Map<string, PropertyDescriptor | undefined>();
beforeAll(async () => {
  const win = new Window({ url: "http://localhost/" });
  for (const key of ["window", "document", "navigator", "localStorage", "sessionStorage", "HTMLElement", "HTMLInputElement", "HTMLButtonElement", "MutationObserver", "getComputedStyle", "requestAnimationFrame", "cancelAnimationFrame", "ResizeObserver", "Image", "CustomEvent", "Node", "NodeFilter", "IS_REACT_ACT_ENVIRONMENT"]) {
    descriptors.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, { configurable: true, value: key === "window" ? win : key === "IS_REACT_ACT_ENVIRONMENT" ? true : win[key as keyof Window] });
  }
  ({ AnnotationWorkspace } = await import("../AnnotationWorkspace"));
});
afterAll(() => {
  for (const [key, descriptor] of descriptors) {
    if (descriptor) Object.defineProperty(globalThis, key, descriptor);
    else Reflect.deleteProperty(globalThis, key);
  }
});
function services(getById: IScreenshotService["getById"]) {
  const container = new ServiceContainer();
  container.register(TOKENS.SCREENSHOT_SERVICE, {
    getById,
    getList: async () => ({ items: [{ id: 1 }], total: 1, page: 1, has_next: false }),
    navigate: async () => ({ current_index: 1, total_in_filter: 1, has_next: false, has_prev: false }),
    getImageUrl: async () => "",
  } as unknown as IScreenshotService);
  container.register(TOKENS.ANNOTATION_SERVICE, { getByScreenshot: async () => [] } as unknown as IAnnotationService);
  container.register(TOKENS.CONSENSUS_SERVICE, {} as IConsensusService);
  container.register(TOKENS.FEATURES, { groups: false, consensusComparison: false, admin: false, preprocessing: false, phiDetection: false });
  container.register(TOKENS.PREPROCESSING_PIPELINE_SERVICE, {} as never);
  return container;
}
test("explicit screenshot deep link wins over a saved verification filter", async () => {
  const loaded: number[] = [];
  localStorage.setItem("annotate-verification-filter", "not_verified_by_me");
  const container = services(async (id) => { loaded.push(id); return { id, image_type: "screen_time", extracted_title: "App", extracted_hourly_data: {}, current_annotation_count: 0 } as Screenshot; });
  const element = document.createElement("div");
  document.body.append(element);
  const root = createRoot(element);
  await act(async () => { root.render(<MemoryRouter><ServiceContext.Provider value={container}><AnnotationWorkspace groupId="deep-link-test" initialScreenshotId={42} /></ServiceContext.Provider></MemoryRouter>); });
  expect(loaded).toEqual([42]);
  await act(async () => { root.unmount(); });
  element.remove();
});
test("missing screenshot renders a recoverable not-found state", async () => {
  localStorage.removeItem("annotate-verification-filter");
  const container = services(async () => { throw new Error("Screenshot not found"); });
  const element = document.createElement("div");
  document.body.append(element);
  const root = createRoot(element);
  await act(async () => { root.render(<MemoryRouter><ServiceContext.Provider value={container}><AnnotationWorkspace groupId="missing-test" initialScreenshotId={999} /></ServiceContext.Provider></MemoryRouter>); });
  expect(element.textContent).toContain("Screenshot not found");
  expect([...element.querySelectorAll("button")].some((button) => button.textContent === "Retry")).toBe(true);
  expect(element.querySelector('a[href="/"]')).not.toBeNull();
  await act(async () => { root.unmount(); });
  element.remove();
});
