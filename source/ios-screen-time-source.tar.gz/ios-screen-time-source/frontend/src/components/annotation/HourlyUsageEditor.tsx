import { memo, useMemo } from "react";
import type { HourlyData, Consensus } from "@/types";
import clsx from "clsx";
import { MAX_REVIEW_HOURLY_MINUTES } from "@/utils/dataQuality";

interface HourlyUsageEditorProps {
  data: HourlyData;
  onChange: (hour: number, value: number) => void;
  consensus?: Consensus;
  readOnly?: boolean;
  title?: string;
  axisMaximumMinutes?: number | null;
}

const HourlyUsageEditorInner = ({
  data,
  onChange,
  consensus,
  readOnly = false,
  axisMaximumMinutes = null,
}: HourlyUsageEditorProps) => {
  const handleChange = (hour: number, delta: number) => {
    const currentValue = data[hour] || 0;
    const newValue = Math.max(0, Math.min(MAX_REVIEW_HOURLY_MINUTES, currentValue + delta));
    onChange(hour, newValue);
  };

  const handleInputChange = (hour: number, value: string) => {
    // Preserve invalid aggregated-device evidence up to the API's review bound.
    // Clamping instead of rejecting keeps multi-digit entry predictable.
    const numValue = Math.max(0, Math.min(MAX_REVIEW_HOURLY_MINUTES, parseInt(value) || 0));
    onChange(hour, numValue);
  };

  // Build a Map from hour -> disagreement for O(1) lookups instead of find() per hour
  const disagreementMap = useMemo(() => {
    if (!consensus) return null;
    const map = new Map<number, { consensus_value: number }>();
    for (const d of consensus.disagreements) {
      map.set(d.hour, d);
    }
    return map;
  }, [consensus]);

  const getDisagreementLevel = (
    hour: number,
  ): "none" | "minor" | "major" | null => {
    if (!disagreementMap) return null;
    const disagreement = disagreementMap.get(hour);
    if (!disagreement) return "none";
    const currentValue = data[hour] || 0;
    const diff = Math.abs(currentValue - disagreement.consensus_value);
    if (diff === 0) return "none";
    if (diff <= 5) return "minor";
    return "major";
  };

  const getCellClassName = (hour: number) => {
    const level = getDisagreementLevel(hour);
    return clsx(
      "w-full text-center text-sm font-medium border rounded-eq-md focus:outline-none focus:ring-2 transition-all py-1",
      {
        "bg-eq-success-bg border-eq-success text-eq-success": level === "none",
        "bg-eq-warning-bg border-eq-warning text-eq-warning": level === "minor",
        "bg-eq-danger-bg border-eq-danger text-eq-danger": level === "major",
        "bg-eq-surface border-eq-border text-eq-ink focus:ring-eq-focus focus:border-eq-primary":
          level === null,
        "bg-eq-surface-muted text-eq-muted cursor-not-allowed": readOnly,
      },
    );
  };

  const graphHeight = 200;
  const maxObservedMinutes = Math.max(
    ...Array.from({ length: 24 }, (_, hour) => data[hour] || 0),
  );
  const detectedChartMaximum =
    axisMaximumMinutes !== null && Number.isFinite(axisMaximumMinutes) && axisMaximumMinutes > 60
      ? Math.min(MAX_REVIEW_HOURLY_MINUTES, axisMaximumMinutes)
      : null;
  const chartMaximum = Math.max(60, maxObservedMinutes, detectedChartMaximum ?? 0);

  return (
    <div className="w-full" data-testid="hourly-editor">
      {/* Bar Graph - EXACTLY 24 columns */}
      <div
        className="relative bg-eq-surface rounded-eq-md overflow-hidden border border-eq-border"
        style={{ height: graphHeight }}
      >
        <div
          className="absolute inset-0 w-full h-full grid"
          style={{
            gridTemplateColumns: "repeat(24, 1fr)",
          }}
        >
          {Array.from({ length: 24 }, (_, i) => {
            const value = data[i] || 0;
            const heightPercentage = (value / chartMaximum) * 100;

            return (
              <div
                key={i}
                className="flex flex-col h-full justify-end items-center border-r border-eq-border last:border-r-0"
              >
                {/* Bar — only render when there's a value. Rendering a
                    zero-height div left a 1px border sliver at the base of
                    every empty column. */}
                {value > 0 ? (
                  <div
                    className="w-4/5 bg-eq-chart-bar transition-all duration-300 rounded-t-md"
                    style={{
                      height: `${heightPercentage}%`,
                      minHeight: "2px",
                    }}
                  />
                ) : null}
              </div>
            );
          })}
        </div>
      </div>

      {detectedChartMaximum !== null && (
        <div className="mt-1.5 text-[10px] text-eq-warning">
          Detected chart scale: {detectedChartMaximum} minutes
        </div>
      )}

      {/* Controls grid - EXACTLY 24 columns to match bar graph above */}
      <div
        className="w-full grid gap-2 mt-4"
        style={{ gridTemplateColumns: "repeat(24, 1fr)" }}
      >
        {Array.from({ length: 24 }, (_, i) => {
          const value = data[i] || 0;

          return (
            <div key={i} className="flex flex-col items-center gap-1">
              {/* X-Axis Label */}
              <div className="text-[10px] text-eq-muted font-semibold text-center">
                {i}h
              </div>

              <button
                type="button"
                onClick={() => handleChange(i, 1)}
                disabled={readOnly}
                className="w-full h-5 flex items-center justify-center text-[10px] bg-eq-surface-muted hover:bg-eq-surface-muted hover:text-eq-primary rounded-eq-sm text-eq-muted disabled:opacity-50 transition-colors"
              >
                ▲
              </button>
              <input
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                value={value}
                onChange={(e) => handleInputChange(i, e.target.value)}
                disabled={readOnly}
                aria-label={`Usage for hour ${i === 0 ? "12 AM" : i < 12 ? `${i} AM` : i === 12 ? "12 PM" : `${i - 12} PM`}`}
                className={getCellClassName(i)}
                style={{ appearance: "textfield" }}
                data-testid={`hour-input-${i}`}
              />
              <button
                type="button"
                onClick={() => handleChange(i, -1)}
                disabled={readOnly}
                className="w-full h-5 flex items-center justify-center text-[10px] bg-eq-surface-muted hover:bg-eq-surface-muted hover:text-eq-primary rounded-eq-sm text-eq-muted disabled:opacity-50 transition-colors"
              >
                ▼
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const HourlyUsageEditor = memo(HourlyUsageEditorInner);
