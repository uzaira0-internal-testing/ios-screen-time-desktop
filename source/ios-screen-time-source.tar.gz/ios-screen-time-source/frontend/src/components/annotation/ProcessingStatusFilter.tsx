import {
  FILTER_STATUSES,
  FILTER_STATUS_LABELS,
  type FilterStatus,
} from "@/constants/processingStatus";

interface ProcessingStatusFilterProps {
  value: FilterStatus | "all";
  onChange: (value: FilterStatus | "all") => void;
}

const filterOptions: { value: FilterStatus | "all"; label: string }[] = [
  { value: "all", label: "All Statuses" },
  ...FILTER_STATUSES.map((status) => ({
    value: status,
    label: FILTER_STATUS_LABELS[status],
  })),
];

export const ProcessingStatusFilter = ({
  value,
  onChange,
}: ProcessingStatusFilterProps) => {
  return (
    <div className="flex gap-1 flex-wrap">
      {filterOptions.map((option) => (
        <button
          key={option.value}
          onClick={() => onChange(option.value)}
          className={`px-2 py-1 text-xs rounded-eq-sm transition-colors ${
            value === option.value
              ? "bg-eq-primary text-eq-primary-ink"
              : "bg-eq-surface-muted text-eq-muted hover:bg-eq-surface-muted"
          }`}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
};
