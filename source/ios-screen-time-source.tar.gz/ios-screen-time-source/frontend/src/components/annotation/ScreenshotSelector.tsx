import { useState, useEffect, useRef, useCallback } from "react";
import type { Screenshot, ScreenshotListResponse } from "@/core/models";
import { FILTER_STATUS_LABELS, type FilterStatus } from "@/constants/processingStatus";
import { useSettingsStore } from "@/store/settingsStore";

interface ScreenshotSelectorProps {
  currentScreenshot: Screenshot | null;
  screenshotList: ScreenshotListResponse | null;
  currentIndex: number;
  totalInFilter: number;
  hasNext: boolean;
  hasPrev: boolean;
  onNavigateNext: () => void;
  onNavigatePrev: () => void;
  onSelectScreenshot: (id: number) => void;
  onSearch: (search: string) => void;
  onLoadMore: () => void;
  isLoading: boolean;
  currentUsername: string | null;
}

export const ScreenshotSelector = ({
  currentScreenshot,
  screenshotList,
  currentIndex,
  totalInFilter,
  hasNext,
  hasPrev,
  onNavigateNext,
  onNavigatePrev,
  onSelectScreenshot,
  onSearch,
  onLoadMore,
  isLoading,
  currentUsername,
}: ScreenshotSelectorProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const dropdownRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const showIdentifierMetadata = useSettingsStore((s) => s.showIdentifierMetadata);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Focus search input when dropdown opens
  useEffect(() => {
    if (isOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isOpen]);

  // Handle search with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      onSearch(searchTerm);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm, onSearch]);

  // Load more screenshots when scrolling near the bottom of the list
  const scrollThrottled = useRef(false);
  const scrollTimer = useRef<ReturnType<typeof setTimeout>>(undefined);
  useEffect(() => () => { clearTimeout(scrollTimer.current); }, []);

  const handleListScroll = useCallback(() => {
    const el = listRef.current;
    if (!el || !screenshotList?.has_next || scrollThrottled.current) return;

    const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 100;
    if (nearBottom) {
      scrollThrottled.current = true;
      onLoadMore();
      // Throttle: ignore scroll events for 300ms after triggering a load
      scrollTimer.current = setTimeout(() => { scrollThrottled.current = false; }, 300);
    }
  }, [onLoadMore, screenshotList?.has_next]);

  const handleSelectScreenshot = (id: number) => {
    onSelectScreenshot(id);
    setIsOpen(false);
    // Keep the search term so the filter PERSISTS after picking a result — and so
    // we don't fire onSearch(""), which would reload the UNFILTERED list and bounce
    // the workspace off the just-selected screenshot when it isn't on the first page.
  };

  const getVerificationBadge = (screenshot: Screenshot) => {
    const verifierUsernames = screenshot.verified_by_usernames || [];
    const verifierCount = verifierUsernames.length;
    const isVerifiedByMe =
      currentUsername !== null && verifierUsernames.includes(currentUsername);

    if (verifierCount === 0) {
      return null;
    }

    // Green if verified by current user, yellow if not
    const colorClasses = isVerifiedByMe
      ? "bg-eq-success-bg text-eq-success"
      : "bg-eq-warning-bg text-eq-warning";

    return (
      <span className={`ml-1 px-1.5 py-0.5 text-xs ${colorClasses} rounded-eq-sm font-medium`}>
        {verifierCount}
      </span>
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-eq-success";
      case "failed":
        return "text-eq-danger";
      case "pending":
        return "text-eq-primary";
      case "skipped":
        return "text-eq-muted";
      default:
        return "text-eq-muted";
    }
  };

  return (
    <div className="flex items-center gap-2" ref={dropdownRef} data-testid="screenshot-selector">
      {/* Previous Button */}
      <button
        onClick={onNavigatePrev}
        disabled={!hasPrev || isLoading}
        className={`p-1.5 rounded-eq-sm transition-colors ${
          hasPrev && !isLoading
            ? "bg-eq-surface-muted hover:bg-eq-surface-muted text-eq-ink"
            : "bg-eq-surface-muted text-eq-muted cursor-not-allowed"
        }`}
        aria-label="Previous screenshot"
        title="Previous screenshot (←)"
        data-testid="navigate-prev"
      >
        <svg
          className="w-4 h-4"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M15 19l-7-7 7-7"
          />
        </svg>
      </button>

      {/* Screenshot Selector Dropdown */}
      <div className="relative flex-1 min-w-0">
        <button
          onClick={() => setIsOpen(!isOpen)}
          aria-haspopup="listbox"
          aria-expanded={isOpen}
          aria-label="Select screenshot"
          className="w-full px-2 py-1.5 text-left bg-eq-surface border border-eq-border rounded-eq-sm hover:border-eq-border focus:outline-none focus:ring-2 focus:ring-eq-focus flex items-center gap-2"
        >
          {currentScreenshot ? (
                <>
                  <span className="font-semibold text-eq-ink whitespace-nowrap">
                    #{currentScreenshot.id}
                  </span>
                  <span className="text-xs text-eq-muted truncate">
                    {showIdentifierMetadata
                      ? (
                        <>
                          {currentScreenshot.participant_id || ""}
                          {currentScreenshot.screenshot_date && ` · ${currentScreenshot.screenshot_date}`}
                        </>
                      )
                      : currentScreenshot.screenshot_date}
                  </span>
              {(() => {
                const verifierUsernames =
                  currentScreenshot.verified_by_usernames || [];
                const verifierCount = verifierUsernames.length;
                if (verifierCount === 0) return null;
                const isVerifiedByMe =
                  currentUsername !== null &&
                  verifierUsernames.includes(currentUsername);
                const colorClasses = isVerifiedByMe
                  ? "bg-eq-success-bg text-eq-success"
                  : "bg-eq-warning-bg text-eq-warning";
                return (
                  <span className={`px-1.5 py-0.5 text-[10px] ${colorClasses} rounded-eq-sm font-medium whitespace-nowrap`}>
                    {verifierCount}
                  </span>
                );
              })()}
              <span className="text-xs text-eq-muted whitespace-nowrap ml-auto" data-testid="navigation-info">
                {currentIndex}/{totalInFilter}
              </span>
            </>
          ) : (
            <span className="text-eq-muted flex-1">Select...</span>
          )}
          <svg
            className={`w-4 h-4 text-eq-muted flex-shrink-0 transition-transform ${isOpen ? "rotate-180" : ""}`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 9l-7 7-7-7"
            />
          </svg>
        </button>

        {/* Dropdown Menu */}
        {isOpen && (
          <div className="absolute z-50 mt-1 w-full bg-eq-surface border border-eq-border rounded-eq-md shadow-lg max-h-80 overflow-hidden">
            {/* Search Input */}
            <div className="p-2 border-b border-eq-border">
              <input
                ref={searchInputRef}
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={showIdentifierMetadata ? "Search by ID or participant" : "Search by ID"}
                className="w-full px-2 py-1 text-sm border border-eq-border rounded-eq-sm focus:outline-none focus:ring-1 focus:ring-eq-focus"
                aria-label="Search screenshots"
              />
            </div>

            {/* Screenshot List */}
            <div className="max-h-52 overflow-y-auto" ref={listRef} onScroll={handleListScroll} role="listbox" aria-label="Screenshots">
              {screenshotList?.items.map((screenshot: Screenshot) => {
                // Extract filename from file_path
                const filename = screenshot.file_path?.split("/").pop() || "";
                const dateStr = screenshot.screenshot_date || "";
                return (
                  <button
                    key={screenshot.id}
                    onClick={() => handleSelectScreenshot(screenshot.id)}
                    role="option"
                    aria-selected={currentScreenshot?.id === screenshot.id}
                    className={`w-full px-3 py-2 text-left hover:bg-eq-surface-muted flex items-center justify-between ${
                      currentScreenshot?.id === screenshot.id
                        ? "bg-eq-info-bg"
                        : ""
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="font-medium whitespace-nowrap">#{screenshot.id}</span>
                      <span className="text-xs text-eq-muted truncate">
                        {showIdentifierMetadata
                          ? (
                            <>
                              {screenshot.participant_id || ""}
                              {dateStr && ` · ${dateStr}`}
                              {filename && ` · ${filename}`}
                            </>
                          )
                          : dateStr}
                      </span>
                      {getVerificationBadge(screenshot)}
                    </div>
                    <span
                      className={`text-xs flex-shrink-0 ml-2 ${getStatusColor(screenshot.processing_status)}`}
                    >
                      {FILTER_STATUS_LABELS[screenshot.processing_status as FilterStatus] || screenshot.processing_status}
                    </span>
                  </button>
                );
              })}
              {screenshotList?.items.length === 0 && (
                <div className="px-3 py-4 text-center text-eq-muted text-sm">
                  No screenshots found
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Next Button */}
      <button
        onClick={onNavigateNext}
        disabled={!hasNext || isLoading}
        className={`p-1.5 rounded-eq-sm transition-colors ${
          hasNext && !isLoading
            ? "bg-eq-surface-muted hover:bg-eq-surface-muted text-eq-ink"
            : "bg-eq-surface-muted text-eq-muted cursor-not-allowed"
        }`}
        aria-label="Next screenshot"
        title="Next screenshot (→)"
        data-testid="navigate-next"
      >
        <svg
          className="w-4 h-4"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M9 5l7 7-7 7"
          />
        </svg>
      </button>
    </div>
  );
};
