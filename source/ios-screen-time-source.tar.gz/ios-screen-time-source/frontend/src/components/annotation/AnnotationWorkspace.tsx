import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { useNavigate, Link } from "react-router";
import { useAnnotation } from "@/hooks/useAnnotationWithDI";
import { useKeyboardShortcuts } from "@/hooks/useKeyboardShortcuts";
import { useAutoSave } from "@/hooks/useAutoSave";
import { useGridProcessing } from "@/hooks/useGridProcessing";
import { useAuth } from "@/hooks/useAuth";
import { GridSelector } from "./GridSelector";
import { CroppedGraphViewer } from "./CroppedGraphViewer";
import { HourlyUsageEditor } from "./HourlyUsageEditor";
import { HourlyUsageOverlay } from "./HourlyUsageOverlay";
import { IssueDisplay } from "./IssueDisplay";
import { DuplicateWarning } from "./DuplicateWarning";
import { ScreenshotSelector } from "./ScreenshotSelector";
import { VerificationFilter } from "./VerificationFilter";
import { ProcessingStatusFilter } from "./ProcessingStatusFilter";
import { SaveStatusIndicator } from "./SaveStatusIndicator";
import { Skeleton } from "@/components/ui/Skeleton";
import { CollapsibleSection } from "@/components/ui/CollapsibleSection";
import { TotalsDisplay } from "./TotalsDisplay";
import { AlignmentWarning } from "./AlignmentWarning";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import type { ProcessingStatus } from "@/types";
import type { FilterStatus } from "@/constants/processingStatus";
import type { VerificationFilterType } from "@/store/slices/types";
import { PreprocessingSummary } from "./PreprocessingSummary";
import { useScreenshotImage } from "@/hooks/useScreenshotImage";
import { Modal } from "@/components/ui/Modal";
import { CropAdjustModal } from "@/components/preprocessing/CropAdjustModal";
import { CropHistoryControls } from "@/components/preprocessing/CropHistoryControls";
import { getCropRectFromEvent } from "@/components/preprocessing/croppingUtils";
import { getCurrentEvent } from "@/components/preprocessing/stageReviewUtils";
import { useConsensusService, useFeatures } from "@/core/hooks/useServices";
import { useConfirmDialog } from "@/hooks/useConfirmDialog";
import { isChunkLoadError, reloadForStaleChunk } from "@/lib/chunkReload";
import type { Consensus } from "@/types";
import toast from "react-hot-toast";
import { config } from "@/config";
import { useSettingsStore } from "@/store/settingsStore";
import {
  formatFailureReasonForDisplay,
  getBlockingFailureReasons,
  getDataQualityFlags,
  hasExplicitAllDevicesText,
  hasCurrentBlockingProcessingIssue,
  isOcrFailed,
} from "@/utils/dataQuality";
import { useVoidHandler, voidHandler } from "@/lib/asyncHandler";
import { useLeaveGuard } from "@/lib/desktop/leaveGuard";

type ProcessingMethod = "ocr_anchored" | "line_based";

export type GraphDisplayMode = "separate" | "overlay";

/** Module-level frozen empty object so every component that reads
 *  `hourlyValues` while annotation is still loading sees the same
 *  reference instead of a fresh `{}` per workspace render. */
const EMPTY_HOURLY: Record<number, number> = Object.freeze({}) as Record<number, number>;

interface AnnotationWorkspaceProps {
  groupId?: string | undefined;
  processingStatus?: ProcessingStatus | undefined;
  initialScreenshotId?: number | undefined;
  initialFilter?: VerificationFilterType | undefined;
}

export const AnnotationWorkspace = ({
  groupId,
  processingStatus,
  initialScreenshotId,
  initialFilter,
}: AnnotationWorkspaceProps) => {
  const navigate = useNavigate();
  const { username } = useAuth();
  const {
    screenshot,
    annotation,
    isLoading,
    noScreenshots,
    processingIssues,
    loadNext,
    loadById,
    updateHour,
    saveOnly,
    skip,
    reprocessWithGrid,
    setGrid,
    setTitle,
    currentIndex,
    totalInFilter,
    hasNext,
    hasPrev,
    screenshotList,
    verificationFilter,
    navigateNext,
    navigatePrev,
    loadScreenshotList,
    loadMoreScreenshots,
    setVerificationFilter,
    setSearch,
    verifyCurrentScreenshot,
    unverifyCurrentScreenshot,
    recalculateOcrTotal,
    reprocessWithLineBased,
    reprocessWithOcrAnchored,
    error,
    clearError,
  } = useAnnotation(groupId, processingStatus);

  // ScreenshotSelector keys effects on these props (the 300ms search debounce on
  // `onSearch`, the scroll handler on `onLoadMore`), so they must keep a stable
  // identity across renders — see `useVoidHandler`.
  const onNavigateNextStable = useVoidHandler(navigateNext);
  const onNavigatePrevStable = useVoidHandler(navigatePrev);
  const onSelectScreenshotStable = useVoidHandler(loadById);
  const onSearchStable = useVoidHandler(setSearch);
  const onLoadMoreStable = useVoidHandler(loadMoreScreenshots);

  const [imageRefreshKey, setImageRefreshKey] = useState(0);
  const imageUrl = useScreenshotImage(screenshot?.id || 0, imageRefreshKey);

  // Stabilize the data references that get passed into the heavy
  // overlay/editor children. The previous inline `annotation?.hourly_values || {}`
  // and `... || null` literals minted a fresh `{}` / `null` reference
  // on every workspace render — which made HourlyUsageOverlay (canvas
  // redraw + image reload) and the editor rerender even when nothing
  // about their inputs had actually changed. Each navigation churned
  // them four or five times in a row.
  const hourlyValues = useMemo(
    () => annotation?.hourly_values ?? EMPTY_HOURLY,
    [annotation?.hourly_values],
  );
  const gridCoords = annotation?.grid_coords ?? null;
  const qualityFlags = useMemo(
    () => (screenshot ? getDataQualityFlags(screenshot) : null),
    [screenshot],
  );
  const explicitAllDevices = qualityFlags != null && hasExplicitAllDevicesText(qualityFlags);
  const ocrFailed = useMemo(
    () => (screenshot ? isOcrFailed(screenshot) : false),
    [screenshot],
  );
  const failureReasons = useMemo(
    () => (screenshot ? getBlockingFailureReasons(screenshot) : []),
    [screenshot],
  );
  const hasCurrentOcrFailure = useMemo(
    () => failureReasons.some((reason) =>
      /^(?:ocr_processing_failed|ocr_extraction_failed|ocr_error):/.test(reason),
    ),
    [failureReasons],
  );
  const hasCurrentProcessingFailure = useMemo(
    () => Boolean(
      screenshot &&
      screenshot.processing_status !== "skipped" &&
      screenshot.processing_status !== "deleted" &&
      (screenshot.processing_status === "failed" || hasCurrentBlockingProcessingIssue(screenshot)),
    ),
    [screenshot],
  );

  const [notes, setNotes] = useState("");
  const [displayMode, setDisplayMode] = useState<GraphDisplayMode>(() => {
    try {
      const v = localStorage.getItem("annotate-display-mode");
      return v === "separate" || v === "overlay" ? v : "overlay";
    } catch { return "overlay"; }
  });
  const [isRecalculatingOcr, setIsRecalculatingOcr] = useState(false);
  const [reprocessingMethod, setReprocessingMethod] =
    useState<ProcessingMethod | null>(null);
  const [cropEditorOpen, setCropEditorOpen] = useState(false);
  const [skipMenuOpen, setSkipMenuOpen] = useState(false);
  const [helpDismissed, setHelpDismissed] = useState(() => {
    try { return localStorage.getItem("annotation-help-dismissed") === "1"; } catch { return false; }
  });
  const [shortcutsHintDismissed, setShortcutsHintDismissed] = useState(() => {
    try { return localStorage.getItem("shortcuts-hint-dismissed") === "1"; } catch { return false; }
  });
  const skipMenuRef = useRef<HTMLDivElement>(null);
  const [consensus, setConsensus] = useState<Consensus | null>(null);
  const consensusService = useConsensusService();
  const features = useFeatures();
  const { confirm, ConfirmDialog } = useConfirmDialog();
  const showIdentifierMetadata = useSettingsStore((s) => s.showIdentifierMetadata);

  // Show global error toast when store error changes
  useEffect(() => {
    if (error) {
      toast.error(error || "Something went wrong");
      clearError();
    }
  }, [error, clearError]);

  // Reset notes when the screenshot changes so a note typed on one screenshot
  // can't bleed into — and then silently auto-save onto — the next one. Seed
  // from the loaded annotation's saved notes. Done as a render-time adjustment
  // (React's "adjusting state when a prop changes" pattern) rather than a
  // useEffect: an effect lags one render, and the auto-save hook would then
  // mistake the seeded value for a user edit and spuriously re-save the
  // destination screenshot. screenshot + annotation update together in the
  // store, so annotation?.notes is already the new screenshot's notes here.
  const [notesForScreenshotId, setNotesForScreenshotId] = useState(screenshot?.id);
  if (screenshot?.id !== notesForScreenshotId) {
    setNotesForScreenshotId(screenshot?.id);
    setNotes(annotation?.notes ?? "");
  }

  // Load consensus data when screenshot has multiple verifiers. Skip entirely
  // when the consensus feature is disabled — the service may not be registered
  // in the DI container, and the panel that consumes `consensus` is gated on
  // the same flag.
  useEffect(() => {
    if (!features.consensusComparison) {
      setConsensus(null);
      return;
    }
    if (!screenshot?.id || !screenshot.verified_by_usernames || screenshot.verified_by_usernames.length < 2) {
      setConsensus(null);
      return;
    }
    let cancelled = false;
    consensusService.getForScreenshot(screenshot.id)
      .then((data) => { if (!cancelled) setConsensus(data); })
      .catch((e) => {
        if (cancelled) return;
        // SPA-navigation aborts and offline blips routinely cancel this
        // fetch; those aren't real errors. For everything else, the
        // dispute/consensus panel hiding silently could mislead a
        // reviewer into annotating without seeing the conflict.
        const name = (e as { name?: string })?.name ?? "";
        const msg = e instanceof Error ? e.message : String(e);
        const isTransient =
          name === "AbortError" ||
          /failed to fetch|networkerror|aborted|load failed/i.test(msg);
        setConsensus(null);
        if (!isTransient) {
          console.error("Failed to load consensus:", e);
          toast.error("Could not load consensus — dispute status may be stale");
        }
      });
    return () => { cancelled = true; };
  }, [screenshot?.id, screenshot?.verified_by_usernames, consensusService, features.consensusComparison]);

  // Close skip dropdown when clicking outside
  useEffect(() => {
    if (!skipMenuOpen) return;
    const handleOutsideClick = (e: MouseEvent) => {
      if (skipMenuRef.current && !skipMenuRef.current.contains(e.target as Node)) {
        setSkipMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleOutsideClick);
    return () => document.removeEventListener("mousedown", handleOutsideClick);
  }, [skipMenuOpen]);

  // Check if THIS USER has verified the screenshot (read-only mode for them)
  // Use username-based check as it's more reliable than userId which can get stale
  const isVerifiedByMe = !!(
    username &&
    screenshot?.verified_by_usernames?.includes(username)
  );

  // Get ALL verifiers' usernames
  const allVerifierUsernames = screenshot?.verified_by_usernames || [];

  // Grid processing hook with debounce
  const { isProcessing, handleGridSelect } = useGridProcessing({
    screenshotId: screenshot?.id,
    onReprocess: reprocessWithGrid,
    onSetGrid: setGrid,
  });

  // Auto-save hook
  const { isSaving, lastSaved, timeSinceLastSave, saveFailCount, lastError, hasUnsavedChanges, retrySave } = useAutoSave({
    screenshotId: screenshot?.id,
    hourlyData: annotation?.hourly_values,
    extractedTitle: screenshot?.extracted_title,
    extractedTotal: screenshot?.extracted_total,
    gridCoords: annotation?.grid_coords,
    notes,
    onSave: saveOnly,
  });

  // Ask before the tab or window closes with unsaved changes.
  useLeaveGuard(hasUnsavedChanges, "This screenshot has unsaved changes. Quitting now discards them.");

  // Hold the deep-link target + filter in refs so the queue-init effect below
  // can read them WITHOUT depending on them. The URL-sync effect rewrites the
  // route to /annotate/:id on every navigation (and drops ?filter after the
  // first step), so depending on initialScreenshotId / initialFilter would
  // re-fire this effect on each move and snap the queue back to its first
  // item — making it impossible to advance in any non-"all" filter.
  const initialScreenshotIdRef = useRef(initialScreenshotId);
  initialScreenshotIdRef.current = initialScreenshotId;
  const initialFilterRef = useRef(initialFilter);
  initialFilterRef.current = initialFilter;

  // Initial load: runs once per queue identity (groupId / processingStatus).
  // If a filter is set (URL param or localStorage), use setVerificationFilter
  // which internally loads the screenshot list and first screenshot. Otherwise
  // load directly. The HomePage "Needs attention" deep-link changes groupId
  // too, so it re-fires this effect and is honored on the fresh queue.
  useEffect(() => {
    // Determine the filter to apply
    let filterToApply: VerificationFilterType | undefined;
    if (initialFilterRef.current) {
      filterToApply = initialFilterRef.current;
    } else {
      try {
        const saved = localStorage.getItem("annotate-verification-filter");
        const valid: VerificationFilterType[] = ["all", "verified_by_me", "not_verified_by_me", "verified_by_others", "totals_mismatch"];
        if (saved && (valid as string[]).includes(saved) && saved !== "all") {
          filterToApply = saved as VerificationFilterType;
        }
      } catch { /* ignore */ }
    }

    if (filterToApply) {
      // setVerificationFilter loads the list + first screenshot internally — no separate calls needed
      setVerificationFilter(filterToApply, initialScreenshotIdRef.current);
    } else {
      if (initialScreenshotIdRef.current) {
        void loadById(initialScreenshotIdRef.current).catch(() => { /* surfaced: the store records the load error and renders the not-found state */ });
      } else {
        void loadNext().catch(() => { /* surfaced: the store records the load error and renders the not-found state */ });
      }
      void loadScreenshotList();
    }
  }, [groupId, processingStatus, loadById, loadNext, loadScreenshotList, setVerificationFilter]);

  // Persist displayMode and verificationFilter
  useEffect(() => {
    try { localStorage.setItem("annotate-display-mode", displayMode); } catch { /* ignore */ }
  }, [displayMode]);
  useEffect(() => {
    try { localStorage.setItem("annotate-verification-filter", verificationFilter); } catch { /* ignore */ }
  }, [verificationFilter]);

  // Update URL when screenshot changes
  useEffect(() => {
    if (screenshot?.id) {
      const searchParams = new URLSearchParams();
      if (groupId) searchParams.set("group", groupId);
      if (processingStatus)
        searchParams.set("processing_status", processingStatus);
      const search = searchParams.toString();
      const newUrl = `/annotate/${screenshot.id}${search ? `?${search}` : ""}`;
      void navigate(newUrl, { replace: true });
    }
  }, [screenshot?.id, groupId, processingStatus, navigate]);
  // Note: navigate is stable from react-router-dom

  const handleRecalculateOcr = useCallback(async () => {
    if (isRecalculatingOcr) return;
    setIsRecalculatingOcr(true);
    try {
      const newTotal = await recalculateOcrTotal();
      if (newTotal) {
        toast.success(`OCR total updated: ${newTotal}`);
      } else {
        toast.error("Could not extract OCR total");
      }
    } catch {
      toast.error("Failed to recalculate OCR total");
    } finally {
      setIsRecalculatingOcr(false);
    }
  }, [recalculateOcrTotal, isRecalculatingOcr]);

  const handleReprocess = useCallback(
    async (method: ProcessingMethod) => {
      if (reprocessingMethod) return;
      setReprocessingMethod(method);
      try {
        if (method === "line_based") {
          await reprocessWithLineBased();
          toast.success("Line-based detection completed");
        } else {
          await reprocessWithOcrAnchored();
          toast.success("OCR-anchored detection completed");
        }
      } catch (error) {
        const methodName =
          method === "line_based" ? "Line-based" : "OCR-anchored";
        const message =
          error instanceof Error
            ? error.message
            : `${methodName} detection failed`;
        toast.error(message);
      } finally {
        setReprocessingMethod(null);
      }
    },
    [reprocessWithLineBased, reprocessWithOcrAnchored, reprocessingMethod],
  );

  const screenshotIdRef = useRef(screenshot?.id);
  screenshotIdRef.current = screenshot?.id;
  const [isVerifying, setIsVerifying] = useState(false);
  const [mismatchInfo, setMismatchInfo] = useState<{ screenshotId: number; barStr: string; ocrStr: string; onConfirm: () => void; onCancel: () => void } | null>(null);
  useEffect(() => {
    if (mismatchInfo && mismatchInfo.screenshotId !== screenshot?.id) mismatchInfo.onCancel();
  }, [screenshot?.id, mismatchInfo]);
  const handleVerificationToggle = useCallback(async () => {
    if (!screenshot || isVerifying) return;
    setIsVerifying(true);
    try {
      if (isVerifiedByMe) {
        await unverifyCurrentScreenshot(screenshot.id);
        toast.success("Your verification removed");
      } else {
        // Check if title is required and missing
        if (
          screenshot.image_type === "screen_time" &&
          !screenshot.extracted_title
        ) {
          toast.error("Cannot verify: App/Title is required");
          return;
        }
        // Check if bar total and OCR total mismatch.
        // Skip check if grid reprocessing is in progress (values are stale).
        // Use the SAME comparator as the totals ring (sum the bars, round once,
        // shared threshold) so the verify dialog never contradicts the
        // green/amber/red box the annotator is looking at.
        if (!isProcessing && screenshot.extracted_total && annotation?.hourly_values) {
          const { totalsDiffMinutes, TOTALS_MISMATCH_THRESHOLD_MINUTES, formatMinutes, calculateTotalMinutes } =
            await import("@/utils/formatters");
          if (screenshotIdRef.current !== screenshot.id) return;
          const diff = totalsDiffMinutes(annotation.hourly_values, screenshot.extracted_total);
          if (diff !== null && diff >= TOTALS_MISMATCH_THRESHOLD_MINUTES) {
            const barStr = formatMinutes(calculateTotalMinutes(annotation.hourly_values));
            // Show modal and wait for user decision
            const proceed = await new Promise<boolean>((resolve) => {
              setMismatchInfo({ screenshotId: screenshot.id, barStr, ocrStr: screenshot.extracted_total!, onConfirm: () => resolve(true), onCancel: () => resolve(false) });
            });
            setMismatchInfo(null);
            if (!proceed) return;
          }
        }
        if (screenshotIdRef.current !== screenshot.id) return;
        await verifyCurrentScreenshot(screenshot.id, notes);
        toast.success("Screenshot verified by you");
      }
    } catch (error) {
      // A deploy renamed the lazily-imported chunk this handler pulls
      // (`import("@/utils/formatters")`); a stale tab 404s on it. Reload once to
      // pick up the fresh build instead of surfacing a misleading failure.
      if (isChunkLoadError(error)) {
        reloadForStaleChunk();
        return;
      }
      console.error("[handleVerificationToggle] Failed:", error);
      toast.error(isVerifiedByMe ? "Failed to remove verification" : "Failed to verify screenshot");
    } finally {
      setIsVerifying(false);
    }
  }, [
    screenshot,
    annotation,
    isVerifiedByMe,
    isVerifying,
    isProcessing,
    verifyCurrentScreenshot,
    unverifyCurrentScreenshot,
    notes,
  ]);

  // Handler for changing processing status filter
  const handleProcessingStatusChange = useCallback(
    (newStatus: ProcessingStatus | "all") => {
      const searchParams = new URLSearchParams();
      if (groupId) searchParams.set("group", groupId);
      if (newStatus !== "all") searchParams.set("processing_status", newStatus);
      const search = searchParams.toString();
      void navigate(`/annotate${search ? `?${search}` : ""}`, { replace: false });
    },
    [groupId, navigate]
  );

  const confirmSkip = useCallback(async (reason?: string) => {
    const ok = await confirm({
      title: "Skip Screenshot?",
      message: reason
        ? `Skip this screenshot and mark it as ${reason.replace(/_/g, " ")}?`
        : "Skip this screenshot? It will leave the current annotation queue.",
      confirmLabel: "Skip",
      cancelLabel: "Keep Reviewing",
      variant: "warning",
    });
    if (!ok) return;
    await skip(reason);
  }, [confirm, skip]);

  useKeyboardShortcuts([
    {
      key: "Escape",
      handler: () => {
        if (!isLoading) void confirmSkip();
      },
    },
    {
      key: "ArrowLeft",
      handler: () => {
        if (hasPrev) void navigatePrev();
      },
    },
    {
      key: "ArrowRight",
      handler: () => {
        if (hasNext) void navigateNext();
      },
    },
    {
      key: "v",
      handler: voidHandler(handleVerificationToggle),
    },
    {
      key: "c",
      handler: () => {
        if (!isVerifiedByMe) setCropEditorOpen(true);
      },
    },
  ]);

  if (noScreenshots) {
    return (
      <div className="flex min-h-full items-start justify-center px-4 py-8">
        <div className="w-full max-w-2xl rounded-eq-sm border border-eq-border bg-eq-surface p-5 shadow-sm">
          <h2 className="text-lg font-semibold text-eq-ink">
            No screenshots to annotate
          </h2>
          <p className="mt-1 text-sm text-eq-muted">
            {groupId ? (
              <>No screenshots match the current filter for group <span className="font-semibold">{groupId}</span>.</>
            ) : config.isLocalMode ? (
              "Load screenshots, run preprocessing, then return here to review grid alignment, hourly values, titles, and verification status."
            ) : (
              "No screenshots match the current filter."
            )}
          </p>

          <div className="mt-5 grid gap-4 text-left sm:grid-cols-2">
            <div>
              <div className="mb-2 text-xs font-medium uppercase tracking-wide text-eq-muted">
                Processing Status
              </div>
              <ProcessingStatusFilter
                value={(processingStatus as FilterStatus) || "all"}
                onChange={handleProcessingStatusChange}
              />
            </div>
            <div>
              <div className="mb-2 text-xs font-medium uppercase tracking-wide text-eq-muted">
                Verification Status
              </div>
              <VerificationFilter
                value={verificationFilter}
                onChange={setVerificationFilter}
              />
            </div>
          </div>

          <div className="mt-5 flex flex-wrap items-center gap-2">
            <button
              onClick={() => { void navigate("/"); }}
              className="rounded-eq-sm border border-eq-border bg-eq-surface px-3 py-1.5 text-sm font-medium text-eq-muted transition-colors hover:bg-eq-surface-muted"
            >
              {config.isLocalMode ? "Load screenshots" : "Back to Groups"}
            </button>
            {config.isLocalMode && (
              <Link
                to="/preprocessing"
                className="rounded-eq-sm bg-eq-primary px-3 py-1.5 text-sm font-medium text-eq-primary-ink transition-colors hover:bg-eq-primary"
              >
                Process screenshots
              </Link>
            )}
            {!config.isLocalMode && (
              <Link
                to="/upload"
                className="rounded-eq-sm bg-eq-primary px-3 py-1.5 text-sm font-medium text-eq-primary-ink transition-colors hover:bg-eq-primary"
              >
                Go to Upload
              </Link>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (!screenshot && !isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <p className="text-eq-muted">Screenshot not found. It may have been deleted.</p>
          <button onClick={() => { void (initialScreenshotIdRef.current ? loadById(initialScreenshotIdRef.current) : loadNext()).catch(() => { /* surfaced: the store records the load error and renders the not-found state */ }); }} className="mt-4 px-4 py-2 bg-eq-primary text-eq-primary-ink rounded-eq-sm">Retry</button>
          <Link to="/" className="ml-4 text-eq-primary">Back to screenshots</Link>
        </div>
      </div>
    );
  }

  if (!screenshot) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-eq-primary mx-auto mb-4"></div>
          <p className="text-eq-muted">Loading screenshot...</p>
        </div>
      </div>
    );
  }

  // currentIndex is 1-based (matches the selector's "{currentIndex}/{totalInFilter}").
  // On the last item currentIndex === totalInFilter → 100%, not 100.4%.
  const progressPercent = totalInFilter > 0 ? (currentIndex / totalInFilter) * 100 : 0;

  return (
    <ErrorBoundary fallback={
      <div className="flex items-center justify-center h-96">
        <div className="text-center max-w-md p-6">
          <p className="text-xl font-bold text-eq-ink mb-2">Something went wrong</p>
          <p className="text-eq-muted mb-4">{config.isTauri ? "Try reloading the app." : "Try reloading the page."}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-eq-primary text-eq-primary-ink rounded-eq-sm hover:bg-eq-primary"
          >
            {config.isTauri ? "Reload App" : "Reload Page"}
          </button>
        </div>
      </div>
    }>
    <div className="flex flex-col h-full" role="main" aria-label="Annotation workspace" data-testid="annotation-workspace">
      {/* Progress bar */}
      {totalInFilter > 0 && (
        <div className="h-1 w-full bg-eq-surface-muted flex-shrink-0" title={`${currentIndex} of ${totalInFilter}`}>
          <div
            className="h-full bg-eq-primary transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      )}
      {/* First-visit help banner */}
      {!helpDismissed && (
        <div className="flex items-center justify-between gap-2 px-3 py-2 bg-eq-info-bg border-b border-eq-info text-sm text-eq-info flex-shrink-0">
          <span>Drag the blue grid to align with the bar graph. Review hourly values (normally 0-60 min; values above 60 are flagged) and app title, then click Verify. Press <kbd className="px-1 py-0.5 text-xs font-mono bg-eq-info-bg rounded-eq-sm">?</kbd> for shortcuts.</span>
          <button
            onClick={() => { setHelpDismissed(true); try { localStorage.setItem("annotation-help-dismissed", "1"); } catch { /* ignore */ } }}
            className="text-eq-info hover:text-eq-info flex-shrink-0 p-0.5"
            aria-label="Dismiss help"
          >
            &#x2715;
          </button>
        </div>
      )}
      {qualityFlags?.suspected_all_devices && (
        <div className="bg-eq-warning-bg border-b border-eq-warning px-4 py-2 text-sm text-eq-warning flex-shrink-0">
          <span className="font-semibold">
            {explicitAllDevices ? "All Devices detected:" : "Suspected All Devices:"}
          </span>{" "}
          {qualityFlags.all_devices_reasons.join("; ") ||
            "this screenshot may combine usage from multiple devices."}{" "}
          {explicitAllDevices
            ? "This is combined cross-device usage and is invalid for this study."
            : "Treat it as potentially invalid for the study."}{" "}
          Annotation and reprocessing remain available for review.
        </div>
      )}
      {hasCurrentProcessingFailure && (
        <div className="bg-eq-danger-bg border-b border-eq-danger px-4 py-2 text-sm text-eq-danger flex-shrink-0">
          <span className="font-semibold">
            {hasCurrentOcrFailure ? "OCR failed." : "Automated processing failed."}
          </span>{" "}
          {failureReasons.map(formatFailureReasonForDisplay).join("; ")}
          {failureReasons.length > 0 ? ". " : ""}
          {ocrFailed && !hasCurrentOcrFailure
            ? "An OCR failure from an earlier attempt is also retained in the audit history. "
            : ""}
          You can still place the grid, enter the title/hourly values, annotate, and reprocess this image.
          Its export row retains Processing Status = Failed; OCR Failed records any attempt where OCR itself failed.
        </div>
      )}
      <div className="flex gap-1 flex-1 min-h-0">
      {/* Left Column - Grid Selector */}
      <div className="flex-1">
        <div className="bg-eq-surface h-full p-1 flex items-center justify-center relative">
          <div className="w-full max-w-3xl">
            {imageUrl ? (
              <GridSelector
                imageUrl={imageUrl}
                onGridSelect={handleGridSelect}
                initialCoords={gridCoords ?? undefined}
                disabled={isVerifiedByMe}
                imageType={screenshot.image_type}
                extractedTitle={screenshot.extracted_title}
                onTitleChange={setTitle}
                data-testid="grid-selector"
              />
            ) : (
              <Skeleton className="w-full aspect-[9/16] max-h-[70vh]" />
            )}
          </div>
        </div>
      </div>

      {/* Center Column - Cropped Graph + Hourly Bars */}
      <div className="flex-[2] min-h-0">
        <div className="bg-eq-surface h-full flex flex-col relative overflow-y-auto min-h-0">
          {/* Screenshot metadata header */}
          <div className="bg-eq-surface-muted px-4 py-2 rounded-t text-sm flex-shrink-0 border-b border-eq-border text-center space-y-1">
            <div className="flex items-center justify-center gap-4 text-eq-ink">
              {showIdentifierMetadata && screenshot.group_id && (
                <span><span className="font-semibold text-eq-muted">Group:</span> {screenshot.group_id}</span>
              )}
              {processingStatus && (
                <span><span className="font-semibold text-eq-muted">Subgroup:</span> <span className="capitalize">{processingStatus}</span></span>
              )}
              {showIdentifierMetadata && screenshot.participant_id && (
                <span><span className="font-semibold text-eq-muted">ID:</span> {screenshot.participant_id}</span>
              )}
              {screenshot.screenshot_date && (
                <span><span className="font-semibold text-eq-muted">Date:</span> {screenshot.screenshot_date}</span>
              )}
              <span className="text-eq-muted font-mono">#{screenshot.id}</span>
            </div>
            {showIdentifierMetadata && screenshot.original_filepath && (
              <div className="text-xs text-eq-muted">
                <span className="font-semibold text-eq-muted">Source:</span> {screenshot.original_filepath}
              </div>
            )}
          </div>
          {/* Preprocessing status banner */}
          {(() => {
            const pp = (screenshot.processing_metadata as Record<string, unknown>)?.preprocessing as Record<string, unknown> | undefined;
            const stageStatus = pp?.stage_status as Record<string, string> | undefined;
            if (!stageStatus) return null;
            const problemStages = Object.entries(stageStatus).filter(
              ([, st]) => st === "invalidated" || st === "failed",
            );
            if (problemStages.length === 0) return null;
            const stageNames = problemStages.map(([s]) => s.replace(/_/g, " ")).join(", ");
            return (
              <div className="bg-eq-warning-bg border-b border-eq-warning px-4 py-2 text-sm flex items-center gap-2">
                <span className="text-eq-warning">
                  Preprocessing issue: {stageNames} {problemStages.length === 1 ? "is" : "are"} {problemStages[0]![1]}.
                </span>
                <Link
                  to={`/preprocessing?screenshot_id=${screenshot.id}&returnUrl=${encodeURIComponent(`/annotate/${screenshot.id}`)}`}
                  className="text-eq-primary hover:text-eq-primary underline text-xs font-medium"
                >
                  Fix in Preprocessing &rarr;
                </Link>
              </div>
            );
          })()}
          {consensus && (
            <div className="bg-eq-info-bg border-b border-eq-info px-4 py-1.5 text-xs flex items-center gap-3">
              <span className="font-medium text-eq-info">
                Consensus ({consensus.total_annotations} annotations, {consensus.agreement_percentage}% agreement)
              </span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-eq-success" /> Agree</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-eq-warning" /> Minor diff</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-eq-danger" /> Major diff</span>
            </div>
          )}
          <div className="flex-1 flex items-center justify-center p-4 min-h-0">
            <div className="w-full">
              {!imageUrl ? (
                <Skeleton className="w-full" height="12rem" />
              ) : displayMode === "overlay" ? (
                <HourlyUsageOverlay
                  data={hourlyValues}
                  onChange={updateHour}
                  imageUrl={imageUrl}
                  gridCoords={gridCoords}
                  axisMaximumMinutes={qualityFlags?.axis_max_minutes ?? null}
                  {...(consensus ? { consensus } : {})}
                  readOnly={isVerifiedByMe}
                />
              ) : (
                <>
                  <CroppedGraphViewer
                    imageUrl={imageUrl}
                    gridCoords={gridCoords}
                    targetWidth={800}
                  />
                  <HourlyUsageEditor
                    data={hourlyValues}
                    onChange={updateHour}
                    readOnly={isVerifiedByMe}
                    axisMaximumMinutes={qualityFlags?.axis_max_minutes ?? null}
                  />
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Right Column - Info Panel */}
      <div className="flex-1">
        <div className="bg-eq-surface p-2 h-full flex items-center justify-center">
          <div className="w-full space-y-2 overflow-y-auto max-h-full px-1">
            {/* Screenshot Navigator */}
            <div className="border-b border-eq-border pb-2">
              <ScreenshotSelector
                currentScreenshot={screenshot}
                screenshotList={screenshotList}
                currentIndex={currentIndex}
                totalInFilter={totalInFilter}
                hasNext={hasNext}
                hasPrev={hasPrev}
                onNavigateNext={onNavigateNextStable}
                onNavigatePrev={onNavigatePrevStable}
                onSelectScreenshot={onSelectScreenshotStable}
                onSearch={onSearchStable}
                onLoadMore={onLoadMoreStable}
                isLoading={isLoading}
                currentUsername={username}
              />
            </div>

            {/* Filters */}
            <CollapsibleSection title="Filters" storageKey="annotation-filters">
              <div className="space-y-2">
                <div>
                  <div className="text-xs text-eq-muted mb-1">Status</div>
                  <ProcessingStatusFilter
                    value={(processingStatus as FilterStatus) || "all"}
                    onChange={handleProcessingStatusChange}
                  />
                </div>
                <div>
                  <div className="text-xs text-eq-muted mb-1">Verified</div>
                  <VerificationFilter
                    value={verificationFilter}
                    onChange={setVerificationFilter}
                  />
                </div>
              </div>
            </CollapsibleSection>

            {/* Alignment Score Warning */}
            <AlignmentWarning alignmentScore={screenshot.alignment_score} />

            {/* Preprocessing Summary */}
            <PreprocessingSummary
              processingMetadata={screenshot.processing_metadata}
              onEditCrop={() => setCropEditorOpen(true)}
            />

            {/* Tools — always visible so users discover crop adjustment */}
            <CollapsibleSection title="Tools (C)" storageKey="annotation-tools">
              <div className="flex flex-col gap-1.5">
                <div className="flex gap-1">
                  <button
                    onClick={() => setCropEditorOpen(true)}
                    disabled={isVerifiedByMe}
                    className="flex-1 px-2 py-1.5 text-xs font-medium border border-eq-info rounded-eq-sm bg-eq-info-bg text-eq-secondary hover:bg-eq-info-bg disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-1"
                    title="Adjust the crop boundaries (C)"
                  >
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    Adjust Crop
                  </button>
                </div>
                {/* Undo/Redo the applied crop without opening the editor. Self-hides
                    until a crop exists. Keyboard is gated off while the crop modal
                    is open, since the modal renders its OWN CropHistoryControls
                    (which binds Cmd/Ctrl+Z); leaving both enabled would fire two
                    listeners on one keystroke → double-undo. This gate is
                    load-bearing — do not remove it. */}
                <CropHistoryControls
                  screenshotId={screenshot.id}
                  refreshKey={imageRefreshKey}
                  keyboard={!cropEditorOpen}
                  onRestored={() => {
                    void loadById(screenshot.id);
                    setImageRefreshKey((k) => k + 1);
                  }}
                />
              </div>
            </CollapsibleSection>

            {/* Totals Display */}
            <TotalsDisplay
              ocrTotal={screenshot.extracted_total}
              hourlyData={hourlyValues}
              isProcessing={isProcessing}
              onRecalculateOcr={voidHandler(handleRecalculateOcr)}
              isRecalculatingOcr={isRecalculatingOcr}
              showRecalculateButton={
                !isVerifiedByMe && screenshot.image_type === "screen_time"
              }
            />

            {/* View Mode Toggle */}
            <CollapsibleSection title="View Mode" storageKey="annotation-view-mode">
              <div className="flex gap-1">
                <button
                  onClick={() => setDisplayMode("overlay")}
                  className={`flex-1 px-2 py-1 text-xs rounded-eq-sm ${
                    displayMode === "overlay"
                      ? "bg-eq-primary text-eq-primary-ink"
                      : "bg-eq-surface-muted text-eq-muted hover:bg-eq-surface-muted"
                  }`}
                >
                  Overlay
                </button>
                <button
                  onClick={() => setDisplayMode("separate")}
                  className={`flex-1 px-2 py-1 text-xs rounded-eq-sm ${
                    displayMode === "separate"
                      ? "bg-eq-primary text-eq-primary-ink"
                      : "bg-eq-surface-muted text-eq-muted hover:bg-eq-surface-muted"
                  }`}
                >
                  Separate
                </button>
              </div>
            </CollapsibleSection>

            {/* Potential Duplicate Warning */}
            {screenshot?.potential_duplicate_of && (
              <div className="border-b border-eq-border pb-2">
                <DuplicateWarning
                  duplicateId={screenshot.potential_duplicate_of}
                  duplicateStatus={(screenshot as Record<string, unknown>).duplicate_status as string | null}
                  onSkipThis={() => {
                    void confirmSkip("duplicate");
                  }}
                  onGoToDuplicate={() => {
                    if (screenshot?.potential_duplicate_of) {
                      void loadById(screenshot.potential_duplicate_of);
                    }
                  }}
                  isLoading={isLoading}
                />
              </div>
            )}

            {/* Issues */}
            {processingIssues && processingIssues.length > 0 && (
              <div className="border-b border-eq-border pb-2">
                <IssueDisplay issues={processingIssues} />
              </div>
            )}

            {/* Reprocessing Buttons */}
            <CollapsibleSection title="Reprocess Grid" storageKey="annotation-reprocess" defaultOpen={false}>
              <div className={isVerifiedByMe ? "opacity-50" : ""}>
              <div className="flex gap-1">
                <button
                  onClick={() => { void handleReprocess("ocr_anchored"); }}
                  disabled={
                    isVerifiedByMe || reprocessingMethod !== null || isLoading
                  }
                  className={`flex-1 py-2 px-2 text-xs border rounded-eq-sm flex items-center justify-center gap-1 ${
                    screenshot?.processing_method === "ocr_anchored"
                      ? "bg-eq-info-bg text-eq-secondary border-eq-info"
                      : "bg-eq-info-bg text-eq-secondary border-eq-info hover:bg-eq-info-bg"
                  } disabled:opacity-50 disabled:cursor-not-allowed`}
                  title={
                    isVerifiedByMe
                      ? "Unverify to reprocess"
                      : "Reprocess using OCR text anchors"
                  }
                >
                  {reprocessingMethod === "ocr_anchored" ? (
                    <div className="animate-spin h-3 w-3 border-2 border-eq-secondary border-t-transparent rounded-full" />
                  ) : (
                    <svg
                      className="w-3 h-3"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                      />
                    </svg>
                  )}
                  OCR
                </button>
                <button
                  onClick={() => { void handleReprocess("line_based"); }}
                  disabled={
                    isVerifiedByMe || reprocessingMethod !== null || isLoading
                  }
                  className={`flex-1 py-2 px-2 text-xs border rounded-eq-sm flex items-center justify-center gap-1 ${
                    screenshot?.processing_method === "line_based"
                      ? "bg-eq-info-bg text-eq-info border-eq-info"
                      : "bg-eq-info-bg text-eq-info border-eq-info hover:bg-eq-info-bg"
                  } disabled:opacity-50 disabled:cursor-not-allowed`}
                  title={
                    isVerifiedByMe
                      ? "Unverify to reprocess"
                      : "Reprocess using visual line detection"
                  }
                >
                  {reprocessingMethod === "line_based" ? (
                    <div className="animate-spin h-3 w-3 border-2 border-eq-primary border-t-transparent rounded-full" />
                  ) : (
                    <svg
                      className="w-3 h-3"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                      />
                    </svg>
                  )}
                  Lines
                </button>
              </div>
              <div className="text-xs text-eq-muted mt-1 text-center">
                {isVerifiedByMe
                  ? "Verified (read-only)"
                  : screenshot?.processing_method
                    ? `Current: ${screenshot.processing_method === "ocr_anchored" ? "OCR" : screenshot.processing_method === "line_based" ? "Lines" : screenshot.processing_method}`
                    : "Click to detect grid"}
              </div>
              </div>
            </CollapsibleSection>

            {/* Notes */}
            <CollapsibleSection title="Notes" storageKey="annotation-notes" defaultOpen={false}>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-2 py-1 border border-eq-border rounded-eq-sm text-sm focus:outline-none focus:ring-1 focus:ring-eq-focus resize-none"
                placeholder="Optional notes..."
                aria-label="Annotation notes"
                rows={2}
              />
            </CollapsibleSection>

            {/* Action Buttons */}
            <div className="pt-2 space-y-2">
              {/* Verify Button */}
              {(() => {
                const isMissingTitle =
                  screenshot.image_type === "screen_time" &&
                  !screenshot.extracted_title;
                const canVerify = !isMissingTitle || isVerifiedByMe;
                return (
                  <button
                    onClick={voidHandler(handleVerificationToggle)}
                    disabled={!canVerify || isVerifying}
                    data-testid={isVerifiedByMe ? "unverify-button" : "verify-button"}
                    aria-label={isVerifiedByMe ? "Remove verification" : "Mark screenshot as verified"}
                    title={
                      isMissingTitle && !isVerifiedByMe
                        ? "Cannot verify: App/Title is required"
                        : undefined
                    }
                    className={`w-full py-2 text-sm font-medium rounded-eq-sm transition-colors ${
                      isVerifiedByMe
                        ? "bg-eq-success text-eq-primary-ink hover:bg-eq-success"
                        : canVerify
                          ? "bg-eq-success-bg text-eq-success hover:bg-eq-success-bg border border-eq-success"
                          : "bg-eq-surface-muted text-eq-muted border border-eq-border cursor-not-allowed"
                    }`}
                  >
                    {isVerifying
                      ? "Verifying..."
                      : isVerifiedByMe
                        ? "Verified (V to undo)"
                        : isMissingTitle
                          ? "Title required to verify"
                          : "Mark as Verified (V)"}
                  </button>
                );
              })()}

              {/* Verifiers Info */}
              {allVerifierUsernames.length > 0 && (
                <div className="text-xs text-center text-eq-info bg-eq-info-bg rounded-eq-sm py-1">
                  Verified by: {allVerifierUsernames.join(", ")}
                </div>
              )}

              {/* Skip Button with reasons dropdown */}
              <div className="relative" ref={skipMenuRef}>
                <div className="flex">
                  <button
                    onClick={() => void confirmSkip()}
                    disabled={isLoading}
                    className="flex-1 py-2 text-sm bg-eq-surface-muted text-eq-ink rounded-l hover:bg-eq-surface-muted disabled:opacity-50"
                    aria-label="Skip this screenshot"
                    title="Skip this screenshot"
                  >
                    Skip (Esc)
                  </button>
                  <button
                    onClick={() => setSkipMenuOpen((o) => !o)}
                    disabled={isLoading}
                    className="px-2 py-2 text-sm bg-eq-surface-muted text-eq-ink rounded-r border-l border-eq-border hover:bg-eq-surface-muted disabled:opacity-50"
                    title="Skip with reason"
                    aria-label="Skip with reason"
                  >
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                  </button>
                </div>
                {skipMenuOpen && (
                  <div className="absolute bottom-full left-0 right-0 mb-1 bg-eq-surface border border-eq-border rounded-eq-sm shadow-lg z-20">
                    {["Duplicate", "Bad quality", "Wrong type", "Daily total", "Other"].map((reason) => (
                      <button
                        key={reason}
                        onClick={() => {
                          setSkipMenuOpen(false);
                          void confirmSkip(reason.toLowerCase().replace(/ /g, "_"));
                        }}
                        className="w-full text-left px-3 py-1.5 text-xs text-eq-ink hover:bg-eq-surface-muted first:rounded-t last:rounded-b"
                      >
                        {reason}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Auto-save Status */}
              <SaveStatusIndicator
                isSaving={isSaving}
                lastSaved={lastSaved}
                timeSinceLastSave={timeSinceLastSave}
                saveFailCount={saveFailCount}
                lastError={lastError}
                hasUnsavedChanges={hasUnsavedChanges}
                onRetry={retrySave}
              />

              <div className="text-xs text-eq-muted text-center space-y-1">
                <div>
                  <strong>←/→</strong> navigate | <strong>V</strong> verify |{" "}
                  <strong>Esc</strong> skip | <strong>C</strong> crop
                </div>
                <div>
                  <strong>WASD</strong> move grid | <strong>Shift+WASD</strong>{" "}
                  move 10px | <strong>Ctrl+WASD</strong> resize
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {ConfirmDialog}

      {/* Crop Adjust Modal */}
      {screenshot && (
        <CropAdjustModal
          key={`crop-${screenshot.id}`}
          screenshotId={screenshot.id}
          isOpen={cropEditorOpen}
          onClose={() => setCropEditorOpen(false)}
          onCropApplied={() => {
            setCropEditorOpen(false);
            void loadById(screenshot.id);
            setImageRefreshKey((k) => k + 1);
          }}
          initialCrop={getCropRectFromEvent(getCurrentEvent(screenshot, "cropping"))}
        />
      )}
      {/* Shortcuts hint */}
      {!shortcutsHintDismissed && (
        <button
          onClick={() => { setShortcutsHintDismissed(true); try { localStorage.setItem("shortcuts-hint-dismissed", "1"); } catch { /* ignore */ } }}
          className="fixed bottom-4 right-4 text-xs text-eq-muted hover:text-eq-ink transition-colors"
        >
          Press ? for shortcuts
        </button>
      )}
      </div>
    </div>
    {/* Totals mismatch confirmation modal */}
    <Modal
      open={!!mismatchInfo}
      onOpenChange={(open) => { if (!open) mismatchInfo?.onCancel(); }}
      title="Totals Mismatch"
      size="sm"
    >
      {mismatchInfo && (
        <>
          <p className="text-sm text-eq-muted mb-4">
            The bar total <span className="font-semibold text-eq-ink">{mismatchInfo.barStr}</span> doesn&apos;t
            match the OCR total <span className="font-semibold text-eq-ink">{mismatchInfo.ocrStr}</span>.
          </p>
          <p className="text-sm text-eq-muted mb-4">
            You may want to adjust the grid position first. Verify anyway?
          </p>
          <div className="flex justify-end gap-3">
            <button
              onClick={mismatchInfo.onCancel}
              className="px-4 py-2 text-sm font-medium text-eq-ink bg-eq-surface-muted rounded-eq-md hover:bg-eq-surface-muted"
            >
              Go Back
            </button>
            <button
              onClick={mismatchInfo.onConfirm}
              className="px-4 py-2 text-sm font-medium text-eq-primary-ink bg-eq-warning rounded-eq-md hover:bg-eq-warning"
            >
              Verify Anyway
            </button>
          </div>
        </>
      )}
    </Modal>
    </ErrorBoundary>
  );
};
