import {
  calculateTotalMinutes,
  formatMinutes,
  classifyTotalsAgreement,
  totalsDiffMinutes,
} from "@/utils/formatters";

interface TotalsDisplayProps {
  ocrTotal: string | null | undefined;
  hourlyData: Record<string, number>;
  isProcessing: boolean;
  onRecalculateOcr: () => void;
  isRecalculatingOcr: boolean;
  showRecalculateButton: boolean;
}

export function TotalsDisplay({
  ocrTotal,
  hourlyData,
  isProcessing,
  onRecalculateOcr,
  isRecalculatingOcr,
  showRecalculateButton,
}: TotalsDisplayProps) {
  const totalMinutes = calculateTotalMinutes(hourlyData);
  // Three-state agreement (shared comparator with the Verify gate):
  //   exact (green) — totals agree to the minute
  //   tolerated (amber) — non-zero gap below the mismatch threshold; the
  //     pipeline reconciles it and Verify passes it silently, so it's NOT red,
  //     but it's also NOT exact — surface the gap honestly instead of a green
  //     ring that claims a perfect match.
  //   mismatch (red) — gap ≥ threshold; the Verify gate flags this too.
  const agreement = classifyTotalsAgreement(hourlyData, ocrTotal);
  const diffMinutes = totalsDiffMinutes(hourlyData, ocrTotal);

  const highlightClass =
    agreement === "exact"
      ? "ring-2 ring-eq-success bg-eq-success-bg"
      : agreement === "tolerated"
        ? "ring-2 ring-eq-warning bg-eq-warning-bg"
        : agreement === "mismatch"
          ? "ring-2 ring-eq-danger bg-eq-danger-bg"
          : "";

  return (
    <div
      className={`border-b border-eq-border pb-2 rounded-eq-md p-2 ${highlightClass}`}
    >
      <div className="flex flex-col items-center text-center">
        {/* OCR Total */}
        <div className="mb-1">
          <div className="text-xs text-eq-muted flex items-center justify-center gap-1">
            OCR Total
            {showRecalculateButton && (
              <button
                onClick={onRecalculateOcr}
                disabled={isRecalculatingOcr}
                className="text-eq-muted hover:text-eq-primary disabled:opacity-50"
                title="Recalculate OCR total"
              >
                {isRecalculatingOcr ? (
                  <svg
                    className="w-3 h-3 animate-spin"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    />
                  </svg>
                ) : (
                  <svg
                    className="w-3 h-3"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                    />
                  </svg>
                )}
              </button>
            )}
          </div>
          <div className="text-lg font-medium text-eq-ink" data-testid="ocr-total">
            {ocrTotal || "—"}
          </div>
        </div>

        {/* Bar Total */}
        <div>
          <div className="text-xs text-eq-muted">Bar Total</div>
          <div
            className="text-lg font-bold text-eq-primary flex items-center justify-center gap-1"
            data-testid="bar-total"
          >
            {formatMinutes(totalMinutes)}
            {isProcessing && (
              <div
                className="animate-spin h-3 w-3 border-2 border-eq-primary border-t-transparent rounded-full"
                data-testid="processing-indicator"
              ></div>
            )}
          </div>
          {/* Honest gap caption — amber "within tolerance" vs red "mismatch" so
              a non-zero difference is never hidden behind a green "matches" ring. */}
          {diffMinutes !== null && diffMinutes > 0 && (
            <div
              className={`text-[10px] mt-0.5 ${
                agreement === "mismatch" ? "text-eq-danger" : "text-eq-warning"
              }`}
              data-testid="totals-gap"
            >
              {agreement === "tolerated"
                ? `≈ off by ${diffMinutes}m (within tolerance)`
                : `off by ${diffMinutes}m`}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
