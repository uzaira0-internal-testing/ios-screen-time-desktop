import React from "react";
import { Link } from "react-router";
import { AlertTriangle, X } from "lucide-react";
import { config } from "@/config";

/**
 * Warns when local browser storage is nearly full, BEFORE a write fails or a
 * dataset grows too large to boot.
 *
 * The offline build keeps everything (images, OCR caches, annotations) in
 * IndexedDB + OPFS against the browser's per-origin quota. When that quota is
 * exhausted, writes start throwing and — on weaker machines — the app can grow
 * large enough that a cold boot OOMs. This banner gives the user a chance to
 * export a backup and free space while the app is still healthy.
 *
 * Self-measuring (navigator.storage.estimate), dismissible for the session,
 * and a no-op in server mode (the server owns storage there).
 */
const PRESSURE_THRESHOLD = 0.8; // 80% of quota
const DISMISS_KEY = "storagePressureDismissed";

export function StoragePressureBanner() {
  const [pct, setPct] = React.useState<number | null>(null);
  const [dismissed, setDismissed] = React.useState(() => {
    try {
      return sessionStorage.getItem(DISMISS_KEY) === "1";
    } catch {
      return false;
    }
  });

  React.useEffect(() => {
    // Server mode delegates storage to the backend — nothing local to warn about.
    if (!config.isLocalMode || !navigator.storage?.estimate) return;
    let cancelled = false;
    navigator.storage
      .estimate()
      .then(({ usage, quota }) => {
        if (cancelled || !quota) return;
        // Clamp to 1 — browsers can transiently report usage > quota, which
        // would otherwise render a nonsensical "104% full".
        setPct(Math.min(1, (usage ?? 0) / quota));
      })
      .catch(() => {
        /* estimate unsupported — stay silent */
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (dismissed || pct === null || pct < PRESSURE_THRESHOLD) return null;

  const isCritical = pct >= 0.95;
  const pctLabel = Math.round(pct * 100);

  function dismiss() {
    setDismissed(true);
    try {
      sessionStorage.setItem(DISMISS_KEY, "1");
    } catch {
      /* private mode — dismissal just won't persist */
    }
  }

  return (
    <div
      role="alert"
      className={`mb-4 flex items-start gap-3 rounded-eq-md p-3 ring-2 ${
        isCritical
          ? "ring-eq-danger bg-eq-danger-bg"
          : "ring-eq-warning bg-eq-warning-bg"
      }`}
    >
      <AlertTriangle
        className={`mt-0.5 h-5 w-5 shrink-0 ${
          isCritical ? "text-eq-danger" : "text-eq-warning"
        }`}
      />
      <div className="min-w-0 flex-1 text-sm">
        <div
          className={`font-medium ${
            isCritical ? "text-eq-danger" : "text-eq-warning"
          }`}
        >
          Local storage is {pctLabel}% full
        </div>
        <div className="text-eq-muted">
          {isCritical
            ? "New uploads may fail and the app can get slow to load. "
            : config.isTauri
              ? "You're approaching the app's storage limit. "
              : "You're approaching the browser's storage limit. "}
          Export a backup from{" "}
          <Link to="/settings" className="text-eq-primary hover:underline">
            Settings → Workspace
          </Link>
          , then delete processed groups to free space.
        </div>
      </div>
      <button
        type="button"
        aria-label="Dismiss storage warning"
        className="shrink-0 rounded-eq-sm p-1 text-eq-muted hover:bg-eq-surface-muted focus-ring"
        onClick={dismiss}
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
