interface UploadProgressBarProps {
  completed: number;
  total: number;
  errors: string[];
}

export const UploadProgressBar = ({ completed, total, errors }: UploadProgressBarProps) => {
  const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
  const batchSize = 60;
  const currentBatch = Math.floor(completed / batchSize) + 1;
  const totalBatches = Math.ceil(total / batchSize);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-sm">
        <span className="text-eq-muted" aria-live="polite">
          Uploading{totalBatches > 1 ? ` batch ${currentBatch}/${totalBatches}` : ""}
          {" "}({completed}/{total})
        </span>
        <span className="font-medium text-eq-muted">{pct}%</span>
      </div>
      <div
        className="w-full h-2.5 bg-eq-surface-muted rounded-full overflow-hidden"
        role="progressbar"
        aria-label="Upload progress"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={pct}
        aria-valuetext={`${completed} of ${total} uploaded`}
      >
        {pct === 0 ? (
          // Indeterminate pulse while waiting for the first batch to respond
          <div className="h-full bg-eq-primary rounded-full animate-pulse w-full opacity-60" />
        ) : (
          <div
            className="h-full bg-eq-primary rounded-full transition-all duration-300"
            style={{ width: `${pct}%` }}
          />
        )}
      </div>
      {errors.length > 0 && (
        <div className="mt-2 p-3 bg-eq-danger-bg border border-eq-danger rounded-eq-md" role="alert">
          <p className="text-sm font-medium text-eq-danger mb-1">
            {errors.length} error{errors.length !== 1 ? "s" : ""}:
          </p>
          <ul className="text-xs text-eq-danger space-y-0.5 max-h-24 overflow-y-auto">
            {errors.map((err, i) => (
              <li key={i}>{err}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
