import type { Screenshot } from "@/types";
import type { PreprocessingEventData } from "@/store/preprocessingStore";
import { StageReviewTable, type ResultHeader } from "./StageReviewTable";
import { displayText } from "@/lib/displayText";

const RESULT_HEADERS: ResultHeader[] = [
  { label: "Device", sortKey: "device_category" },
  { label: "Model", sortKey: "device_model" },
  { label: "Conf", sortKey: "confidence" },
  { label: "Orientation", sortKey: "orientation" },
];

function getResultSortValue(_s: Screenshot, event: PreprocessingEventData | null, sortKey: string): string | number | null {
  const result = event?.result as Record<string, unknown> | undefined;
  if (!result) return null;
  const val = result[sortKey];
  if (val == null) return null;
  if (typeof val === "number") return val;
  return displayText(val);
}

function renderResultColumns(_s: Screenshot, event: PreprocessingEventData | null) {
  const result = event?.result as Record<string, unknown> | undefined;

  return (
    <>
      <td className="px-2 py-1">
        {result ? (
          <span
            className={`inline-flex px-2 py-0.5 rounded-eq-sm text-xs font-medium ${
              result.device_category === "ipad"
                ? "bg-eq-info-bg text-eq-primary"
                : result.device_category === "iphone"
                  ? "bg-eq-success-bg text-eq-success"
                  : "bg-eq-surface-muted text-eq-muted"
            }`}
          >
            {result.device_category as string}
          </span>
        ) : (
          <span className="text-eq-muted">{"\u2014"}</span>
        )}
      </td>
      <td className="px-2 py-1 text-eq-muted text-xs">
        {(result?.device_model as string) || "\u2014"}
      </td>
      <td className="px-2 py-1">
        {result ? (
          <span
            className={`font-mono text-xs ${
              (result.confidence as number) >= 0.9
                ? "text-eq-success"
                : (result.confidence as number) >= 0.7
                  ? "text-eq-warning"
                  : "text-eq-danger"
            }`}
          >
            {Math.round((result.confidence as number) * 100)}%
          </span>
        ) : (
          "\u2014"
        )}
      </td>
      <td className="px-2 py-1 text-eq-muted text-xs">
        {(result?.orientation as string) || "\u2014"}
      </td>
    </>
  );
}

export const DeviceDetectionTab = () => {
  return (
    <StageReviewTable
      stage="device_detection"
      resultHeaders={RESULT_HEADERS}
      renderResultColumns={renderResultColumns}
      getResultSortValue={getResultSortValue}
    />
  );
};
