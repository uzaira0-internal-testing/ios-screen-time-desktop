import { useCallback, useEffect, useMemo, useState } from "react";
import { usePreprocessingStore } from "@/hooks/usePreprocessingWithDI";
import { useConfirmDialog } from "@/hooks/useConfirmDialog";
import { config } from "@/config";
import type { UploadFileItem } from "@/store/preprocessingStore";
import { UploadDropZone } from "./UploadDropZone";
import { UploadTagTable } from "./UploadTagTable";
import { UploadProgressBar } from "./UploadProgressBar";
import { voidHandler } from "@/lib/asyncHandler";

function useStorageWarning() {
  const [percentUsed, setPercentUsed] = useState<number | null>(null);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (!config.isLocalMode || !navigator.storage?.estimate) return;
    navigator.storage.estimate().then(({ usage, quota }) => {
      if (quota) setPercentUsed(((usage ?? 0) / quota) * 100);
    }).catch((e) => console.warn("[StorageWarning] estimate failed:", e));
  }, []);

  if (dismissed || percentUsed === null || percentUsed <= 80) return null;
  return { percentUsed, dismiss: () => setDismissed(true) };
}

export const BrowserUpload = () => {
  const uploadFiles = usePreprocessingStore((s) => s.uploadFiles);
  const setUploadFiles = usePreprocessingStore((s) => s.setUploadFiles);
  const uploadGroupId = usePreprocessingStore((s) => s.uploadGroupId);
  const setUploadGroupId = usePreprocessingStore((s) => s.setUploadGroupId);
  const uploadImageType = usePreprocessingStore((s) => s.uploadImageType);
  const setUploadImageType = usePreprocessingStore((s) => s.setUploadImageType);
  const isUploading = usePreprocessingStore((s) => s.isUploading);
  const uploadProgress = usePreprocessingStore((s) => s.uploadProgress);
  const uploadErrors = usePreprocessingStore((s) => s.uploadErrors);
  const startBrowserUpload = usePreprocessingStore((s) => s.startBrowserUpload);
  const cancelUpload = usePreprocessingStore((s) => s.cancelUpload);
  const setSelectedGroupId = usePreprocessingStore((s) => s.setSelectedGroupId);

  const { confirm, ConfirmDialog } = useConfirmDialog();
  const storageWarning = useStorageWarning();

  const canUpload = uploadFiles.length > 0 && uploadGroupId.trim().length > 0 && !isUploading;

  // Append new files to existing list (dedup by original_filepath)
  const appendFiles = useCallback(
    (newFiles: UploadFileItem[]) => {
      const existingPaths = new Set(uploadFiles.map((f) => f.original_filepath));
      const unique = newFiles.filter((f) => !existingPaths.has(f.original_filepath));
      setUploadFiles([...uploadFiles, ...unique]);
    },
    [uploadFiles, setUploadFiles],
  );

  const groups = usePreprocessingStore((s) => s.groups);
  const groupIds = useMemo(() => groups.map((g) => g.id), [groups]);
  const setPageMode = usePreprocessingStore((s) => s.setPageMode);
  const resetUploadResult = usePreprocessingStore((s) => s.resetUploadResult);

  const clearUpload = () => {
    resetUploadResult();
  };

  const storageBanner = storageWarning && (
    <div className="flex items-center justify-between p-3 rounded-eq-md border border-eq-warning bg-eq-warning-bg">
      <p className="text-sm text-eq-warning">
        Storage is {storageWarning.percentUsed.toFixed(0)}% full. Delete old groups to free space.
      </p>
      <button onClick={storageWarning.dismiss} className="ml-3 text-eq-warning hover:text-eq-warning text-sm font-medium">
        Dismiss
      </button>
    </div>
  );

  // Step 1: Drop zone (no files yet, no completed upload)
  if (uploadFiles.length === 0 && !isUploading && !uploadProgress) {
    return (
      <div className="space-y-4">
        {storageBanner}
        <UploadDropZone onFilesSelected={setUploadFiles} />
      </div>
    );
  }

  // Step 3: Uploading in progress
  if (isUploading && uploadProgress) {
    return (
      <div className="space-y-4">
        <UploadProgressBar
          completed={uploadProgress.completed}
          total={uploadProgress.total}
          errors={uploadErrors}
        />
        <button
          onClick={cancelUpload}
          className="px-4 py-2 text-sm font-medium text-eq-danger bg-eq-danger-bg border border-eq-danger rounded-eq-md hover:bg-eq-danger-bg"
        >
          Cancel Upload
        </button>
      </div>
    );
  }

  // Step 4: Upload finished — show persistent result until user acts
  if (!isUploading && uploadFiles.length === 0 && uploadProgress) {
    const succeeded = uploadProgress.completed;
    const failed = uploadErrors.length;
    const allOk = failed === 0;
    return (
      <div className="space-y-4">
        {/* Result banner */}
        <div className={`p-4 rounded-eq-md border ${allOk ? "bg-eq-success-bg border-eq-success" : "bg-eq-warning-bg border-eq-warning"}`}>
          <p className={`text-sm font-medium ${allOk ? "text-eq-success" : "text-eq-warning"}`}>
            {allOk
              ? `${succeeded} screenshot${succeeded !== 1 ? "s" : ""} uploaded successfully`
              : `${succeeded} uploaded, ${failed} failed`}
          </p>
          {failed > 0 && (
            <ul className="mt-2 text-xs text-eq-warning space-y-0.5 max-h-32 overflow-y-auto">
              {uploadErrors.map((err, i) => <li key={i}>{err}</li>)}
            </ul>
          )}
        </div>
        {/* Progress bar showing final state */}
        <UploadProgressBar
          completed={uploadProgress.completed}
          total={uploadProgress.total}
          errors={[]}
        />
        {/* Actions */}
        <div className="flex gap-3">
          <button
            onClick={clearUpload}
            className="px-4 py-2 text-sm border border-eq-border rounded-eq-md hover:bg-eq-surface-muted"
          >
            Upload More
          </button>
          <button
            onClick={() => {
              if (uploadGroupId) setSelectedGroupId(uploadGroupId);
              setPageMode("pipeline");
            }}
            className="px-4 py-2 text-sm font-medium text-eq-primary-ink bg-eq-primary rounded-eq-md hover:bg-eq-primary"
          >
            View in Pipeline →
          </button>
        </div>
      </div>
    );
  }

  // Step 2: Tag table with ability to add more folders
  return (
    <div className="space-y-4">
      {storageBanner}
      <UploadTagTable
        files={uploadFiles}
        groupId={uploadGroupId}
        imageType={uploadImageType}
        groupOptions={groupIds}
        onFilesChange={setUploadFiles}
        onGroupIdChange={setUploadGroupId}
        onImageTypeChange={setUploadImageType}
      />
      {/* Compact drop zone for adding more folders */}
      <UploadDropZone onFilesSelected={appendFiles} compact />
      <div className="flex items-center justify-between">
        <button
          onClick={voidHandler(async () => {
            if (uploadFiles.length > 0) {
              const ok = await confirm({ title: "Clear Files", message: `Clear all ${uploadFiles.length} selected files?`, confirmLabel: "Clear All", variant: "danger" });
              if (ok) setUploadFiles([]);
            }
          })}
          className="px-4 py-2 text-sm text-eq-muted border border-eq-border rounded-eq-md hover:bg-eq-surface-muted focus-ring"
        >
          Clear
        </button>
        <button
          onClick={voidHandler(startBrowserUpload)}
          disabled={!canUpload}
          className="px-6 py-2 text-sm font-medium text-eq-primary-ink bg-eq-primary rounded-eq-md hover:bg-eq-primary disabled:opacity-50 disabled:cursor-not-allowed focus-ring"
        >
          Upload {uploadFiles.length} File{uploadFiles.length !== 1 ? "s" : ""}
        </button>
      </div>
      {ConfirmDialog}
    </div>
  );
};
