import { afterAll, beforeAll, expect, test } from "bun:test";
import { Window } from "happy-dom";
import { act } from "react";
import { createRoot } from "react-dom/client";
import { ServiceContext } from "@/core/hooks/ServiceContext";
import { ServiceContainer } from "@/core/di/Container";
import { TOKENS } from "@/core/di/tokens";
import type { IPreprocessingService } from "@/core/interfaces";
let CropAdjustModal: typeof import("../CropAdjustModal").CropAdjustModal;

const descriptors = new Map<string, PropertyDescriptor | undefined>();
const images: TestImage[] = [];
class TestImage {
  naturalWidth = 500;
  naturalHeight = 500;
  src = "";
  onload: (() => void) | null = null;
  constructor() { images.push(this); }
}
beforeAll(async () => {
  const win = new Window();
  for (const key of ["window", "document", "navigator", "localStorage", "Image", "ResizeObserver", "IS_REACT_ACT_ENVIRONMENT"]) {
    descriptors.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    const value = key === "window" ? win : key === "Image" ? TestImage : key === "IS_REACT_ACT_ENVIRONMENT" ? true : win[key as keyof Window];
    Object.defineProperty(globalThis, key, { configurable: true, value });
  }
  ({ CropAdjustModal } = await import("../CropAdjustModal"));
});
afterAll(() => {
  for (const [key, descriptor] of descriptors) {
    if (descriptor) Object.defineProperty(globalThis, key, descriptor);
    else Reflect.deleteProperty(globalThis, key);
  }
});
test("crop Apply stays disabled until the current screenshot image and crop load", async () => {
  const container = new ServiceContainer();
  container.register(TOKENS.PREPROCESSING_PIPELINE_SERVICE, {
    getOriginalImageUrl: async () => "image.png",
    getCropHistory: async () => ({ canUndo: false, canRedo: false }),
  } as unknown as IPreprocessingService);
  const element = document.createElement("div");
  const root = createRoot(element);
  const render = (id: number) => <ServiceContext.Provider value={container}><CropAdjustModal screenshotId={id} inline isOpen onClose={() => {}} onCropApplied={() => {}} onApplyAndNext={() => {}} /></ServiceContext.Provider>;
  await act(async () => { root.render(render(1)); });
  const applyButtons = () => [...element.querySelectorAll("button")].filter((b) => b.textContent?.startsWith("Apply"));
  expect(applyButtons().every((button) => button.disabled)).toBe(true);
  await act(async () => { images[0]!.onload?.(); });
  expect(applyButtons().every((button) => !button.disabled)).toBe(true);
  await act(async () => { root.render(render(2)); });
  expect(applyButtons().every((button) => button.disabled)).toBe(true);
  await act(async () => { root.unmount(); });
});
