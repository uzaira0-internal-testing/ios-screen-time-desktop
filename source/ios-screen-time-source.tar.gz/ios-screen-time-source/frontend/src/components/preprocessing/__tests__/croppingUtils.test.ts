import { expect, test } from "bun:test";
import { getCropRectFromEvent } from "../croppingUtils";
import type { PreprocessingEventData } from "@/store/preprocessingStore";

test("manual crop prefers validated result crop_region over inference", () => {
  const bounds = { left: 12, top: 34, right: 200, bottom: 300 };
  const event = { params: {}, result: { manual: true, was_cropped: true, crop_region: bounds, original_dimensions: [500, 600], cropped_dimensions: [188, 266] } } as unknown as PreprocessingEventData;
  expect(getCropRectFromEvent(event)).toEqual(bounds);
  expect(getCropRectFromEvent({ ...event, result: { ...event.result, crop_region: { ...bounds, left: NaN } } })).toEqual({ left: 312, top: 334, right: 500, bottom: 600 });
});
