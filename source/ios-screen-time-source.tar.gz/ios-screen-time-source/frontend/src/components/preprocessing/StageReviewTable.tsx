import { memo, useCallback, useDeferredValue, useEffect, useMemo, useRef } from "react";
import { useVirtualizer } from "@/lib/virtual";
import { usePreprocessingStore, useScreenshotImageUrl } from "@/hooks/usePreprocessingWithDI";
import type { Stage, StageStatus, PreprocessingEventData } from "@/store/preprocessingStore";
import type { Screenshot } from "@/types";
import { useSettingsStore } from "@/store/settingsStore";
import { Skeleton } from "@/components/ui/Skeleton";
import { StageStatus as SS } from "@/core/generated/constants";
import { getCurrentEvent, type ResultHeader } from "./stageReviewUtils";
import { config } from "@/config";
import { useConfirmDialog } from "@/hooks/useConfirmDialog";
import { voidHandler } from "@/lib/asyncHandler";

export type { ResultHeader };

type SortDirection = "asc" | "desc";

interface StageReviewTableProps {
  stage: Stage;
  renderResultColumns: (screenshot: Screenshot, event: PreprocessingEventData | null) => React.ReactNode;
  resultHeaders: ResultHeader[];
  /** Return a comparable value for a result column. Strings are compared via localeCompare, numbers numerically. */
  getResultSortValue?: (screenshot: Screenshot, event: PreprocessingEventData | null, sortKey: string) => string | number | null;
}

const STATUS_BADGES: Record<StageStatus, { label: string; classes: string }> = {
  completed: { label: "Completed", classes: "bg-eq-success-bg text-eq-success" },
  invalidated: { label: "Invalidated", classes: "bg-eq-warning-bg text-eq-warning" },
  pending: { label: "Pending", classes: "bg-eq-surface-muted text-eq-muted" },
  running: { label: "Running", classes: "bg-eq-info-bg text-eq-primary" },
  failed: { label: "Failed", classes: "bg-eq-danger-bg text-eq-danger" },
  skipped: { label: "Skipped", classes: "bg-eq-info-bg text-eq-secondary" },
  cancelled: { label: "Cancelled", classes: "bg-eq-surface-muted text-eq-muted" },
};

const STATUS_SORT_ORDER: Record<StageStatus, number> = {
  running: 0,
  failed: 1,
  pending: 2,
  invalidated: 3,
  cancelled: 4,
  skipped: 4.5,
  completed: 5,
};

function SortIcon({ column, sortColumn, sortDirection }: { column: string; sortColumn: string; sortDirection: SortDirection }) {
  if (column !== sortColumn) {
    return <span className="text-eq-muted ml-1">&#8597;</span>;
  }
  return <span className="text-eq-primary ml-1">{sortDirection === "asc" ? "\u25B2" : "\u25BC"}</span>;
}

const ROW_HEIGHT = 48; // px — matches py-1 + h-10 thumbnail

interface RowProps {
  screenshot: Screenshot;
  stage: Stage;
  status: StageStatus;
  isException: boolean;
  event: PreprocessingEventData | null;
  showIdentifierMetadata: boolean;
  isHighlighted: boolean;
  highlightedRef: React.Ref<HTMLTableRowElement>;
  onEnterQueue: (screenshotId: number) => void;
  onLoadLog: (id: number) => void;
  onSkip: (screenshotId: number) => void;
  renderResultColumns: (screenshot: Screenshot, event: PreprocessingEventData | null) => React.ReactNode;
  imageVersion: number;
}

const TableRow = memo(function TableRow({
  screenshot,
  stage,
  status,
  isException,
  event,
  showIdentifierMetadata,
  isHighlighted,
  highlightedRef,
  onEnterQueue,
  onLoadLog,
  onSkip,
  renderResultColumns,
  imageVersion,
}: RowProps) {
  const unskipStage = usePreprocessingStore((s) => s.unskipStage);
  const badge = STATUS_BADGES[status] ?? STATUS_BADGES.pending;
  // The device-detection review must show the PRE-CROP original — that's the
  // image detection ran on. Every other stage's relevant image is the current
  // blob (cropping output, redaction output, OCR input). Route only this stage
  // through the stage-image path: server falls back to base_file_path, WASM maps
  // it to the preserved "original" blob.
  const isDeviceStage = stage === "device_detection";
  const imageUrl = useScreenshotImageUrl(
    screenshot.id,
    isDeviceStage ? "getStageImageUrl" : "getImageUrl",
    isDeviceStage ? "device_detection" : undefined,
    imageVersion,
  );
  const ppMeta = (screenshot.processing_metadata as Record<string, unknown>)?.preprocessing as Record<string, unknown> | undefined;
  const imageWriteFailed = ppMeta?.image_write_failed === true;
  return (
    <tr
      ref={isHighlighted ? highlightedRef : undefined}
      className={`border-b border-eq-border hover:bg-eq-surface-muted ${
        isHighlighted ? "bg-eq-info-bg ring-2 ring-eq-focus" : ""
      } ${isException ? "bg-eq-warning-bg" : ""} ${
        status === SS.INVALIDATED ? "bg-eq-warning-bg" : ""
      }`}
    >
      <td className="px-2 py-1">
        <button
          onClick={() => onEnterQueue(screenshot.id)}
          className="block cursor-pointer hover:ring-2 hover:ring-eq-focus rounded-eq-sm transition-shadow"
          title="Open in review queue"
          aria-label={`Review screenshot ${screenshot.id} in queue`}
        >
          {imageUrl ? (
            <img
              src={imageUrl}
              alt={`Screenshot ${screenshot.id}`}
              className="w-8 h-10 object-cover rounded-eq-sm bg-eq-surface-muted"
              loading="lazy"
            />
          ) : (
            <Skeleton className="w-8 h-10" />
          )}
        </button>
      </td>
      <td className="px-2 py-1 font-mono text-eq-muted">{screenshot.id}</td>
      {showIdentifierMetadata ? (
        <td className="px-2 py-1" title={screenshot.participant_id || undefined}>
          {screenshot.participant_id || "\u2014"}
        </td>
      ) : null}
      <td className="px-2 py-1">
        <div className="flex items-center gap-1.5">
          <span
            className={`inline-flex px-2 py-0.5 rounded-eq-sm text-xs font-medium ${badge.classes}`}
          >
            {badge.label}
          </span>
          {isException && (
            <span className="text-eq-warning" title="Needs review">!</span>
          )}
          {status === SS.INVALIDATED && (
            <span className="text-eq-warning text-xs" title="Upstream stage was re-run. Click Run to update.">(stale)</span>
          )}
          {status === SS.RUNNING && (
            <span className="inline-block w-3 h-3 border-2 border-eq-border border-t-eq-primary rounded-full animate-spin" />
          )}
          {imageWriteFailed && (
            <span
              className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-eq-sm text-[10px] font-medium bg-eq-warning-bg text-eq-warning"
              title="Image write failed during preprocessing — processed image may be stale"
            >
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              Write failed
            </span>
          )}
        </div>
      </td>
      {renderResultColumns(screenshot, event)}
      <td className="px-2 py-1">
        <div className="flex gap-1">
          {status === SS.SKIPPED ? (
            <button
              onClick={() => { void unskipStage(stage, [screenshot.id]); }}
              className="px-2 py-1 text-xs text-eq-secondary hover:text-eq-secondary hover:bg-eq-info-bg rounded-eq-sm"
              title="Unskip this screenshot"
            >
              Unskip
            </button>
          ) : (status === SS.PENDING || status === SS.FAILED || status === SS.INVALIDATED || status === SS.CANCELLED) ? (
            <button
              onClick={() => onSkip(screenshot.id)}
              className="px-2 py-1 text-xs text-eq-secondary hover:text-eq-secondary hover:bg-eq-info-bg rounded-eq-sm"
              title="Skip this stage for this screenshot"
            >
              Skip
            </button>
          ) : null}
          <button
            onClick={() => onLoadLog(screenshot.id)}
            className="px-2 py-1 text-xs text-eq-muted hover:text-eq-primary hover:bg-eq-surface-muted rounded-eq-sm"
            title="View event log"
            aria-label={`View event log for screenshot ${screenshot.id}`}
          >
            Log
          </button>
        </div>
      </td>
    </tr>
  );
});

export const StageReviewTable = ({
  stage,
  renderResultColumns,
  resultHeaders,
  getResultSortValue,
}: StageReviewTableProps) => {
  const allScreenshots = usePreprocessingStore((s) => s.screenshots);
  const filter = usePreprocessingStore((s) => s.filter);
  const getScreenshotStageStatus = usePreprocessingStore((s) => s.getScreenshotStageStatus);
  const isScreenshotException = usePreprocessingStore((s) => s.isScreenshotException);
  const loadEventLog = usePreprocessingStore((s) => s.loadEventLog);
  const highlightedScreenshotId = usePreprocessingStore((s) => s.highlightedScreenshotId);
  const setHighlightedScreenshotId = usePreprocessingStore((s) => s.setHighlightedScreenshotId);
  const enterQueue = usePreprocessingStore((s) => s.enterQueue);
  const imageVersion = usePreprocessingStore((s) => s.imageVersion);

  const sortColumn = usePreprocessingStore((s) => s.tableSortColumn[stage] ?? "id");
  const sortDirection = usePreprocessingStore((s) => s.tableSortDirection[stage] ?? "asc") as SortDirection;
  const setTableSort = usePreprocessingStore((s) => s.setTableSort);
  const skipStage = usePreprocessingStore((s) => s.skipStage);
  const showIdentifierMetadata = useSettingsStore((s) => s.showIdentifierMetadata);
  const { confirm, ConfirmDialog } = useConfirmDialog();
  const sortColumnForDisplay = showIdentifierMetadata ? sortColumn : sortColumn === "participant" ? "id" : sortColumn;

  const handleSort = (column: string) => {
    const targetColumn = showIdentifierMetadata
      ? column
      : column === "participant"
        ? "id"
        : column;
    if (sortColumnForDisplay === targetColumn) {
      setTableSort(stage, targetColumn, sortDirection === "asc" ? "desc" : "asc");
    } else {
      setTableSort(stage, targetColumn, "asc");
    }
  };

  // Decouple the (potentially 5000-row) filter+sort+render from urgent updates.
  // During a stage run the store refreshes `screenshots` ~4 Hz; rendering it as
  // a low-priority value lets the progress bar, scrolling, and clicks stay
  // responsive while the table reconciles a frame later (React 19 concurrent).
  // It also makes filter/sort/tab switches non-blocking on large groups — the
  // expensive re-sort no longer holds up the interaction that triggered it.
  const deferredScreenshots = useDeferredValue(allScreenshots);

  // Memoize filtered + sorted screenshots
  const screenshots = useMemo(() => {
    let filtered = deferredScreenshots;
    if (filter !== "all") {
      filtered = deferredScreenshots.filter((s) => {
        const status = getScreenshotStageStatus(s, stage);
        switch (filter) {
          case "completed": return status === SS.COMPLETED;
          case "pending": return status === SS.PENDING;
          case "skipped": return status === SS.SKIPPED;
          case "invalidated": return status === SS.INVALIDATED;
          case "needs_review": return isScreenshotException(s, stage);
          default: return true;
        }
      });
    }

    const sorted = [...filtered].sort((a, b) => {
      const sortColumnToUse = sortColumnForDisplay;
      let cmp = 0;
      switch (sortColumnToUse) {
        case "id":
          cmp = a.id - b.id;
          break;
        case "participant":
          if (showIdentifierMetadata) {
            cmp = (a.participant_id || "").localeCompare(b.participant_id || "");
          } else {
            cmp = a.id - b.id;
          }
          break;
        case "status": {
          const sa = getScreenshotStageStatus(a, stage);
          const sb = getScreenshotStageStatus(b, stage);
          cmp = (STATUS_SORT_ORDER[sa] ?? 99) - (STATUS_SORT_ORDER[sb] ?? 99);
          break;
        }
        default: {
          // Result column sort via getResultSortValue callback
          if (getResultSortValue) {
            const eventA = getCurrentEvent(a, stage);
            const eventB = getCurrentEvent(b, stage);
            const valA = getResultSortValue(a, eventA, sortColumnToUse);
            const valB = getResultSortValue(b, eventB, sortColumnToUse);
            // nulls sort last
            if (valA == null && valB == null) cmp = 0;
            else if (valA == null) cmp = 1;
            else if (valB == null) cmp = -1;
            else if (typeof valA === "number" && typeof valB === "number") cmp = valA - valB;
            else cmp = String(valA).localeCompare(String(valB));
          }
          break;
        }
      }
      return sortDirection === "asc" ? cmp : -cmp;
    });

    return sorted;
    }, [deferredScreenshots, filter, stage, getScreenshotStageStatus, isScreenshotException, sortColumnForDisplay, sortDirection, getResultSortValue, showIdentifierMetadata]);

  // Stable screenshot ID list for queue entry
  const screenshotIds = useMemo(() => screenshots.map((s) => s.id), [screenshots]);

  const handleEnterQueue = useCallback((screenshotId: number) => {
    const idx = screenshotIds.indexOf(screenshotId);
    enterQueue(screenshotIds, idx >= 0 ? idx : 0);
  }, [screenshotIds, enterQueue]);

  const stageLabel = stage.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
  const handleSkipScreenshot = useCallback(async (screenshotId: number) => {
    const ok = await confirm({
      title: "Skip Screenshot?",
      message: `Skip ${stageLabel} for screenshot #${screenshotId}?`,
      confirmLabel: "Skip",
      cancelLabel: "Keep",
      variant: "warning",
    });
    if (ok) {
      await skipStage(stage, [screenshotId]);
    }
  }, [confirm, skipStage, stage, stageLabel]);

  const highlightedRef = useRef<HTMLTableRowElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to highlighted screenshot
  useEffect(() => {
    if (highlightedScreenshotId && highlightedRef.current) {
      highlightedRef.current.scrollIntoView({ behavior: "smooth", block: "center" });
      const timer = setTimeout(() => setHighlightedScreenshotId(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [highlightedScreenshotId, setHighlightedScreenshotId]);

  // Virtualizer — only render visible rows + overscan buffer
  const virtualizer = useVirtualizer({
    count: screenshots.length,
    getScrollElement: () => scrollContainerRef.current,
    estimateSize: () => ROW_HEIGHT,
    overscan: 20,
  });

  // Sortable headers are real <button>s (keyboard-operable Enter/Space + a focus
  // ring) inside the <th>; the <th> carries aria-sort so SRs announce the order.
  const sortableThClass = "px-2 py-1 select-none";
  const sortBtnClass =
    "flex w-full items-center text-left hover:text-eq-ink transition-colors focus-ring rounded-eq-sm";
  const ariaSortFor = (col: string): "ascending" | "descending" | "none" =>
    sortColumnForDisplay === col ? (sortDirection === "asc" ? "ascending" : "descending") : "none";

  // Keep the scroll container mounted in both empty and populated states
  // so scrollTop survives filter toggles (N → 0 → N) and the virtualizer
  // doesn't lose track of its scroll element.
  const virtualItems = virtualizer.getVirtualItems();
  const lastItem = virtualItems[virtualItems.length - 1];
  const topSpacer = virtualItems[0]?.start ?? 0;
  const bottomSpacer = lastItem
    ? virtualizer.getTotalSize() - (lastItem.start + lastItem.size)
    : 0;

  // Under table-fixed the non-fixed columns split the leftover width equally, so
  // the min-width must scale with the column count or dense tabs over-truncate
  // (OCR has 7 result columns vs Device's 4). Fixed utility columns ≈ 400px
  // (Thumb 64 + ID 64 + Status 160 + Log 112); give each flexible column
  // (Participant + N result columns) ~120px, and let the container scroll
  // horizontally when it's narrower than that.
  const minTableWidth = 400 + (resultHeaders.length + 1) * 120;

  return (
    <div
      ref={scrollContainerRef}
      className="h-full min-h-0 overflow-auto"
      style={config.isLocalMode ? undefined : { maxHeight: "70vh" }}
    >
      {screenshots.length === 0 ? (
        <div className="flex min-h-24 items-center justify-center px-3 py-8 text-center text-sm text-eq-muted">
          No screenshots match current filter
        </div>
      ) : (
        /*
          table-fixed is REQUIRED here: with row virtualization only the visible
          rows exist in the DOM, so an auto-layout table re-fits its columns to
          whatever is currently rendered — a wider value scrolling into view
          widens a column, then it snaps back when it scrolls away. Fixed layout
          derives widths from the header row only, so they stay stable while
          scrolling. nowrap/truncate keep every cell on one line so rows hold the
          fixed ROW_HEIGHT the virtualizer assumes.
        */
        <table
          className="w-full text-sm table-fixed [&_th]:whitespace-nowrap [&_td]:truncate"
          style={{ minWidth: minTableWidth }}
        >
          <thead className="sticky top-0 bg-eq-surface z-10">
            <tr className="border-b border-eq-border text-left text-eq-muted">
              <th className="px-2 py-1 w-16">Thumb</th>
              <th className={`${sortableThClass} w-16`} aria-sort={ariaSortFor("id")}>
                <button type="button" className={sortBtnClass} onClick={() => handleSort("id")}>
                  ID <SortIcon column="id" sortColumn={sortColumnForDisplay} sortDirection={sortDirection} />
                </button>
              </th>
              {showIdentifierMetadata ? (
                <th className={sortableThClass} aria-sort={ariaSortFor("participant")}>
                  <button type="button" className={sortBtnClass} onClick={() => handleSort("participant")}>
                    Participant <SortIcon column="participant" sortColumn={sortColumnForDisplay} sortDirection={sortDirection} />
                  </button>
                </th>
              ) : null}
              <th className={`${sortableThClass} w-40`} aria-sort={ariaSortFor("status")}>
                <button type="button" className={sortBtnClass} onClick={() => handleSort("status")}>
                  Status <SortIcon column="status" sortColumn={sortColumnForDisplay} sortDirection={sortDirection} />
                </button>
              </th>
              {resultHeaders.map((h) => {
                      if (h.sortKey) {
                        return (
                          <th key={h.label} className={sortableThClass} aria-sort={ariaSortFor(h.sortKey)}>
                            <button type="button" className={sortBtnClass} onClick={() => handleSort(h.sortKey!)}>
                              {h.label} <SortIcon column={h.sortKey} sortColumn={sortColumnForDisplay} sortDirection={sortDirection} />
                            </button>
                          </th>
                        );
                      }
                return <th key={h.label} className="px-2 py-1">{h.label}</th>;
              })}
              <th className="px-2 py-1 w-28">Log</th>
            </tr>
          </thead>
          <tbody>
            {/* Spacer for items above the virtual window */}
            {/* Virtual-window spacer row — not interactive content. */}
            <tr aria-hidden="true" style={{ height: topSpacer }}>
              { }
              <td colSpan={(showIdentifierMetadata ? 5 : 4) + resultHeaders.length}>{" "}</td>
            </tr>
            {virtualItems.map((virtualRow) => {
              const s = screenshots[virtualRow.index]!;
              const status = getScreenshotStageStatus(s, stage);
              const isException = isScreenshotException(s, stage);
              const event = getCurrentEvent(s, stage);
              const isHighlighted = s.id === highlightedScreenshotId;

              return (
                <TableRow
                  key={s.id}
                  screenshot={s}
                  stage={stage}
                  status={status}
                  isException={isException}
                  event={event}
                  showIdentifierMetadata={showIdentifierMetadata}
                  isHighlighted={isHighlighted}
                  highlightedRef={highlightedRef}
                  onEnterQueue={handleEnterQueue}
                  onLoadLog={voidHandler(loadEventLog)}
                  onSkip={(id) => void handleSkipScreenshot(id)}
                  renderResultColumns={renderResultColumns}
                  imageVersion={imageVersion}
                />
              );
            })}
            {/* Spacer for items below the virtual window. Not interactive content. */}
            <tr aria-hidden="true" style={{ height: bottomSpacer }}>
              { }
              <td colSpan={(showIdentifierMetadata ? 5 : 4) + resultHeaders.length}>{" "}</td>
            </tr>
          </tbody>
        </table>
      )}
      {ConfirmDialog}
    </div>
  );
};
