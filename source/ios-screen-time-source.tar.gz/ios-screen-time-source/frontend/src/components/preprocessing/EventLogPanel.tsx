import { useState } from "react";
import { usePreprocessingStore } from "@/hooks/usePreprocessingWithDI";
import { useSettingsStore } from "@/store/settingsStore";
import toast from "react-hot-toast";
import { saveBlob } from "@/lib/desktop/saveFile";

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }).catch(() => { /* clipboard denied or unavailable */ });
  };
  return (
    <button
      onClick={handleCopy}
      className="px-1.5 py-0.5 text-[10px] rounded-eq-sm bg-eq-surface-muted text-eq-muted hover:bg-eq-surface-muted hover:text-eq-ink transition-colors"
      title="Copy to clipboard"
    >
      {copied ? "Copied" : "Copy"}
    </button>
  );
}

const STAGE_LABELS: Record<string, string> = {
  device_detection: "Device Detection",
  cropping: "Cropping",
  phi_detection: "PHI Detection",
  phi_redaction: "PHI Redaction",
};

export const EventLogPanel = () => {
  const eventLog = usePreprocessingStore((s) => s.eventLog);
  const selectedScreenshotId = usePreprocessingStore((s) => s.selectedScreenshotId);
  const clearEventLog = usePreprocessingStore((s) => s.clearEventLog);
  const showIdentifierMetadata = useSettingsStore((s) => s.showIdentifierMetadata);

  if (!eventLog || !selectedScreenshotId) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-96 bg-eq-surface shadow-xl border-l border-eq-border z-50 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-eq-border bg-eq-surface-muted">
        <h3 className="text-sm font-semibold text-eq-ink">
          Event Log - Screenshot #{selectedScreenshotId}
        </h3>
        <button
          onClick={clearEventLog}
          className="text-eq-muted hover:text-eq-ink text-lg leading-none"
          aria-label="Close event log"
        >
          &times;
        </button>
      </div>

      {/* Stage status summary */}
      <div className="px-4 py-2 border-b border-eq-border bg-eq-surface-muted">
        <div className="flex flex-wrap gap-2">
          {Object.entries(eventLog.stage_status).map(([stage, status]) => (
            <div key={stage} className="flex items-center gap-1">
              <span className="text-xs text-eq-muted">
                {STAGE_LABELS[stage] ?? stage}:
              </span>
              <span
                className={`text-xs font-medium ${
                  status === "completed"
                    ? "text-eq-success"
                    : status === "invalidated"
                      ? "text-eq-warning"
                      : status === "failed"
                        ? "text-eq-danger"
                        : status === "running"
                          ? "text-eq-primary"
                          : "text-eq-muted"
                }`}
              >
                {status}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Events list */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {eventLog.events.length === 0 ? (
          <p className="text-sm text-eq-muted text-center py-8">
            No events recorded yet
          </p>
        ) : (
          [...eventLog.events].reverse().map((event) => {
            const isCurrent = eventLog.current_events[event.stage] === event.event_id;
            const isError = "error" in event.result;

            return (
              <div
                key={event.event_id}
                className={`rounded-eq-md border p-3 text-xs ${
                  isCurrent
                    ? "border-eq-border bg-eq-info-bg"
                    : isError
                      ? "border-eq-danger bg-eq-danger-bg"
                      : "border-eq-border bg-eq-surface opacity-60"
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-eq-ink">
                      #{event.event_id}
                    </span>
                    {event.source && (
                      <span
                        className={`px-1.5 py-0.5 rounded-eq-sm text-[10px] font-medium ${
                          event.source === "auto"
                            ? "bg-eq-info-bg text-eq-primary"
                            : "bg-eq-info-bg text-eq-secondary"
                        }`}
                      >
                        {event.source}
                      </span>
                    )}
                    <span className="text-eq-muted">
                      {STAGE_LABELS[event.stage] ?? event.stage}
                    </span>
                    {isCurrent && (
                      <span className="px-1.5 py-0.5 rounded-eq-sm text-[10px] font-medium bg-eq-success-bg text-eq-success">
                        current
                      </span>
                    )}
                  </div>
                  {event.supersedes && (
                    <span className="text-eq-muted">
                      replaces #{event.supersedes}
                    </span>
                  )}
                </div>
                <div className="text-eq-muted mb-1">
                  {new Date(event.timestamp).toLocaleString()}
                </div>
                {/* Result summary */}
                <div className="mt-1 text-eq-muted">
                  {isError ? (
                    <div className="flex items-start gap-1">
                      <span className="text-eq-danger flex-1">
                        Error: {event.result.error as string}
                      </span>
                      <CopyButton text={event.result.error as string} />
                    </div>
                  ) : (
                    <div className="relative group">
                      <pre className="whitespace-pre-wrap break-all text-[10px] bg-eq-surface-muted rounded-eq-sm p-1.5 max-h-24 overflow-y-auto">
                        {JSON.stringify(event.result, null, 1)}
                      </pre>
                      <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <CopyButton text={JSON.stringify(event.result, null, 2)} />
                      </div>
                    </div>
                  )}
                </div>
                {showIdentifierMetadata && event.output_file && (
                  <div className="mt-1 text-eq-muted truncate" title={event.output_file}>
                    Output: {event.output_file.split("/").pop()}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Footer */}
      <div className="px-4 py-2 border-t border-eq-border flex items-center justify-between">
        {showIdentifierMetadata && eventLog.base_file_path ? (
          <span className="text-xs text-eq-muted truncate mr-2">
            Base: {eventLog.base_file_path.split("/").pop()}
          </span>
        ) : <span />}
        <button
          onClick={() => {
            const json = JSON.stringify(eventLog, null, 2);
            const blob = new Blob([json], { type: "application/json" });
            saveBlob(blob, `event-log-${selectedScreenshotId}.json`, { name: "JSON", extensions: ["json"] })
              .catch((err: unknown) => {
                console.error("Event log export failed:", err);
                toast.error("Could not save the event log");
              });
          }}
          className="text-xs text-eq-muted hover:text-eq-primary"
          title="Save the full event log as JSON"
        >
          Export JSON
        </button>
      </div>
    </div>
  );
};
