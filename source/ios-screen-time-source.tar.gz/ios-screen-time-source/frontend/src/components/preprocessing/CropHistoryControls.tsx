import { useCallback, useEffect, useState } from "react";
import { usePreprocessingPipelineService } from "@/core";
import toast from "react-hot-toast";
import type { CropRect } from "./CropAdjustModal";

interface CropHistoryControlsProps {
  screenshotId: number;
  /** Bumped by the parent after a fresh crop apply so the controls re-fetch. */
  refreshKey?: number;
  /** Fired after an undo/redo with the now-current applied crop (null =
   *  uncropped) so the editor can sync its draft and refresh the cropped view. */
  onRestored: (currentCrop: CropRect | null) => void;
  /** Bind Cmd/Ctrl+Z (undo) and Cmd/Ctrl+Shift+Z (redo); skipped while typing. */
  keyboard?: boolean;
}

/**
 * Undo/Redo for the manual crop. Backed by the rect-replay crop history in the
 * preprocessing service (WASM-offline only) — server mode reports no history and
 * the whole control hides itself. Renders nothing until at least one crop has
 * been recorded, so it's invisible for never-cropped screenshots.
 */
export const CropHistoryControls = ({
  screenshotId,
  refreshKey = 0,
  onRestored,
  keyboard = false,
}: CropHistoryControlsProps) => {
  const preprocessingService = usePreprocessingPipelineService();
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const state = await preprocessingService.getCropHistory(screenshotId);
      setCanUndo(state.canUndo);
      setCanRedo(state.canRedo);
    } catch {
      // No history surface (e.g. server mode) — leave the control hidden.
      setCanUndo(false);
      setCanRedo(false);
    }
  }, [preprocessingService, screenshotId]);

  useEffect(() => {
    void refresh();
  }, [refresh, refreshKey]);

  const step = useCallback(
    async (dir: "undo" | "redo") => {
      setBusy(true);
      try {
        if (dir === "undo") {
          await preprocessingService.undoManualCrop(screenshotId);
        } else {
          await preprocessingService.redoManualCrop(screenshotId);
        }
        const state = await preprocessingService.getCropHistory(screenshotId);
        setCanUndo(state.canUndo);
        setCanRedo(state.canRedo);
        onRestored(state.currentCrop);
        toast.success(dir === "undo" ? "Crop undone" : "Crop redone");
      } catch (err) {
        toast.error(err instanceof Error ? err.message : `Crop ${dir} failed`);
      } finally {
        setBusy(false);
      }
    },
    [preprocessingService, screenshotId, onRestored],
  );

  // Cmd/Ctrl+Z undo, Cmd/Ctrl+Shift+Z redo. Only while the control is mounted
  // (i.e. history exists) and not while the user is editing a numeric field
  // (so native input undo keeps working).
  useEffect(() => {
    if (!keyboard) return;
    const handler = (e: KeyboardEvent) => {
      if (!(e.ctrlKey || e.metaKey) || e.key.toLowerCase() !== "z") return;
      const t = e.target as HTMLElement | null;
      if (
        t &&
        (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)
      ) {
        return;
      }
      e.preventDefault();
      if (e.shiftKey) {
        if (canRedo && !busy) void step("redo");
      } else if (canUndo && !busy) {
        void step("undo");
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [keyboard, canUndo, canRedo, busy, step]);

  // Nothing recorded yet (or server mode) → no affordance.
  if (!canUndo && !canRedo) return null;

  return (
    <div className="flex items-center gap-1.5" role="group" aria-label="Crop history">
      <button
        type="button"
        onClick={() => { void step("undo"); }}
        disabled={!canUndo || busy}
        className="px-3 py-2 text-sm text-eq-muted border border-eq-border rounded-eq-md hover:bg-eq-surface-muted focus-ring disabled:opacity-40 disabled:cursor-not-allowed"
        title="Undo crop (Ctrl/Cmd+Z)"
        aria-label="Undo crop"
      >
        ↶ Undo
      </button>
      <button
        type="button"
        onClick={() => { void step("redo"); }}
        disabled={!canRedo || busy}
        className="px-3 py-2 text-sm text-eq-muted border border-eq-border rounded-eq-md hover:bg-eq-surface-muted focus-ring disabled:opacity-40 disabled:cursor-not-allowed"
        title="Redo crop (Ctrl/Cmd+Shift+Z)"
        aria-label="Redo crop"
      >
        ↷ Redo
      </button>
    </div>
  );
};
