import { useEffect } from "react";
import { usePreprocessingStore } from "@/hooks/usePreprocessingWithDI";
import { useActiveStages } from "@/core/hooks/useServices";
import type { Stage } from "@/store/preprocessingStore";

const STAGE_LABELS: Record<Stage, string> = {
  device_detection: "Device Detection",
  cropping: "Cropping",
  phi_detection: "PHI Detection",
  phi_redaction: "PHI Redaction",
  ocr: "OCR",
};

export const PreprocessingWizard = () => {
  const activeStages = useActiveStages();
  const activeStage = usePreprocessingStore((s) => s.activeStage);
  const setActiveStage = usePreprocessingStore((s) => s.setActiveStage);
  const summary = usePreprocessingStore((s) => s.summary);
  const screenshots = usePreprocessingStore((s) => s.screenshots);
  const getStageStatus = usePreprocessingStore((s) => s.getStageStatus);

  // If the current activeStage was removed from the list (e.g. PHI off), snap
  // back to the first active stage so the wizard never points at a hidden tab.
  useEffect(() => {
    if (!activeStages.includes(activeStage)) {
      setActiveStage(activeStages[0]!);
    }
  }, [activeStages, activeStage, setActiveStage]);

  return (
    <div className="flex border-b border-eq-border bg-eq-surface">
      {activeStages.map((stage, idx) => {
        const isActive = activeStage === stage;
        const counts = summary
          ? summary[stage]
          : getStageStatus(stage);
        const total = summary?.total ?? screenshots.length;

        return (
          <button
            key={stage}
            data-testid={`wizard-tab-${stage}`}
            onClick={() => setActiveStage(stage)}
            className={`flex-1 relative px-4 py-3 text-left transition-colors ${
              isActive
                ? "bg-eq-surface border-b-2 border-eq-primary"
                : "bg-eq-surface-muted hover:bg-eq-surface-muted border-b-2 border-transparent"
            }`}
          >
            <div className="flex items-center gap-2 mb-1">
              <span
                className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold ${
                  isActive
                    ? "bg-eq-primary text-eq-primary-ink"
                    : counts.completed === total && total > 0
                      ? "bg-eq-success text-eq-primary-ink"
                      : "bg-eq-surface-muted text-eq-muted"
                }`}
              >
                {counts.completed === total && total > 0 ? "\u2713" : idx + 1}
              </span>
              <span
                className={`text-sm font-medium ${
                  isActive ? "text-eq-primary" : "text-eq-muted"
                }`}
              >
                {STAGE_LABELS[stage]}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs ml-8">
              {counts.completed > 0 && (
                <span className="text-eq-success">
                  {counts.completed} completed
                </span>
              )}
              {counts.invalidated > 0 && (
                <span className="text-eq-warning font-medium">
                  {counts.invalidated} invalidated
                </span>
              )}
              {counts.pending > 0 && (
                <span className="text-eq-muted">
                  {counts.pending} pending
                </span>
              )}
              {counts.running > 0 && (
                <span className="text-eq-primary">
                  {counts.running} running
                </span>
              )}
              {counts.failed > 0 && (
                <span className="text-eq-danger">
                  {counts.failed} failed
                </span>
              )}
              {counts.exceptions > 0 && (
                <span className="text-eq-warning font-medium">
                  {counts.exceptions} review
                </span>
              )}
            </div>
            {/* Connector line between steps */}
            {idx < activeStages.length - 1 && (
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-0 h-0 border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent border-l-[6px] border-l-eq-border translate-x-[6px] z-10" />
            )}
          </button>
        );
      })}
    </div>
  );
};
