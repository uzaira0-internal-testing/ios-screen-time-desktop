import { useId, useMemo, useRef, useState } from "react";
import { useVirtualizer } from "@/lib/virtual";
import type { UploadFileItem } from "@/store/preprocessingStore";
import { useSettingsStore } from "@/store/settingsStore";

interface UploadTagTableProps {
  files: UploadFileItem[];
  groupId: string;
  imageType: "battery" | "screen_time";
  groupOptions?: string[];
  onFilesChange: (files: UploadFileItem[]) => void;
  onGroupIdChange: (groupId: string) => void;
  onImageTypeChange: (type: "battery" | "screen_time") => void;
}

const ROW_HEIGHT = 36; // px

export const UploadTagTable = ({
  files,
  groupId,
  imageType,
  groupOptions = [],
  onFilesChange,
  onGroupIdChange,
  onImageTypeChange,
}: UploadTagTableProps) => {
  const [regexInput, setRegexInput] = useState("");
  const [testInput, setTestInput] = useState("");
  const scrollParentRef = useRef<HTMLDivElement>(null);
  const showIdentifierMetadata = useSettingsStore((s) => s.showIdentifierMetadata);
  const datalistId = useId();

  const rowVirtualizer = useVirtualizer({
    count: files.length,
    getScrollElement: () => scrollParentRef.current,
    estimateSize: () => ROW_HEIGHT,
    overscan: 10,
  });

  // Compile regex from current input. Returns { re, error } — one of them is always null.
  const compileRegex = (raw: string): { re: RegExp | null; error: string | null } => {
    const trimmed = raw.trim();
    if (!trimmed) return { re: null, error: null };
    const pattern = trimmed.includes("(") ? trimmed : `(${trimmed})`;
    try {
      return { re: new RegExp(pattern), error: null };
    } catch (e) {
      return { re: null, error: (e as Error).message };
    }
  };

  const { re: liveRegex, error: regexError } = useMemo(() => compileRegex(regexInput), [regexInput]);

  const testPreview = useMemo(() => {
    if (!liveRegex || !testInput.trim()) return null;
    return testInput.match(liveRegex)?.[1] ?? null;
  }, [liveRegex, testInput]);

  const applyRegex = () => {
    if (!liveRegex) return;
    onFilesChange(
      files.map((item) => {
        const m = item.original_filepath.match(liveRegex);
        return m?.[1] ? { ...item, participant_id: m[1] } : item;
      }),
    );
  };

  const updateItem = (index: number, field: keyof UploadFileItem, value: string) => {
    const updated = [...files];
    updated[index] = { ...updated[index]!, [field]: value };
    onFilesChange(updated);
  };

  const removeItem = (index: number) => {
    onFilesChange(files.filter((_, i) => i !== index));
  };

  const cols = showIdentifierMetadata ? "1fr 160px 144px 40px" : "144px 40px";

  return (
    <div className="space-y-4">
      {/* Group-level fields */}
      <div className="flex flex-wrap items-center gap-4 p-3 bg-eq-surface-muted rounded-eq-md border border-eq-border">
        <div className="flex items-center gap-2">
          <label htmlFor="upload-tag-group-id" className="text-sm font-medium text-eq-muted">Group ID:</label>
          <div className="flex flex-col">
            <input
              id="upload-tag-group-id"
              type="text"
              list={datalistId}
              value={groupId}
              onChange={(e) => onGroupIdChange(e.target.value)}
              className="text-sm border border-eq-border rounded-eq-md px-3 py-1.5 w-52"
              placeholder="Enter or select a group"
              aria-label="Group ID"
            />
            {groupOptions.length > 0 && (
              <datalist id={datalistId}>
                {groupOptions.map((g) => (
                  <option key={g} value={g}>{g}</option>
                ))}
              </datalist>
            )}
            {groupOptions.length > 0 && (
              <span className="text-xs text-eq-muted mt-0.5">Enter group name or select a previous group</span>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <label htmlFor="upload-tag-image-type" className="text-sm font-medium text-eq-muted">Type:</label>
          <select
            id="upload-tag-image-type"
            value={imageType}
            onChange={(e) => onImageTypeChange(e.target.value as "battery" | "screen_time")}
            className="text-sm border border-eq-border rounded-eq-md px-2 py-1.5"
            aria-label="Image type"
          >
            <option value="screen_time">Screen Time</option>
            <option value="battery">Battery</option>
          </select>
        </div>
        <span className="text-sm text-eq-muted ml-auto">
          {files.length} file{files.length !== 1 ? "s" : ""}
        </span>
      </div>

      {/* Participant ID Regex — gated on the same setting as the Participant ID
          column it populates. Showing the regex box while the column is hidden
          made the feature look broken (you'd apply it but see no result). */}
      {showIdentifierMetadata && (
      <div className="space-y-2 p-3 bg-eq-surface-muted rounded-eq-md border border-eq-border">
        {/* Regex input row */}
        <div className="flex items-center gap-2">
          <label htmlFor="upload-tag-participant-regex" className="text-sm font-medium text-eq-muted whitespace-nowrap">
            Participant ID Regex:
          </label>
          <input
            id="upload-tag-participant-regex"
            type="text"
            value={regexInput}
            onChange={(e) => setRegexInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") applyRegex(); }}
            className={`text-sm border rounded-eq-md px-3 py-1.5 flex-1 min-w-[200px] font-mono ${
              regexError
                ? "border-eq-danger bg-eq-danger-bg"
                : "border-eq-border"
            }`}
            placeholder="e.g. (P\d{3})"
            aria-label="Participant ID regex"
          />
          <button
            type="button"
            onClick={applyRegex}
            disabled={!liveRegex}
            className="px-3 py-1.5 text-sm font-medium text-eq-primary bg-eq-info-bg border border-eq-border rounded-eq-md hover:bg-eq-info-bg disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Apply
          </button>
        </div>

        {/* Error */}
        {regexError && (
          <p className="text-xs text-eq-danger">Invalid regex: {regexError}</p>
        )}

        {/* Test box — only shown once the user has typed a valid regex */}
        {liveRegex && (
          <div className="flex items-center gap-2">
            <label htmlFor="upload-tag-test-input" className="text-xs text-eq-muted whitespace-nowrap">
              Test path:
            </label>
            <input
              id="upload-tag-test-input"
              type="text"
              value={testInput}
              onChange={(e) => setTestInput(e.target.value)}
              className="text-xs border border-eq-border rounded-eq-md px-3 py-1.5 flex-1 font-mono"
              placeholder="paste a file path to preview the match"
              aria-label="Test path"
            />
            {testInput.trim() && (
              <span className={`text-xs font-mono px-2 py-1 rounded-eq-sm whitespace-nowrap ${
                testPreview
                  ? "bg-eq-success-bg text-eq-success border border-eq-success"
                  : "bg-eq-danger-bg text-eq-danger border border-eq-danger"
              }`}>
                {testPreview ? `→ "${testPreview}"` : "no match"}
              </span>
            )}
          </div>
        )}
      </div>
      )}

      {/* File list — virtualized so large folders don't freeze the browser */}
      <div className="border border-eq-border rounded-eq-md overflow-hidden text-sm">
        {/* Header */}
        <div
          className="grid text-xs font-medium text-eq-muted bg-eq-surface border-b border-eq-border px-2 py-1"
          style={{ gridTemplateColumns: cols }}
        >
          {showIdentifierMetadata ? <span>Filename</span> : null}
          {showIdentifierMetadata ? <span>Participant ID</span> : null}
          <span>Date</span>
          <span />
        </div>
        {/* Virtualized rows */}
        <div ref={scrollParentRef} className="overflow-y-auto" style={{ maxHeight: 384 }}>
          <div style={{ height: rowVirtualizer.getTotalSize(), position: "relative" }}>
            {rowVirtualizer.getVirtualItems().map((virtualRow) => {
              const i = virtualRow.index;
              const item = files[i]!;
              return (
                <div
                  key={i}
                  className="grid items-center border-b border-eq-border hover:bg-eq-surface-muted px-2"
                  style={{
                    gridTemplateColumns: cols,
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: `${ROW_HEIGHT}px`,
                    transform: `translateY(${virtualRow.start}px)`,
                  }}
                >
                  {showIdentifierMetadata ? (
                    <div className="pr-2 text-xs text-eq-muted truncate min-w-0" title={item.original_filepath}>
                      {item.filename}
                    </div>
                  ) : null}
                  {showIdentifierMetadata ? (
                    <div className="pr-2">
                      <input
                      type="text"
                      value={item.participant_id}
                      onChange={(e) => updateItem(i, "participant_id", e.target.value)}
                      className="w-full text-xs border border-eq-border rounded-eq-sm px-2 py-0.5"
                      aria-label={`Participant ID for ${showIdentifierMetadata ? (item.original_filepath || item.filename) : `file ${i + 1}`}`}
                    />
                    </div>
                  ) : null}
                  <div className="pr-2">
                    <input
                      type="date"
                      value={item.screenshot_date}
                      onChange={(e) => updateItem(i, "screenshot_date", e.target.value)}
                      className="w-full text-xs border border-eq-border rounded-eq-sm px-2 py-0.5"
                      aria-label={`Screenshot date for ${showIdentifierMetadata ? (item.filename || item.original_filepath) : `file ${i + 1}`}`}
                    />
                  </div>
                  <div>
                    <button
                      onClick={() => removeItem(i)}
                      className="text-eq-muted hover:text-eq-danger text-sm leading-none"
                      title="Remove file"
                      aria-label={`Remove ${showIdentifierMetadata ? item.filename : `file ${i + 1}`}`}
                    >
                      &times;
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
