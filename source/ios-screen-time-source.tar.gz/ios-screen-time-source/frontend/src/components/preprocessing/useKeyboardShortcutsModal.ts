import { useCallback, useMemo, useState } from "react";
import { useKeyboardShortcuts } from "@/hooks/useKeyboardShortcuts";

/** Hook that listens for "?" keypress and toggles the modal. */
export function useKeyboardShortcutsModal() {
  const [isOpen, setIsOpen] = useState(false);
  const toggle = useCallback(() => setIsOpen((v) => !v), []);

  const shortcuts = useMemo(() => [
    { key: "?", shiftKey: true, handler: toggle },
  ], [toggle]);
  useKeyboardShortcuts(shortcuts);

  return { isOpen, onClose: () => setIsOpen(false), toggle };
}
