import { useState } from "react";
import type { Screenshot } from "@/types";
import type { PreprocessingEventData } from "@/store/preprocessingStore";
import { usePreprocessingStore } from "@/hooks/usePreprocessingWithDI";
import { StageReviewTable, type ResultHeader } from "./StageReviewTable";
import { CropAdjustModal } from "./CropAdjustModal";
import { getCropRectFromEvent, type CropRect } from "./croppingUtils";

const RESULT_HEADERS: ResultHeader[] = [
  { label: "Device", sortKey: "crop_device" },
  { label: "Cropped", sortKey: "was_cropped" },
  { label: "Patched", sortKey: "was_patched" },
  { label: "Original Size", sortKey: "original_area" },
  { label: "Cropped Size", sortKey: "cropped_area" },
  { label: "" },
];

function getResultSortValue(s: Screenshot, event: PreprocessingEventData | null, sortKey: string): string | number | null {
  const result = event?.result as Record<string, unknown> | undefined;
  if (!result) return null;
  switch (sortKey) {
    case "crop_device": {
      const params = event?.params as Record<string, unknown> | undefined;
      return (params?.auto_detected_device as string) || s.device_type || null;
    }
    case "was_cropped":
      return result.was_cropped ? 1 : 0;
    case "was_patched":
      return result.was_patched ? 1 : 0;
    case "original_area": {
      const dims = result.original_dimensions as number[] | undefined;
      return dims?.length === 2 ? dims[0]! * dims[1]! : null;
    }
    case "cropped_area": {
      const dims = result.cropped_dimensions as number[] | undefined;
      return dims?.length === 2 ? dims[0]! * dims[1]! : null;
    }
    default:
      return null;
  }
}

function CroppingTabInner() {
  const [cropModalScreenshotId, setCropModalScreenshotId] = useState<number | null>(null);
  const [cropModalInitialCrop, setCropModalInitialCrop] = useState<CropRect | undefined>(undefined);
  const loadScreenshots = usePreprocessingStore((s) => s.loadScreenshots);
  const loadSummary = usePreprocessingStore((s) => s.loadSummary);

  const handleCropApplied = () => {
    void loadScreenshots();
    void loadSummary();
  };

  const renderResultColumns = (s: Screenshot, event: PreprocessingEventData | null) => {
    const result = event?.result as Record<string, unknown> | undefined;
    const params = event?.params as Record<string, unknown> | undefined;

    return (
      <>
        <td className="px-2 py-1 text-xs">
          {(params?.auto_detected_device as string) || s.device_type || "\u2014"}
        </td>
        <td className="px-2 py-1">
          {result ? (
            result.was_cropped ? (
              <span className="inline-flex px-2 py-0.5 rounded-eq-sm text-xs font-medium bg-eq-success-bg text-eq-success">
                {result.manual ? "Manual" : "Yes"}
              </span>
            ) : (
              <span className="inline-flex px-2 py-0.5 rounded-eq-sm text-xs font-medium bg-eq-surface-muted text-eq-muted">
                No
              </span>
            )
          ) : (
            <span className="text-eq-muted">{"\u2014"}</span>
          )}
        </td>
        <td className="px-2 py-1">
          {result ? (
            result.was_patched ? (
              <span className="inline-flex px-2 py-0.5 rounded-eq-sm text-xs font-medium bg-eq-warning-bg text-eq-warning">
                Yes
              </span>
            ) : (
              <span className="text-eq-muted text-xs">No</span>
            )
          ) : (
            <span className="text-eq-muted">{"\u2014"}</span>
          )}
        </td>
        <td className="px-2 py-1 text-xs text-eq-muted">
          {result?.original_dimensions
            ? `${(result.original_dimensions as number[])[0]} x ${(result.original_dimensions as number[])[1]}`
            : "\u2014"}
        </td>
        <td className="px-2 py-1 text-xs text-eq-muted">
          {result?.cropped_dimensions
            ? `${(result.cropped_dimensions as number[])[0]} x ${(result.cropped_dimensions as number[])[1]}`
            : "\u2014"}
        </td>
        <td className="px-2 py-1">
          <button
            onClick={() => {
              setCropModalScreenshotId(s.id);
              setCropModalInitialCrop(getCropRectFromEvent(event));
            }}
            className="px-2 py-1 text-xs text-eq-primary border border-eq-border rounded-eq-sm hover:bg-eq-surface-muted"
            title="Adjust crop manually"
          >
            Edit Crop
          </button>
        </td>
      </>
    );
  };

  return (
    <>
      <StageReviewTable
        stage="cropping"
        resultHeaders={RESULT_HEADERS}
        renderResultColumns={renderResultColumns}
        getResultSortValue={getResultSortValue}
      />
      {cropModalScreenshotId !== null && (
        <CropAdjustModal
          screenshotId={cropModalScreenshotId}
          isOpen={true}
          onClose={() => {
            setCropModalScreenshotId(null);
            setCropModalInitialCrop(undefined);
          }}
          onCropApplied={handleCropApplied}
          initialCrop={cropModalInitialCrop}
        />
      )}
    </>
  );
}

export const CroppingTab = () => <CroppingTabInner />;
