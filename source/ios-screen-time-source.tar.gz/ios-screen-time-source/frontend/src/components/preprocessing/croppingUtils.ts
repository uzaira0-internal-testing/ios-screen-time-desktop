import type { PreprocessingEventData } from "@/store/preprocessingStore";

export interface CropRect {
  left: number;
  top: number;
  right: number;
  bottom: number;
}

/** Extract crop bounds from a cropping event result. Auto-crop is right-aligned (removes left sidebar). */
export function getCropRectFromEvent(event: PreprocessingEventData | null): CropRect | undefined {
  if (!event) return undefined;
  const result = event.result as Record<string, unknown> | undefined;
  if (!result?.was_cropped) return undefined;

  const region = result.crop_region as Partial<CropRect> | undefined;
  if (region && [region.left, region.top, region.right, region.bottom].every((value) => typeof value === "number" && Number.isFinite(value)) &&
    region.left! >= 0 && region.top! >= 0 && region.right! > region.left! && region.bottom! > region.top!) {
    return region as CropRect;
  }

  // Legacy manual crops stored bounds in params.
  if (result.manual) {
    const params = event.params as Record<string, unknown> | undefined;
    if (params && typeof params.left === "number") {
      return {
        left: params.left,
        top: params.top as number,
        right: params.right as number,
        bottom: params.bottom as number,
      };
    }
  }

  // Auto-crop: right-aligned (removes left sidebar)
  const origDims = result.original_dimensions as number[] | undefined;
  const croppedDims = result.cropped_dimensions as number[] | undefined;
  if (origDims?.length === 2 && croppedDims?.length === 2) {
    const origW = origDims[0]!;
    const origH = origDims[1]!;
    const cropW = croppedDims[0]!;
    const cropH = croppedDims[1]!;
    return {
      left: origW - cropW,
      top: origH - cropH, // typically 0
      right: origW,
      bottom: origH,
    };
  }

  return undefined;
}
