import { useEffect, useMemo, useState } from "react";
import { usePreprocessingStore, useScreenshotImageUrl } from "@/hooks/usePreprocessingWithDI";
import { QueueNavigationBar } from "./QueueNavigationBar";
import { config } from "@/config";
import { PHIRegionEditor } from "./PHIRegionEditor";
import { CropAdjustModal } from "./CropAdjustModal";
import { getCurrentEvent } from "./stageReviewUtils";
import { getCropRectFromEvent } from "./croppingUtils";
import { getRecentCropConfigs, getRecentPHIConfigs } from "./recentConfigHelpers";
import type { PreprocessingEventData } from "@/store/preprocessingStore";
import type { Screenshot } from "@/types";
import { Skeleton } from "@/components/ui/Skeleton";
import { displayText } from "@/lib/displayText";

export const PreprocessingQueueView = () => {
  const queueIndex = usePreprocessingStore((s) => s.queueIndex);
  const queueScreenshotIds = usePreprocessingStore((s) => s.queueScreenshotIds);
  const queueNext = usePreprocessingStore((s) => s.queueNext);
  const queuePrev = usePreprocessingStore((s) => s.queuePrev);
  const exitQueue = usePreprocessingStore((s) => s.exitQueue);
  const activeStage = usePreprocessingStore((s) => s.activeStage);
  const screenshots = usePreprocessingStore((s) => s.screenshots);
  const loadScreenshots = usePreprocessingStore((s) => s.loadScreenshots);
  const loadSummary = usePreprocessingStore((s) => s.loadSummary);

  const currentId = queueScreenshotIds[queueIndex];
  const currentScreenshot = useMemo(
    () => screenshots.find((s) => s.id === currentId),
    [screenshots, currentId],
  );

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept when user is typing in inputs
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;

      if (e.key === "ArrowLeft") {
        e.preventDefault();
        queuePrev();
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        queueNext();
      } else if (e.key === "Escape") {
        e.preventDefault();
        exitQueue();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [queuePrev, queueNext, exitQueue]);

  // Prefetch next 3 screenshots' images (all variants) into browser cache
  useEffect(() => {
    if (!config.apiBaseUrl) return;
    const prefetchIds = queueScreenshotIds.slice(queueIndex + 1, queueIndex + 4);
    for (const id of prefetchIds) {
      new Image().src = `${config.apiBaseUrl}/screenshots/${id}/image`;
      new Image().src = `${config.apiBaseUrl}/screenshots/${id}/stage-image?stage=cropping`;
      new Image().src = `${config.apiBaseUrl}/screenshots/${id}/original-image`;
    }
  }, [queueIndex, queueScreenshotIds]);

  const [imageRefreshKey, setImageRefreshKey] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const handleRefresh = () => {
    setIsRefreshing(true);
    void Promise.all([
      loadScreenshots().catch((e) => console.error("Failed to load screenshots:", e)),
      loadSummary().catch((e) => console.error("Failed to load summary:", e)),
    ]).finally(() => setIsRefreshing(false));
    setImageRefreshKey((k) => k + 1);
  };

  // Hooks must be called unconditionally — compute all derived values here
  const initialCrop = useMemo(
    () => currentScreenshot ? getCropRectFromEvent(getCurrentEvent(currentScreenshot, "cropping")) : undefined,
    [currentScreenshot],
  );

  const recentCrops = useMemo(
    () => currentScreenshot ? getRecentCropConfigs(screenshots, currentScreenshot.id) : [],
    [screenshots, currentScreenshot],
  );

  const recentPHIConfigs = useMemo(
    () => currentScreenshot ? getRecentPHIConfigs(screenshots, currentScreenshot.id) : [],
    [screenshots, currentScreenshot],
  );

  if (!currentScreenshot) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-eq-muted">
        <p>Screenshot not found</p>
        <button
          onClick={exitQueue}
          className="mt-4 px-4 py-2 text-sm border border-eq-border rounded-eq-md hover:bg-eq-surface-muted"
        >
          Back to Table
        </button>
      </div>
    );
  }

  const event = getCurrentEvent(currentScreenshot, activeStage);

  // Show image_write_failed warning if present in preprocessing metadata
  const ppMeta = (currentScreenshot.processing_metadata as Record<string, unknown>)?.preprocessing as Record<string, unknown> | undefined;
  const imageWriteFailed = ppMeta?.image_write_failed === true;

  // Refreshing indicator bar shown below QueueNavigationBar
  const refreshingBar = isRefreshing ? (
    <div className="h-0.5 w-full bg-eq-info-bg overflow-hidden flex-shrink-0">
      <div className="h-full w-1/3 bg-eq-primary animate-[slide_1s_ease-in-out_infinite]" style={{ animation: "slide 1s ease-in-out infinite" }} />
      <style>{`@keyframes slide { 0% { transform: translateX(-100%); } 100% { transform: translateX(400%); } }`}</style>
    </div>
  ) : null;

  // Warning badge for image_write_failed
  const imageWriteFailedBanner = imageWriteFailed ? (
    <div className="bg-eq-warning-bg border-b border-eq-warning px-4 py-1.5 text-xs flex items-center gap-2 flex-shrink-0">
      <svg className="w-4 h-4 text-eq-warning" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
      </svg>
      <span className="text-eq-warning font-medium">Image write failed</span>
      <span className="text-eq-warning">— the processed image could not be saved. Results may be stale.</span>
    </div>
  ) : null;

  if (activeStage === "device_detection") {
    return (
      <div className="flex flex-col h-[calc(100vh-8rem)]">
        <QueueNavigationBar currentScreenshot={currentScreenshot} />
        {refreshingBar}
        {imageWriteFailedBanner}
        <DeviceInfoPanel screenshot={currentScreenshot} event={event} refreshKey={imageRefreshKey} />
      </div>
    );
  }

  if (activeStage === "cropping") {
    return (
      <div className="flex flex-col h-[calc(100vh-8rem)]">
        <QueueNavigationBar currentScreenshot={currentScreenshot} />
        {refreshingBar}
        {imageWriteFailedBanner}
        <div className="flex-1 min-h-0">
          <CropAdjustModal
            screenshotId={currentScreenshot.id}
            isOpen={false}
            onClose={() => {}}
            onCropApplied={handleRefresh}
            initialCrop={initialCrop}
            inline
            onApplyAndNext={() => {
              handleRefresh();
              queueNext();
            }}
            recentCrops={recentCrops}
          />
        </div>
      </div>
    );
  }

  if (activeStage === "phi_detection") {
    return (
      <div className="flex flex-col h-[calc(100vh-8rem)]">
        <QueueNavigationBar currentScreenshot={currentScreenshot} />
        {refreshingBar}
        {imageWriteFailedBanner}
        <div className="flex-1 min-h-0">
          <PHIRegionEditor
            screenshotId={currentScreenshot.id}
            isOpen={false}
            onClose={() => {}}
            onRegionsSaved={handleRefresh}
            onRedactionApplied={handleRefresh}
            inline
            onSaveAndNext={() => {
              queueNext();
              // Refresh data in the background (don't block navigation)
              void loadScreenshots();
              void loadSummary();
            }}
            recentPHIConfigs={recentPHIConfigs}
          />
        </div>
      </div>
    );
  }

  if (activeStage === "phi_redaction") {
    const redactEvent = getCurrentEvent(currentScreenshot, "phi_redaction");
    const phiEvent = getCurrentEvent(currentScreenshot, "phi_detection");
    return (
      <div className="flex flex-col h-[calc(100vh-8rem)]">
        <QueueNavigationBar currentScreenshot={currentScreenshot} />
        {refreshingBar}
        {imageWriteFailedBanner}
        <div className="flex-1 min-h-0">
          <RedactionReviewPanel
            screenshot={currentScreenshot}
            redactEvent={redactEvent}
            phiEvent={phiEvent}
            onNext={queueNext}
            refreshKey={imageRefreshKey}
          />
        </div>
      </div>
    );
  }

  if (activeStage === "ocr") {
    return (
      <div className="flex flex-col h-[calc(100vh-8rem)]">
        <QueueNavigationBar currentScreenshot={currentScreenshot} />
        {refreshingBar}
        {imageWriteFailedBanner}
        <div className="flex-1 min-h-0">
          <OCRReviewPanel
            screenshot={currentScreenshot}
            event={event}
            onNext={queueNext}
            refreshKey={imageRefreshKey}
          />
        </div>
      </div>
    );
  }

  return null;
};

/** Read-only panel for device detection stage — shows image + metadata */
function DeviceInfoPanel({
  screenshot,
  event,
  refreshKey,
}: {
  screenshot: { id: number; participant_id?: string | null; device_type?: string | null };
  event: PreprocessingEventData | null;
  refreshKey?: number;
}) {
  const result = event?.result as Record<string, unknown> | undefined;
  // Show the PRE-CROP original — the image device detection actually measured.
  // The current blob is the cropped result, so getImageUrl would mislead here.
  // server: stage-image falls back to base_file_path; WASM: maps to "original".
  const imageUrl = useScreenshotImageUrl(screenshot.id, "getStageImageUrl", "device_detection", refreshKey);

  return (
    <div className="flex-1 flex overflow-hidden bg-eq-surface rounded-eq-md border border-eq-border min-h-0">
      {/* Image */}
      <div className="flex-1 min-h-0 min-w-0 overflow-hidden flex items-center justify-center p-4">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={`Screenshot ${screenshot.id}`}
            style={{ maxHeight: "calc(100vh - 14rem)" }}
            className="max-w-full object-contain rounded-eq-sm"
          />
        ) : (
          <Skeleton className="w-48 h-64" />
        )}
      </div>

      {/* Metadata sidebar */}
      <div className="w-72 border-l border-eq-border p-4 space-y-4 overflow-y-auto">
        <h3 className="text-sm font-semibold text-eq-ink">Device Detection</h3>

        {result ? (
          <div className="space-y-3 text-sm">
            <div>
              <span className="text-eq-muted">Category:</span>{" "}
              <span className={`inline-flex px-2 py-0.5 rounded-eq-sm text-xs font-medium ${
                result.device_category === "ipad"
                  ? "bg-eq-info-bg text-eq-primary"
                  : result.device_category === "iphone"
                    ? "bg-eq-success-bg text-eq-success"
                    : "bg-eq-surface-muted text-eq-muted"
              }`}>
                {result.device_category as string}
              </span>
            </div>
            <div>
              <span className="text-eq-muted">Model:</span>{" "}
              <span className="text-eq-ink">{(result.device_model as string) || "\u2014"}</span>
            </div>
            <div>
              <span className="text-eq-muted">Confidence:</span>{" "}
              <span className={`font-mono ${
                (result.confidence as number) >= 0.9
                  ? "text-eq-success"
                  : (result.confidence as number) >= 0.7
                    ? "text-eq-warning"
                    : "text-eq-danger"
              }`}>
                {Math.round((result.confidence as number) * 100)}%
              </span>
            </div>
            {result.orientation ? (
              <div>
                <span className="text-eq-muted">Orientation:</span>{" "}
                <span className="text-eq-ink">{displayText(result.orientation)}</span>
              </div>
            ) : null}
          </div>
        ) : (
          <p className="text-sm text-eq-muted">No detection data available</p>
        )}
      </div>
    </div>
  );
}

/** Before/after panel for redaction review — shows final redacted image + metadata */
function RedactionReviewPanel({
  screenshot,
  redactEvent,
  phiEvent,
  onNext,
  refreshKey,
}: {
  screenshot: Screenshot;
  redactEvent: PreprocessingEventData | null;
  phiEvent: PreprocessingEventData | null;
  onNext: () => void;
  refreshKey?: number;
}) {
  const redactResult = redactEvent?.result as Record<string, unknown> | undefined;
  const phiResult = phiEvent?.result as Record<string, unknown> | undefined;
  const regions = (phiResult?.regions ?? []) as Array<Record<string, unknown>>;
  const wasRedacted = redactResult?.redacted === true;
  const regionsRedacted = (redactResult?.regions_redacted as number) ?? 0;
  const method = (redactResult?.method as string) ?? "unknown";

  const afterUrl = useScreenshotImageUrl(screenshot.id, "getImageUrl", undefined, refreshKey);
  const beforeUrl = useScreenshotImageUrl(screenshot.id, "getStageImageUrl", "cropping", refreshKey);

  const [view, setView] = useState<"after" | "before">("after");
  const activeUrl = view === "after" ? afterUrl : beforeUrl;

  return (
    <div className="flex-1 flex overflow-hidden bg-eq-surface rounded-eq-md border border-eq-border min-h-0">
      {/* Image area */}
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        {/* Before/After toggle */}
        {wasRedacted && (
          <div className="flex items-center gap-2 px-4 py-2 border-b border-eq-border bg-eq-surface-muted shrink-0">
            <span className="text-xs text-eq-muted mr-1">View:</span>
            <button
              onClick={() => setView("after")}
              className={`px-3 py-1 text-xs rounded-eq-sm font-medium ${
                view === "after"
                  ? "bg-eq-warning-bg text-eq-warning ring-1 ring-eq-warning"
                  : "bg-eq-surface-muted text-eq-muted hover:bg-eq-surface-muted"
              }`}
            >
              Redacted
            </button>
            <button
              onClick={() => setView("before")}
              className={`px-3 py-1 text-xs rounded-eq-sm font-medium ${
                view === "before"
                  ? "bg-eq-info-bg text-eq-primary ring-1 ring-eq-focus"
                  : "bg-eq-surface-muted text-eq-muted hover:bg-eq-surface-muted"
              }`}
            >
              Original
            </button>
          </div>
        )}

        <div className="flex-1 min-h-0 overflow-hidden flex items-center justify-center p-4">
          {activeUrl ? (
            <img
              src={activeUrl}
              alt={`Screenshot ${screenshot.id} — ${view === "after" ? "redacted" : "original"}`}
              style={{ maxHeight: "calc(100vh - 15rem)" }}
              className="max-w-full object-contain rounded-eq-sm"
            />
          ) : (
            <Skeleton className="w-48 h-64" />
          )}
        </div>
      </div>

      {/* Sidebar */}
      <div className="w-72 border-l border-eq-border flex flex-col">
        <div className="p-4 space-y-4 flex-1 overflow-y-auto">
          <h3 className="text-sm font-semibold text-eq-ink">Redaction Result</h3>

          <div className="space-y-3 text-sm">
            <div>
              <span className="text-eq-muted">Status:</span>{" "}
              {wasRedacted ? (
                <span className="inline-flex px-2 py-0.5 rounded-eq-sm text-xs font-medium bg-eq-warning-bg text-eq-warning">
                  Redacted
                </span>
              ) : (
                <span className="inline-flex px-2 py-0.5 rounded-eq-sm text-xs font-medium bg-eq-surface-muted text-eq-muted">
                  No redaction needed
                </span>
              )}
            </div>
            <div>
              <span className="text-eq-muted">Regions redacted:</span>{" "}
              <span className="font-mono">{regionsRedacted}</span>
            </div>
            <div>
              <span className="text-eq-muted">Method:</span>{" "}
              <span className="text-eq-ink">{method}</span>
            </div>
          </div>

          {/* Region list from phi_detection */}
          {regions.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold text-eq-muted mb-2">PHI Regions</h4>
              <div className="space-y-1">
                {regions.map((r, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs p-1.5 rounded-eq-sm bg-eq-surface-muted">
                    <span className="font-mono text-eq-muted w-4">{i + 1}</span>
                    <span className={`px-1.5 py-0.5 rounded-eq-sm text-[10px] font-medium ${
                      String(r.source) === "manual" ? "bg-eq-info-bg text-eq-primary" : "bg-eq-danger-bg text-eq-danger"
                    }`}>
                      {displayText(r.label || r.type || "?")}
                    </span>
                    <span className="text-eq-muted truncate flex-1" title={displayText(r.text)}>
                      {displayText(r.text) || "\u2014"}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {!redactEvent && (
            <p className="text-sm text-eq-muted">Redaction has not been run yet for this screenshot.</p>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-eq-border space-y-2">
          <button
            onClick={() => onNext()}
            className="w-full px-3 py-2 text-xs font-medium text-eq-primary-ink bg-eq-success rounded-eq-sm hover:bg-eq-success"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}

/** Read-only panel for OCR stage — shows image + extracted data */
function OCRReviewPanel({
  screenshot,
  event,
  onNext,
  refreshKey,
}: {
  screenshot: Screenshot;
  event: PreprocessingEventData | null;
  onNext: () => void;
  refreshKey?: number;
}) {
  const result = event?.result as Record<string, unknown> | undefined;
  const imageUrl = useScreenshotImageUrl(screenshot.id, "getImageUrl", undefined, refreshKey);
  const status = result?.processing_status as string | undefined;
  const issues = (result?.issues as Array<string | { issue_type?: string; severity?: string; description?: string; message?: string }>) ?? [];

  return (
    <div className="flex-1 flex overflow-hidden bg-eq-surface rounded-eq-md border border-eq-border min-h-0">
      {/* Image */}
      <div className="flex-1 min-h-0 min-w-0 overflow-hidden flex items-center justify-center p-4">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={`Screenshot ${screenshot.id}`}
            style={{ maxHeight: "calc(100vh - 14rem)" }}
            className="max-w-full object-contain rounded-eq-sm"
          />
        ) : (
          <Skeleton className="w-48 h-64" />
        )}
      </div>

      {/* Metadata sidebar */}
      <div className="w-72 border-l border-eq-border flex flex-col">
        <div className="p-4 space-y-4 flex-1 overflow-y-auto">
          <h3 className="text-sm font-semibold text-eq-ink">OCR Results</h3>

          {result ? (
            <div className="space-y-3 text-sm">
              <div>
                <span className="text-eq-muted">Status:</span>{" "}
                {status === "completed" ? (
                  <span className="inline-flex px-2 py-0.5 rounded-eq-sm text-xs font-medium bg-eq-success-bg text-eq-success">
                    Completed
                  </span>
                ) : status === "failed" ? (
                  <span className="inline-flex px-2 py-0.5 rounded-eq-sm text-xs font-medium bg-eq-danger-bg text-eq-danger">
                    Failed
                  </span>
                ) : (
                  <span className="inline-flex px-2 py-0.5 rounded-eq-sm text-xs font-medium bg-eq-warning-bg text-eq-warning">
                    {status ?? "Unknown"}
                  </span>
                )}
              </div>
              <div>
                <span className="text-eq-muted">Method:</span>{" "}
                <span className="text-eq-ink">
                  {(result.processing_method as string) || "\u2014"}
                </span>
              </div>
              <div>
                <span className="text-eq-muted">Title:</span>{" "}
                <span className="text-eq-ink font-mono text-xs">
                  {(result.extracted_title as string) || "\u2014"}
                </span>
              </div>
              <div>
                <span className="text-eq-muted">Total:</span>{" "}
                <span className="text-eq-ink font-mono text-xs">
                  {(result.extracted_total as string) || "\u2014"}
                </span>
              </div>
              {issues.length > 0 && (
                <div>
                  <span className="text-eq-muted">Issues:</span>
                  <ul className="mt-1 space-y-1">
                    {issues.map((issue, i) => (
                      <li key={i} className="text-xs text-eq-warning bg-eq-warning-bg rounded-eq-sm px-2 py-1">
                        {typeof issue === "string" ? issue : (issue.description || issue.message || issue.issue_type || JSON.stringify(issue))}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ) : (
            <p className="text-sm text-eq-muted">OCR has not been run yet for this screenshot.</p>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-eq-border space-y-2">
          <button
            onClick={() => onNext()}
            className="w-full px-3 py-2 text-xs font-medium text-eq-primary-ink bg-eq-success rounded-eq-sm hover:bg-eq-success"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}
