import { useCallback } from "react";
import { useDropzone } from "react-dropzone";
import toast from "react-hot-toast";
import type { UploadFileItem } from "@/store/preprocessingStore";
import { parseRelativePath, isImageFile } from "@/utils/filePathParser";
import { FolderStructureHint } from "@/components/common/FolderStructureHint";
import { useSettingsStore } from "@/store/settingsStore";

interface UploadDropZoneProps {
  onFilesSelected: (files: UploadFileItem[]) => void;
  compact?: boolean;
}

export const UploadDropZone = ({ onFilesSelected, compact }: UploadDropZoneProps) => {
  const showIdentifierMetadata = useSettingsStore((s) => s.showIdentifierMetadata);

  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      const imageFiles = acceptedFiles.filter(isImageFile);
      const items: UploadFileItem[] = imageFiles.map((file) => {
        const parsed = parseRelativePath(file);
        return {
          file,
          participant_id: parsed.participant_id,
          filename: parsed.filename,
          original_filepath: parsed.original_filepath,
          screenshot_date: parsed.screenshot_date,
        };
      });
      onFilesSelected(items);
    },
    [onFilesSelected],
  );

  const { getRootProps, getInputProps, isDragActive, open } = useDropzone({
    onDrop,
    onDropRejected: (rejections) => {
      for (const r of rejections) {
        const reasons = r.errors.map((e) => e.message).join(", ");
        const fileLabel = showIdentifierMetadata ? r.file.name : "a selected file";
        toast.error(`${fileLabel}: ${reasons}`);
      }
    },
    accept: { "image/png": [".png"], "image/jpeg": [".jpg", ".jpeg"] },
    maxSize: 25 * 1024 * 1024, // 25 MB per file
    multiple: true,
    noClick: true,
  });

  // Compact version: inline bar for adding more folders to an existing selection
  if (compact) {
    return (
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-eq-md p-3 text-center transition-colors ${
          isDragActive ? "border-eq-primary bg-eq-info-bg" : "border-eq-border hover:border-eq-border"
        }`}
      >
        <input {...getInputProps()} aria-label="Add more files" />
        <input {...getInputProps()} webkitdirectory="" directory="" style={{ display: "none" }} id="folder-input-add" aria-label="Add more folders" />
        <div className="flex items-center justify-center gap-3">
          <span className="text-sm text-eq-muted">
            {isDragActive ? "Drop to add..." : "Add more files or folders"}
          </span>
          <button
            type="button"
            className="px-3 py-1 text-xs bg-eq-surface border border-eq-border rounded-eq-md hover:bg-eq-surface-muted focus-ring"
            onClick={open}
          >
            + Files
          </button>
          <button
            type="button"
            className="px-3 py-1 text-xs bg-eq-surface border border-eq-border rounded-eq-md hover:bg-eq-surface-muted focus-ring"
            onClick={(e) => {
              e.stopPropagation();
              document.getElementById("folder-input-add")?.click();
            }}
          >
            + Folder
          </button>
        </div>
      </div>
    );
  }

  // Full-size drop zone for initial selection
  return (
    <div
      {...getRootProps()}
      className={`border-2 border-dashed rounded-eq-md p-12 text-center cursor-pointer transition-colors ${
        isDragActive ? "border-eq-primary bg-eq-info-bg" : "border-eq-border hover:border-eq-border"
      }`}
    >
      <input {...getInputProps()} aria-label="Upload files" />
      <input {...getInputProps()} webkitdirectory="" directory="" style={{ display: "none" }} id="folder-input" aria-label="Upload folder" />
      <div className="space-y-3">
        <div className="text-eq-muted">
          {isDragActive ? (
            <svg className="w-10 h-10 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4v16m8-8H4" />
            </svg>
          ) : (
            <svg className="w-10 h-10 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
            </svg>
          )}
        </div>
        <p className="text-eq-muted font-medium">
          {isDragActive ? "Drop files here..." : "Drop screenshot files or folders here"}
        </p>
        <p className="text-sm text-eq-muted">
          PNG/JPEG images
        </p>
        <FolderStructureHint />
        <div className="flex items-center justify-center gap-3 pt-2">
          <button
            type="button"
            className="px-4 py-2 text-sm bg-eq-surface border border-eq-border rounded-eq-md hover:bg-eq-surface-muted focus-ring"
            onClick={open}
          >
            Select Files
          </button>
          <button
            type="button"
            className="px-4 py-2 text-sm bg-eq-surface border border-eq-border rounded-eq-md hover:bg-eq-surface-muted focus-ring"
            onClick={(e) => {
              e.stopPropagation();
              document.getElementById("folder-input")?.click();
            }}
          >
            Select Folder
          </button>
        </div>
      </div>
    </div>
  );
};
