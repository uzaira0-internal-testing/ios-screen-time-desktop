import type { Stage, PreprocessingEventData } from "@/store/preprocessingStore";
import type { Screenshot } from "@/types";

export interface ResultHeader {
  label: string;
  /** If provided, column is sortable. This key is passed to getResultSortValue. */
  sortKey?: string;
}

export function getCurrentEvent(screenshot: Screenshot, stage: Stage): PreprocessingEventData | null {
  const pp = (screenshot.processing_metadata as Record<string, unknown>)?.preprocessing as Record<string, unknown> | undefined;
  if (!pp) return null;
  const currentEvents = pp.current_events as Record<string, number | null> | undefined;
  const events = pp.events as PreprocessingEventData[] | undefined;
  if (!currentEvents || !events) return null;
  const eid = currentEvents[stage];
  if (!eid) return null;
  return events.find((e) => e.event_id === eid) ?? null;
}
