import { useState } from "react";
import type { Screenshot } from "@/types";
import type { PreprocessingEventData } from "@/store/preprocessingStore";
import { usePreprocessingStore } from "@/hooks/usePreprocessingWithDI";
import { StageReviewTable, type ResultHeader } from "./StageReviewTable";
import { PHIRegionEditor } from "./PHIRegionEditor";

const RESULT_HEADERS: ResultHeader[] = [
  { label: "PHI Found", sortKey: "phi_detected" },
  { label: "Regions", sortKey: "regions_count" },
  { label: "Preset", sortKey: "preset" },
  { label: "" },
];

function getResultSortValue(_s: Screenshot, event: PreprocessingEventData | null, sortKey: string): string | number | null {
  const result = event?.result as Record<string, unknown> | undefined;
  if (!result) return null;
  switch (sortKey) {
    case "phi_detected":
      return result.phi_detected ? 1 : 0;
    case "regions_count":
      return (result.regions_count as number) ?? 0;
    case "preset":
      return (result.preset as string) || null;
    default:
      return null;
  }
}

function PHIDetectionTabInner() {
  const [editorScreenshotId, setEditorScreenshotId] = useState<number | null>(null);
  const loadScreenshots = usePreprocessingStore((s) => s.loadScreenshots);
  const loadSummary = usePreprocessingStore((s) => s.loadSummary);

  const handleRegionsSaved = () => {
    void loadScreenshots();
    void loadSummary();
  };

  const renderResultColumns = (_s: Screenshot, event: PreprocessingEventData | null) => {
    const result = event?.result as Record<string, unknown> | undefined;

    return (
      <>
        <td className="px-2 py-1">
          {result ? (
            result.phi_detected ? (
              <span className="inline-flex px-2 py-0.5 rounded-eq-sm text-xs font-medium bg-eq-danger-bg text-eq-danger">
                Yes
              </span>
            ) : (
              <span className="inline-flex px-2 py-0.5 rounded-eq-sm text-xs font-medium bg-eq-success-bg text-eq-success">
                Clean
              </span>
            )
          ) : (
            <span className="text-eq-muted">{"\u2014"}</span>
          )}
        </td>
        <td className="px-2 py-1 font-mono text-xs">
          {result ? (result.regions_count as number) : "\u2014"}
        </td>
        <td className="px-2 py-1 text-xs text-eq-muted">
          {(result?.preset as string) || "\u2014"}
        </td>
        <td className="px-2 py-1">
          <button
            onClick={() => setEditorScreenshotId(_s.id)}
            className="px-2 py-1 text-xs text-eq-primary border border-eq-border rounded-eq-sm hover:bg-eq-surface-muted"
            title="Edit PHI regions"
          >
            Edit Regions
          </button>
        </td>
      </>
    );
  };

  return (
    <>
      <StageReviewTable
        stage="phi_detection"
        resultHeaders={RESULT_HEADERS}
        renderResultColumns={renderResultColumns}
        getResultSortValue={getResultSortValue}
      />
      {editorScreenshotId !== null && (
        <PHIRegionEditor
          screenshotId={editorScreenshotId}
          isOpen={true}
          onClose={() => setEditorScreenshotId(null)}
          onRegionsSaved={handleRegionsSaved}
          onRedactionApplied={() => { handleRegionsSaved(); setEditorScreenshotId(null); }}
        />
      )}
    </>
  );
}

export const PHIDetectionTab = () => <PHIDetectionTabInner />;
