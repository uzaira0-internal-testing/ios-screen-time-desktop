import { usePreprocessingStore } from "@/hooks/usePreprocessingWithDI";
import type { FilterMode } from "@/store/preprocessingStore";
import type { Screenshot } from "@/types";
import { PREPROCESSING_STAGES } from "@/core/generated/constants";
import { useConfirmDialog } from "@/hooks/useConfirmDialog";

const FILTER_DEFS: { id: FilterMode; label: string; color: string }[] = [
  { id: "all", label: "All", color: "text-eq-ink bg-eq-surface-muted" },
  { id: "needs_review", label: "Needs Review", color: "text-eq-warning bg-eq-warning-bg" },
  { id: "invalidated", label: "Invalidated", color: "text-eq-warning bg-eq-warning-bg" },
  { id: "completed", label: "Completed", color: "text-eq-success bg-eq-success-bg" },
  { id: "skipped", label: "Skipped", color: "text-eq-secondary bg-eq-info-bg" },
  { id: "pending", label: "Pending", color: "text-eq-muted bg-eq-surface-muted" },
];

export const StageSummaryBar = () => {
  const filter = usePreprocessingStore((s) => s.filter);
  const setFilter = usePreprocessingStore((s) => s.setFilter);
  const activeStage = usePreprocessingStore((s) => s.activeStage);
  const screenshots = usePreprocessingStore((s) => s.screenshots);
  const getStageStatus = usePreprocessingStore((s) => s.getStageStatus);
  const getEligibleCount = usePreprocessingStore((s) => s.getEligibleCount);
  const summary = usePreprocessingStore((s) => s.summary);
  const isRunningStage = usePreprocessingStore((s) => s.isRunningStage);
  const stageProgress = usePreprocessingStore((s) => s.stageProgress);
  const runStage = usePreprocessingStore((s) => s.runStage);
  const resetStage = usePreprocessingStore((s) => s.resetStage);
  const skipStage = usePreprocessingStore((s) => s.skipStage);
  const unskipStage = usePreprocessingStore((s) => s.unskipStage);
  const { confirm, ConfirmDialog } = useConfirmDialog();

  const stopStage = usePreprocessingStore((s) => s.stopStage);
  const enterQueue = usePreprocessingStore((s) => s.enterQueue);
  const getScreenshotsForStage = usePreprocessingStore((s) => s.getScreenshotsForStage);

  const counts = summary ? summary[activeStage] : getStageStatus(activeStage);
  const total = summary?.total ?? screenshots.length;

  // Count for each filter
  const filterCounts: Record<FilterMode, number> = {
    all: total,
    needs_review: counts.exceptions,
    invalidated: counts.invalidated,
    completed: counts.completed,
    skipped: counts.skipped ?? 0,
    pending: counts.pending,
  };

  // Eligible = pending/invalidated AND prerequisites completed.
  // Computed inline (cheap) because the function reads `screenshots` via the
  // store and useMemo would lie about its dependency surface.
  const { eligible, blockedByPrereq } = getEligibleCount(activeStage);

  // Stage label for the run button
  const stageLabel = activeStage.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

  const confirmSkipStage = async () => {
    const ok = await confirm({
      title: `Skip ${stageLabel}?`,
      message: `Skip ${eligible} eligible screenshot${eligible !== 1 ? "s" : ""} for ${stageLabel}? Skipped items will not run this preprocessing stage unless you unskip them.`,
      confirmLabel: "Skip",
      cancelLabel: "Keep",
      variant: "warning",
    });
    if (ok) {
      await skipStage(activeStage);
    }
  };

  // Previous stage label for the "blocked" message
  const STAGE_LABELS: Record<string, string> = {
    device_detection: "Device Detection",
    cropping: "Cropping",
    phi_detection: "PHI Detection",
    phi_redaction: "PHI Redaction",
  };
  // Stages with prerequisites (all except the first one)
  const STAGE_ORDER = PREPROCESSING_STAGES.slice(0, -1);
  const stageIdx = STAGE_ORDER.indexOf(activeStage);
  const prevStageLabel = stageIdx > 0 ? STAGE_LABELS[STAGE_ORDER[stageIdx - 1]!] : null;

  return (
    <div className="flex flex-wrap items-center gap-2 p-3 bg-eq-surface-muted rounded-eq-md" role="toolbar" aria-label="Preprocessing stage controls">
      {/* Filter toggles */}
      <div className="flex items-center gap-1">
        {FILTER_DEFS.map((f) => {
          const count = filterCounts[f.id];
          if (f.id !== "all" && count === 0) return null;
          return (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`px-2.5 py-1 rounded-eq-sm text-xs font-medium transition-colors ${
                filter === f.id
                  ? `${f.color} ring-1 ring-current`
                  : "text-eq-muted hover:text-eq-ink hover:bg-eq-surface-muted"
              }`}
            >
              {f.label} ({count})
            </button>
          );
        })}
      </div>

      {/* Progress bar + stop button when running */}
      {isRunningStage && (
        <div className="flex items-center gap-2 ml-2">
          {/* The bar shows the whole time the stage runs. Before the first
              progress tick arrives it's indeterminate (a pulsing sliver); once
              counts come in it eases between the ~4 Hz throttled updates with a
              300ms width transition so the fill glides instead of stepping. */}
          <div
            className="w-32 h-1.5 bg-eq-surface-muted rounded-full overflow-hidden"
            role="progressbar"
            aria-label="Stage progress"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={
              stageProgress && stageProgress.total > 0
                ? Math.round((stageProgress.completed / stageProgress.total) * 100)
                : undefined
            }
            aria-valuetext={
              stageProgress ? `${stageProgress.completed} of ${stageProgress.total}` : "Starting…"
            }
          >
            {stageProgress ? (
              <div
                className="h-full bg-eq-primary rounded-full transition-[width] duration-300 ease-out"
                style={{ width: `${stageProgress.total > 0 ? (stageProgress.completed / stageProgress.total) * 100 : 0}%` }}
              />
            ) : (
              <div className="h-full w-2/5 bg-eq-primary rounded-full animate-pulse" />
            )}
          </div>
          {stageProgress && (
            <span className="text-xs text-eq-muted tabular-nums">
              {stageProgress.completed}/{stageProgress.total}
            </span>
          )}
          <span className="inline-block w-3 h-3 border-2 border-eq-border border-t-eq-primary rounded-full animate-spin" />
          <button
            onClick={stopStage}
            className="px-2.5 py-1 text-xs font-medium text-eq-danger bg-eq-danger-bg border border-eq-danger rounded-eq-md hover:bg-eq-danger-bg transition-colors"
          >
            Stop
          </button>
        </div>
      )}

      {/* Blocked-by-prerequisite hint */}
      {!isRunningStage && blockedByPrereq > 0 && (
        <span className="text-xs text-eq-warning ml-2">
          {blockedByPrereq} blocked — complete {prevStageLabel} first
        </span>
      )}

      {/* Review queue button */}
      {total > 0 && (
        <button
          onClick={() => {
            const filtered = getScreenshotsForStage(activeStage);
            if (filtered.length > 0) {
              enterQueue(filtered.map((s: Screenshot) => s.id));
            }
          }}
          className="ml-2 px-3 py-1.5 text-sm font-medium text-eq-primary bg-eq-info-bg border border-eq-border rounded-eq-md hover:bg-eq-info-bg transition-colors"
        >
          Review ({filterCounts[filter]})
        </button>
      )}

      {/* Reset button — always available when not running and there are any non-pending screenshots */}
      {!isRunningStage && (total - counts.pending > 0) && (
        <button
          onClick={() => { void resetStage(activeStage); }}
          className="ml-auto px-4 py-1.5 text-sm font-medium text-eq-warning bg-eq-warning-bg border border-eq-warning rounded-eq-md hover:bg-eq-warning-bg transition-colors"
        >
          Reset {stageLabel} ({total - counts.pending})
        </button>
      )}

      {/* Skip button — skip all eligible screenshots for this stage */}
      {!isRunningStage && eligible > 0 && (
        <button
          onClick={() => void confirmSkipStage()}
          className="px-4 py-1.5 text-sm font-medium text-eq-secondary bg-eq-info-bg border border-eq-border rounded-eq-md hover:bg-eq-info-bg transition-colors"
        >
          Skip {stageLabel} ({eligible})
        </button>
      )}

      {/* Unskip button — restore skipped screenshots to pending */}
      {!isRunningStage && (counts.skipped ?? 0) > 0 && (
        <button
          onClick={() => { void unskipStage(activeStage); }}
          className="px-4 py-1.5 text-sm font-medium text-eq-secondary bg-eq-info-bg border border-eq-border rounded-eq-md hover:bg-eq-info-bg transition-colors"
        >
          Unskip ({counts.skipped})
        </button>
      )}

      {/* Run button */}
      <button
        onClick={() => { void runStage(activeStage); }}
        disabled={isRunningStage || eligible === 0}
        className={`${eligible === 0 && counts.completed > 0 ? "" : "ml-auto "}px-4 py-1.5 bg-eq-primary text-eq-primary-ink text-sm font-medium rounded-eq-md hover:bg-eq-primary disabled:bg-eq-muted disabled:text-eq-primary-ink disabled:cursor-not-allowed transition-colors`}
      >
        {isRunningStage
          ? "Running..."
          : `Run ${stageLabel} on ${eligible} screenshot${eligible !== 1 ? "s" : ""}`}
      </button>
      {ConfirmDialog}
    </div>
  );
};
