import { Component, ReactNode } from "react";
import { AlertTriangle } from "lucide-react";
import { isChunkLoadError, reloadForStaleChunk } from "@/lib/chunkReload";
import { config } from "@/config";

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  override componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // A stale tab lazy-importing a renamed chunk after a deploy routes the
    // rejection here (React intercepts it before the global window 'error' net
    // in chunkReload). Auto-recover by reloading once instead of dead-ending on
    // "Something went wrong" — this is the exact case chunkReload exists for.
    if (isChunkLoadError(error)) {
      reloadForStaleChunk();
      return;
    }
    console.error("ErrorBoundary caught an error:", error, errorInfo);
  }

  override render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="flex items-center justify-center h-96">
          <div className="text-center max-w-md p-6">
            <AlertTriangle className="h-16 w-16 text-eq-warning mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-eq-ink mb-2">
              Something went wrong
            </h2>
            <p className="text-eq-muted mb-4">
              An unexpected error occurred while rendering this component.
            </p>
            {this.state.error && (
              <details className="text-left bg-eq-surface-muted p-4 rounded-eq-md mb-4">
                <summary className="cursor-pointer text-sm font-medium text-eq-muted mb-2">
                  Error Details
                </summary>
                <pre className="text-xs text-eq-danger overflow-auto">
                  {this.state.error.message}
                  {"\n"}
                  {this.state.error.stack}
                </pre>
              </details>
            )}
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-eq-primary text-eq-primary-ink rounded-eq-sm hover:bg-eq-primary focus-ring"
            >
              {config.isTauri ? "Reload App" : "Reload Page"}
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
