import { useMemo, useState } from "react";
import { Link, NavLink, useSearchParams, useLocation, useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { FILTER_STATUS_LABELS, type FilterStatus } from "@/constants/processingStatus";
import { ProcessingStatus } from "@/core/generated/constants";
import { Menu, X, LogOut, HelpCircle, Settings, FolderOpen, Play, Download, PencilLine, Compass } from "lucide-react";
import { openAppTour } from "@/components/onboarding/tourEvents";
import { useThemeStore, THEME_OPTIONS, THEME_CYCLE } from "@/store/themeStore";
import { useFeatures } from "@/core/hooks/useServices";
import { config } from "@/config";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useSettingsStore } from "@/store/settingsStore";
import { useViewTransitionClick } from "@/lib/viewTransition";

// Static — never depends on render-time state.
const LOCAL_NAV_LINKS = [
  { to: "/", label: "Load", icon: FolderOpen },
  { to: "/preprocessing", label: "Process", icon: Play },
  { to: "/annotate", label: "Annotate", icon: PencilLine },
  { to: "/export", label: "Export", icon: Download },
];

export const Header = () => {
  const { username, isAuthenticated, isAdmin, logout } = useAuth();
  const [searchParams] = useSearchParams();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { mode: themeMode, setMode: setThemeMode } = useThemeStore();
  const features = useFeatures();
  const showIdentifierMetadata = useSettingsStore((s) => s.showIdentifierMetadata);
  // Wraps client-side nav in a View Transition (cross-fade + lift). No-op /
  // graceful fallback when the API or motion preference says so.
  const vtClick = useViewTransitionClick();

  // Reactive connection state — no polling needed
  const { connected } = useWebSocket();

  const ThemeIcon = (THEME_OPTIONS.find((o) => o.value === themeMode) ?? THEME_OPTIONS[0]!).icon;

  // Get current filter context from URL
  const groupId = searchParams.get("group");
  const participantId = searchParams.get("participant_id");
  const processingStatus = searchParams.get("processing_status");
  const isAnnotatePage = location.pathname === "/annotate";

  // Memoize so the array isn't rebuilt every render — Header re-renders
  // on every WS connection change, route change, and theme switch.
  const navLinks = useMemo(
    () => [
      // Server mode: separate upload page. WASM mode: loading is on Home page.
      ...(!config.isLocalMode && features.preprocessing ? [{ to: "/upload", label: "Upload" }] : []),
      ...(features.preprocessing ? [{ to: "/preprocessing", label: "Preprocessing" }] : []),
      { to: "/", label: "Groups" },
      { to: "/annotate", label: "Annotate" },
      ...(!config.isLocalMode && features.consensusComparison ? [{ to: "/consensus", label: "Consensus" }] : []),
      { to: "/export", label: "Export" },
      { to: "/settings", label: "Settings" },
      ...(features.admin && isAdmin ? [{ to: "/admin", label: "Admin" }] : []),
    ],
    [features.preprocessing, features.consensusComparison, features.admin, isAdmin],
  );

  const localNavLinks = LOCAL_NAV_LINKS;

  if (config.isLocalMode) {
    return (
      <header className="shrink-0 border-b border-eq-border bg-eq-surface text-eq-ink">
        <div className="flex h-12 w-full items-center justify-between gap-3 px-4 sm:px-6 lg:px-8">
          <Link
            to="/"
            className="min-w-0 text-sm font-semibold tracking-normal text-eq-ink focus-ring rounded"
          >
            iOS Screen Time Screenshot Processor
          </Link>

          <nav className="hidden items-center gap-1 md:flex" aria-label="Primary">
            {localNavLinks.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                end={to === "/"}
                onClick={vtClick(to)}
                className={({ isActive }) =>
                  [
                    "inline-flex h-8 items-center gap-1.5 rounded-eq-sm border px-3 text-xs font-medium transition-colors focus-ring",
                    isActive
                      ? "border-eq-primary bg-eq-primary text-eq-primary-ink"
                      : "border-eq-border bg-eq-surface text-eq-muted hover:bg-eq-surface-muted",
                  ].join(" ")
                }
              >
                <Icon className="h-3.5 w-3.5" />
                {label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setThemeMode(THEME_CYCLE[themeMode])}
              className="inline-flex h-8 w-8 items-center justify-center rounded-eq-sm border border-eq-border bg-eq-surface text-eq-muted hover:bg-eq-surface-muted focus-ring"
              aria-label={`Theme: ${themeMode}. Click to switch.`}
              title={`Theme: ${themeMode} (click to switch)`}
            >
              <ThemeIcon className="h-4 w-4" />
            </button>
            <Link
              to="/settings"
              className="inline-flex h-8 w-8 items-center justify-center rounded-eq-sm border border-eq-border bg-eq-surface text-eq-muted hover:bg-eq-surface-muted focus-ring"
              aria-label="Settings"
              title="Settings"
            >
              <Settings className="h-4 w-4" />
            </Link>
            <button
              onClick={() => openAppTour()}
              className="inline-flex h-8 w-8 items-center justify-center rounded-eq-sm border border-eq-border bg-eq-surface text-eq-muted hover:bg-eq-surface-muted focus-ring"
              aria-label="Take the guided tour"
              title="Take the guided tour"
            >
              <Compass className="h-4 w-4" />
            </button>
            <Link
              to="/help"
              className="inline-flex h-8 w-8 items-center justify-center rounded-eq-sm border border-eq-border bg-eq-surface text-eq-muted hover:bg-eq-surface-muted focus-ring"
              aria-label="Help"
              title="Help"
            >
              <HelpCircle className="h-4 w-4" />
            </Link>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="inline-flex h-8 w-8 items-center justify-center rounded-eq-sm border border-eq-border bg-eq-surface text-eq-muted hover:bg-eq-surface-muted focus-ring md:hidden"
              aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <nav className="border-t border-eq-border bg-eq-surface px-3 py-2 md:hidden">
            <div className="grid w-full grid-cols-4 gap-2">
              {localNavLinks.map(({ to, label, icon: Icon }) => (
                <NavLink
                  key={to}
                  to={to}
                  end={to === "/"}
                  onClick={(e) => { setMobileMenuOpen(false); vtClick(to)(e); }}
                  className={({ isActive }) =>
                    [
                      "inline-flex h-9 items-center justify-center gap-1.5 rounded-eq-sm border px-2 text-xs font-medium focus-ring",
                      isActive
                        ? "border-eq-primary bg-eq-primary text-eq-primary-ink"
                        : "border-eq-border bg-eq-surface text-eq-muted hover:bg-eq-surface-muted",
                    ].join(" ")
                  }
                >
                  <Icon className="h-3.5 w-3.5" />
                  {label}
                </NavLink>
              ))}
            </div>
          </nav>
        )}
      </header>
    );
  }

  return (
    <header className="bg-eq-surface shadow-sm border-b border-eq-border">
      <div className="px-4">
        <div className="flex justify-between items-center h-16">
          {/* Left: Logo and Nav */}
          <div className="flex items-center space-x-8">
            <Link to="/" className="text-xl font-bold text-eq-primary font-heading focus-ring rounded">
              iOS Screen Time Screenshot Processor
            </Link>

            {/* Desktop Navigation */}
            {isAuthenticated && (
              <nav className="hidden md:flex space-x-1">
                {navLinks.map((link) => (
                  <Link
                    key={link.to}
                    to={link.to}
                    onClick={vtClick(link.to)}
                    className="text-eq-muted hover:text-eq-primary hover:bg-eq-surface-muted px-3 py-2 rounded-md text-sm font-medium transition-colors focus-ring"
                  >
                    {link.label}
                  </Link>
                ))}
              </nav>
            )}
          </div>

          {/* Center: Queue Context Indicator */}
          {isAnnotatePage && (participantId || processingStatus || (showIdentifierMetadata && groupId)) && (
            <div className="absolute left-1/2 transform -translate-x-1/2 hidden lg:flex items-center gap-2 px-3 py-1 bg-eq-surface-muted rounded-md text-sm">
              <span className="text-eq-muted">Queue:</span>
              {showIdentifierMetadata && groupId && (
                <span className="font-medium text-eq-muted">{groupId}</span>
              )}
              {showIdentifierMetadata && groupId && participantId && (
                <span className="text-eq-muted">/</span>
              )}
              {showIdentifierMetadata && participantId && (
                <span className="font-medium text-eq-secondary">
                  {participantId}
                </span>
              )}
              {showIdentifierMetadata && participantId && processingStatus && (
                <span className="text-eq-muted">/</span>
              )}
              {processingStatus && (
                <>
                  <span className="text-eq-muted">Status:</span>
                  <span
                    className={"font-medium " + (
                      processingStatus === ProcessingStatus.COMPLETED
                        ? "text-eq-success"
                        : processingStatus === ProcessingStatus.FAILED
                          ? "text-eq-danger"
                          : processingStatus === ProcessingStatus.PENDING
                            ? "text-eq-info"
                            : "text-eq-muted"
                    )}
                  >
                    {FILTER_STATUS_LABELS[processingStatus as FilterStatus] || processingStatus}
                  </span>
                </>
              )}
            </div>
          )}

          {/* Right: User info + Mobile menu toggle */}
          <div className="flex items-center space-x-4">
            {isAuthenticated && username ? (
              <>
                {/* Online/offline indicator (server mode only) */}
                {!config.isLocalMode && (
                  <span
                    className="hidden sm:inline-flex items-center gap-1.5 text-xs"
                    title={connected ? "WebSocket connected" : "WebSocket disconnected"}
                  >
                    <span
                      className={`inline-block h-2 w-2 rounded-full ${
                        connected
                          ? "bg-eq-success"
                          : "bg-eq-danger"
                      }`}
                    />
                    <span className={connected ? "text-eq-success" : "text-eq-danger"}>
                      {connected ? "Connected" : "Offline"}
                    </span>
                  </span>
                )}
                <span className="text-sm text-eq-muted hidden sm:inline">
                  Welcome, <span className="font-medium">{username}</span>
                </span>
                <Link
                  to="/help"
                  className="p-2 text-eq-muted hover:text-eq-ink hover:bg-eq-surface-muted rounded-md transition-colors focus-ring"
                  aria-label="Help"
                  title="Help"
                >
                  <HelpCircle className="h-4 w-4" />
                </Link>
                {!config.isLocalMode && (
                  <button
                    onClick={() => setThemeMode(THEME_CYCLE[themeMode])}
                    className="p-2 text-eq-muted hover:text-eq-ink hover:bg-eq-surface-muted rounded-md transition-colors focus-ring"
                    aria-label={`Theme: ${themeMode}. Click to switch.`}
                    title={`Theme: ${themeMode}`}
                  >
                    <ThemeIcon className="h-4 w-4" />
                  </button>
                )}
                <button
                  onClick={() => { logout(); void navigate("/login"); }}
                  className="hidden md:inline-flex items-center gap-2 bg-eq-surface-muted hover:bg-eq-border text-eq-ink px-4 py-2 rounded-md text-sm font-medium transition-colors focus-ring"
                  aria-label="Logout"
                >
                  <LogOut className="h-4 w-4" />
                  Logout
                </button>
                {/* Mobile hamburger */}
                <button
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="md:hidden p-2 text-eq-muted hover:text-eq-ink hover:bg-eq-surface-muted rounded-md focus-ring"
                  aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
                  aria-expanded={mobileMenuOpen}
                >
                  {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
                </button>
              </>
            ) : (
              <Link
                to="/login"
                className="bg-eq-primary hover:bg-eq-primary/90 text-eq-primary-ink px-4 py-2 rounded-md text-sm font-medium transition-colors focus-ring"
              >
                Login
              </Link>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && isAuthenticated && (
        <nav className="md:hidden border-t border-eq-border bg-eq-surface px-4 py-2 space-y-1">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              onClick={(e) => { setMobileMenuOpen(false); vtClick(link.to)(e); }}
              className="block text-eq-muted hover:text-eq-primary hover:bg-eq-surface-muted px-3 py-2 rounded-md text-sm font-medium transition-colors focus-ring"
            >
              {link.label}
            </Link>
          ))}
          <button
            onClick={() => { logout(); setMobileMenuOpen(false); void navigate("/login"); }}
            className="w-full text-left text-eq-muted hover:text-eq-danger hover:bg-eq-danger-bg px-3 py-2 rounded-md text-sm font-medium transition-colors focus-ring flex items-center gap-2"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </button>
        </nav>
      )}
    </header>
  );
};
