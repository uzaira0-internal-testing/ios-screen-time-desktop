import { useEffect } from "react";
import { useNavigate } from "react-router";
import { config } from "@/config";
import { useThemeStore } from "@/store/themeStore";

/** Right-click keeps its menu where it edits or copies something. */
const wantsContextMenu = (target: EventTarget | null) => {
  if (window.getSelection()?.toString()) return true;
  const el = target instanceof Element ? target : null;
  return !!el?.closest("input, textarea, select, [contenteditable=''], [contenteditable='true']");
};

/**
 * Desktop-only window behaviour that the web page itself cannot see: showing
 * the window once the page has rendered, the app menu's Settings… item, the
 * title bar and window colour following the app's theme, and no browser
 * right-click menu (Reload, Back, Inspect) outside text.
 * Renders nothing; mounted inside the router so it can navigate.
 * All imports from @tauri-apps/* are dynamic to avoid breaking web/WASM builds.
 */
export function DesktopShell() {
  const navigate = useNavigate();
  const themeMode = useThemeStore((s) => s.mode);

  // The window starts hidden so it never shows a blank frame. Effects run
  // after the first commit without waiting for an animation frame, which a
  // hidden window may never get.
  useEffect(() => {
    void import("@tauri-apps/api/core")
      .then(({ invoke }) => invoke("app_ready"))
      .catch((err: unknown) => console.error("app_ready failed:", err));
  }, []);

  useEffect(() => {
    let unlisten: (() => void) | undefined;
    let disposed = false;
    void import("@tauri-apps/api/event")
      .then(({ listen }) =>
        listen<string>("menu", ({ payload }) => {
          if (payload === "settings") void navigate("/settings");
        }),
      )
      .then((fn) => {
        if (disposed) fn();
        else unlisten = fn;
      })
      .catch((err: unknown) => console.error("Menu listener failed:", err));
    return () => {
      disposed = true;
      unlisten?.();
    };
  }, [navigate]);

  // The title bar follows the app's theme, and the window behind the page
  // matches the page so resizing never flashes the other colour.
  useEffect(() => {
    const sync = () => {
      const background = getComputedStyle(document.documentElement).getPropertyValue("--eq-bg").trim();
      void import("@tauri-apps/api/webviewWindow")
        .then(async ({ getCurrentWebviewWindow }) => {
          const win = getCurrentWebviewWindow();
          await win.setTheme(themeMode === "system" ? null : themeMode);
          if (background) await win.setBackgroundColor(background);
        })
        .catch(() => {
          /* non-fatal: cosmetic; the page keeps its own theme */
        });
    };
    sync();
    if (themeMode !== "system") return;
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    media.addEventListener("change", sync);
    return () => media.removeEventListener("change", sync);
  }, [themeMode]);

  useEffect(() => {
    if (config.isDev) return;
    const onContextMenu = (e: MouseEvent) => {
      if (!wantsContextMenu(e.target)) e.preventDefault();
    };
    document.addEventListener("contextmenu", onContextMenu);
    return () => document.removeEventListener("contextmenu", onContextMenu);
  }, []);

  return null;
}
