import { useCallback, useEffect, useRef, useState } from "react";
import { config } from "../../config";
import type { UpdateInfo } from "../../lib/updater";
import { useAutoUpdateCheck } from "../../lib/desktop/updatePreference";
import { Download, RefreshCw, RotateCcw, X, ChevronDown, ChevronUp } from "lucide-react";
import toast from "react-hot-toast";

type BannerState =
  | { status: "idle" }
  | { status: "checking" }
  | { status: "available"; info: UpdateInfo }
  | { status: "downloading"; percent: number | null; downloaded: number; total: number }
  | { status: "ready"; info: UpdateInfo }
  | { status: "error"; message: string; retryAction?: "check" | "download"; info?: UpdateInfo | undefined }
  | { status: "dismissed"; version: string };

/** Check interval: 15 minutes */
const CHECK_INTERVAL_MS = 15 * 60 * 1000;
/** Initial delay before first check */
const INITIAL_DELAY_MS = 3000;
/** Max retries for failed checks */
const MAX_RETRIES = 3;
/** Delay between retries (doubles each time) */
const RETRY_BASE_MS = 5000;
/** Minimum time between visibility-triggered checks */
const VISIBILITY_COOLDOWN_MS = 60 * 1000;

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export const UpdateBanner = () => {
  const [state, setState] = useState<BannerState>({ status: "idle" });
  const [showNotes, setShowNotes] = useState(false);
  const retryCount = useRef(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastCheckRef = useRef(0);
  // Store the in-flight promise itself for atomic compare-and-swap dedup
  const checkInFlightRef = useRef<Promise<void> | null>(null);
  // Ref mirror of state.status so event handlers can read it without stale closures
  const stateRef = useRef<BannerState["status"]>("idle");
  const autoCheck = useAutoUpdateCheck((s) => s.enabled);

  const doCheck = useCallback(async (): Promise<void> => {
    // Prevent concurrent checks (visibility + focus can fire together).
    // Compare-and-swap on the promise itself avoids the race window between
    // reading a boolean flag and setting it.
    if (checkInFlightRef.current) return checkInFlightRef.current;
    // Don't interrupt active download or ready states
    if (stateRef.current === "downloading" || stateRef.current === "ready") return;

    const runCheck = async (): Promise<void> => {
      lastCheckRef.current = Date.now();
      setState({ status: "checking" });
      try {
        const { checkForUpdate } = await import("../../lib/updater");
        const info = await checkForUpdate();
        if (config.isDev) console.warn("[UpdateBanner] Check result:", info);
        retryCount.current = 0;
        if (info) {
          // Show the banner — even if previously dismissed, a NEW version should appear
          setState((prev) => {
            if (prev.status === "dismissed" && prev.version === info.version) {
              return prev;
            }
            return { status: "available", info };
          });
        } else {
          setState({ status: "idle" });
        }
      } catch (err) {
        console.error("[UpdateBanner] Update check failed:", err);
        const message = err instanceof Error ? err.message : "Update check failed";

        // Auto-retry with exponential backoff
        if (retryCount.current < MAX_RETRIES) {
          retryCount.current++;
          const delay = RETRY_BASE_MS * Math.pow(2, retryCount.current - 1);
          if (config.isDev) console.warn(`[UpdateBanner] Retrying in ${delay}ms (attempt ${retryCount.current}/${MAX_RETRIES})`);
          setTimeout(() => {
            void doCheck();
          }, delay);
          return;
        }

        // Background checks fail quietly: the app is meant to work offline, so
        // no network is not an error worth a red banner. Check for Updates…
        // in the app menu reports failures, and a failed download still shows.
        console.warn("[UpdateBanner] Giving up on this update check:", message);
        setState({ status: "idle" });
      }
    };

    const promise = runCheck();
    checkInFlightRef.current = promise;
    try {
      await promise;
    } finally {
      // Only clear if we're still the in-flight promise (defensive against races)
      if (checkInFlightRef.current === promise) {
        checkInFlightRef.current = null;
      }
    }
  }, []);

  // Keep stateRef in sync
  useEffect(() => {
    stateRef.current = state.status;
  }, [state.status]);

  // App menu → Check for Updates…: check now, show the banner even for a
  // version dismissed earlier, and say so when there is nothing newer.
  useEffect(() => {
    if (!config.isTauri) return;
    const checkNow = async () => {
      if (stateRef.current === "downloading" || stateRef.current === "ready") return;
      try {
        const { checkForUpdate } = await import("../../lib/updater");
        const info = await checkForUpdate();
        lastCheckRef.current = Date.now();
        if (info) {
          setState({ status: "available", info });
          return;
        }
        const { getVersion } = await import("@tauri-apps/api/app");
        toast.success(`You have the latest version (${await getVersion()}).`);
      } catch (err) {
        console.error("[UpdateBanner] Manual update check failed:", err);
        toast.error("Could not check for updates. Check the internet connection and try again.");
      }
    };
    let unlisten: (() => void) | undefined;
    let disposed = false;
    void import("@tauri-apps/api/event")
      .then(({ listen }) =>
        listen<string>("menu", ({ payload }) => {
          if (payload === "check-updates") void checkNow();
        }),
      )
      .then((fn) => {
        if (disposed) fn();
        else unlisten = fn;
      })
      .catch((err: unknown) => console.error("[UpdateBanner] Menu listener failed:", err));
    return () => {
      disposed = true;
      unlisten?.();
    };
  }, []);

  // Initial check + periodic re-check + visibility/focus re-check, unless the
  // user turned automatic checks off in Settings → Privacy.
  useEffect(() => {
    if (!config.isTauri || !autoCheck) return;

    const initialTimer = setTimeout(() => {
      void doCheck();
    }, INITIAL_DELAY_MS);

    // Periodic re-check
    intervalRef.current = setInterval(() => {
      void doCheck();
    }, CHECK_INTERVAL_MS);

    // Re-check when the app comes back to foreground or gains focus.
    // Both events can fire on the same user action — the in-flight guard deduplicates.
    const handleAppResume = () => {
      if (document.visibilityState !== "visible") return;
      if (Date.now() - lastCheckRef.current < VISIBILITY_COOLDOWN_MS) return;
      // Fire-and-forget: doCheck handles its own errors and sets banner state.
      void doCheck();
    };
    document.addEventListener("visibilitychange", handleAppResume);
    window.addEventListener("focus", handleAppResume);

    return () => {
      clearTimeout(initialTimer);
      if (intervalRef.current) clearInterval(intervalRef.current);
      document.removeEventListener("visibilitychange", handleAppResume);
      window.removeEventListener("focus", handleAppResume);
    };
  }, [doCheck, autoCheck]);

  const handleUpdate = async () => {
    const info = state.status === "available" ? state.info
      : state.status === "error" ? state.info
      : undefined;

    setState({ status: "downloading", percent: null, downloaded: 0, total: 0 });
    let downloadedSoFar = 0;

    try {
      const { downloadAndInstall } = await import("../../lib/updater");
      await downloadAndInstall((progress) => {
        if (progress.total > 0 && progress.downloaded === progress.total) {
          // Finished
          setState({ status: "downloading", percent: 100, downloaded: progress.total, total: progress.total });
        } else if (progress.total > 0) {
          downloadedSoFar += progress.downloaded;
          const percent = Math.min(100, Math.round((downloadedSoFar / progress.total) * 100));
          setState({ status: "downloading", percent, downloaded: downloadedSoFar, total: progress.total });
        }
      });
      setState({ status: "ready", info: info ?? { version: "latest", currentVersion: "" } });
    } catch (err) {
      console.error("[UpdateBanner] Download/install failed:", err);
      setState({
        status: "error",
        message: err instanceof Error ? err.message : "Update failed",
        retryAction: "download",
        info,
      });
    }
  };

  const handleRestart = async () => {
    try {
      const { relaunchApp } = await import("../../lib/updater");
      await relaunchApp();
    } catch (err) {
      console.error("[UpdateBanner] Relaunch failed:", err);
      setState({
        status: "error",
        message: "Could not restart automatically. Please close and reopen the app.",
      });
    }
  };

  const handleRetry = () => {
    if (state.status === "error") {
      retryCount.current = 0;
      if (state.retryAction === "download") {
        // Fire-and-forget: both handlers report failures via banner state.
        void handleUpdate();
      } else {
        void doCheck();
      }
    }
  };

  const dismiss = () => {
    const version = state.status === "available" ? state.info.version
      : state.status === "error" && state.info ? state.info.version
      : "unknown";
    setState({ status: "dismissed", version });
  };

  // Show nothing for idle, checking, dismissed, or non-Tauri
  if (!config.isTauri || state.status === "idle" || state.status === "checking" || state.status === "dismissed") {
    return null;
  }

  if (state.status === "available") {
    const notes = state.info.body;
    return (
      <div className="bg-eq-secondary text-sm text-white">
        <div className="flex items-center justify-between gap-3 px-4 py-2">
          <div className="flex items-center gap-2 min-w-0">
            <Download className="h-4 w-4 shrink-0" />
            <span className="truncate">
              <strong>v{state.info.version}</strong> available
              {state.info.currentVersion && (
                <span className="text-eq-info-bg ml-1">(current: v{state.info.currentVersion})</span>
              )}
            </span>
            {notes && (
              <button
                onClick={() => setShowNotes(!showNotes)}
                className="text-eq-info-bg hover:text-white transition-colors shrink-0"
                aria-label={showNotes ? "Hide release notes" : "Show release notes"}
              >
                {showNotes ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </button>
            )}
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => {
                void handleUpdate();
              }}
              className="rounded-eq-sm bg-white px-3 py-1 text-xs font-medium text-eq-secondary hover:bg-eq-info-bg transition-colors"
            >
              Update now
            </button>
            <button
              onClick={dismiss}
              className="text-eq-info-bg hover:text-white transition-colors"
              aria-label="Dismiss"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
        {showNotes && notes && (
          <div className="px-4 pb-2 text-xs text-eq-info-bg whitespace-pre-wrap border-t border-eq-border pt-2">
            {notes}
          </div>
        )}
      </div>
    );
  }

  if (state.status === "downloading") {
    const isIndeterminate = state.percent === null;
    return (
      <div className="bg-eq-secondary px-4 py-2 text-sm text-white">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <RefreshCw className="h-3.5 w-3.5 animate-spin" />
            <span>
              Downloading update...
              {!isIndeterminate && ` ${state.percent}%`}
              {state.total > 0 && (
                <span className="text-eq-info-bg ml-1">
                  ({formatBytes(state.downloaded)} / {formatBytes(state.total)})
                </span>
              )}
            </span>
          </div>
        </div>
        <div className="h-1.5 w-full rounded-full bg-eq-info-bg/40 overflow-hidden">
          <div
            className={`h-full rounded-full bg-white ${isIndeterminate ? "animate-pulse w-full opacity-60" : "transition-all duration-300"}`}
            style={isIndeterminate ? undefined : { width: `${state.percent}%` }}
          />
        </div>
      </div>
    );
  }

  if (state.status === "ready") {
    return (
      <div className="flex items-center justify-between gap-3 bg-eq-primary px-4 py-2 text-sm text-eq-primary-ink">
        <div className="flex items-center gap-2">
          <RotateCcw className="h-4 w-4" />
          <span>
            Update to <strong>v{state.info.version}</strong> installed — Restart to apply
          </span>
        </div>
        <button
          onClick={() => {
            void handleRestart();
          }}
          className="rounded-eq-sm bg-white px-3 py-1 text-xs font-medium text-eq-ink hover:bg-eq-surface-muted transition-colors"
        >
          Restart now
        </button>
      </div>
    );
  }

  if (state.status === "error") {
    return (
      <div className="flex items-center justify-between gap-3 bg-eq-danger px-4 py-2 text-sm text-white">
        <span className="truncate">Update failed: {state.message}</span>
        <div className="flex items-center gap-2 shrink-0">
          {state.retryAction && (
            <button
              onClick={handleRetry}
              className="rounded-eq-sm bg-white px-3 py-1 text-xs font-medium text-eq-danger hover:bg-eq-danger-bg transition-colors"
            >
              Retry
            </button>
          )}
          <button
            onClick={dismiss}
            className="text-eq-danger-bg hover:text-white transition-colors"
            aria-label="Dismiss"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    );
  }

  return null;
};
