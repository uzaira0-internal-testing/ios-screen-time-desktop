import { ReactNode, useEffect, useRef } from "react";
import { useLocation } from "react-router";
import { Header } from "./Header";
import { UpdateBanner } from "./UpdateBanner";
import { FirstRunTour } from "@/components/onboarding/FirstRunTour";

interface LayoutProps {
  children: ReactNode;
  /** Set to true to disable scrolling (e.g., for annotation workspace) */
  noScroll?: boolean;
}

export const Layout = ({ children, noScroll = false }: LayoutProps) => {
  const location = useLocation();
  const mainRef = useRef<HTMLElement>(null);
  // Move focus to the main region on client-side navigation so keyboard/screen
  // reader users aren't stranded on the old page's nav link and are told the
  // content changed. preventScroll avoids a jarring jump.
  useEffect(() => {
    mainRef.current?.focus({ preventScroll: true });
  }, [location.pathname]);

  return (
    <div className="h-screen bg-eq-bg text-eq-ink font-eq-sans flex flex-col overflow-hidden">
      {/* Skip-to-content link (WCAG 2.4.1 Bypass Blocks): visually hidden until
          focused, it must be the first focusable element so keyboard/screen-reader
          users can jump past the banner + nav straight to the main region. */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-[100] focus:px-4 focus:py-2 focus:bg-eq-surface focus:text-eq-ink focus:rounded-eq-md focus:shadow-xl focus-ring"
      >
        Skip to main content
      </a>
      <UpdateBanner />
      <Header />
      {/* tabIndex=0 makes the scrollable main region keyboard-focusable so
          keyboard-only users can scroll long content (WCAG 2.1.1). The role
          is implicit on <main>; aria-label provides a screen-reader name. */}
      <main
        ref={mainRef}
        id="main-content"
        className={`flex-1 focus:outline-none ${noScroll ? "overflow-hidden" : "overflow-auto"}`}
        tabIndex={noScroll ? -1 : 0}
        aria-label="Main content"
      >
        {children}
      </main>
      <FirstRunTour />
    </div>
  );
};
