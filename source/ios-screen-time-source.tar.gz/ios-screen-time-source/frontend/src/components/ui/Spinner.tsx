interface SpinnerProps {
  /** Diameter. sm = 1rem, md = 1.5rem, lg = 2rem, xl = 3rem. */
  size?: "sm" | "md" | "lg" | "xl";
  /** Optional visible label rendered beside the spinner. */
  label?: string;
  className?: string;
}

const SIZE: Record<NonNullable<SpinnerProps["size"]>, string> = {
  sm: "h-4 w-4 border-2",
  md: "h-6 w-6 border-2",
  lg: "h-8 w-8 border-[3px]",
  xl: "h-12 w-12 border-4",
};

/**
 * Shared loading spinner — a single, theme-token-driven implementation to
 * replace the many ad-hoc inline `animate-spin border-t-transparent` divs that
 * had drifted in size, border, and color across the app. The track uses
 * eq-border with an eq-primary head so it follows the active theme.
 */
export function Spinner({ size = "md", label, className = "" }: SpinnerProps) {
  return (
    <span className={`inline-flex items-center gap-2 ${className}`} role="status" aria-live="polite">
      <span
        className={`inline-block animate-spin rounded-full border-eq-border border-t-eq-primary ${SIZE[size]}`}
        aria-hidden="true"
      />
      {label ? <span className="text-eq-muted">{label}</span> : <span className="sr-only">Loading</span>}
    </span>
  );
}
