/**
 * Settings section for optional OCR language packs.
 *
 * The app ships English only. Everything numeric — the grid, the 24 hourly bars
 * — reads fine in any locale that uses Western digits, so a pack is purely an
 * accuracy upgrade for TEXT: app names (which are the title on app-detail
 * pages) and the total string.
 *
 * Downloading is explicit and per-language because the packs total ~75 MB and
 * this app is otherwise fully offline. Nothing is fetched until the user asks.
 */

import { Check, Download, Globe, Loader2, Trash2, TriangleAlert } from "lucide-react";
import React from "react";

import { Card } from "@/components/ui/Card";
import {
  installLanguagePack,
  LanguagePackError,
  listLanguagePacks,
  type LanguagePackStatus,
  removeLanguagePack,
  setPackEnabled,
  totalLanguagePackBytes,
} from "@/core/implementations/wasm/languagePacks/languagePackStore";

function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

export function LanguagePacks() {
  const [packs, setPacks] = React.useState<LanguagePackStatus[] | null>(null);
  const [busy, setBusy] = React.useState<string | null>(null);
  const [progress, setProgress] = React.useState<{ code: string; pct: number } | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [totalBytes, setTotalBytes] = React.useState(0);

  const refresh = React.useCallback(async () => {
    setPacks(await listLanguagePacks());
    setTotalBytes(await totalLanguagePackBytes());
  }, []);

  React.useEffect(() => {
    void refresh();
  }, [refresh]);

  async function download(pack: LanguagePackStatus) {
    setError(null);
    setBusy(pack.code);
    setProgress({ code: pack.code, pct: 0 });
    try {
      await installLanguagePack(pack.code, (received, total) => {
        setProgress({ code: pack.code, pct: total ? Math.min(100, (received / total) * 100) : 0 });
      });
      // A freshly downloaded pack is useless until it is switched on, and the
      // user just asked for it — enabling here avoids a pointless second click.
      await setPackEnabled(pack.code, true);
      await refresh();
    } catch (e) {
      setError(
        e instanceof LanguagePackError ? e.message : `Could not download the ${pack.english_name} pack`,
      );
    } finally {
      setBusy(null);
      setProgress(null);
    }
  }

  async function remove(pack: LanguagePackStatus) {
    setError(null);
    setBusy(pack.code);
    try {
      await removeLanguagePack(pack.code);
      await refresh();
    } catch (e) {
      setError(e instanceof LanguagePackError ? e.message : `Could not remove the ${pack.english_name} pack`);
    } finally {
      setBusy(null);
    }
  }

  async function toggle(pack: LanguagePackStatus) {
    setError(null);
    try {
      await setPackEnabled(pack.code, !pack.enabled);
      await refresh();
    } catch (e) {
      setError(e instanceof LanguagePackError ? e.message : "Could not change the language selection");
    }
  }

  const installed = packs?.filter((p) => p.installed) ?? [];
  const available = packs?.filter((p) => !p.installed) ?? [];

  return (
    <Card padding="lg">
      <div className="flex items-center gap-3 mb-4">
        <Globe className="w-6 h-6 text-eq-muted" aria-hidden="true" />
        <div>
          <h2 className="text-xl font-semibold text-eq-ink">OCR Languages</h2>
          <p className="text-sm text-eq-muted">
            English is built in and always used. Add a language to read app names and totals more
            accurately on screenshots from a non-English phone.
          </p>
        </div>
      </div>

      <p className="text-sm text-eq-muted mb-4">
        Charts and hourly values already work in any language — these packs only improve text.
        Downloading uses the network once; everything stays on this device afterwards.
      </p>

      {error && (
        <div
          role="alert"
          className="flex items-start gap-2 mb-4 p-3 rounded-md bg-eq-danger-soft text-eq-danger text-sm"
        >
          <TriangleAlert className="w-4 h-4 mt-0.5 shrink-0" aria-hidden="true" />
          <span>{error}</span>
        </div>
      )}

      {packs === null ? (
        <p className="text-sm text-eq-muted">Loading…</p>
      ) : (
        <div className="space-y-6">
          {installed.length > 0 && (
            <section aria-labelledby="lp-installed">
              <h3 id="lp-installed" className="text-sm font-semibold text-eq-ink mb-2">
                Downloaded ({formatBytes(totalBytes)})
              </h3>
              <ul className="divide-y divide-eq-line">
                {installed.map((p) => (
                  <li key={p.code} className="flex items-center gap-3 py-2">
                    <input
                      type="checkbox"
                      id={`lp-${p.code}`}
                      checked={p.enabled}
                      onChange={() => void toggle(p)}
                      aria-label={`Use ${p.english_name} for OCR`}
                      className="w-4 h-4"
                    />
                    <label htmlFor={`lp-${p.code}`} className="flex-1 text-sm text-eq-ink">
                      {p.english_name}{" "}
                      <span className="text-eq-muted" dir={p.direction}>
                        ({p.native_name})
                      </span>
                    </label>
                    <span className="text-xs text-eq-muted">{formatBytes(p.bytes)}</span>
                    <button
                      type="button"
                      onClick={() => void remove(p)}
                      disabled={busy === p.code}
                      aria-label={`Remove the ${p.english_name} language pack`}
                      className="p-1.5 rounded text-eq-muted hover:text-eq-danger disabled:opacity-50"
                    >
                      {busy === p.code ? (
                        <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
                      ) : (
                        <Trash2 className="w-4 h-4" aria-hidden="true" />
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          )}

          <section aria-labelledby="lp-available">
            <h3 id="lp-available" className="text-sm font-semibold text-eq-ink mb-2">
              Available
            </h3>
            <ul className="divide-y divide-eq-line max-h-80 overflow-y-auto">
              {available.map((p) => (
                <li key={p.code} className="flex items-center gap-3 py-2">
                  <span className="flex-1 text-sm text-eq-ink">
                    {p.english_name}{" "}
                    <span className="text-eq-muted" dir={p.direction}>
                      ({p.native_name})
                    </span>
                  </span>
                  <span className="text-xs text-eq-muted">{formatBytes(p.bytes)}</span>
                  <button
                    type="button"
                    onClick={() => void download(p)}
                    disabled={busy !== null}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded text-sm text-eq-accent hover:bg-eq-accent-soft disabled:opacity-50"
                  >
                    {busy === p.code ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
                        <span>
                          {progress?.code === p.code ? `${Math.round(progress.pct)}%` : "Downloading…"}
                        </span>
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4" aria-hidden="true" />
                        <span>Download</span>
                      </>
                    )}
                  </button>
                </li>
              ))}
              {available.length === 0 && (
                <li className="flex items-center gap-2 py-2 text-sm text-eq-muted">
                  <Check className="w-4 h-4" aria-hidden="true" />
                  Every available language is downloaded.
                </li>
              )}
            </ul>
          </section>

          <p aria-live="polite" className="sr-only">
            {busy ? `Working on ${busy}` : ""}
          </p>
        </div>
      )}
    </Card>
  );
}
