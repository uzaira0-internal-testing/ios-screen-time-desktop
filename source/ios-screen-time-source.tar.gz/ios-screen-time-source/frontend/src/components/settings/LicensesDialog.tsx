import { useEffect, useState } from "react";
import { Modal } from "@/components/ui/Modal";

/**
 * Shows dist/third-party-licenses.txt, which the build writes from
 * licenses/ (native libraries, fonts, Rust crates) and the npm packages it
 * bundled. Fetched on open: it is several hundred KB of text.
 */
export function LicensesDialog() {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open || text !== null) return;
    const controller = new AbortController();
    fetch("third-party-licenses.txt", { signal: controller.signal })
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.text();
      })
      .then(setText)
      .catch((e: unknown) => {
        if (controller.signal.aborted) return;
        setError(e instanceof Error ? e.message : String(e));
      });
    return () => controller.abort();
  }, [open, text]);

  return (
    <>
      <button
        type="button"
        onClick={() => {
          setError(null);
          setOpen(true);
        }}
        className="text-eq-primary hover:underline focus-ring rounded-sm"
      >
        Third-party licenses
      </button>
      <Modal
        open={open}
        onOpenChange={setOpen}
        title="Third-party licenses"
        description="Open-source software and data included in this app."
        size="xl"
      >
        {error ? (
          <p className="text-sm text-eq-danger" role="alert">
            Could not load the license list ({error}).
          </p>
        ) : text === null ? (
          <p className="text-sm text-eq-muted">Loading…</p>
        ) : (
          <pre
            data-testid="third-party-licenses"
            role="region"
            aria-label="License text"
            // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex -- a scrolling text box must take focus so the keyboard can scroll it
            tabIndex={0}
            className="max-h-[65vh] overflow-auto whitespace-pre-wrap rounded-eq-sm border border-eq-border bg-eq-surface-muted p-3 font-mono text-xs text-eq-ink focus-ring"
          >
            {text}
          </pre>
        )}
      </Modal>
    </>
  );
}
