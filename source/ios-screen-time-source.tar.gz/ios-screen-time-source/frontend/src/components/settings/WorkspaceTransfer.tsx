import React from "react";
import { Download, Upload, Loader2, AlertTriangle, CheckCircle2, FolderArchive } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { useStorageService } from "@/core/hooks/useServices";
import {
  getInterruptedImport,
  clearImportSentinel,
} from "@/core/implementations/wasm/workspace/workspaceSentinel";
import type { ImportPhase } from "@/core/implementations/wasm/workspace/workspaceTransfer";
import { voidHandler } from "@/lib/asyncHandler";
import { saveBlob } from "@/lib/desktop/saveFile";
import { useLeaveGuard } from "@/lib/desktop/leaveGuard";
import { config } from "@/config";

const PHASE_LABEL: Record<ImportPhase, string> = {
  reading: "Reading archive…",
  validating: "Validating archive…",
  clearing: "Clearing current workspace…",
  "restoring-records": "Restoring records…",
  "restoring-blobs": "Restoring images…",
  finalizing: "Finalizing…",
};

type State =
  | { kind: "idle" }
  | { kind: "exporting" }
  | { kind: "importing"; phase: ImportPhase }
  | { kind: "error"; message: string }
  | { kind: "done"; message: string };

/**
 * Export / import the entire offline workspace (roadmap #22). WASM-only — the
 * caller gates this on `config.isLocalMode`. Export saves a ZIP of every Dexie
 * table + every image blob; import REPLACES the current workspace from such a ZIP
 * (validated in full before anything is cleared), then reloads.
 */
export function WorkspaceTransfer() {
  const storage = useStorageService();
  const [state, setState] = React.useState<State>({ kind: "idle" });
  const [confirmFile, setConfirmFile] = React.useState<File | null>(null);
  const [interrupted, setInterrupted] = React.useState(() => getInterruptedImport());
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const busy = state.kind === "exporting" || state.kind === "importing";
  useLeaveGuard(
    state.kind === "importing",
    "The workspace is still being restored. Quitting now leaves it incomplete until the archive is imported again.",
  );

  async function handleExport() {
    setState({ kind: "exporting" });
    try {
      const { exportWorkspace } = await import("@/core/implementations/wasm/workspace");
      const blob = await exportWorkspace();
      const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
      const saved = await saveBlob(blob, `screen-time-workspace_${ts}.zip`, { name: "ZIP archive", extensions: ["zip"] });
      if (!saved) {
        setState({ kind: "idle" });
        return;
      }
      setState({ kind: "done", message: config.isTauri ? `Workspace saved to ${saved}.` : "Workspace exported." });
    } catch (e) {
      setState({ kind: "error", message: e instanceof Error ? e.message : String(e) });
    }
  }

  function onPickFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0] ?? null;
    e.target.value = ""; // let the user re-pick the same file later
    if (file) setConfirmFile(file);
  }

  async function runImport(file: File) {
    setConfirmFile(null);
    setState({ kind: "importing", phase: "reading" });
    try {
      const bytes = new Uint8Array(await file.arrayBuffer());
      const { importWorkspace } = await import("@/core/implementations/wasm/workspace");
      const result = await importWorkspace(bytes, storage, {
        onProgress: (phase) => setState({ kind: "importing", phase }),
      });
      setInterrupted(null);
      // Reload so every Zustand store / service re-reads the restored workspace.
      setState({
        kind: "done",
        message: `Imported ${result.screenshots} screenshots, ${result.annotations} annotations, ${result.blobs} images. Reloading…`,
      });
      setTimeout(() => window.location.reload(), 800);
    } catch (e) {
      // The archive is validated before anything is cleared, so a failure here means
      // either pre-clear validation rejected it (workspace untouched) or a rare
      // mid-restore crash (the sentinel stays set and warns on next load).
      setState({ kind: "error", message: e instanceof Error ? e.message : String(e) });
    }
  }

  function dismissInterrupted() {
    clearImportSentinel();
    setInterrupted(null);
  }

  return (
    <Card padding="lg">
      <div className="flex items-center gap-3 mb-4">
        <FolderArchive className="w-6 h-6 text-eq-muted" />
        <div>
          <h2 className="text-xl font-semibold text-eq-ink">Workspace backup</h2>
          <p className="text-sm text-eq-muted">
            Export everything on this device to a single file. <strong className="text-eq-ink">Importing replaces your
            entire workspace</strong> — every group, screenshot, and annotation currently on this device is erased and
            swapped for the archive&rsquo;s contents. There is no merge. Export first if you want to keep what you have.
          </p>
        </div>
      </div>

      {interrupted && (
        <div className="mb-4 flex items-start gap-3 bg-eq-warning-bg border border-eq-warning rounded-eq-md p-3">
          <AlertTriangle className="w-5 h-5 text-eq-warning shrink-0 mt-0.5" />
          <div className="flex-1 text-sm text-eq-ink">
            A previous import did not finish (started {new Date(interrupted.startedAt).toLocaleString()}).
            Your workspace may be incomplete — re-import the archive to restore it fully.
          </div>
          <button
            onClick={dismissInterrupted}
            className="px-2 py-1 rounded-eq-sm text-sm text-eq-muted hover:bg-eq-surface-muted focus-ring"
          >
            Dismiss
          </button>
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={voidHandler(handleExport)}
          disabled={busy}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-eq-md bg-eq-primary text-white text-sm hover:bg-eq-primary disabled:opacity-50 focus-ring"
        >
          {state.kind === "exporting" ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Download className="w-4 h-4" />
          )}
          Export workspace
        </button>

        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={busy}
          title="Replaces ALL data currently on this device"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-eq-md border border-eq-danger text-sm text-eq-danger hover:bg-eq-danger-bg disabled:opacity-50 focus-ring"
        >
          <Upload className="w-4 h-4" /> Import workspace (replaces all)…
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".zip,application/zip"
          onChange={onPickFile}
          className="hidden"
          aria-hidden="true"
        />
      </div>

      {confirmFile && (
        <div className="mt-4 flex flex-col gap-3 bg-eq-danger-bg border border-eq-danger rounded-eq-md p-3">
          <span className="text-sm text-eq-danger">
            Importing <span className="font-mono">{confirmFile.name}</span> will <strong>replace</strong> your
            current workspace. The archive is fully checked first, so if it is invalid nothing is changed.
            This cannot be undone — export your current workspace first if you want to keep it.
          </span>
          <div className="flex gap-2">
            <button
              onClick={() => setConfirmFile(null)}
              className="px-3 py-1.5 rounded-eq-md border border-eq-border text-sm text-eq-muted"
            >
              Cancel
            </button>
            <button
              onClick={() => { void runImport(confirmFile); }}
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-eq-md bg-eq-danger text-white text-sm hover:bg-eq-danger"
            >
              <Upload className="w-4 h-4" /> Replace workspace
            </button>
          </div>
        </div>
      )}

      {state.kind === "importing" && (
        <div className="mt-4 flex items-center gap-2 text-sm text-eq-muted">
          <Loader2 className="w-4 h-4 animate-spin" /> {PHASE_LABEL[state.phase]}
        </div>
      )}
      {state.kind === "done" && (
        <div className="mt-4 flex items-center gap-2 text-sm text-eq-success">
          <CheckCircle2 className="w-4 h-4" /> {state.message}
        </div>
      )}
      {state.kind === "error" && (
        <div className="mt-4 flex items-start gap-2 text-sm text-eq-danger">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" /> {state.message}
        </div>
      )}
    </Card>
  );
}
