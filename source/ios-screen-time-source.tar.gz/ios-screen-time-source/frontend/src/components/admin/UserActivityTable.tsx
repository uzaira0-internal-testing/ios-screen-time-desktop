import { useState } from "react";
import type { components } from "@/types/api-schema";

// Use type from OpenAPI schema (Pydantic is the single source of truth)
type UserActivity = components["schemas"]["UserStatsRead"];

interface UserActivityTableProps {
  users: UserActivity[];
  loading: boolean;
  onUpdateUser: (
    userId: number,
    updates: { is_active?: boolean; role?: string },
  ) => Promise<void>;
}

export const UserActivityTable = ({
  users,
  loading,
  onUpdateUser,
}: UserActivityTableProps) => {
  const [updatingUserId, setUpdatingUserId] = useState<number | null>(null);

  const handleToggleActive = async (user: UserActivity) => {
    setUpdatingUserId(user.id);
    try {
      await onUpdateUser(user.id, { is_active: !user.is_active });
    } finally {
      setUpdatingUserId(null);
    }
  };

  const handleToggleRole = async (user: UserActivity) => {
    setUpdatingUserId(user.id);
    try {
      const newRole = user.role === "admin" ? "annotator" : "admin";
      await onUpdateUser(user.id, { role: newRole });
    } finally {
      setUpdatingUserId(null);
    }
  };

  if (loading) {
    return (
      <div className="bg-eq-surface rounded-lg shadow overflow-hidden">
        <div className="p-6">
          <div className="animate-pulse space-y-4">
            {Array.from({ length: 5 }, (_, i) => (
              <div key={i} className="h-12 bg-eq-surface-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-eq-surface rounded-lg shadow overflow-hidden">
      <div className="px-6 py-4 border-b border-eq-border">
        <h3 className="text-lg font-semibold text-eq-ink">User Activity</h3>
      </div>

      <div className="overflow-x-auto">
        <table
          className="min-w-full divide-y divide-eq-border"
          data-testid="user-table"
        >
          <thead className="bg-eq-surface-muted">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-eq-muted uppercase tracking-wider">
                User
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-eq-muted uppercase tracking-wider">
                Role
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-eq-muted uppercase tracking-wider">
                Annotations
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-eq-muted uppercase tracking-wider">
                Avg Time
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-eq-muted uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-eq-muted uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-eq-surface divide-y divide-eq-border">
            {users.map((user) => (
              <tr key={user.id} className="hover:bg-eq-surface-muted">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-eq-ink">
                    {user.username}
                  </div>
                  <div className="text-sm text-eq-muted">{user.email ?? "-"}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span
                    className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      user.role === "admin"
                        ? "bg-eq-info-bg text-eq-info"
                        : "bg-eq-surface-muted text-eq-ink"
                    }`}
                  >
                    {user.role}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-eq-ink">
                  {user.annotations_count}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-eq-ink">
                  {Math.round(user.avg_time_spent_seconds)}s
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span
                    className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      user.is_active
                        ? "bg-eq-success-bg text-eq-success"
                        : "bg-eq-danger-bg text-eq-danger"
                    }`}
                  >
                    {user.is_active ? "Active" : "Inactive"}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm space-x-2">
                  <button
                    onClick={() => { void handleToggleActive(user); }}
                    disabled={updatingUserId === user.id}
                    className="text-eq-primary hover:underline disabled:opacity-50"
                  >
                    {updatingUserId === user.id
                      ? "Updating..."
                      : user.is_active
                        ? "Deactivate"
                        : "Activate"}
                  </button>
                  <button
                    onClick={() => { void handleToggleRole(user); }}
                    disabled={updatingUserId === user.id}
                    className="text-eq-secondary hover:underline disabled:opacity-50"
                  >
                    {user.role === "admin" ? "Demote" : "Promote"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {users.length === 0 && (
        <div className="text-center py-12">
          <p className="text-eq-muted">No users found</p>
        </div>
      )}
    </div>
  );
};
