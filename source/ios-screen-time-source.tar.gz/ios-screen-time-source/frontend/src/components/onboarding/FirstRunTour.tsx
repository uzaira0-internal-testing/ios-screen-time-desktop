import { useCallback, useEffect, useRef, useState, type ComponentType } from "react";
import { useLocation } from "react-router";
import {
  FolderOpen,
  Play,
  PencilLine,
  Download,
  Sparkles,
  X,
  ArrowLeft,
  ArrowRight,
  Check,
} from "lucide-react";
import { config } from "@/config";
import { useFocusTrap } from "@/hooks/useFocusTrap";
import { OPEN_TOUR_EVENT } from "./tourEvents";

const TOUR_STORAGE_KEY = "app-tour-seen-v1";

interface TourStep {
  icon: ComponentType<{ className?: string }>;
  title: string;
  body: string;
}

const STEPS: TourStep[] = [
  {
    icon: Sparkles,
    title: config.isTauri
      ? "Welcome — everything runs on this computer"
      : "Welcome — this runs entirely in your browser",
    body: config.isTauri
      ? "No account, no server, nothing uploaded. Every screenshot, image, and result stays on this computer; the app only goes online to check for updates, which you can turn off in Settings. Quitting the app keeps your work; “Delete all local data” in Settings erases it."
      : "No account, no server, nothing uploaded. Every screenshot, image, and result stays on this device. Closing the tab keeps your work; clearing site data erases it.",
  },
  {
    icon: FolderOpen,
    title: "1. Load your screenshots",
    body: "On the Load page, drag in a folder of iOS Screen Time screenshots. Identical files are skipped automatically, and near-identical ones are flagged as possible duplicates so you don't review the same day twice.",
  },
  {
    icon: Play,
    title: "2. Process the batch",
    body: "The pipeline detects the device, crops the screenshot, then reads the grid and the 24 hourly bars with on-device OCR. Run it once per group from the Process page.",
  },
  {
    icon: PencilLine,
    title: "3. Annotate & verify",
    body: "Each screenshot opens with its grid and hourly values already filled in. Bars worth a second look are highlighted with the reason why. Use ← / → to move between screenshots, and Reprocess if the grid is off.",
  },
  {
    icon: Download,
    title: "4. Export",
    body: "Once a group is reviewed, export it to CSV or JSON from the Export page. That's the whole loop: Load → Process → Annotate → Export.",
  },
];

/**
 * First-run guided tour for the offline app. Auto-opens once (local mode),
 * remembers dismissal in localStorage, and can be replayed via `openAppTour()`.
 * Renders nothing when closed.
 */
/** First-run detection, computed once for the lazy initial state. Auto-opens on
 *  step 0 in local/WASM mode when the tour hasn't been seen; otherwise closed. */
function initialTourStep(pathname: string): number | null {
  if (!config.isLocalMode || pathname !== "/") return null;
  try {
    return localStorage.getItem(TOUR_STORAGE_KEY) === "1" ? null : 0;
  } catch {
    return null;
  }
}

export function FirstRunTour() {
  const location = useLocation();
  const [step, setStep] = useState<number | null>(() => initialTourStep(location.pathname)); // null = closed
  const panelRef = useRef<HTMLDivElement>(null);

  // Bespoke dialog (not Radix) → manage focus ourselves: move focus into the
  // panel on open, trap Tab within it, restore focus to the trigger on close.
  // Focus the panel itself (not the first control) so the dismiss "✕" isn't
  // pre-armed and a screen reader reads the dialog title. guardFocusin re-pulls
  // focus when Layout's route-change `<main>.focus()` races the auto-open and
  // would otherwise strand focus behind the modal. Esc/←/→ stay below.
  useFocusTrap(step !== null, panelRef, {
    lockScroll: true,
    initialFocus: "container",
    guardFocusin: true,
  });

  const go = useCallback((delta: number) => {
    setStep((s) => (s === null ? s : Math.max(0, Math.min(STEPS.length - 1, s + delta))));
  }, []);

  const close = useCallback(() => {
    setStep(null);
    try {
      localStorage.setItem(TOUR_STORAGE_KEY, "1");
    } catch {
      /* private mode — best effort */
    }
  }, []);

  // Replay via global event (header button, help page).
  useEffect(() => {
    const open = () => setStep(0);
    window.addEventListener(OPEN_TOUR_EVENT, open);
    return () => window.removeEventListener(OPEN_TOUR_EVENT, open);
  }, []);

  // While open, own Esc + arrow keys. Capture phase + stopImmediatePropagation
  // so the annotation page's own ← / → navigation never fires behind the modal.
  useEffect(() => {
    if (step === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopImmediatePropagation();
        close();
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        e.stopImmediatePropagation();
        go(1);
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        e.stopImmediatePropagation();
        go(-1);
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [step, close, go]);

  if (step === null) return null;
  const current = STEPS[step]!;
  const Icon = current.icon;
  const isLast = step === STEPS.length - 1;

  return (
    <div
      className="fixed inset-0 z-[200] flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="tour-title"
    >
      {/* Backdrop as a real button so click-to-dismiss is keyboard-accessible. */}
      <button
        type="button"
        aria-label="Close tour"
        onClick={close}
        className="absolute inset-0 bg-black/50 focus-ring"
      />
      <div
        ref={panelRef}
        tabIndex={-1}
        className="relative w-full max-w-md rounded-eq-lg bg-eq-surface border border-eq-border shadow-2xl outline-none"
      >
        <div className="flex items-start justify-between gap-3 p-5 pb-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-eq-md bg-eq-primary/10 text-eq-primary">
              <Icon className="h-5 w-5" />
            </div>
            <h2 id="tour-title" className="text-base font-semibold text-eq-ink">
              {current.title}
            </h2>
          </div>
          <button
            onClick={close}
            aria-label="Skip tour"
            className="shrink-0 rounded-eq-sm p-1 text-eq-muted hover:bg-eq-surface-muted focus-ring"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <p className="px-5 text-sm leading-relaxed text-eq-muted">{current.body}</p>

        <div className="flex items-center justify-between gap-3 p-5 pt-4">
          <div className="flex items-center gap-1.5" aria-hidden="true">
            {STEPS.map((_, i) => (
              <span
                key={i}
                className={`h-1.5 rounded-full transition-all ${
                  i === step ? "w-4 bg-eq-primary" : "w-1.5 bg-eq-border"
                }`}
              />
            ))}
          </div>
          <div className="flex items-center gap-2">
            {step > 0 && (
              <button
                onClick={() => go(-1)}
                className="inline-flex items-center gap-1.5 rounded-eq-md border border-eq-border px-3 py-1.5 text-sm text-eq-ink hover:bg-eq-surface-muted focus-ring"
              >
                <ArrowLeft className="h-3.5 w-3.5" /> Back
              </button>
            )}
            {isLast ? (
              <button
                onClick={close}
                className="inline-flex items-center gap-1.5 rounded-eq-md bg-eq-primary px-3 py-1.5 text-sm text-eq-primary-ink hover:bg-eq-primary focus-ring"
              >
                <Check className="h-3.5 w-3.5" /> Get started
              </button>
            ) : (
              <button
                onClick={() => go(1)}
                className="inline-flex items-center gap-1.5 rounded-eq-md bg-eq-primary px-3 py-1.5 text-sm text-eq-primary-ink hover:bg-eq-primary focus-ring"
              >
                Next <ArrowRight className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>

        <div className="border-t border-eq-border px-5 py-2 text-center">
          <button
            onClick={close}
            className="text-xs text-eq-muted hover:text-eq-ink focus-ring rounded"
          >
            Skip the tour
          </button>
        </div>
      </div>
    </div>
  );
}
