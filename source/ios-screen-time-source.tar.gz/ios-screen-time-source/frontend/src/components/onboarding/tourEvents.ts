/** Custom DOM event that opens / replays the first-run tour. */
export const OPEN_TOUR_EVENT = "open-app-tour";

/** Dispatch from anywhere (header button, help page) to replay the tour. */
export function openAppTour(): void {
  window.dispatchEvent(new CustomEvent(OPEN_TOUR_EVENT));
}
