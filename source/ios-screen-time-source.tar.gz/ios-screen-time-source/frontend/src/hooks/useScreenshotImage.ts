import { useEffect, useState } from "react";
import { useScreenshotService } from "@/core/hooks/useServices";

/**
 * Hook to get the image URL for a screenshot, handling both server and WASM modes.
 * Pass a refreshKey that changes when the image needs to be re-fetched
 * (e.g., after crop or redaction modifies the underlying file).
 */
export function useScreenshotImage(screenshotId: number, refreshKey?: number): string | null {
  const screenshotService = useScreenshotService();
  const [imageUrl, setImageUrl] = useState<string | null>(null);

  // Clear the resolved URL when the request identity changes (different
  // screenshot, different refresh generation, missing ID). Done via React's
  // "adjusting state when a prop changes" pattern so the effect body only
  // owns the async resolve path.
  const requestKey = screenshotId ? `${screenshotId}|${refreshKey ?? 0}` : null;
  const [prevRequestKey, setPrevRequestKey] = useState<string | null>(requestKey);
  if (requestKey !== prevRequestKey) {
    setPrevRequestKey(requestKey);
    setImageUrl(null);
  }

  useEffect(() => {
    if (!screenshotId) {
      return;
    }

    let cancelled = false;

    const loadImage = async () => {
      try {
        let resolvedUrl = await screenshotService.getImageUrl(screenshotId);
        // Bust browser cache when image has been modified (crop/redaction)
        if (refreshKey && !resolvedUrl.startsWith("blob:")) {
          const separator = resolvedUrl.includes("?") ? "&" : "?";
          resolvedUrl = `${resolvedUrl}${separator}_t=${refreshKey}`;
        }
        if (!cancelled) {
          setImageUrl(resolvedUrl);
        }
        // Note: blob URLs are managed by the opfsBlobStorage LRU cache.
        // Do NOT revoke them here — the cache shares URLs across components
        // and revokes them automatically on eviction.
      } catch (error) {
        if (!cancelled) {
          console.error(
            `Failed to load image for screenshot ${screenshotId}:`,
            error,
          );
          setImageUrl(null);
        }
      }
    };

    void loadImage();

    return () => {
      cancelled = true;
    };
  }, [screenshotId, screenshotService, refreshKey]);

  return imageUrl;
}
