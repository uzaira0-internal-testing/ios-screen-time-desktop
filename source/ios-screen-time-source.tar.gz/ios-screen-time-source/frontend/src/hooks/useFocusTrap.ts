import { useEffect, type RefObject } from "react";

const FOCUSABLE =
  'a[href], button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';

/**
 * Focus management for a bespoke (non-Radix) modal dialog. While `active`, it:
 *  - moves focus into `containerRef` on activation (the first focusable child, or
 *    the container itself when `initialFocus: "container"`),
 *  - keeps Tab / Shift+Tab cycling within the container (WCAG 2.1.2 / 2.4.3), and
 *  - restores focus to whatever was focused before, on deactivation or unmount.
 * Optionally locks background scroll while active.
 *
 * Esc / arrow handling stays with the caller — modals differ there (some guard
 * Esc against in-flight work, some own ←/→). This hook owns ONLY focus-in, the
 * Tab trap, and focus-restore. Extracted from the byte-identical trap effects
 * previously copy-pasted into CropAdjustModal and PHIRegionEditor.
 *
 * `initialFocus: "container"` requires the container to be programmatically
 * focusable (give it `tabIndex={-1}`) — useful when the first focusable child is
 * a dismiss control you don't want pre-armed (e.g. an onboarding panel).
 *
 * `guardFocusin: true` adds a document-level backstop that re-pulls focus into
 * the container whenever it escapes while active — needed when something else
 * focuses an element after the dialog opens (e.g. an auto-opened dialog racing a
 * route-change `<main>` focus). Leave it OFF for modals that intentionally spawn
 * portaled sub-dialogs (Radix confirm, popovers) whose focus lives outside this
 * container — the guard would yank focus out of them.
 */
export function useFocusTrap(
  active: boolean,
  containerRef: RefObject<HTMLElement | null>,
  options: {
    lockScroll?: boolean;
    initialFocus?: "firstChild" | "container";
    guardFocusin?: boolean;
  } = {},
): void {
  const { lockScroll = false, initialFocus = "firstChild", guardFocusin = false } = options;
  useEffect(() => {
    if (!active) return;
    const dialog = containerRef.current;
    if (!dialog) return;

    const previouslyFocused = document.activeElement as HTMLElement | null;
    const prevOverflow = document.body.style.overflow;
    if (lockScroll) document.body.style.overflow = "hidden";

    const focusables = () =>
      Array.from(dialog.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
        (el) => el.offsetParent !== null,
      );

    const focusInitial = () =>
      (initialFocus === "container" ? dialog : (focusables()[0] ?? dialog)).focus();

    focusInitial();

    const handleTab = (e: KeyboardEvent) => {
      if (e.key !== "Tab") return;
      const items = focusables();
      if (items.length === 0) {
        e.preventDefault();
        dialog.focus();
        return;
      }
      const first = items[0]!;
      const last = items[items.length - 1]!;
      const active = document.activeElement;
      // If focus is sitting OUTSIDE the cycle — on the container itself (when
      // `initialFocus: "container"`), or on a now-hidden/disabled control —
      // pull it back in: Tab → first, Shift+Tab → last. Without this, a
      // Shift+Tab off the container would walk to whatever is behind the modal.
      if (!(active instanceof HTMLElement) || !items.includes(active)) {
        e.preventDefault();
        (e.shiftKey ? last : first).focus();
        return;
      }
      // Own the whole cycle, not only its boundaries. WebKit's platform
      // keyboard-access setting may skip button elements during native Tab
      // traversal; an explicit cycle keeps modal order identical everywhere.
      e.preventDefault();
      const current = items.indexOf(active);
      const next = e.shiftKey
        ? items[(current - 1 + items.length) % items.length]!
        : items[(current + 1) % items.length]!;
      next.focus();
    };

    // Backstop: if focus lands outside the container while we're active (a
    // route-change `<main>.focus()`, a programmatic steal), pull it back in.
    const handleFocusIn = (e: FocusEvent) => {
      const t = e.target;
      if (t instanceof Node && !dialog.contains(t)) focusInitial();
    };

    // WebKit can move focus to <body> between keydown events when tabbing from
    // a programmatically focused container. With the focus-in guard enabled,
    // listen at document scope too so the next Tab cannot bypass the cycle.
    if (guardFocusin) document.addEventListener("keydown", handleTab);
    else dialog.addEventListener("keydown", handleTab);
    if (guardFocusin) document.addEventListener("focusin", handleFocusIn);
    return () => {
      if (guardFocusin) document.removeEventListener("keydown", handleTab);
      else dialog.removeEventListener("keydown", handleTab);
      if (guardFocusin) document.removeEventListener("focusin", handleFocusIn);
      if (lockScroll) document.body.style.overflow = prevOverflow;
      previouslyFocused?.focus?.();
    };
  }, [active, containerRef, lockScroll, initialFocus, guardFocusin]);
}
