import { afterAll, beforeAll, expect, test } from "bun:test";
import { Window } from "happy-dom";
import { act, useEffect } from "react";
import { createRoot, type Root } from "react-dom/client";
import type { AnnotationCreate } from "@/types";

// Hooks load after the DOM globals exist: a module-scope window without a
// document (left by other suites) breaks react-hot-toast's import.
let useAutoSave: typeof import("../useAutoSave").useAutoSave;
let useGridProcessing: typeof import("../useGridProcessing").useGridProcessing;
let useKeyboardShortcuts: typeof import("../useKeyboardShortcuts").useKeyboardShortcuts;

const descriptors = new Map<string, PropertyDescriptor | undefined>();
beforeAll(async () => {
  const win = new Window();
  for (const key of ["window", "document", "navigator", "HTMLElement", "IS_REACT_ACT_ENVIRONMENT"]) {
    descriptors.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, { configurable: true, value: key === "window" ? win : key === "IS_REACT_ACT_ENVIRONMENT" ? true : win[key as keyof Window] });
  }
  ({ useAutoSave } = await import("../useAutoSave"));
  ({ useGridProcessing } = await import("../useGridProcessing"));
  ({ useKeyboardShortcuts } = await import("../useKeyboardShortcuts"));
});
afterAll(() => {
  for (const [key, descriptor] of descriptors) {
    if (descriptor) Object.defineProperty(globalThis, key, descriptor);
    else Reflect.deleteProperty(globalThis, key);
  }
});
const wait = (ms: number) => new Promise((resolve) => { setTimeout(resolve, ms); });
let root: Root;
function setup() { const container = document.createElement("div"); document.body.append(container); root = createRoot(container); return container; }
const coords = { upper_left: { x: 1, y: 1 }, lower_right: { x: 100, y: 100 } };

test("grid debounce is cancelled when screenshot changes", async () => {
  setup();
  const calls: unknown[] = [];
  let select!: (grid: typeof coords) => void;
  function Grid({ id }: { id: number }) {
    const result = useGridProcessing({ screenshotId: id, onSetGrid: () => {}, onReprocess: async (grid) => { calls.push(grid); } });
    useEffect(() => { select = result.handleGridSelect; }, [result.handleGridSelect]);
    return null;
  }
  await act(async () => { root.render(<Grid id={1} />); });
  await act(async () => { select(coords); });
  await act(async () => { root.render(<Grid id={2} />); });
  await act(async () => { await wait(550); });
  expect(calls).toEqual([]);
  await act(async () => { root.unmount(); });
});

function autosaveHarness(onSave: (payload: AnnotationCreate) => Promise<void>) {
  setup();
  let status!: ReturnType<typeof useAutoSave>;
  function Draft({ id, title = "App", notes = "", hourly = {}, total = "60" }: { id: number; title?: string; notes?: string; hourly?: Record<string, number>; total?: string }) {
    const result = useAutoSave({ screenshotId: id, extractedTitle: title, extractedTotal: total, hourlyData: hourly, gridCoords: undefined, notes, onSave });
    useEffect(() => { status = result; });
    return null;
  }
  return { render: async (props: Parameters<typeof Draft>[0]) => { await act(async () => { root.render(<Draft {...props} />); }); }, status: () => status };
}
test("navigation and unmount flush screenshot-specific debounced drafts", async () => {
  const saved: AnnotationCreate[] = [];
  const h = autosaveHarness(async (payload) => { saved.push(payload); });
  await h.render({ id: 1 });
  await h.render({ id: 1, title: "A edit", notes: "A note" });
  await h.render({ id: 2 });
  await h.render({ id: 2, title: "B edit" });
  await act(async () => { root.unmount(); });
  expect(saved.map((p) => [p.screenshot_id, p.extracted_title, p.notes])).toEqual([[1, "A edit", "A note"], [2, "B edit", null]]);
});
test("queued saves keep latest payload per screenshot after navigation", async () => {
  const saved: AnnotationCreate[] = [];
  let release!: () => void;
  const pending = new Promise<void>((resolve) => { release = resolve; });
  const h = autosaveHarness(async (payload) => { saved.push(payload); if (saved.length === 1) await pending; });
  await h.render({ id: 1 });
  await h.render({ id: 1, hourly: { 0: 1 } });
  await h.render({ id: 1, hourly: { 0: 2 } });
  await h.render({ id: 1, hourly: { 0: 3 } });
  await h.render({ id: 2 });
  await act(async () => { root.unmount(); release(); await wait(0); });
  expect(saved.map((p) => [p.screenshot_id, p.hourly_values])).toEqual([[1, { 0: 1 }], [1, { 0: 3 }]]);
});
test("title and notes without grid or hourly data remain dirty and persist", async () => {
  const saved: AnnotationCreate[] = [];
  const h = autosaveHarness(async (payload) => { saved.push(payload); });
  await h.render({ id: 1 });
  await h.render({ id: 1, title: "edited", notes: "note" });
  expect(h.status().hasUnsavedChanges).toBe(true);
  await act(async () => { await wait(850); });
  expect(saved[0]).toMatchObject({ screenshot_id: 1, extracted_title: "edited", notes: "note", hourly_values: {} });
  await act(async () => { root.unmount(); });
});
test("OCR total changes trigger persistence with the new total", async () => {
  const saved: AnnotationCreate[] = [];
  const h = autosaveHarness(async (payload) => { saved.push(payload); });
  await h.render({ id: 1, total: "60" });
  await h.render({ id: 1, total: "65" });
  expect(saved[0]?.extracted_total).toBe("65");
  await act(async () => { root.unmount(); });
});
test("workspace shortcuts suspend while a dialog is open", async () => {
  const container = setup();
  let calls = 0;
  function Shortcuts() { useKeyboardShortcuts([{ key: "ArrowRight", handler: () => { calls++; } }]); return <div role="dialog"><button>Confirm</button></div>; }
  await act(async () => { root.render(<Shortcuts />); });
  container.querySelector("button")!.dispatchEvent(new window.KeyboardEvent("keydown", { key: "ArrowRight", bubbles: true }));
  expect(calls).toBe(0);
  await act(async () => { root.unmount(); });
});
