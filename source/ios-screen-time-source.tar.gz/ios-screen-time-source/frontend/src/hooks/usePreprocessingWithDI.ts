import { createContext, useContext, useMemo, useEffect, useState, useRef, createElement, type ReactNode } from "react";
import { usePreprocessingPipelineService, useActiveStages } from "@/core";
import { createPreprocessingStore, type PreprocessingState } from "@/store/preprocessingStore";
import type { IPreprocessingService } from "@/core/interfaces/IPreprocessingService";

type PreprocessingStore = ReturnType<typeof createPreprocessingStore>;

// Store instances cached by service identity, with reference counting
interface StoreEntry {
  store: PreprocessingStore;
  refCount: number;
}
const storeInstances = new Map<string, StoreEntry>();

const CLEANUP_DELAY_MS = 5000;

const PreprocessingStoreContext = createContext<PreprocessingStore | null>(null);

/**
 * Provider that creates a preprocessing store backed by the DI-resolved service.
 * Wrap PreprocessingPage (or any subtree that needs preprocessing state) with this.
 */
export function PreprocessingProvider({ children }: { children: ReactNode }) {
  const service = usePreprocessingPipelineService();
  const activeStages = useActiveStages();

  // Derive the cache key during render — it's a pure function of activeStages —
  // and pass it directly to the cleanup effect via the dep array instead of
  // syncing through a ref (which would be a write during render).
  const cacheKey = useMemo(
    () => `preprocessing:${activeStages.join(",")}`,
    [activeStages],
  );

  const store = useMemo(() => {
    const existing = storeInstances.get(cacheKey);
    if (existing) {
      existing.refCount++;
      return existing.store;
    }

    const newStore = createPreprocessingStore(service, activeStages);
    storeInstances.set(cacheKey, { store: newStore, refCount: 1 });
    return newStore;
  }, [service, activeStages, cacheKey]);

  // Cleanup on unmount: stop polling immediately, then clean up store after delay
  useEffect(() => {
    const currentStore = store;
    return () => {
      // Stop polling immediately to prevent stale interval timers
      currentStore.getState().stopPolling();

      setTimeout(() => {
        const entry = storeInstances.get(cacheKey);
        if (entry) {
          entry.refCount--;
          if (entry.refCount <= 0) {
            storeInstances.delete(cacheKey);
          }
        }
      }, CLEANUP_DELAY_MS);
    };
  }, [store, cacheKey]);

  return createElement(
    serviceContext.Provider,
    { value: service },
    createElement(PreprocessingStoreContext.Provider, { value: store }, children),
  );
}

/**
 * Drop-in replacement for the old `usePreprocessingStore` import.
 * Supports the same selector pattern: `usePreprocessingStore((s) => s.field)`
 */
export function usePreprocessingStore(): PreprocessingStore;
export function usePreprocessingStore<T>(selector: (state: PreprocessingState) => T): T;
export function usePreprocessingStore<T>(selector?: (state: PreprocessingState) => T) {
  const store = useContext(PreprocessingStoreContext);
  if (!store) {
    throw new Error("usePreprocessingStore must be used within a <PreprocessingProvider>");
  }
  if (selector) {
    return store(selector);
  }
  return store;
}

// ---------------------------------------------------------------------------
// Image URL hooks — async blob URL loading with cleanup for WASM mode
// ---------------------------------------------------------------------------

const serviceContext = createContext<IPreprocessingService | null>(null);

/**
 * Load an image URL for a screenshot via the preprocessing service.
 * In server mode this returns a static API URL; in WASM mode it creates
 * an object URL from the blob store and revokes it on cleanup.
 */
export function useScreenshotImageUrl(
  screenshotId: number | undefined,
  method: "getImageUrl" | "getStageImageUrl" | "getOriginalImageUrl" = "getImageUrl",
  stage?: string,
  refreshKey?: number,
): string | null {
  const service = useContext(serviceContext);
  const [url, setUrl] = useState<string | null>(null);
  // Holds the currently-committed blob URL. Re-runs (refreshKey / stage / method
  // change) revoke the PREVIOUS URL only after the replacement commits — never
  // the on-screen URL synchronously — so bumping refreshKey after a crop/redact
  // no longer flashes a broken image (ERR_FILE_NOT_FOUND) in every consumer.
  const committedUrlRef = useRef<string | null>(null);
  // Mirror `method` into a ref (updated in an effect, not during render) so the
  // unmount-only cleanup below revokes using the latest method.
  const methodRef = useRef(method);
  useEffect(() => {
    methodRef.current = method;
  }, [method]);

  // Clear the resolved URL when the screenshot ID changes (different screenshot
  // entirely), or when the request becomes unusable (no service / no ID).
  // Other inputs (method / stage / refreshKey) keep the stale URL visible
  // until the new fetch resolves, preventing a flash of blank thumbnail. We
  // use React's "adjusting state when a prop changes" pattern (compare prior
  // value during render, dispatch setState inline) instead of doing this work
  // inside the effect.
  const shouldReset = !service || screenshotId == null;
  const resetKey = shouldReset ? null : screenshotId;
  const [prevResetKey, setPrevResetKey] = useState<number | null>(resetKey);
  if (resetKey !== prevResetKey) {
    setPrevResetKey(resetKey);
    setUrl(null);
  }

  useEffect(() => {
    if (!service || screenshotId == null) {
      return;
    }

    let revoked = false;

    void (async () => {
      try {
        let result: string;
        if (method === "getStageImageUrl" && stage) {
          result = await service.getStageImageUrl(screenshotId, stage);
        } else if (method === "getOriginalImageUrl") {
          result = await service.getOriginalImageUrl(screenshotId);
        } else {
          result = await service.getImageUrl(screenshotId);
        }
        if (revoked) {
          // This run was superseded before it committed — release its URL now.
          if (result.startsWith("blob:") && method !== "getImageUrl") {
            URL.revokeObjectURL(result);
          }
          return;
        }
        // Append cache-buster so browser doesn't serve stale image after redaction
        const objectUrl = result.startsWith("blob:") ? result :
          result + (result.includes("?") ? "&" : "?") + `_t=${refreshKey ?? 0}`;
        // Revoke the PREVIOUS committed URL now that its replacement is ready.
        // Never revoke the on-screen URL before the new one exists, or the
        // <img> momentarily points at a dead blob (ERR_FILE_NOT_FOUND flash).
        // getOriginalImageUrl/getStageImageUrl mint uncached per-call URLs;
        // getImageUrl uses the shared LRU and must NOT be revoked here.
        const prev = committedUrlRef.current;
        if (prev && prev !== objectUrl && prev.startsWith("blob:") && method !== "getImageUrl") {
          URL.revokeObjectURL(prev);
        }
        committedUrlRef.current = objectUrl;
        setUrl(objectUrl);
      } catch (err) {
        console.error(`[useScreenshotImageUrl] Failed to load image for screenshot ${screenshotId}:`, err);
        if (!revoked) setUrl(null);
      }
    })();

    return () => {
      // Only mark this run superseded — do NOT revoke the committed URL here.
      // The next run revokes the previous URL after committing its replacement;
      // the unmount-only effect below revokes the final one.
      revoked = true;
    };
  }, [service, screenshotId, method, stage, refreshKey]);

  // Unmount-only: release the last committed blob URL (uncached methods only).
  useEffect(() => {
    return () => {
      const last = committedUrlRef.current;
      if (last?.startsWith("blob:") && methodRef.current !== "getImageUrl") {
        URL.revokeObjectURL(last);
      }
      committedUrlRef.current = null;
    };
  }, []);

  return url;
}
