import { useEffect, useRef } from "react";
import { useAuthStore } from "@/store/authStore";
import { useNavigate } from "react-router";
import { api } from "@/services/apiClient";
import toast from "react-hot-toast";
import { config } from "@/config";

// Module-level dedup so the N components calling useAuth on the same page
// don't each fire their own /auth/me. One verify per minute is plenty for
// catching out-of-band role/ID drift, and the in-flight promise guard
// coalesces concurrent mounts in the same render pass into a single request.
let lastVerifiedAt = 0;
let inFlight: Promise<void> | null = null;
const VERIFY_INTERVAL_MS = 60_000;

export const useAuth = () => {
  const {
    userId,
    username,
    role,
    sitePassword,
    isAuthenticated,
    login,
    logout,
    setUserId,
    setRole,
  } = useAuthStore();

  // We intentionally don't re-fire the verification effect when `userId` or
  // `role` change (the effect itself writes them via setUserId/setRole), so
  // we capture their latest values in refs and read them inside the effect.
  // This keeps the dependency surface honest without restarting the verifier
  // every time it succeeds.
  const userIdRef = useRef(userId);
  const roleRef = useRef(role);
  useEffect(() => {
    userIdRef.current = userId;
  }, [userId]);
  useEffect(() => {
    roleRef.current = role;
  }, [role]);

  // Always verify userId and role with server on mount
  // This handles stale cached data after database reset/migration or role changes
  // Skip in Tauri/WASM mode — no server to verify against
  useEffect(() => {
    if (config.isLocalMode) return;
    if (!(isAuthenticated && username)) return;
    if (inFlight) return;
    const now = Date.now();
    if (now - lastVerifiedAt < VERIFY_INTERVAL_MS) return;

    inFlight = api.auth
      .getMe()
      .then((user) => {
        lastVerifiedAt = Date.now();
        if (user?.id && user.id !== userIdRef.current) {
          setUserId(user.id);
        }
        // Always update role from server (handles promotions/demotions)
        if (user?.role && user.role !== roleRef.current) {
          setRole(user.role);
        }
      })
      .catch((err) => {
        // AbortError / "Failed to fetch" happens routinely when the user
        // navigates away mid-request. The global 401 interceptor in
        // apiClient handles real auth failures with a toast + logout.
        // Logging these as errors creates noise in devtools without any
        // user-actionable value. Leave lastVerifiedAt untouched on failure
        // so the next mount retries instead of waiting out the window.
        const name = (err as { name?: string })?.name ?? "";
        const msg = err instanceof Error ? err.message : String(err);
        if (name === "AbortError" || /failed to fetch|networkerror|aborted/i.test(msg)) {
          return;
        }
        console.error("Failed to fetch user ID:", err);
      })
      .finally(() => {
        inFlight = null;
      });
  }, [isAuthenticated, username, setUserId, setRole]);

  const isAdmin = role === "admin";

  return {
    userId,
    username,
    role,
    sitePassword,
    isAdmin,
    isAuthenticated,
    login,
    logout,
  };
};

interface UseRequireAuthOptions {
  skip?: boolean;
}

export const useRequireAuth = (options: UseRequireAuthOptions = {}) => {
  const { skip = false } = options;
  const { isAuthenticated, userId, username } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (config.isLocalMode) return;
    if (!skip && !isAuthenticated) {
      toast.error("Please login to continue");
      void navigate("/login");
    }
  }, [isAuthenticated, navigate, skip]);

  return { isAuthenticated, userId, username };
};
