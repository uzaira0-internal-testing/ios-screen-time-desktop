import { useEffect, useRef, useState, useCallback } from "react";
import type { AnnotationCreate, GridCoordinates } from "@/types";

interface UseAutoSaveOptions {
  screenshotId: number | undefined;
  hourlyData: Record<string, number> | undefined;
  extractedTitle: string | null | undefined;
  extractedTotal: string | null | undefined;
  gridCoords: GridCoordinates | undefined;
  notes: string;
  onSave: (payload: AnnotationCreate) => Promise<void>;
}

interface UseAutoSaveReturn {
  isSaving: boolean;
  lastSaved: Date | null;
  timeSinceLastSave: string;
  /** Number of consecutive save failures. Resets on success or screenshot change. */
  saveFailCount: number;
  /** Last error message from a failed save attempt. */
  lastError: string | null;
  /** True if there are unsaved changes (edits made since last successful save). */
  hasUnsavedChanges: boolean;
  /** Manually trigger a save (e.g., from a "Retry" button). */
  retrySave: () => void;
}

export function useAutoSave(options: UseAutoSaveOptions): UseAutoSaveReturn {
  const { screenshotId, hourlyData, extractedTitle, extractedTotal, gridCoords, notes, onSave } = options;

  const [isSaving, setIsSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [timeSinceLastSave, setTimeSinceLastSave] = useState<string>("");
  const [saveFailCount, setSaveFailCount] = useState(0);
  const [lastError, setLastError] = useState<string | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  type Draft = { payload: AnnotationCreate; save: typeof onSave; signature: string };
  const previousRef = useRef<Draft | null>(null);
  const latestRef = useRef<Draft | null>(null);
  const debounceRef = useRef<{ timer: ReturnType<typeof setTimeout>; draft: Draft } | null>(null);
  const saveInFlightRef = useRef<Promise<void> | null>(null);
  const pendingSavesRef = useRef(new Map<number, Draft>());
  const isMountedRef = useRef(true);
  const screenshotIdRef = useRef(screenshotId);
  screenshotIdRef.current = screenshotId;
  const onSaveRef = useRef(onSave);
  onSaveRef.current = onSave;
  useEffect(() => {
    isMountedRef.current = true;
    return () => { isMountedRef.current = false; };
  }, []);

  const payload: AnnotationCreate = {
    screenshot_id: screenshotId ?? 0,
    hourly_values: { ...hourlyData },
    extracted_title: extractedTitle ?? null,
    extracted_total: extractedTotal ?? null,
    grid_upper_left: gridCoords ? { ...gridCoords.upper_left } : null,
    grid_lower_right: gridCoords ? { ...gridCoords.lower_right } : null,
    notes: notes || null,
  };
  const signature = JSON.stringify(payload);

  // Reset save status when screenshot changes
  useEffect(() => {
    setIsSaving(false);
    setLastSaved(null);
    setTimeSinceLastSave("");
    setSaveFailCount(0);
    setLastError(null);
    setHasUnsavedChanges(false);
  }, [screenshotId]);

  // Update time since last save every second
  useEffect(() => {
    if (!lastSaved) {
      setTimeSinceLastSave("");
      return;
    }

    let prevStr = "";
    const updateTime = () => {
      const now = new Date();
      const diffMs = now.getTime() - lastSaved.getTime();
      const diffSeconds = Math.floor(diffMs / 1000);

      let newStr: string;
      if (diffSeconds < 3) {
        newStr = "just now";
      } else if (diffSeconds < 60) {
        newStr = `${diffSeconds}s ago`;
      } else if (diffSeconds < 3600) {
        const minutes = Math.floor(diffSeconds / 60);
        newStr = `${minutes}m ago`;
      } else {
        const hours = Math.floor(diffSeconds / 3600);
        newStr = `${hours}h ago`;
      }
      // Only trigger re-render when the display string actually changes
      if (newStr !== prevStr) {
        prevStr = newStr;
        setTimeSinceLastSave(newStr);
      }
    };

    updateTime();
    // Check every 5 seconds — granularity is sufficient for "Xs ago" display
    const interval = setInterval(updateTime, 5000);

    return () => clearInterval(interval);
  }, [lastSaved]);

  const doSave = useCallback((draft: Draft): Promise<void> => {
    pendingSavesRef.current.set(draft.payload.screenshot_id, draft);
    if (saveInFlightRef.current) return saveInFlightRef.current;

    const run = async () => {
      while (pendingSavesRef.current.size > 0) {
        const next = pendingSavesRef.current.values().next().value!;
        pendingSavesRef.current.delete(next.payload.screenshot_id);
        const isCurrent = () => isMountedRef.current && screenshotIdRef.current === next.payload.screenshot_id;
        if (isCurrent()) setIsSaving(true);
        try {
          // eslint-disable-next-line no-await-in-loop -- queued drafts must save in order, including after unmount
          await next.save(next.payload);
          if (isCurrent()) {
            setLastSaved(new Date());
            setSaveFailCount(0);
            setLastError(null);
            setHasUnsavedChanges(latestRef.current?.signature !== next.signature);
          }
        } catch (error) {
          const message = error instanceof Error ? error.message : "Save failed";
          console.error("[AutoSave] Failed:", message);
          if (isCurrent()) {
            setSaveFailCount((c) => c + 1);
            setLastError(message);
          }
        } finally {
          if (isCurrent()) setIsSaving(false);
        }
      }
    };
    const promise = run().finally(() => { saveInFlightRef.current = null; });
    saveInFlightRef.current = promise;
    return promise;
  }, []);

  // Flush the captured draft before leaving its screenshot, including unmount.
  useEffect(() => {
    return () => {
      const pending = debounceRef.current;
      if (!pending || pending.draft.payload.screenshot_id !== screenshotId) return;
      clearTimeout(pending.timer);
      debounceRef.current = null;
      void doSave(pending.draft);
    };
  }, [screenshotId, doSave]);

  useEffect(() => {
    if (!screenshotId) return;
    const draft: Draft = { payload: JSON.parse(signature) as AnnotationCreate, signature, save: onSaveRef.current };
    latestRef.current = draft;
    const previous = previousRef.current;
    previousRef.current = draft;
    if (!previous || previous.payload.screenshot_id !== screenshotId) return;
    if (previous.signature === signature) return;

    if (debounceRef.current) clearTimeout(debounceRef.current.timer);
    debounceRef.current = null;
    setHasUnsavedChanges(true);
    if (saveFailCount >= 3) return;

    const textChanged = previous.payload.extracted_title !== draft.payload.extracted_title || previous.payload.notes !== draft.payload.notes;
    const dataChanged = JSON.stringify(previous.payload.hourly_values) !== JSON.stringify(draft.payload.hourly_values) || previous.payload.extracted_total !== draft.payload.extracted_total;
    if (textChanged && !dataChanged) {
      const timer = setTimeout(() => {
        debounceRef.current = null;
        void doSave(draft);
      }, 800);
      debounceRef.current = { timer, draft };
    } else {
      void doSave(draft);
    }
  }, [signature, screenshotId, doSave, saveFailCount]);

  const retrySave = useCallback(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current.timer);
    debounceRef.current = null;
    if (latestRef.current) void doSave(latestRef.current);
  }, [doSave]);

  return {
    isSaving,
    lastSaved,
    timeSinceLastSave,
    saveFailCount,
    lastError,
    hasUnsavedChanges,
    retrySave,
  };
}
