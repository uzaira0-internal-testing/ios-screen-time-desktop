import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import type { GridCoordinates } from "@/types";
import { toastErrorWithRetry } from "@/utils/toastWithRetry";

interface UseGridProcessingOptions {
  screenshotId: number | undefined;
  onReprocess: (coords: GridCoordinates, screenshotId?: number) => Promise<void>;
  onSetGrid: (coords: GridCoordinates) => void;
}

interface UseGridProcessingReturn {
  isProcessing: boolean;
  handleGridSelect: (coords: GridCoordinates) => void;
}

export function useGridProcessing(options: UseGridProcessingOptions): UseGridProcessingReturn {
  const { screenshotId, onReprocess, onSetGrid } = options;

  const [isProcessing, setIsProcessing] = useState(false);
  const [previousScreenshotId, setPreviousScreenshotId] = useState(screenshotId);
  if (previousScreenshotId !== screenshotId) {
    setPreviousScreenshotId(screenshotId);
    setIsProcessing(false);
  }
  const debounceTimer = useRef<NodeJS.Timeout | null>(null);
  const currentRequestId = useRef<number>(0);
  // Retry path needs to call the same handler that's currently being defined;
  // route the recursive call through a ref so it always sees the latest
  // closure rather than the stale identifier captured during initialization.
  const handlerRef = useRef<(coords: GridCoordinates) => void>(() => {});

  const screenshotIdRef = useRef(screenshotId);
  useLayoutEffect(() => { screenshotIdRef.current = screenshotId; }, [screenshotId]);

  const handleGridSelect = useCallback(
    (coords: GridCoordinates) => {
      const selectedId = screenshotId;
      coords = { upper_left: { ...coords.upper_left }, lower_right: { ...coords.lower_right } };
      // INSTANT: Update grid coords immediately for crop preview
      onSetGrid(coords);

      // Cancel any pending debounce timer (user still moving)
      if (debounceTimer.current) {
        clearTimeout(debounceTimer.current);
      }

      // Invalidate any in-flight request by incrementing ID
      currentRequestId.current += 1;
      setIsProcessing(false);

      // A degenerate grid (cleared via Reset Grid → zero sentinel, or an
      // inverted/zero-size drag) has nothing to extract. Persist the cleared
      // coords above, but skip the heavy reprocess that would otherwise error.
      const degenerate =
        coords.lower_right.x - coords.upper_left.x <= 0 ||
        coords.lower_right.y - coords.upper_left.y <= 0;
      if (degenerate) return;

      // Debounce (500ms) - wait for the user to actually settle before kicking
      // off the (relatively heavy) re-extraction. 300ms fired while users were
      // still nudging the grid, so a single adjustment triggered several
      // back-to-back recomputes; 500ms collapses a drag into one.
      debounceTimer.current = setTimeout(() => { void (async () => {
        if (screenshotIdRef.current !== selectedId) return;
        // Capture request ID at start
        const requestId = ++currentRequestId.current;

        setIsProcessing(true);

        try {
          await onReprocess(coords, selectedId);

          // Only update state if this is still the latest request
          if (requestId === currentRequestId.current) {
            setIsProcessing(false);
          }
        } catch (error) {
          // Only show error if this is still the latest request
          if (requestId === currentRequestId.current) {
            const errorMessage =
              error instanceof Error
                ? error.message
                : "Failed to reprocess with selected grid";
            toastErrorWithRetry({
              message: errorMessage,
              onRetry: () => { if (screenshotIdRef.current === selectedId) handlerRef.current(coords); },
              retryLabel: "Retry Processing",
            });
            setIsProcessing(false);
          }
        }
      })(); }, 500);
    },
    [screenshotId, onReprocess, onSetGrid],
  );

  // Keep the ref pointed at the latest handler so the retry callback always
  // invokes the current closure (avoids the "accessed before declared" cycle).
  useEffect(() => {
    handlerRef.current = handleGridSelect;
  }, [handleGridSelect]);

  // Cancel pending work when leaving its screenshot.
  useEffect(() => {
    return () => {
      currentRequestId.current += 1;
      if (debounceTimer.current) {
        clearTimeout(debounceTimer.current);
      }
    };
  }, [screenshotId]);

  return {
    isProcessing,
    handleGridSelect,
  };
}
