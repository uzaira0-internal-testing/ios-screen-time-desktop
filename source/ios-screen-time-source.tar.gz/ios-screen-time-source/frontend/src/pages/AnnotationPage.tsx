import { useEffect, useRef } from "react";
import { useSearchParams, useParams, useNavigate } from "react-router";
import { Layout } from "@/components/layout/Layout";
import { AnnotationWorkspace } from "@/components/annotation/AnnotationWorkspace";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { useRequireAuth } from "@/hooks/useAuth";
import { PROCESSING_STATUSES, type ProcessingStatus } from "@/types";
import type { VerificationFilterType } from "@/store/slices/types";

const VALID_STATUSES = new Set<string>(Object.values(PROCESSING_STATUSES));
const VALID_FILTERS = new Set<string>(["all", "verified_by_me", "not_verified_by_me", "verified_by_others", "totals_mismatch"]);
const LS_KEY = "annotate-last-params";

export const AnnotationPage = () => {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const groupId = searchParams.get("group") || undefined;
  const rawStatus = searchParams.get("processing_status");
  const processingStatus = (rawStatus && VALID_STATUSES.has(rawStatus) ? rawStatus : undefined) as ProcessingStatus | undefined;
  const initialScreenshotId = id ? parseInt(id, 10) : undefined;
  const rawFilter = searchParams.get("filter");
  const initialFilter = (rawFilter && VALID_FILTERS.has(rawFilter) ? rawFilter : undefined) as VerificationFilterType | undefined;

  useRequireAuth();

  // Capture the current URL params via refs so the mount-only restore effect
  // can read them without forcing the effect to re-run when params change.
  const groupIdRef = useRef(groupId);
  const processingStatusRef = useRef(processingStatus);
  const initialScreenshotIdRef = useRef(initialScreenshotId);
  const navigateRef = useRef(navigate);
  useEffect(() => { groupIdRef.current = groupId; }, [groupId]);
  useEffect(() => { processingStatusRef.current = processingStatus; }, [processingStatus]);
  useEffect(() => { initialScreenshotIdRef.current = initialScreenshotId; }, [initialScreenshotId]);
  useEffect(() => { navigateRef.current = navigate; }, [navigate]);

  // Restore last-used params when landing on bare /annotate (mount-only).
  useEffect(() => {
    if (!groupIdRef.current && !processingStatusRef.current && !initialScreenshotIdRef.current) {
      const saved = localStorage.getItem(LS_KEY);
      if (saved) {
        void navigateRef.current(`/annotate?${saved}`, { replace: true });
      }
    }
  }, []);

  // Save current params whenever they change
  useEffect(() => {
    if (groupId || processingStatus) {
      const parts: string[] = [];
      if (groupId) parts.push(`group=${encodeURIComponent(groupId)}`);
      if (processingStatus) parts.push(`processing_status=${encodeURIComponent(processingStatus)}`);
      localStorage.setItem(LS_KEY, parts.join("&"));
    }
  }, [groupId, processingStatus]);

  return (
    <Layout noScroll>
      {/* Visually-hidden page heading so screen readers and the document
          outline reflect the route. The workspace itself is full-bleed and
          intentionally chrome-free, so the heading would otherwise be absent. */}
      <h1
        style={{
          position: "absolute",
          width: 1,
          height: 1,
          padding: 0,
          margin: -1,
          overflow: "hidden",
          clip: "rect(0,0,0,0)",
          whiteSpace: "nowrap",
          border: 0,
        }}
      >
        Annotate screenshots
      </h1>
      <ErrorBoundary>
        <AnnotationWorkspace
          groupId={groupId}
          processingStatus={processingStatus}
          initialScreenshotId={initialScreenshotId}
          initialFilter={initialFilter}
        />
      </ErrorBoundary>
    </Layout>
  );
};
