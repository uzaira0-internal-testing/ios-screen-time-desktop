import { useState, useEffect, useCallback } from "react";
import { Layout } from "@/components/layout/Layout";
import { useAuth, useRequireAuth } from "@/hooks/useAuth";
import { UserActivityTable } from "@/components/admin/UserActivityTable";
import { api } from "@/services/apiClient";
import toast from "react-hot-toast";
import type { components } from "@/types/api-schema";

// Use type from OpenAPI schema (Pydantic is the single source of truth)
type UserActivity = components["schemas"]["UserStatsRead"];

export const AdminPage = () => {
  useRequireAuth(); // Ensure user is logged in
  const { isAdmin } = useAuth();

  const [users, setUsers] = useState<UserActivity[]>([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(true);

  const loadUsers = useCallback(async () => {
    try {
      const users = await api.admin.getUsers();
      setUsers(users ?? []);
    } catch (error) {
      const name = (error as { name?: string })?.name ?? "";
      const msg = error instanceof Error ? error.message : String(error);
      if (name !== "AbortError" && !/failed to fetch|networkerror|aborted|load failed/i.test(msg)) {
        console.error("Failed to load users:", error);
      }
    } finally {
      setIsLoadingUsers(false);
    }
  }, []);

  const handleUpdateUser = async (
    userId: number,
    updates: { is_active?: boolean; role?: string },
  ) => {
    try {
      await api.admin.updateUser(userId, updates);
      toast.success("User updated successfully");
      void loadUsers();
    } catch (error) {
      const name = (error as { name?: string })?.name ?? "";
      const msg = error instanceof Error ? error.message : String(error);
      if (name === "AbortError" || /failed to fetch|networkerror|aborted|load failed/i.test(msg)) return;
      toast.error("Failed to update user");
      console.error("Update user error:", error);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      void loadUsers();
    }
  }, [isAdmin, loadUsers]);

  if (!isAdmin) {
    return (
      <Layout>
        <div className="bg-eq-danger-bg border border-eq-danger rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold text-eq-danger mb-2">
            Access Denied
          </h2>
          <p className="text-eq-danger">You need admin privileges to access this page</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-eq-ink">User Management</h1>
          <p className="text-eq-muted mt-2">
            Manage user accounts and permissions
          </p>
        </div>

        <UserActivityTable
          users={users}
          loading={isLoadingUsers}
          onUpdateUser={handleUpdateUser}
        />
      </div>
    </Layout>
  );
};
