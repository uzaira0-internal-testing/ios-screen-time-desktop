import {
  browserResourceNumber,
  computeMetadataIoConcurrency,
} from "./resourceBudget";

export function browserMaintenanceConcurrency(): number {
  return computeMetadataIoConcurrency(
    browserResourceNumber("hardwareConcurrency"),
    browserResourceNumber("deviceMemory"),
  );
}

export async function forEachBoundedBestEffort<T>(
  items: readonly T[],
  mapper: (item: T, index: number) => Promise<void>,
  concurrency = browserMaintenanceConcurrency(),
): Promise<void> {
  if (items.length === 0) return;

  let cursor = 0;
  const runnerCount = Math.min(Math.max(1, Math.floor(concurrency)), items.length);

  async function runNext(): Promise<void> {
    const index = cursor;
    cursor += 1;
    if (index >= items.length) return;
    try {
      await mapper(items[index] as T, index);
    } catch {
      // Best-effort maintenance: callers use this for cleanup/recovery paths
      // where a single stale or blocked entry should not stop the rest.
    }
    await runNext();
  }

  await Promise.all(Array.from({ length: runnerCount }, () => runNext()));
}
