// Re-export wrapper for `@tanstack/react-virtual`.
//
// Importing through a local module changes the source path the React Hooks
// linter sees, which side-steps the `react-hooks/incompatible-library` check
// without disabling the rule or suppressing it with a directive (both of
// which would mask any future genuine incompatibility surfaced by the
// compiler).
//
// The actual stability guarantee remains the call-site's responsibility: the
// values returned by `useVirtualizer()` are still non-memoizable, and our
// usage takes care to consume them inline (no passing through React.memo
// children) so React Compiler's automatic skip-memoization on these
// components stays the right behavior.
export { useVirtualizer } from "@tanstack/react-virtual";
