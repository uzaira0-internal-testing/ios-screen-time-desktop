/**
 * Self-heal for a WASM ABI skew (stale / mismatched cached pipeline bundle).
 *
 * The compiled pipeline lives at a FIXED URL
 * (`/pipeline-em/IosScreenTimePipeline.wasm`) while the app's JS is
 * content-hashed. When the C-ABI changes — e.g. `pipeline_process` grew from 12
 * to 16 args for the scoring-config knobs — a service worker can transiently
 * serve a JS bundle and a wasm from *different* deploys to the same page. The
 * page's in-memory JS then calls the wasm with the wrong argument layout: the
 * wasm reads its output-buffer length from a config slot (`-1`), can't write,
 * and every `pipeline_process` returns a negative length. That surfaces to the
 * user as "Output buffer too small" on every screenshot.
 *
 * For the pipeline's result JSON (24 hourly ints plus a few scalars / short
 * strings) the 64 KB output buffer is never genuinely too small, so a negative
 * length is an unambiguous skew signal — not a real overflow. The cure is to
 * drop the mismatched caches + service worker and reload ONCE so the browser
 * pulls a self-consistent bundle.
 *
 * Only `pipeline_process` changed arity, so the loader flags only that call;
 * this module performs the recovery on the main thread (a worker can neither
 * reload the page nor manage the SW registration).
 */

/** sessionStorage key guarding against a reload loop. Scoped to the tab session
 *  so a genuine second skew (a real bug, not a stale cache) surfaces instead of
 *  reloading forever. */
import { forEachBoundedBestEffort } from "./browserMaintenance";

const RECOVERY_GUARD_KEY = "wasm-abi-skew-recovered";

/** True once a recovery has been attempted in this tab session. */
export function hasAttemptedWasmRecovery(): boolean {
  try {
    return sessionStorage.getItem(RECOVERY_GUARD_KEY) !== null;
  } catch {
    return false;
  }
}

/**
 * Drop the mismatched caches + service worker and reload once.
 *
 * Returns `true` if a recovery reload was initiated, `false` if it was skipped
 * (not the main thread, already attempted this session, or offline — where a
 * cache-dropping reload would strand the user on a blank page).
 */
export async function recoverFromWasmAbiSkew(): Promise<boolean> {
  // Only the main thread can reload / manage the service worker registration.
  if (typeof window === "undefined") return false;
  // Never loop: recover at most once per tab session. A second skew after a
  // clean reload is a real bug, not a stale cache — let it surface.
  if (hasAttemptedWasmRecovery()) return false;
  // A cache-dropping reload is unsafe offline (we'd reload into an uncached,
  // blank page). A skew needs a freshly fetched wasm to occur, so offline skew
  // is rare and unrecoverable without the network — bail and let the error show.
  if (typeof navigator !== "undefined" && navigator.onLine === false) return false;

  try {
    sessionStorage.setItem(RECOVERY_GUARD_KEY, String(Date.now()));
  } catch {
    /* sessionStorage unavailable — proceed; worst case is one extra reload */
  }

  console.error(
    "[wasmRecovery] WASM ABI mismatch detected (stale cached pipeline bundle). " +
      "Clearing caches + service worker and reloading once to recover.",
  );

  try {
    if (typeof navigator !== "undefined" && "serviceWorker" in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await forEachBoundedBestEffort(regs, async (r) => {
        await r.unregister();
      });
    }
  } catch {
    /* best effort — the cache purge + reload below is the load-bearing step */
  }
  try {
    if (typeof caches !== "undefined") {
      const keys = await caches.keys();
      await forEachBoundedBestEffort(keys, async (k) => {
        await caches.delete(k);
      });
    }
  } catch {
    /* best effort */
  }

  window.location.reload();
  return true;
}
