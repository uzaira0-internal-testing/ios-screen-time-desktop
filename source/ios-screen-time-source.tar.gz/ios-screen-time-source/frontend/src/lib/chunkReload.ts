/**
 * Recovery for "Failed to fetch dynamically imported module" after a deploy.
 *
 * A deploy replaces content-hashed chunks; a tab still running the PREVIOUS
 * build 404s when it lazy-imports a now-removed chunk (e.g. clicking verify
 * `import("@/utils/formatters")` after the bundle was redeployed). Reload ONCE
 * to pick up the freshly-deployed index.html and its matching chunks. A
 * sessionStorage one-shot guards against reload loops when the failure is not
 * deploy-related (genuinely offline, a real 500, etc.).
 */

import { displayText } from "@/lib/displayText";

const CHUNK_ERROR_RE =
  /Failed to fetch dynamically imported module|error loading dynamically imported module|Importing a module script failed|ChunkLoadError|Loading chunk \S+ failed/i;

export function isChunkLoadError(err: unknown): boolean {
  if (err == null) return false;
  const msg =
    typeof err === 'string'
      ? err
      : err instanceof Error
        ? `${err.name}: ${err.message}`
        : displayText((err as { message?: unknown }).message ?? err);
  return CHUNK_ERROR_RE.test(msg);
}

/** Reload once to recover a stale tab; loop-guarded so a persistent failure can't spin. */
export function reloadForStaleChunk(): void {
  if (typeof window === 'undefined') return;
  try {
    const KEY = 'chunk-reload-at';
    const last = Number(sessionStorage.getItem(KEY) || 0);
    // At most one recovery reload per 30s. If the chunk is still missing after a
    // fresh load it is not a stale-deploy problem, so don't loop.
    if (Date.now() - last < 30_000) return;
    sessionStorage.setItem(KEY, String(Date.now()));
  } catch {
    /* sessionStorage unavailable — reload once anyway */
  }
  window.location.reload();
}

/**
 * Global net for UNCAUGHT chunk-load failures (React.lazy boundaries,
 * un-try/caught `import()`). Call once at startup. Handlers that already catch
 * their own dynamic import should additionally call `reloadForStaleChunk()` when
 * `isChunkLoadError(err)` is true.
 */
export function installChunkReloadHandler(): void {
  if (typeof window === 'undefined') return;
  window.addEventListener('error', (e) => {
    if (isChunkLoadError(e.message) || isChunkLoadError((e).error)) {
      e.preventDefault();
      reloadForStaleChunk();
    }
  });
  window.addEventListener('unhandledrejection', (e) => {
    if (isChunkLoadError(e.reason)) {
      // The failure is handled by the recovery reload. Mark it handled so
      // WebKit does not additionally surface a noisy uncaught rejection.
      e.preventDefault();
      reloadForStaleChunk();
    }
  });
}
