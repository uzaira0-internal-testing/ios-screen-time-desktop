const FALLBACK_CORES = 4;
// Firefox/WebKit do not expose navigator.deviceMemory. Treat unknown memory as
// a low-memory browser so memory-heavy WASM stages stay safe by default; wider
// pools are enabled only when Chromium-style coarse RAM buckets prove headroom.
const FALLBACK_DEVICE_MEMORY_GB = 1;
const MIN_APP_RESERVE_MB = 384;
const APP_RESERVE_RATIO = 0.35;

const MAX_UPLOAD_IMPORT_ITEMS = 12;
const MAX_UPLOAD_HASH_SLOTS = 4;
const MAX_UPLOAD_PERCEPTUAL_HASH_SLOTS = 4;
const MAX_DEVICE_DETECTION_ITEMS = 12;
const MAX_DEVICE_CROP_ITEMS = 12;
const MAX_CROP_DECODE_SLOTS = 6;
const DEFAULT_MAX_OCR_WORKERS = 13;
const MAX_WORKSPACE_BLOB_SLOTS = 4;
const MAX_WORKSPACE_TABLE_SLOTS = 4;
const MAX_IMAGE_URL_CACHE_ENTRIES = 40;
const MAX_STAGE_IMAGE_URL_CACHE_ENTRIES = 24;
const MAX_METADATA_IO_SLOTS = 8;
const MAX_SERVICE_WORKER_PRECACHE_SLOTS = 4;

const ESTIMATED_UPLOAD_ITEM_MB = 128;
const ESTIMATED_CONTENT_HASH_MB = 256;
const ESTIMATED_PERCEPTUAL_HASH_MB = 192;
const ESTIMATED_DEVICE_DETECTION_MB = 96;
const ESTIMATED_CROP_DECODE_MB = 256;
const ESTIMATED_OCR_WORKER_MB = 384;
const ESTIMATED_WORKSPACE_BLOB_MB = 256;
const ESTIMATED_WORKSPACE_TABLE_MB = 256;
const ESTIMATED_PINNED_IMAGE_URL_MB = 40;
const ESTIMATED_STAGE_IMAGE_URL_MB = 64;
const ESTIMATED_METADATA_IO_MB = 64;
const ESTIMATED_SERVICE_WORKER_PRECACHE_MB = 256;
const MIN_MEASURED_OCR_WORKER_MB = ESTIMATED_OCR_WORKER_MB;
const MAX_MEASURED_OCR_WORKER_MB = 2048;

declare const __MAX_OCR_WORKERS__: number | undefined;

function configuredMaxOcrWorkers(): number {
  const processEnv = (globalThis as typeof globalThis & {
    process?: { env?: Record<string, string | undefined> };
  }).process?.env;
  const nodeConfigured = Number(processEnv?.VITE_MAX_OCR_WORKERS);
  const configured = typeof __MAX_OCR_WORKERS__ === "number"
    ? __MAX_OCR_WORKERS__
    : Number.isFinite(nodeConfigured)
      ? nodeConfigured
    : DEFAULT_MAX_OCR_WORKERS;
  return Number.isFinite(configured) && configured > 0
    ? Math.floor(configured)
    : DEFAULT_MAX_OCR_WORKERS;
}

export interface OcrWorkerPoolSizingPlan {
  hardwareConcurrency: number;
  reportedDeviceMemoryGb: number | null;
  effectiveDeviceMemoryGb: number;
  usedDeviceMemoryFallback: boolean;
  totalMemoryMb: number;
  appReserveMb: number;
  availableMemoryMb: number;
  workerMemoryBudgetMb: number;
  measuredWorkerCostMb: number | null;
  cpuBoundWorkers: number;
  memoryBoundWorkers: number;
  maxWorkers: number;
  selectedWorkers: number;
}

export function browserResourceNumber<K extends "hardwareConcurrency" | "deviceMemory">(key: K): number | undefined {
  if (typeof navigator === "undefined") return undefined;
  // The desktop app's WebKit reports no deviceMemory; its shell supplies the
  // machine's total instead (src-tauri/src/lib.rs).
  const value = (navigator as Navigator & { deviceMemory?: number })[key]
    ?? (key === "deviceMemory" ? (globalThis as { __DESKTOP_MEMORY_GB__?: number }).__DESKTOP_MEMORY_GB__ : undefined);
  return typeof value === "number" && Number.isFinite(value) && value > 0 ? value : undefined;
}

function resolveDeviceMemoryGb(deviceMemoryGb: number | undefined): {
  reportedDeviceMemoryGb: number | null;
  effectiveDeviceMemoryGb: number;
  usedDeviceMemoryFallback: boolean;
} {
  const valid = typeof deviceMemoryGb === "number" && Number.isFinite(deviceMemoryGb) && deviceMemoryGb > 0;
  return {
    reportedDeviceMemoryGb: valid ? deviceMemoryGb : null,
    effectiveDeviceMemoryGb: valid ? deviceMemoryGb : FALLBACK_DEVICE_MEMORY_GB,
    usedDeviceMemoryFallback: !valid,
  };
}

function computeMemorySlotPlan(
  deviceMemoryGb: number | undefined,
  perSlotMb: number,
  maxSlots: number,
): {
  reportedDeviceMemoryGb: number | null;
  effectiveDeviceMemoryGb: number;
  usedDeviceMemoryFallback: boolean;
  totalMemoryMb: number;
  appReserveMb: number;
  availableMemoryMb: number;
  memoryBoundSlots: number;
} {
  const memory = resolveDeviceMemoryGb(deviceMemoryGb);
  const totalMb = memory.effectiveDeviceMemoryGb * 1024;
  const appReserveMb = Math.max(MIN_APP_RESERVE_MB, totalMb * APP_RESERVE_RATIO);
  const availableMemoryMb = Math.max(0, totalMb - appReserveMb);
  return {
    ...memory,
    totalMemoryMb: totalMb,
    appReserveMb,
    availableMemoryMb,
    memoryBoundSlots: Math.max(1, Math.min(maxSlots, Math.floor(availableMemoryMb / perSlotMb))),
  };
}

export function computeMemoryBoundSlots(
  deviceMemoryGb: number | undefined,
  perSlotMb: number,
  maxSlots: number,
): number {
  return computeMemorySlotPlan(deviceMemoryGb, perSlotMb, maxSlots).memoryBoundSlots;
}

export function computeOcrWorkerMemoryBudgetMb(measuredWorkerMb?: number): number {
  return typeof measuredWorkerMb === "number" && Number.isFinite(measuredWorkerMb)
    ? Math.min(
        MAX_MEASURED_OCR_WORKER_MB,
        Math.max(MIN_MEASURED_OCR_WORKER_MB, measuredWorkerMb),
      )
    : ESTIMATED_OCR_WORKER_MB;
}

export function computeOcrWorkerPoolSizingPlan(
  cores = FALLBACK_CORES,
  deviceMemoryGb?: number,
  measuredWorkerMb?: number,
): OcrWorkerPoolSizingPlan {
  const maxOcrWorkers = configuredMaxOcrWorkers();
  const cpuBoundWorkers = Math.max(1, Math.min(maxOcrWorkers, Math.floor(cores / 2)));
  const workerMemoryBudgetMb = computeOcrWorkerMemoryBudgetMb(measuredWorkerMb);
  const memory = computeMemorySlotPlan(
    deviceMemoryGb,
    workerMemoryBudgetMb,
    maxOcrWorkers,
  );
  return {
    hardwareConcurrency: cores,
    reportedDeviceMemoryGb: memory.reportedDeviceMemoryGb,
    effectiveDeviceMemoryGb: memory.effectiveDeviceMemoryGb,
    usedDeviceMemoryFallback: memory.usedDeviceMemoryFallback,
    totalMemoryMb: memory.totalMemoryMb,
    appReserveMb: memory.appReserveMb,
    availableMemoryMb: memory.availableMemoryMb,
    workerMemoryBudgetMb,
    measuredWorkerCostMb:
      typeof measuredWorkerMb === "number" && Number.isFinite(measuredWorkerMb) && measuredWorkerMb > 0
        ? measuredWorkerMb
        : null,
    cpuBoundWorkers,
    memoryBoundWorkers: memory.memoryBoundSlots,
    maxWorkers: maxOcrWorkers,
    selectedWorkers: Math.min(cpuBoundWorkers, memory.memoryBoundSlots),
  };
}

export function computeUploadImportConcurrency(
  cores = FALLBACK_CORES,
  deviceMemoryGb?: number,
): number {
  const cpuBound = Math.max(1, Math.min(MAX_UPLOAD_IMPORT_ITEMS, cores * 2));
  const memoryBound = computeMemoryBoundSlots(
    deviceMemoryGb,
    ESTIMATED_UPLOAD_ITEM_MB,
    MAX_UPLOAD_IMPORT_ITEMS,
  );
  return Math.min(cpuBound, memoryBound);
}

export function computeUploadContentHashConcurrency(
  cores = FALLBACK_CORES,
  deviceMemoryGb?: number,
): number {
  const cpuBound = Math.max(1, Math.min(MAX_UPLOAD_HASH_SLOTS, Math.floor(cores / 2)));
  const memoryBound = computeMemoryBoundSlots(
    deviceMemoryGb,
    ESTIMATED_CONTENT_HASH_MB,
    MAX_UPLOAD_HASH_SLOTS,
  );
  return Math.min(cpuBound, memoryBound);
}

export function computeUploadPerceptualHashConcurrency(
  cores = FALLBACK_CORES,
  deviceMemoryGb?: number,
): number {
  const cpuBound = Math.max(1, Math.min(MAX_UPLOAD_PERCEPTUAL_HASH_SLOTS, Math.floor(cores / 2)));
  const memoryBound = computeMemoryBoundSlots(
    deviceMemoryGb,
    ESTIMATED_PERCEPTUAL_HASH_MB,
    MAX_UPLOAD_PERCEPTUAL_HASH_SLOTS,
  );
  return Math.min(cpuBound, memoryBound);
}

export function computeOcrWorkerConcurrency(
  cores = FALLBACK_CORES,
  deviceMemoryGb?: number,
  measuredWorkerMb?: number,
): number {
  return computeOcrWorkerPoolSizingPlan(cores, deviceMemoryGb, measuredWorkerMb).selectedWorkers;
}

export function computeCropDecodeConcurrency(
  cores = FALLBACK_CORES,
  deviceMemoryGb?: number,
): number {
  const cpuBound = Math.max(1, Math.min(MAX_CROP_DECODE_SLOTS, Math.floor(cores / 2)));
  const memoryBound = computeMemoryBoundSlots(
    deviceMemoryGb,
    ESTIMATED_CROP_DECODE_MB,
    MAX_CROP_DECODE_SLOTS,
  );
  return Math.min(cpuBound, memoryBound);
}

export function computeDeviceDetectionConcurrency(
  cores = FALLBACK_CORES,
  deviceMemoryGb?: number,
): number {
  // Device detection is normally header-only plus metadata/original-blob writes,
  // so it can run wider than crop decode and OCR. Keep it RAM-aware because the
  // original snapshot write still pins Blob handles and IDB/OPFS work in flight.
  const cpuBound = Math.max(2, Math.min(MAX_DEVICE_DETECTION_ITEMS, cores * 2));
  const memoryBound = computeMemoryBoundSlots(
    deviceMemoryGb,
    ESTIMATED_DEVICE_DETECTION_MB,
    MAX_DEVICE_DETECTION_ITEMS,
  );
  return Math.min(cpuBound, memoryBound);
}

export function computeDeviceCropConcurrency(
  cores = FALLBACK_CORES,
  deviceMemoryGb?: number,
): number {
  // Cropping's no-crop majority is metadata-only, while the expensive crop
  // decode/canvas path is separately gated by computeCropDecodeConcurrency.
  const cpuBound = Math.max(2, Math.min(MAX_DEVICE_CROP_ITEMS, cores * 2));
  const memoryBound = computeMemoryBoundSlots(
    deviceMemoryGb,
    ESTIMATED_CROP_DECODE_MB,
    MAX_DEVICE_CROP_ITEMS,
  );
  return Math.min(cpuBound, memoryBound);
}

export function computeWorkspaceBlobConcurrency(
  cores = FALLBACK_CORES,
  deviceMemoryGb?: number,
): number {
  // Workspace export/import must eventually hold archive bytes, but individual
  // blob read/write materialization is still memory-heavy. Keep it narrower
  // than upload item import and tied to the same conservative RAM fallback.
  const cpuBound = Math.max(1, Math.min(MAX_WORKSPACE_BLOB_SLOTS, Math.floor(cores / 2)));
  const memoryBound = computeMemoryBoundSlots(
    deviceMemoryGb,
    ESTIMATED_WORKSPACE_BLOB_MB,
    MAX_WORKSPACE_BLOB_SLOTS,
  );
  return Math.min(cpuBound, memoryBound);
}

export function computeWorkspaceTableConcurrency(
  cores = FALLBACK_CORES,
  deviceMemoryGb?: number,
): number {
  // Workspace export reads whole Dexie tables into arrays before ZIP encoding.
  // These are not image blobs, but they are still full-workspace materialized
  // payloads, so keep table fan-out in the same conservative memory class.
  const cpuBound = Math.max(1, Math.min(MAX_WORKSPACE_TABLE_SLOTS, Math.floor(cores / 2)));
  const memoryBound = computeMemoryBoundSlots(
    deviceMemoryGb,
    ESTIMATED_WORKSPACE_TABLE_MB,
    MAX_WORKSPACE_TABLE_SLOTS,
  );
  return Math.min(cpuBound, memoryBound);
}

export function computeImageUrlCacheSize(deviceMemoryGb?: number): number {
  // Each blob: URL keeps its Blob reachable. The views are virtualized, so this
  // cache is a memory residency budget, not a correctness requirement.
  return computeMemoryBoundSlots(
    deviceMemoryGb,
    ESTIMATED_PINNED_IMAGE_URL_MB,
    MAX_IMAGE_URL_CACHE_ENTRIES,
  );
}

export function computeStageImageUrlCacheSize(deviceMemoryGb?: number): number {
  // Review-stage URLs often point at original pre-crop screenshots, which are
  // larger than cropped thumbnails. Keep this cache tighter while using the
  // same conservative memory fallback model.
  return computeMemoryBoundSlots(
    deviceMemoryGb,
    ESTIMATED_STAGE_IMAGE_URL_MB,
    MAX_STAGE_IMAGE_URL_CACHE_ENTRIES,
  );
}

export function computeMetadataIoConcurrency(
  cores = FALLBACK_CORES,
  deviceMemoryGb?: number,
): number {
  // IndexedDB metadata reads/writes are much cheaper than image decode, but
  // large reset/reconcile operations can still queue thousands of structured
  // clone operations. Keep them bounded so UI-driven maintenance work cannot
  // starve the decode/OCR pipeline.
  const cpuBound = Math.max(1, Math.min(MAX_METADATA_IO_SLOTS, cores));
  const memoryBound = computeMemoryBoundSlots(
    deviceMemoryGb,
    ESTIMATED_METADATA_IO_MB,
    MAX_METADATA_IO_SLOTS,
  );
  return Math.min(cpuBound, memoryBound);
}

export function computeServiceWorkerPrecacheConcurrency(
  cores = FALLBACK_CORES,
  deviceMemoryGb?: number,
): number {
  // The service worker verifies every precached response by buffering it for a
  // SHA-256 digest before cache.put(). Keep install-time fetch/hash fan-out
  // narrow, especially on unknown-memory browsers and GitHub Pages deploys
  // where the app chunks, wasm, and tessdata all become cold-cache requests.
  const cpuBound = Math.max(1, Math.min(MAX_SERVICE_WORKER_PRECACHE_SLOTS, Math.floor(cores / 2)));
  const memoryBound = computeMemoryBoundSlots(
    deviceMemoryGb,
    ESTIMATED_SERVICE_WORKER_PRECACHE_MB,
    MAX_SERVICE_WORKER_PRECACHE_SLOTS,
  );
  return Math.min(cpuBound, memoryBound);
}
