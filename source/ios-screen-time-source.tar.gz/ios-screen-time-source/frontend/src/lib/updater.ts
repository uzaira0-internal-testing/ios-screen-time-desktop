/**
 * Tauri auto-update utilities.
 * All imports from @tauri-apps/* are dynamic to avoid breaking web/WASM builds.
 */

export interface UpdateInfo {
  version: string;
  currentVersion: string;
  body?: string;
  date?: string;
}

export interface UpdateProgress {
  downloaded: number;
  total: number;
}

export async function relaunchApp(): Promise<void> {
  const mod = await import("@tauri-apps/plugin-process") as unknown as {
    relaunch: () => Promise<void>;
  };
  await mod.relaunch();
}

// Module-level reference to the raw Update object from the plugin
// so downloadAndInstall can use it after checkForUpdate returns.
// Typed as the subset of the Tauri Update interface we use (plugin may not be installed)
type PendingUpdate = {
  available?: boolean;
  version: string;
  currentVersion: string;
  body?: string;
  date?: string;
  downloadAndInstall: (cb: (event: UpdateEvent) => void) => Promise<void>;
};

let pendingUpdate: PendingUpdate | null = null;

// Synchronous setter — wrapping the assignment in a non-async helper takes the
// write out of the async function body so eslint's require-atomic-updates flow
// analysis no longer flags it as a race with the preceding await.
function setPendingUpdate(value: PendingUpdate | null): void {
  pendingUpdate = value;
}

interface UpdateEvent {
  event: "Started" | "Progress" | "Finished";
  data: { contentLength?: number; chunkLength?: number };
}

export async function checkForUpdate(): Promise<UpdateInfo | null> {
  const mod = await import("@tauri-apps/plugin-updater") as unknown as {
    check: () => Promise<PendingUpdate | null>;
  };
  const update = await mod.check();

  const next = update?.available ? update : null;
  setPendingUpdate(next);

  if (!next) return null;

  const info: UpdateInfo = {
    version: next.version,
    currentVersion: next.currentVersion,
  };
  if (next.body !== undefined) info.body = next.body;
  if (next.date !== undefined) info.date = next.date;
  return info;
}

export async function downloadAndInstall(
  onProgress?: (progress: UpdateProgress) => void,
): Promise<void> {
  if (!pendingUpdate) {
    throw new Error("No pending update. Call checkForUpdate() first.");
  }

  let totalBytes = 0;

  await pendingUpdate.downloadAndInstall(
    (event: UpdateEvent) => {
      if (!onProgress) return;

      switch (event.event) {
        case "Started":
          totalBytes = event.data.contentLength ?? 0;
          onProgress({ downloaded: 0, total: totalBytes });
          break;
        case "Progress":
          onProgress({
            downloaded: event.data.chunkLength ?? 0,
            total: totalBytes,
          });
          break;
        case "Finished":
          onProgress({ downloaded: totalBytes, total: totalBytes });
          break;
      }
    },
  );

}
