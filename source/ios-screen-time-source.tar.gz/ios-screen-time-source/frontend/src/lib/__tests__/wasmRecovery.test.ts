/**
 * Self-heal guard for a WASM ABI skew. The dangerous bits are the guards:
 * recover at most ONCE per tab session (no reload loop), never reload offline
 * (would strand the user on an uncached page), and never run off the main
 * thread (a worker can't reload). These tests pin all three plus the happy path.
 */
import { describe, it, expect, beforeEach, afterEach } from "bun:test";

import { recoverFromWasmAbiSkew, hasAttemptedWasmRecovery } from "../wasmRecovery";

type Saved = Record<string, PropertyDescriptor | undefined>;
const GLOBAL_KEYS = ["window", "navigator", "caches", "sessionStorage"] as const;
let saved: Saved;

let reloadCount: number;
let unregisterCount: number;
let cacheDeleteKeys: string[];
let peakUnregisters: number;
let peakCacheDeletes: number;

function fakeSessionStorage() {
  const m = new Map<string, string>();
  return {
    getItem: (k: string) => (m.has(k) ? (m.get(k) as string) : null),
    setItem: (k: string, v: string) => void m.set(k, v),
    removeItem: (k: string) => void m.delete(k),
  };
}

/** Install fake DOM/SW/cache globals. `online` and `worker` toggle the guards. */
function install({
  online = true,
  worker = false,
  registrationCount = 2,
  cacheKeys = ["shell-v2-abc", "pipeline-v2-abc", "app-v2-abc"],
  delayCleanup = false,
}: {
  online?: boolean;
  worker?: boolean;
  registrationCount?: number;
  cacheKeys?: string[];
  delayCleanup?: boolean;
} = {}) {
  reloadCount = 0;
  unregisterCount = 0;
  cacheDeleteKeys = [];
  peakUnregisters = 0;
  peakCacheDeletes = 0;
  let activeUnregisters = 0;
  let activeCacheDeletes = 0;

  const maybeDelay = () =>
    delayCleanup ? new Promise<void>((resolve) => { setTimeout(resolve, 0); }) : Promise.resolve();

  const ss = fakeSessionStorage();
  Object.defineProperty(globalThis, "sessionStorage", { value: ss, configurable: true });

  // A worker context is modelled as `window` being undefined.
  Object.defineProperty(globalThis, "window", {
    value: worker ? undefined : { location: { reload: () => void reloadCount++ } },
    configurable: true,
  });

  Object.defineProperty(globalThis, "navigator", {
    value: {
      onLine: online,
      hardwareConcurrency: 8,
      deviceMemory: 0.5,
      serviceWorker: {
        getRegistrations: async () =>
          Array.from({ length: registrationCount }, () => ({
            unregister: async () => {
              activeUnregisters += 1;
              peakUnregisters = Math.max(peakUnregisters, activeUnregisters);
              await maybeDelay();
              activeUnregisters -= 1;
              unregisterCount += 1;
            },
          })),
      },
    },
    configurable: true,
  });

  Object.defineProperty(globalThis, "caches", {
    value: {
      keys: async () => cacheKeys,
      delete: async (k: string) => {
        activeCacheDeletes += 1;
        peakCacheDeletes = Math.max(peakCacheDeletes, activeCacheDeletes);
        await maybeDelay();
        activeCacheDeletes -= 1;
        cacheDeleteKeys.push(k);
        return true;
      },
    },
    configurable: true,
  });
}

beforeEach(() => {
  saved = {};
  for (const k of GLOBAL_KEYS) saved[k] = Object.getOwnPropertyDescriptor(globalThis, k);
});

afterEach(() => {
  for (const k of GLOBAL_KEYS) {
    if (saved[k]) Object.defineProperty(globalThis, k, saved[k]);
    else delete (globalThis as Record<string, unknown>)[k];
  }
});

describe("recoverFromWasmAbiSkew", () => {
  it("clears every cache + service worker and reloads once on first skew", async () => {
    install();
    const did = await recoverFromWasmAbiSkew();
    expect(did).toBe(true);
    expect(reloadCount).toBe(1);
    expect(unregisterCount).toBe(2);
    expect(cacheDeleteKeys.sort()).toEqual(["app-v2-abc", "pipeline-v2-abc", "shell-v2-abc"]);
    expect(hasAttemptedWasmRecovery()).toBe(true);
  });

  it("bounds recovery cleanup fan-out by the maintenance resource budget", async () => {
    install({
      registrationCount: 6,
      cacheKeys: ["a", "b", "c", "d", "e", "f"],
      delayCleanup: true,
    });

    const did = await recoverFromWasmAbiSkew();

    expect(did).toBe(true);
    expect(unregisterCount).toBe(6);
    expect(cacheDeleteKeys.sort()).toEqual(["a", "b", "c", "d", "e", "f"]);
    expect(peakUnregisters).toBe(2);
    expect(peakCacheDeletes).toBe(2);
  });

  it("does NOT reload a second time in the same session (no loop)", async () => {
    install();
    await recoverFromWasmAbiSkew();
    expect(reloadCount).toBe(1);

    const second = await recoverFromWasmAbiSkew();
    expect(second).toBe(false);
    expect(reloadCount).toBe(1); // still 1 — guarded
  });

  it("does NOT reload when offline (would strand on an uncached page)", async () => {
    install({ online: false });
    const did = await recoverFromWasmAbiSkew();
    expect(did).toBe(false);
    expect(reloadCount).toBe(0);
    expect(cacheDeleteKeys).toEqual([]);
  });

  it("does NOT act off the main thread (no window)", async () => {
    install({ worker: true });
    const did = await recoverFromWasmAbiSkew();
    expect(did).toBe(false);
    expect(reloadCount).toBe(0);
  });
});
