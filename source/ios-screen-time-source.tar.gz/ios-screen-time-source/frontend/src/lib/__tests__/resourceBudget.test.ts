import { describe, expect, test } from "bun:test";

import {
  browserResourceNumber,
  computeCropDecodeConcurrency,
  computeDeviceDetectionConcurrency,
  computeDeviceCropConcurrency,
  computeImageUrlCacheSize,
  computeMetadataIoConcurrency,
  computeMemoryBoundSlots,
  computeOcrWorkerConcurrency,
  computeOcrWorkerMemoryBudgetMb,
  computeOcrWorkerPoolSizingPlan,
  computeServiceWorkerPrecacheConcurrency,
  computeStageImageUrlCacheSize,
  computeUploadContentHashConcurrency,
  computeUploadImportConcurrency,
  computeUploadPerceptualHashConcurrency,
  computeWorkspaceBlobConcurrency,
  computeWorkspaceTableConcurrency,
} from "../resourceBudget";

describe("resource budget helpers", () => {
  test("memory slots reserve app headroom and use a conservative fallback", () => {
    expect(computeMemoryBoundSlots(undefined, 256, 8)).toBe(2);
    expect(computeMemoryBoundSlots(1, 256, 8)).toBe(2);
    expect(computeMemoryBoundSlots(4, 256, 8)).toBe(8);
  });

  test("upload item concurrency scales with CPU and memory", () => {
    expect(computeUploadImportConcurrency(2, 1)).toBe(4);
    expect(computeUploadImportConcurrency(8, 1)).toBe(5);
    expect(computeUploadImportConcurrency(8, 2)).toBe(10);
    expect(computeUploadImportConcurrency(16, 8)).toBe(12);
  });

  test("upload hash sub-stages are capped below item concurrency", () => {
    expect(computeUploadContentHashConcurrency(2, 1)).toBe(1);
    expect(computeUploadContentHashConcurrency(8, 1)).toBe(2);
    expect(computeUploadContentHashConcurrency(8, 2)).toBe(4);
    expect(computeUploadPerceptualHashConcurrency(2, 1)).toBe(1);
    expect(computeUploadPerceptualHashConcurrency(8, 1)).toBe(3);
    expect(computeUploadPerceptualHashConcurrency(8, 2)).toBe(4);
  });

  test("OCR workers use the same conservative CPU and memory budget model", () => {
    expect(computeOcrWorkerConcurrency(2)).toBe(1);
    expect(computeOcrWorkerConcurrency(8)).toBe(1);
    expect(computeOcrWorkerConcurrency(32)).toBe(1);
    expect(computeOcrWorkerConcurrency(8, 1)).toBe(1);
    expect(computeOcrWorkerConcurrency(8, 4)).toBe(4);
    expect(computeOcrWorkerConcurrency(16, 8)).toBe(8);
  });

  test("OCR worker measurements can tighten but not loosen the conservative budget", () => {
    expect(computeOcrWorkerMemoryBudgetMb()).toBe(384);
    expect(computeOcrWorkerMemoryBudgetMb(64)).toBe(384);
    expect(computeOcrWorkerMemoryBudgetMb(768)).toBe(768);
    expect(computeOcrWorkerConcurrency(16, 4, 768)).toBe(3);
    expect(computeOcrWorkerConcurrency(16, 4, 128)).toBe(6);
    expect(computeOcrWorkerConcurrency(16, 4, Number.NaN)).toBe(6);
  });

  test("OCR worker sizing plan exposes CPU and memory bounds without hard-coded 1 GB special cases", () => {
    expect(computeOcrWorkerPoolSizingPlan(8, 1)).toMatchObject({
      hardwareConcurrency: 8,
      reportedDeviceMemoryGb: 1,
      effectiveDeviceMemoryGb: 1,
      usedDeviceMemoryFallback: false,
      totalMemoryMb: 1024,
      appReserveMb: 384,
      availableMemoryMb: 640,
      workerMemoryBudgetMb: 384,
      measuredWorkerCostMb: null,
      cpuBoundWorkers: 4,
      memoryBoundWorkers: 1,
      maxWorkers: 13,
      selectedWorkers: 1,
    });

    expect(computeOcrWorkerPoolSizingPlan(32)).toMatchObject({
      reportedDeviceMemoryGb: null,
      effectiveDeviceMemoryGb: 1,
      usedDeviceMemoryFallback: true,
      cpuBoundWorkers: 13,
      memoryBoundWorkers: 1,
      selectedWorkers: 1,
    });

    expect(computeOcrWorkerPoolSizingPlan(16, 4, 768)).toMatchObject({
      measuredWorkerCostMb: 768,
      workerMemoryBudgetMb: 768,
      cpuBoundWorkers: 8,
      memoryBoundWorkers: 3,
      selectedWorkers: 3,
    });
  });

  test("device and crop stages split cheap detection from decode-bound work", () => {
    expect(computeDeviceDetectionConcurrency(8)).toBe(6);
    expect(computeDeviceDetectionConcurrency(2, 1)).toBe(4);
    expect(computeDeviceDetectionConcurrency(4, 2)).toBe(8);
    expect(computeDeviceDetectionConcurrency(16, 8)).toBe(12);
    expect(computeDeviceCropConcurrency(8)).toBe(2);
    expect(computeDeviceCropConcurrency(2, 1)).toBe(2);
    expect(computeDeviceCropConcurrency(4, 2)).toBe(5);
    expect(computeDeviceCropConcurrency(16, 8)).toBe(12);
    expect(computeCropDecodeConcurrency(8)).toBe(2);
    expect(computeCropDecodeConcurrency(8, 1)).toBe(2);
    expect(computeCropDecodeConcurrency(8, 2)).toBe(4);
    expect(computeCropDecodeConcurrency(16, 4)).toBe(6);
  });

  test("workspace archive blob materialization stays narrowly bounded", () => {
    expect(computeWorkspaceBlobConcurrency(8)).toBe(2);
    expect(computeWorkspaceBlobConcurrency(2, 1)).toBe(1);
    expect(computeWorkspaceBlobConcurrency(8, 2)).toBe(4);
    expect(computeWorkspaceBlobConcurrency(16, 8)).toBe(4);
  });

  test("workspace table materialization uses a memory-aware export budget", () => {
    expect(computeWorkspaceTableConcurrency(8)).toBe(2);
    expect(computeWorkspaceTableConcurrency(2, 1)).toBe(1);
    expect(computeWorkspaceTableConcurrency(8, 2)).toBe(4);
    expect(computeWorkspaceTableConcurrency(16, 8)).toBe(4);
  });

  test("blob URL cache residency follows the same memory fallback model", () => {
    expect(computeImageUrlCacheSize()).toBe(16);
    expect(computeImageUrlCacheSize(1)).toBe(16);
    expect(computeImageUrlCacheSize(2)).toBe(33);
    expect(computeImageUrlCacheSize(4)).toBe(40);
    expect(computeImageUrlCacheSize(8)).toBe(40);
  });

  test("stage image URL cache is tighter for full-size review images", () => {
    expect(computeStageImageUrlCacheSize()).toBe(10);
    expect(computeStageImageUrlCacheSize(1)).toBe(10);
    expect(computeStageImageUrlCacheSize(2)).toBe(20);
    expect(computeStageImageUrlCacheSize(4)).toBe(24);
    expect(computeStageImageUrlCacheSize(8)).toBe(24);
  });

  test("metadata IO stays bounded during batch maintenance operations", () => {
    expect(computeMetadataIoConcurrency(2)).toBe(2);
    expect(computeMetadataIoConcurrency(8)).toBe(8);
    expect(computeMetadataIoConcurrency(32)).toBe(8);
    expect(computeMetadataIoConcurrency(8, 1)).toBe(8);
    expect(computeMetadataIoConcurrency(8, 0.5)).toBe(2);
  });

  test("service worker precache verification stays narrow on cold installs", () => {
    expect(computeServiceWorkerPrecacheConcurrency(2)).toBe(1);
    expect(computeServiceWorkerPrecacheConcurrency(8)).toBe(2);
    expect(computeServiceWorkerPrecacheConcurrency(8, 1)).toBe(2);
    expect(computeServiceWorkerPrecacheConcurrency(8, 2)).toBe(4);
    expect(computeServiceWorkerPrecacheConcurrency(16, 8)).toBe(4);
  });

  test("deviceMemory falls back to the desktop shell's figure when the engine reports none", () => {
    const scope = globalThis as { __DESKTOP_MEMORY_GB__?: number };
    const reported = (navigator as Navigator & { deviceMemory?: number }).deviceMemory;
    scope.__DESKTOP_MEMORY_GB__ = 16;
    try {
      expect(browserResourceNumber("deviceMemory")).toBe(reported ?? 16);
    } finally {
      delete scope.__DESKTOP_MEMORY_GB__;
    }
    expect(browserResourceNumber("deviceMemory")).toBe(reported);
  });
});
