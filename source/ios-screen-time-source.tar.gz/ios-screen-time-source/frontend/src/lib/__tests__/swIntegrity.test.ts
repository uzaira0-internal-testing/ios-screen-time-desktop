/**
 * The service worker's runtime-repair path (`cacheFirst` on an install-time
 * cache miss) verifies a network-fetched asset against the precache manifest's
 * SHA-256 before persisting it — the same SEC-10 guarantee the install step
 * enforces, extended to the post-install fetch that previously cached unverified
 * bytes. These pin the pure decision logic that drives that verification.
 */
import { describe, it, expect } from "bun:test";

import { buildIntegrityIndex, integrityDecision, type PrecacheManifest } from "../swIntegrity";

const manifest: PrecacheManifest = {
  version: 3,
  basePath: "/base",
  shellAssets: [{ url: "/base/index.html", sha256: "shell" }],
  appAssets: [{ url: "/base/assets/main-abc.js", sha256: "app" }],
  pipelineAssets: [
    // ABI-coupled wasm carries the ?v=<hash> query — it must survive into the key.
    { url: "/base/pipeline-em/IosScreenTimePipeline.wasm?v=deadbeef", sha256: "wasm" },
    // tessdata is ABI-independent → left bare on both sides.
    { url: "/base/pipeline-em/eng.traineddata", sha256: "tess" },
  ],
};

describe("buildIntegrityIndex", () => {
  it("indexes every group keyed by the resolved absolute URL, preserving the ?v= query", () => {
    const index = buildIntegrityIndex(manifest, (u) => `https://host${u}`);
    expect(index.get("https://host/base/index.html")).toBe("shell");
    expect(index.get("https://host/base/assets/main-abc.js")).toBe("app");
    expect(index.get("https://host/base/pipeline-em/IosScreenTimePipeline.wasm?v=deadbeef")).toBe(
      "wasm",
    );
    expect(index.get("https://host/base/pipeline-em/eng.traineddata")).toBe("tess");
    expect(index.size).toBe(4);
  });

  it("skips malformed entries (missing url or sha256) rather than indexing a blank key", () => {
    const bad: PrecacheManifest = {
      version: 3,
      basePath: "",
      shellAssets: [],
      appAssets: [],
      pipelineAssets: [
        { url: "", sha256: "x" },
        { url: "/a", sha256: "" },
        { url: "/good", sha256: "g" },
      ],
    };
    const index = buildIntegrityIndex(bad, (u) => u);
    expect(index.size).toBe(1);
    expect(index.get("/good")).toBe("g");
  });
});

describe("integrityDecision", () => {
  it("persists a manifest asset whose hash matches (either strictness)", () => {
    expect(integrityDecision("abc", "abc", true)).toBe("serve-and-cache");
    expect(integrityDecision("abc", "abc", false)).toBe("serve-and-cache");
  });

  it("rejects a manifest asset whose hash MISMATCHES — never serve or cache poisoned bytes", () => {
    expect(integrityDecision("abc", "xyz", true)).toBe("reject");
    expect(integrityDecision("abc", "xyz", false)).toBe("reject");
  });

  it("serves but never persists an unlisted executable pipeline asset (strict)", () => {
    // Covers both the genuinely-unlisted case and the no-manifest case
    // (expected === undefined when the index couldn't be loaded).
    expect(integrityDecision(undefined, undefined, true)).toBe("serve-no-cache");
  });

  it("persists an unlisted app chunk (non-strict: nerWorker is deliberately off-manifest)", () => {
    expect(integrityDecision(undefined, undefined, false)).toBe("serve-and-cache");
  });
});
