import { afterEach, describe, expect, test } from "bun:test";
import { wipeAllLocalData } from "../resetLocalData";

const GLOBAL_KEYS = [
  "window",
  "indexedDB",
  "navigator",
  "caches",
  "localStorage",
  "sessionStorage",
] as const;

type Saved = Record<(typeof GLOBAL_KEYS)[number], PropertyDescriptor | undefined>;
let saved: Saved;

function delayed<T>(value: T, after: () => void): Promise<T> {
  return new Promise((resolve) => {
    setTimeout(() => {
      after();
      resolve(value);
    }, 0);
  });
}

describe("wipeAllLocalData", () => {
  afterEach(() => {
    for (const k of GLOBAL_KEYS) {
      if (saved[k]) Object.defineProperty(globalThis, k, saved[k]);
      else Reflect.deleteProperty(globalThis, k);
    }
  });

  test("reset deletes only app-owned data and bounds cleanup concurrency", async () => {
    saved = {} as Saved;
    for (const k of GLOBAL_KEYS) saved[k] = Object.getOwnPropertyDescriptor(globalThis, k);

    let activeDbDeletes = 0;
    let activeCacheDeletes = 0;
    let activeUnregisters = 0;
    let peakDbDeletes = 0;
    let peakCacheDeletes = 0;
    let peakUnregisters = 0;
    const deletedDbs: string[] = [];
    const deletedCaches: string[] = [];
    let unregisterCount = 0;
    const removedFiles: string[] = [];
    const localKeys = new Map([
      ["processing-settings", "{}"],
      ["desktop-last-import-folder", "/data/STUDY01"],
      ["desktop-auto-update-check", "off"],
      ["other-project", "keep"],
    ]);
    const sessionKeys = new Map([["wasm-abi-skew-recovered", "1"], ["other-project", "keep"]]);
    Object.defineProperty(globalThis, "window", { configurable: true, value: { __CONFIG__: { basePath: "/app" }, location: { origin: "https://example.test" } } });

    Object.defineProperty(globalThis, "indexedDB", {
      configurable: true,
      value: {
        databases: async () =>
          [{ name: "ScreenshotProcessorDB" }, { name: "language-packs" }, { name: "other-project-db" }],
        deleteDatabase: (name: string) => {
          activeDbDeletes += 1;
          peakDbDeletes = Math.max(peakDbDeletes, activeDbDeletes);
          const req: {
            onsuccess: (() => void) | null;
            onerror: (() => void) | null;
            onblocked: (() => void) | null;
          } = {
            onsuccess: null,
            onerror: null,
            onblocked: null,
          };
          setTimeout(() => {
            activeDbDeletes -= 1;
            deletedDbs.push(name);
            req.onsuccess?.();
          }, 0);
          return req;
        },
      },
    });

    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        hardwareConcurrency: 8,
        deviceMemory: 0.5,
        storage: {
          getDirectory: async () => {
            return {
              async *entries() { for (const name of ["screenshots", "language-packs", "db-backups", "other-project"]) yield [name, {}]; },
              removeEntry: async (name: string) => { removedFiles.push(name); },
            };
          },
        },
        serviceWorker: {
          getRegistrations: async () =>
            Array.from({ length: 6 }, (_, i) => ({
              scope: `https://example.test/${i === 0 ? "app" : `other-${i}`}/`,
              unregister: async () => {
                activeUnregisters += 1;
                peakUnregisters = Math.max(peakUnregisters, activeUnregisters);
                await delayed(undefined, () => {
                  activeUnregisters -= 1;
                  unregisterCount += 1;
                });
              },
            })),
        },
      },
    });

    Object.defineProperty(globalThis, "caches", {
      configurable: true,
      value: {
        keys: async () => ["shell-v2-a", "app-v2-a", "pipeline-v2-a", "runtime-v2-a", "transformers-cache", "other-project-cache"],
        delete: async (key: string) => {
          activeCacheDeletes += 1;
          peakCacheDeletes = Math.max(peakCacheDeletes, activeCacheDeletes);
          await delayed(undefined, () => {
            activeCacheDeletes -= 1;
            deletedCaches.push(key);
          });
          return true;
        },
      },
    });

    Object.defineProperty(globalThis, "localStorage", {
      configurable: true,
      value: { clear: () => localKeys.clear(), removeItem: (key: string) => localKeys.delete(key), key: (i: number) => [...localKeys.keys()][i], get length() { return localKeys.size; } },
    });
    Object.defineProperty(globalThis, "sessionStorage", {
      configurable: true,
      value: { clear: () => sessionKeys.clear(), removeItem: (key: string) => sessionKeys.delete(key) },
    });

    await wipeAllLocalData();

    expect(deletedDbs.sort()).toEqual(["ScreenshotProcessorDB", "language-packs"]);
    expect(deletedCaches.sort()).toEqual(["app-v2-a", "pipeline-v2-a", "runtime-v2-a", "shell-v2-a", "transformers-cache"]);
    expect(unregisterCount).toBe(1);
    expect(peakDbDeletes).toBe(2);
    expect(peakCacheDeletes).toBe(2);
    expect(removedFiles.sort()).toEqual(["db-backups", "language-packs", "screenshots"]);
    expect([...localKeys]).toEqual([["other-project", "keep"]]);
    expect([...sessionKeys]).toEqual([["other-project", "keep"]]);
    expect(peakUnregisters).toBe(1);
  });
});
