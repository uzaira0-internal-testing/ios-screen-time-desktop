import { useCallback } from "react";
import { flushSync } from "react-dom";
import { useNavigate, type NavigateOptions, type To } from "react-router";

/**
 * View-Transition-aware navigation for the DECLARATIVE router.
 *
 * This app uses `<BrowserRouter>` (declarative), not `createBrowserRouter`
 * (data router). React Router only wraps navigations in
 * `document.startViewTransition()` on the *data*-router path — the `<Link
 * viewTransition>` prop is a verified no-op under `<BrowserRouter>`. So we drive
 * the transition ourselves: call `startViewTransition`, and inside its callback
 * apply the route change synchronously via `flushSync(navigate)` so the browser
 * captures the new DOM as the transition's "new" snapshot.
 *
 * `flushSync` is normally discouraged, but it is the documented pattern here and
 * safe because the primary nav targets are idle-preloaded (AppRouter), so the
 * destination renders without hitting its Suspense fallback.
 *
 * Degrades cleanly: when the API is missing or the user prefers reduced motion,
 * or the click is a modified/middle click (open-in-new-tab), the handler does
 * nothing and lets React Router's own `<Link>`/`<NavLink>` onClick navigate
 * normally — so behavior is identical to before, just without the animation.
 */

function viewTransitionsUsable(): boolean {
  return (
    typeof document !== "undefined" &&
    typeof document.startViewTransition === "function" &&
    !window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
}

type AnchorClick = (e: React.MouseEvent<HTMLAnchorElement>) => void;

/** Returns `(to, opts?) => onClick` — attach the result to a `<Link>`/`<NavLink>`. */
export function useViewTransitionClick(): (to: To, opts?: NavigateOptions) => AnchorClick {
  const navigate = useNavigate();
  return useCallback(
    (to: To, opts?: NavigateOptions): AnchorClick =>
      (e) => {
        // Let the browser / React Router handle modified, middle, or already
        // handled clicks (open-in-new-tab, etc.).
        if (
          e.defaultPrevented ||
          e.button !== 0 ||
          e.metaKey ||
          e.ctrlKey ||
          e.shiftKey ||
          e.altKey
        ) {
          return;
        }
        if (!viewTransitionsUsable()) {
          return; // fall through to React Router's own navigation
        }
        e.preventDefault();
        document.startViewTransition(() => {
          void flushSync(() => navigate(to, opts));
        });
      },
    [navigate],
  );
}
