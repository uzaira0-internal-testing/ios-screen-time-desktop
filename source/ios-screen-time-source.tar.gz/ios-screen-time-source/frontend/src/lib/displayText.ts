/**
 * Render an unknown value as display text.
 *
 * Preprocessing stage results and PHI regions arrive as
 * `Record<string, unknown>` decoded from stored JSON, and the columns that show
 * them reached for `String(value)`. That is correct for primitives and wrong
 * for everything else: an object renders as the literal `[object Object]`, so a
 * nested result silently shows as noise instead of its contents. This renders
 * primitives exactly as `String` did and falls back to compact JSON — the value
 * the reader actually wanted — for anything structured.
 */
export function displayText(value: unknown): string {
  if (value === null || value === undefined) return "";
  if (typeof value === "string") return value;
  if (
    typeof value === "number" ||
    typeof value === "boolean" ||
    typeof value === "bigint"
  ) {
    return String(value);
  }
  if (value instanceof Error) return value.message;
  try {
    return JSON.stringify(value) ?? Object.prototype.toString.call(value);
  } catch {
    // Cyclic or otherwise unserializable — the tag is still better than a throw.
    return Object.prototype.toString.call(value);
  }
}
