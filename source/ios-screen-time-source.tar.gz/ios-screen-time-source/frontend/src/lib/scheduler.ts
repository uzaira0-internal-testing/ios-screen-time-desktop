/**
 * Main-thread yielding helpers for keeping interactions responsive (INP) while
 * a long batch runs.
 *
 * `scheduler.yield()` is the 2024+ primitive: unlike `setTimeout(0)`, the
 * continuation is scheduled as a *prioritized* task, so genuinely pending user
 * input runs BEFORE the loop resumes — exactly what we want during a
 * preprocessing batch. It is Chromium-shipped but not universally Baseline yet,
 * so we fall back to `scheduler.postTask` (user-visible priority), then to the
 * universally-available `setTimeout(0)`.
 *
 * Reference: https://developer.mozilla.org/en-US/docs/Web/API/Scheduler/yield
 */

interface SchedulerLike {
  yield?: () => Promise<void>;
  postTask?: (cb: () => void, opts?: { priority?: string }) => Promise<unknown>;
}

function getScheduler(): SchedulerLike | undefined {
  return (globalThis as unknown as { scheduler?: SchedulerLike }).scheduler;
}

/** Yield control to the main thread so pending input/paint can run, resuming
 *  with the highest-priority continuation the platform supports. */
export function yieldToMain(): Promise<void> {
  const s = getScheduler();
  if (typeof s?.yield === "function") {
    return s.yield();
  }
  if (typeof s?.postTask === "function") {
    return s.postTask(() => {}, { priority: "user-visible" }).then(() => undefined);
  }
  return new Promise<void>((resolve) => {
    setTimeout(resolve, 0);
  });
}

/** True when the platform exposes `scheduler.yield` (best-quality yielding). */
export function hasNativeYield(): boolean {
  return typeof getScheduler()?.yield === "function";
}
