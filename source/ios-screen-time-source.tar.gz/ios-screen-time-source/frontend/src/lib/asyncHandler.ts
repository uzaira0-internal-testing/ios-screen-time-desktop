import { useMemo } from "react";

/**
 * Adapt an async function to a `void`-returning callback slot.
 *
 * React event props (`onClick`, `onSubmit`), timer callbacks and component
 * props declared `() => void` all discard whatever they are given. Handing
 * them an `async` function therefore drops the promise on the floor: a
 * rejection surfaces as an unhandled rejection with no stack pointing at the
 * handler, and nothing in the type system objects.
 *
 * `voidHandler` makes that discard explicit and keeps the argument types, so
 * the call site reads as a deliberate fire-and-forget rather than an oversight.
 * Failures stay exactly where they were — reported by the handler itself
 * (toast, store `error` field) or, failing that, as an unhandled rejection.
 * Use `await`/`.catch` instead wherever the caller can actually act on failure.
 *
 * Which form to use:
 *
 *   onClick={voidHandler(handleSave)}            // passing the function itself
 *   onClick={() => { void step("undo"); }}       // binding arguments here
 *
 * Reach for `voidHandler` when a function reference goes straight into the
 * slot — it keeps the slot's own arguments (React hands `onSubmit` its event)
 * instead of dropping them, which a bare `() => { void fn(); }` would. When the
 * call needs arguments from this scope there is nothing to adapt, so the inline
 * arrow is the shorter and clearer form; wrapping it as
 * `voidHandler(() => step("undo"))` only adds a layer.
 */
/**
 * `voidHandler` with a stable identity across renders.
 *
 * `voidHandler(fn)` returns a NEW function every call, so passing it inline to
 * a child prop makes that prop change on every parent render. When the child
 * lists the prop in an effect's dependencies that is a real defect, not just a
 * wasted render: `ScreenshotSelector` debounces search by 300ms in an effect
 * keyed on `[searchTerm, onSearch]`, so a per-render `onSearch` tore the timer
 * down before it could fire and, during a burst of parent renders, the search
 * never ran at all. Use this hook for anything handed to a component; a plain
 * `voidHandler` is fine on a DOM event prop, where identity does not matter.
 */
export function useVoidHandler<A extends unknown[]>(
  fn: (...args: A) => Promise<unknown>,
): (...args: A) => void {
  return useMemo(() => voidHandler(fn), [fn]);
}

export function voidHandler<A extends unknown[]>(
  fn: (...args: A) => Promise<unknown>,
): (...args: A) => void {
  return (...args: A): void => {
    void fn(...args);
  };
}
