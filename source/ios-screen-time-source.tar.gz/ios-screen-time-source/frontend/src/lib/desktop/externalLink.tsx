/**
 * A link that leaves the app. The desktop webview cannot open new windows, so
 * there it hands the URL to the system browser through plugin-opener, whose
 * capability only allows the desktop repo's URLs. The import is dynamic so the
 * Pages build never loads it.
 */
import type { ReactNode } from "react";
import { config } from "@/config";

export function ExternalLink({ href, children }: { href: string; children: ReactNode }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="text-eq-primary hover:underline focus-ring rounded-sm"
      onClick={(e) => {
        if (!config.isTauri) return;
        e.preventDefault();
        void import("@tauri-apps/plugin-opener")
          .then(({ openUrl }) => openUrl(href))
          .catch((err: unknown) => console.error("[ExternalLink] could not open", href, err));
      }}
    >
      {children}
    </a>
  );
}
