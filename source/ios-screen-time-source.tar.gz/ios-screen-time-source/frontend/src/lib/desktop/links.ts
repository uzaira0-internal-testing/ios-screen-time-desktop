/** Releases of the desktop app; each carries its installers and its source archive. */
export const DESKTOP_RELEASES_URL = "https://github.com/uzaira0-internal-testing/ios-screen-time-desktop/releases";
