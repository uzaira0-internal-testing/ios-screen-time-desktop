/**
 * Screenshot folders chosen in the desktop app's Open dialog or dropped on its
 * window. The app is given file-system paths, not browser `File`s, so a folder
 * is listed up front and each image is read only when the import reaches it.
 * All imports from @tauri-apps/* are dynamic to avoid breaking web/WASM builds.
 */

/** An image on disk, read into a `File` by {@link loadNativeFile}. */
export interface NativeFileRef {
  readonly kind: "native";
  readonly path: string;
  readonly name: string;
  /** Path below the chosen folder, starting with its name, `/`-separated. */
  readonly webkitRelativePath: string;
}

export type ImportCandidate = File | NativeFileRef;

export const isNativeFileRef = (c: ImportCandidate): c is NativeFileRef =>
  !(c instanceof File) && c.kind === "native";

const MIME_BY_EXTENSION: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  webp: "image/webp",
};

const extensionOf = (name: string) => {
  const dot = name.lastIndexOf(".");
  return dot < 0 ? "" : name.slice(dot + 1).toLowerCase();
};

/** The same extensions `isImageFile` accepts for browser files. */
export const isImageName = (name: string) => !name.startsWith(".") && extensionOf(name) in MIME_BY_EXTENSION;

const baseName = (path: string) => path.split(/[\\/]/).filter(Boolean).pop() ?? path;

/** Reads the image into a `File` that `parseRelativePath` treats like a browser pick. */
export async function loadNativeFile(ref: NativeFileRef): Promise<File> {
  const { readFile } = await import("@tauri-apps/plugin-fs");
  const bytes = await readFile(ref.path);
  const file = new File([bytes], ref.name, { type: MIME_BY_EXTENSION[extensionOf(ref.name)] ?? "" });
  Object.defineProperty(file, "webkitRelativePath", { value: ref.webkitRelativePath, configurable: true });
  return file;
}

const LAST_FOLDER_KEY = "desktop-last-import-folder";

/** The folder holding `path`, or `undefined` at a filesystem root. */
export const parentFolder = (path: string): string | undefined => {
  const trimmed = path.replace(/[\\/]+$/, "");
  const cut = Math.max(trimmed.lastIndexOf("/"), trimmed.lastIndexOf("\\"));
  if (cut < 0) return undefined;
  const parent = cut === 0 ? trimmed.slice(0, 1) : trimmed.slice(0, cut);
  // A Windows drive needs its separator to name the drive's root folder.
  return /^[A-Za-z]:$/.test(parent) ? `${parent}\\` : parent;
};

/**
 * The system folder picker, opened beside the last folder chosen so the next
 * study folder is one click away (GTK would otherwise start in Recent, where
 * a folder cannot be chosen at all). `null` if cancelled.
 */
export async function pickNativeFolder(): Promise<string | null> {
  const { open } = await import("@tauri-apps/plugin-dialog");
  let last: string | null = null;
  try {
    last = localStorage.getItem(LAST_FOLDER_KEY);
  } catch {
    /* localStorage unavailable: start wherever the system dialog starts */
  }
  const defaultPath = last ? parentFolder(last) : undefined;
  const picked = await open({
    directory: true,
    recursive: true,
    title: "Choose a Screenshot Folder",
    ...(defaultPath && { defaultPath }),
  });
  if (typeof picked !== "string") return null;
  try {
    localStorage.setItem(LAST_FOLDER_KEY, picked);
  } catch {
    /* localStorage unavailable: the next pick starts from the default */
  }
  return picked;
}

export interface ScanProgress {
  filesSeen: number;
  imageFiles: number;
  foldersSeen: number;
  currentPath: string;
}

/**
 * Lists the images under `paths`: folders are walked, files are taken as they
 * are. Hidden entries and symlinks are skipped, the latter so a link loop
 * cannot walk forever. Relative paths start at each dropped item's own name,
 * as a browser folder pick does.
 */
export async function collectNativeImages(
  paths: readonly string[],
  onProgress?: (p: ScanProgress) => void,
  signal?: AbortSignal,
): Promise<NativeFileRef[]> {
  const { readDir, stat } = await import("@tauri-apps/plugin-fs");
  const { sep } = await import("@tauri-apps/api/path");
  const separator = sep();
  const found: NativeFileRef[] = [];
  const progress: ScanProgress = { filesSeen: 0, imageFiles: 0, foldersSeen: 0, currentPath: "" };

  const addFile = (path: string, name: string, relative: string) => {
    progress.filesSeen++;
    if (!isImageName(name)) return;
    progress.imageFiles++;
    found.push({ kind: "native", path, name, webkitRelativePath: relative });
  };

  for (const root of paths) {
    const rootName = baseName(root);
    // eslint-disable-next-line no-await-in-loop -- one dropped item at a time keeps the scan's file-system load bounded
    const info = await stat(root);
    if (info.isFile) {
      addFile(root, rootName, rootName);
      continue;
    }
    if (!info.isDirectory) continue;
    // Depth-first with an explicit stack: deep study trees cannot overflow it.
    const stack: { path: string; relative: string }[] = [{ path: root, relative: rootName }];
    while (stack.length > 0) {
      if (signal?.aborted) throw new DOMException("Folder scan cancelled", "AbortError");
      const dir = stack.pop()!;
      progress.foldersSeen++;
      progress.currentPath = dir.relative;
      onProgress?.({ ...progress });
      // eslint-disable-next-line no-await-in-loop -- one folder at a time keeps the scan's file-system load bounded
      const entries = await readDir(dir.path);
      // Sorted so files import in the order a file browser shows them.
      entries.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
      const subfolders: { path: string; relative: string }[] = [];
      for (const entry of entries) {
        if (entry.isSymlink || entry.name.startsWith(".")) continue;
        const path = `${dir.path}${separator}${entry.name}`;
        const relative = `${dir.relative}/${entry.name}`;
        if (entry.isDirectory) subfolders.push({ path, relative });
        else if (entry.isFile) addFile(path, entry.name, relative);
      }
      // Reversed onto the stack so the subfolders are visited A→Z.
      stack.push(...subfolders.reverse());
    }
  }
  onProgress?.({ ...progress });
  return found;
}
