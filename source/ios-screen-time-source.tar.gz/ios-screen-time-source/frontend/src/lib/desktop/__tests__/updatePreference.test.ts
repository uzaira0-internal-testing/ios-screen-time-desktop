import { afterAll, describe, expect, test } from "bun:test";

const store = new Map<string, string>([["desktop-auto-update-check", "off"]]);
let failWrites = false;
const saved = (globalThis as { localStorage?: unknown }).localStorage;
(globalThis as { localStorage?: unknown }).localStorage = {
  getItem: (k: string) => store.get(k) ?? null,
  setItem: (k: string, v: string) => {
    if (failWrites) throw new DOMException("quota", "QuotaExceededError");
    store.set(k, v);
  },
};
afterAll(() => {
  (globalThis as { localStorage?: unknown }).localStorage = saved;
});

const { useAutoUpdateCheck, AUTO_UPDATE_CHECK_KEY } = await import("../updatePreference");

describe("automatic update check preference", () => {
  test("a stored 'off' is read at startup", () => {
    expect(useAutoUpdateCheck.getState().enabled).toBe(false);
  });

  test("turning it back on is stored for the next launch", () => {
    useAutoUpdateCheck.getState().setEnabled(true);
    expect(useAutoUpdateCheck.getState().enabled).toBe(true);
    expect(store.get(AUTO_UPDATE_CHECK_KEY)).toBe("on");
  });

  test("a failed write still applies the choice for this session", () => {
    failWrites = true;
    useAutoUpdateCheck.getState().setEnabled(false);
    failWrites = false;
    expect(useAutoUpdateCheck.getState().enabled).toBe(false);
    expect(store.get(AUTO_UPDATE_CHECK_KEY)).toBe("on");
  });
});
