/**
 * One set of @tauri-apps module mocks for every desktop test. Bun runs all
 * test files in one process, so two files mocking the same module would
 * replace each other's mock; each test sets the parts of `tauri` it uses.
 */
import { mock } from "bun:test";

export type Entry = { name: string; isDirectory: boolean; isFile: boolean; isSymlink: boolean };

export const tauri = {
  tree: {} as Record<string, Entry[]>,
  readDirCalls: [] as string[],
  fileBytes: new Uint8Array(),
  savePath: null as string | null,
  saveOptions: [] as unknown[],
  writeFile: (async () => {
    throw new Error("writeFile not set");
  }) as (path: string, data: Uint8Array, options?: { append?: boolean }) => Promise<void>,
  /** Close-request handlers currently registered on the window. */
  closeHandlers: new Set<(event: { preventDefault(): void }) => Promise<void> | void>(),
  maxCloseHandlers: 0,
  askAnswer: true,
  openResult: null as string | null,
  openOptions: [] as unknown[],
  asked: [] as string[],
  destroyed: 0,
};

void mock.module("@tauri-apps/plugin-fs", () => ({
  stat: async (path: string) => ({ isFile: !(path in tauri.tree), isDirectory: path in tauri.tree }),
  readDir: async (path: string) => {
    tauri.readDirCalls.push(path);
    return tauri.tree[path] ?? [];
  },
  readFile: async () => tauri.fileBytes,
  writeFile: async (path: string, data: Uint8Array, options?: { append?: boolean }) =>
    tauri.writeFile(path, data, options),
}));

void mock.module("@tauri-apps/plugin-dialog", () => ({
  ask: async (message: string) => {
    tauri.asked.push(message);
    return tauri.askAnswer;
  },
  open: async (options: unknown) => {
    tauri.openOptions.push(options);
    return tauri.openResult;
  },
  save: async (options: unknown) => {
    tauri.saveOptions.push(options);
    return tauri.savePath;
  },
}));

void mock.module("@tauri-apps/api/path", () => ({ sep: () => "/" }));

void mock.module("@tauri-apps/api/window", () => ({
  getCurrentWindow: () => ({
    onCloseRequested: async (handler: (event: { preventDefault(): void }) => Promise<void> | void) => {
      tauri.closeHandlers.add(handler);
      tauri.maxCloseHandlers = Math.max(tauri.maxCloseHandlers, tauri.closeHandlers.size);
      return () => tauri.closeHandlers.delete(handler);
    },
    destroy: async () => {
      tauri.destroyed++;
    },
  }),
}));

/** Fires a close request the way @tauri-apps/api does: the window is destroyed unless a handler prevents it. */
export async function requestClose(): Promise<{ closed: boolean }> {
  let prevented = false;
  const event = {
    preventDefault: () => {
      prevented = true;
    },
  };
  let closed = false;
  for (const handler of [...tauri.closeHandlers]) {
    // eslint-disable-next-line no-await-in-loop -- @tauri-apps/api runs each handler to completion before deciding
    await handler(event);
    if (!prevented) closed = true;
  }
  if (tauri.closeHandlers.size === 0) closed = true;
  return { closed };
}
