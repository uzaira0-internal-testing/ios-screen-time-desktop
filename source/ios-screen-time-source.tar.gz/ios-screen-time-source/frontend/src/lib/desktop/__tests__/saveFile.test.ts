import { beforeEach, describe, expect, test } from "bun:test";
import { tauri } from "./tauriMocks";

const writes: { path: string; bytes: number; append: boolean }[] = [];
let failWriteAt: number | null = null;

tauri.writeFile = async (path, data, options) => {
  if (failWriteAt !== null && writes.length === failWriteAt) throw new Error("disk full");
  writes.push({ path, bytes: data.byteLength, append: options?.append ?? false });
};

const { saveNative, savedMessage } = await import("../saveFile");

beforeEach(() => {
  tauri.saveOptions = [];
  tauri.savePath = "/exports/annotations.csv";
  writes.length = 0;
  failWriteAt = null;
});

describe("saveNative", () => {
  test("asks where to save, then writes the file in 8 MB pieces", async () => {
    const MB = 1024 * 1024;
    const blob = new Blob([new Uint8Array(20 * MB)]);

    const saved = await saveNative(blob, "annotations.csv", { name: "CSV", extensions: ["csv"] });

    expect(saved).toBe("/exports/annotations.csv");
    expect(tauri.saveOptions).toEqual([
      { defaultPath: "annotations.csv", filters: [{ name: "CSV", extensions: ["csv"] }] },
    ]);
    // The first piece replaces the file, so saving over a longer one leaves
    // none of its old tail; the rest are appended.
    expect(writes).toEqual([
      { path: "/exports/annotations.csv", bytes: 8 * MB, append: false },
      { path: "/exports/annotations.csv", bytes: 8 * MB, append: true },
      { path: "/exports/annotations.csv", bytes: 4 * MB, append: true },
    ]);
  });

  test("derives the file-type filter from the name when none is given", async () => {
    await saveNative(new Blob(["{}"]), "event-log-7.json");
    expect(tauri.saveOptions).toEqual([
      { defaultPath: "event-log-7.json", filters: [{ name: "JSON", extensions: ["json"] }] },
    ]);
  });

  test("writes nothing when the dialog is cancelled", async () => {
    tauri.savePath = null;
    expect(await saveNative(new Blob(["a,b"]), "annotations.csv")).toBeNull();
    expect(writes).toEqual([]);
  });

  test("stops at the first failed write and reports it", async () => {
    failWriteAt = 1;
    const blob = new Blob([new Uint8Array(20 * 1024 * 1024)]);
    await expect(saveNative(blob, "workspace.zip")).rejects.toThrow("disk full");
    expect(writes).toHaveLength(1);
  });

  test("an empty export still creates the file", async () => {
    expect(await saveNative(new Blob([]), "annotations.csv")).toBe("/exports/annotations.csv");
    expect(writes).toEqual([{ path: "/exports/annotations.csv", bytes: 0, append: false }]);
  });
});

describe("savedMessage", () => {
  test("names only the file, on any platform", () => {
    expect(savedMessage("/Users/a/Desktop/annotations.csv")).toBe("Saved annotations.csv");
    expect(savedMessage("C:\\Users\\a\\Desktop\\annotations.csv")).toBe("Saved annotations.csv");
  });
});
