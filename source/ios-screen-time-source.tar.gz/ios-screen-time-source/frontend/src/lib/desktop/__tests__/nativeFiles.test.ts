import { describe, expect, test } from "bun:test";
import { tauri, type Entry } from "./tauriMocks";

const dir = (name: string): Entry => ({ name, isDirectory: true, isFile: false, isSymlink: false });
const file = (name: string): Entry => ({ name, isDirectory: false, isFile: true, isSymlink: false });
const link = (name: string): Entry => ({ name, isDirectory: true, isFile: false, isSymlink: true });

// A study folder as a researcher would drop it, with the clutter a real one has.
tauri.tree = {
  "/data/STUDY01": [dir("P017"), dir("P002"), file(".DS_Store"), file("README.txt"), dir(".thumbnails"), link("latest")],
  "/data/STUDY01/P002": [file("10.png"), file("9.png")],
  "/data/STUDY01/P017": [dir("2024-03-15"), file("notes.docx")],
  "/data/STUDY01/P017/2024-03-15": [file("0830.PNG"), file("0900.jpeg"), file("._0830.PNG")],
  "/data/STUDY01/.thumbnails": [file("x.png")],
};
tauri.fileBytes = new Uint8Array([0x89, 0x50, 0x4e, 0x47]);

const { collectNativeImages, isImageName, isNativeFileRef, loadNativeFile, parentFolder, pickNativeFolder } =
  await import("../nativeFiles");
const { parseRelativePath } = await import("@/utils/filePathParser");

describe("collectNativeImages", () => {
  test("walks a dropped folder into images with browser-style relative paths", async () => {
    const found = await collectNativeImages(["/data/STUDY01"]);
    expect(found.map((f) => f.webkitRelativePath)).toEqual([
      "STUDY01/P002/9.png",
      "STUDY01/P002/10.png",
      "STUDY01/P017/2024-03-15/0830.PNG",
      "STUDY01/P017/2024-03-15/0900.jpeg",
    ]);
    expect(found[2]).toEqual({
      kind: "native",
      path: "/data/STUDY01/P017/2024-03-15/0830.PNG",
      name: "0830.PNG",
      webkitRelativePath: "STUDY01/P017/2024-03-15/0830.PNG",
    });
  });

  test("never enters hidden folders or follows symlinks", async () => {
    tauri.readDirCalls = [];
    await collectNativeImages(["/data/STUDY01"]);
    expect(tauri.readDirCalls).not.toContain("/data/STUDY01/.thumbnails");
    expect(tauri.readDirCalls).not.toContain("/data/STUDY01/latest");
  });

  test("takes dropped files as they are, named by themselves", async () => {
    const found = await collectNativeImages(["/Users/a/Desktop/shot.webp", "/Users/a/Desktop/notes.txt"]);
    expect(found.map((f) => [f.path, f.webkitRelativePath])).toEqual([["/Users/a/Desktop/shot.webp", "shot.webp"]]);
  });

  test("reports what it has seen", async () => {
    const seen: number[][] = [];
    await collectNativeImages(["/data/STUDY01"], (p) => seen.push([p.foldersSeen, p.filesSeen, p.imageFiles]));
    // Hidden files (.DS_Store, ._0830.PNG) are skipped before counting; README and notes are not images.
    expect(seen.at(-1)).toEqual([4, 6, 4]);
  });

  test("stops when cancelled", async () => {
    const abort = new AbortController();
    abort.abort();
    await expect(collectNativeImages(["/data/STUDY01"], undefined, abort.signal)).rejects.toThrow("cancelled");
  });
});

describe("loadNativeFile", () => {
  test("reads a file that parses like a browser folder pick", async () => {
    const [ref] = await collectNativeImages(["/data/STUDY01/P017/2024-03-15"]);
    const loaded = await loadNativeFile(ref!);
    expect(loaded.name).toBe("0830.PNG");
    expect(loaded.type).toBe("image/png");
    expect(loaded.size).toBe(4);
    expect(loaded.webkitRelativePath).toBe("2024-03-15/0830.PNG");

    const parsed = parseRelativePath(
      await loadNativeFile({ ...ref!, webkitRelativePath: "STUDY01/P017/2024-03-15/0830.PNG" }),
    );
    expect(parsed.participant_id).toBe("P017");
    expect(parsed.screenshot_date).toBe("2024-03-15");
  });
});

describe("helpers", () => {
  test("isImageName matches the browser's accepted types and skips hidden files", () => {
    expect(["a.png", "b.JPG", "c.jpeg", "d.webp"].every(isImageName)).toBe(true);
    expect(["a.heic", "b.txt", ".png", "._a.png", "png"].some(isImageName)).toBe(false);
  });

  test("isNativeFileRef tells paths from browser files", () => {
    expect(isNativeFileRef(new File([], "a.png"))).toBe(false);
    expect(isNativeFileRef({ kind: "native", path: "/a.png", name: "a.png", webkitRelativePath: "a.png" })).toBe(true);
  });
});

describe("pickNativeFolder", () => {
  test("opens beside the last folder chosen and remembers the new one", async () => {
    const store = new Map<string, string>();
    const saved = (globalThis as { localStorage?: unknown }).localStorage;
    (globalThis as { localStorage?: unknown }).localStorage = {
      getItem: (k: string) => store.get(k) ?? null,
      setItem: (k: string, v: string) => void store.set(k, v),
    };
    try {
      tauri.openOptions = [];
      tauri.openResult = "/data/STUDY01";
      expect(await pickNativeFolder()).toBe("/data/STUDY01");
      expect(tauri.openOptions[0]).toEqual({ directory: true, recursive: true, title: "Choose a Screenshot Folder" });

      tauri.openResult = null;
      expect(await pickNativeFolder()).toBeNull();
      expect(tauri.openOptions[1]).toMatchObject({ defaultPath: "/data" });
      expect(store.get("desktop-last-import-folder")).toBe("/data/STUDY01");
    } finally {
      (globalThis as { localStorage?: unknown }).localStorage = saved;
    }
  });

  test("parentFolder handles both separators and roots", () => {
    expect(parentFolder("/data/STUDY01")).toBe("/data");
    expect(parentFolder("/data/STUDY01/")).toBe("/data");
    expect(parentFolder("/data")).toBe("/");
    expect(parentFolder("C:\\Users\\a\\Study")).toBe("C:\\Users\\a");
    expect(parentFolder("C:\\Study")).toBe("C:\\");
    expect(parentFolder("Study")).toBeUndefined();
  });
});
