import { beforeEach, describe, expect, test } from "bun:test";
import { requestClose, tauri } from "./tauriMocks";

const { holdWindowOpen, settled } = await import("../leaveGuard");

beforeEach(async () => {
  await settled();
  tauri.maxCloseHandlers = tauri.closeHandlers.size;
  tauri.askAnswer = true;
  tauri.asked = [];
  tauri.destroyed = 0;
});

describe("holdWindowOpen", () => {
  test("listens for close only while something is held", async () => {
    expect(tauri.closeHandlers.size).toBe(0);
    const releaseA = holdWindowOpen("Preprocessing is still running.");
    const releaseB = holdWindowOpen("This screenshot has unsaved changes.");
    await settled();
    expect(tauri.closeHandlers.size).toBe(1);
    releaseA();
    await settled();
    expect(tauri.closeHandlers.size).toBe(1);
    releaseB();
    await settled();
    expect(tauri.closeHandlers.size).toBe(0);
  });

  test("a release followed at once by a new hold never leaves two listeners", async () => {
    for (let i = 0; i < 5; i++) {
      const release = holdWindowOpen("busy");
      release();
    }
    const release = holdWindowOpen("busy");
    await settled();
    expect(tauri.maxCloseHandlers).toBe(1);
    expect(tauri.closeHandlers.size).toBe(1);
    release();
    await settled();
    expect(tauri.closeHandlers.size).toBe(0);
  });

  test("asks with the newest message, and stays open when the user keeps working", async () => {
    const releaseA = holdWindowOpen("first");
    const releaseB = holdWindowOpen("second");
    await settled();
    tauri.askAnswer = false;
    expect(await requestClose()).toEqual({ closed: false });
    expect(tauri.asked).toEqual(["second"]);
    expect(tauri.destroyed).toBe(0);
    releaseA();
    releaseB();
    await settled();
  });

  test("closes the window when the user confirms", async () => {
    const release = holdWindowOpen("busy");
    await settled();
    tauri.askAnswer = true;
    await requestClose();
    expect(tauri.destroyed).toBe(1);
    release();
    await settled();
  });

  test("closes without asking once nothing is held", async () => {
    const release = holdWindowOpen("busy");
    await settled();
    release();
    await settled();
    expect(await requestClose()).toEqual({ closed: true });
    expect(tauri.asked).toEqual([]);
  });
});
