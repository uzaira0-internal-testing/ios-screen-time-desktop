/**
 * Long-running work in the desktop app reports through the OS as well as the
 * page: progress on the Dock / taskbar icon, and a notification plus a bounce
 * or flash when it finishes while the window is in the background.
 * No-ops in the browser. All imports from @tauri-apps/* are dynamic to avoid
 * breaking web/WASM builds.
 */
import { useEffect, useRef } from "react";
import { config } from "@/config";

/** Mirrors `fraction` (0–1) on the app icon; `null` clears it. */
export function useTaskbarProgress(fraction: number | null): void {
  const percent = fraction === null ? null : Math.max(0, Math.min(100, Math.round(fraction * 100)));
  useEffect(() => {
    if (!config.isTauri) return;
    void (async () => {
      const { getCurrentWindow, ProgressBarStatus } = await import("@tauri-apps/api/window");
      await getCurrentWindow().setProgressBar(
        percent === null ? { status: ProgressBarStatus.None } : { status: ProgressBarStatus.Normal, progress: percent },
      );
    })().catch(() => {
      /* non-fatal: the page shows its own progress bar */
    });
  }, [percent]);
  useEffect(
    () => () => {
      if (!config.isTauri) return;
      void import("@tauri-apps/api/window")
        .then(({ getCurrentWindow, ProgressBarStatus }) => getCurrentWindow().setProgressBar({ status: ProgressBarStatus.None }))
        .catch(() => {
          /* non-fatal: the page shows its own progress bar */
        });
    },
    [],
  );
}

/**
 * Asks for notification permission once, at a moment the user just started
 * something long, so the prompt is not sprung on them later.
 */
export async function prepareNotifications(): Promise<void> {
  if (!config.isTauri) return;
  const { isPermissionGranted, requestPermission } = await import("@tauri-apps/plugin-notification");
  if (!(await isPermissionGranted())) await requestPermission();
}

/** Notifies and asks for attention, but only if the window is not in front. */
export async function notifyIfInBackground(title: string, body: string): Promise<void> {
  if (!config.isTauri) return;
  const { getCurrentWindow, UserAttentionType } = await import("@tauri-apps/api/window");
  const win = getCurrentWindow();
  if (await win.isFocused()) return;
  await win.requestUserAttention(UserAttentionType.Informational);
  const { isPermissionGranted, sendNotification } = await import("@tauri-apps/plugin-notification");
  if (await isPermissionGranted()) sendNotification({ title, body });
}

/**
 * Notifies when `running` has been false for `settleMs` after being true, so
 * a pipeline that runs several stages back to back notifies once at the end.
 */
export function useNotifyWhenDone(running: boolean, title: string, body: string, settleMs = 1500): void {
  const wasRunning = useRef(false);
  useEffect(() => {
    if (running) {
      if (!wasRunning.current) {
        void prepareNotifications().catch(() => {
          /* non-fatal: without permission the batch simply finishes silently */
        });
      }
      wasRunning.current = true;
      return;
    }
    if (!wasRunning.current) return;
    const timer = setTimeout(() => {
      wasRunning.current = false;
      void notifyIfInBackground(title, body).catch(() => {
        /* non-fatal: the in-page toast already reported the result */
      });
    }, settleMs);
    return () => clearTimeout(timer);
  }, [running, title, body, settleMs]);
}
