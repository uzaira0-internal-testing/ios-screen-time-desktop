/**
 * Whether the desktop app looks for updates on its own (at launch, every 15
 * minutes, and on refocus). Kept out of the processing settings so a workspace
 * import from another machine does not switch it. Check for Updates… in the
 * app menu works either way.
 */
import { create } from "zustand";

export const AUTO_UPDATE_CHECK_KEY = "desktop-auto-update-check";

function load(): boolean {
  try {
    return localStorage.getItem(AUTO_UPDATE_CHECK_KEY) !== "off";
  } catch {
    return true;
  }
}

interface AutoUpdateCheckState {
  enabled: boolean;
  setEnabled: (enabled: boolean) => void;
}

export const useAutoUpdateCheck = create<AutoUpdateCheckState>((set) => ({
  enabled: load(),
  setEnabled: (enabled) => {
    try {
      localStorage.setItem(AUTO_UPDATE_CHECK_KEY, enabled ? "on" : "off");
    } catch {
      /* non-fatal: the choice still applies until the app quits */
    }
    set({ enabled });
  },
}));
