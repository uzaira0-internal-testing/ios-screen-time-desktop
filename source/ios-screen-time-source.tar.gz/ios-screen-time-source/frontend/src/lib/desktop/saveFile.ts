/**
 * Save a generated file (CSV, JSON, workspace ZIP).
 *
 * The desktop app asks where to save with the system Save dialog and writes the
 * file itself; a webview download would land silently in Downloads, or nowhere.
 * The browser build keeps the ordinary download.
 * All imports from @tauri-apps/* are dynamic to avoid breaking web/WASM builds.
 */
import { config } from "@/config";

/** Written in pieces so a large workspace ZIP never crosses IPC in one message. */
const WRITE_CHUNK_BYTES = 8 * 1024 * 1024;

/** How long the browser keeps the download URL alive before it is released. */
const REVOKE_AFTER_MS = 60_000;

export interface SaveFilter {
  name: string;
  extensions: string[];
}

/**
 * Saves `blob` as `filename`. Resolves to where it went: the full path on the
 * desktop, the file name in the browser, or `null` if the user cancelled.
 */
export async function saveBlob(blob: Blob, filename: string, filter?: SaveFilter): Promise<string | null> {
  if (config.isTauri) return saveNative(blob, filename, filter);
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  // The browser reads the blob after this tick; a large one can still be
  // streaming to disk seconds later, so the URL outlives the click.
  setTimeout(() => URL.revokeObjectURL(url), REVOKE_AFTER_MS);
  return filename;
}

/** The desktop half of {@link saveBlob}: Save dialog, then a chunked write. */
export async function saveNative(blob: Blob, filename: string, filter?: SaveFilter): Promise<string | null> {
  const { save } = await import("@tauri-apps/plugin-dialog");
  const ext = filename.includes(".") ? filename.slice(filename.lastIndexOf(".") + 1) : "";
  const filters = filter ? [filter] : ext ? [{ name: ext.toUpperCase(), extensions: [ext] }] : undefined;
  const path = await save({ defaultPath: filename, ...(filters && { filters }) });
  if (!path) return null;

  // writeFile sends the bytes as-is and writes all of them; the first piece
  // replaces any existing file and the rest are appended.
  const { writeFile } = await import("@tauri-apps/plugin-fs");
  let offset = 0;
  do {
    // eslint-disable-next-line no-await-in-loop -- pieces are written in order, one in memory at a time
    const piece = new Uint8Array(await blob.slice(offset, offset + WRITE_CHUNK_BYTES).arrayBuffer());
    // eslint-disable-next-line no-await-in-loop -- see above
    await writeFile(path, piece, { append: offset > 0 });
    offset += WRITE_CHUNK_BYTES;
  } while (offset < blob.size);
  return path;
}

/** "Saved to <file name>" for a toast, with only the last path segment. */
export function savedMessage(path: string): string {
  return `Saved ${path.split(/[\\/]/).pop() ?? path}`;
}
