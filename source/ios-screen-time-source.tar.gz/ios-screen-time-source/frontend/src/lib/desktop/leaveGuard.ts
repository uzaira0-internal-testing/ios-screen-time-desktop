/**
 * Asks before the page is left while work would be lost.
 *
 * In the browser that is `beforeunload`. A desktop window closes without ever
 * firing it, so the desktop app also holds the window open and asks with a
 * native dialog. The window is held only while a guard is active: if the page
 * hangs otherwise, closing still works.
 * All imports from @tauri-apps/* are dynamic to avoid breaking web/WASM builds.
 */
import { useEffect } from "react";
import { config } from "@/config";

const active = new Map<symbol, string>();
let asking = false;
// A plain setter keeps the write out of the async handler, which eslint's
// require-atomic-updates would otherwise flag; the handler runs on one thread.
const setAsking = (value: boolean) => {
  asking = value;
};
// Listener changes run one after another, so there is never more than one: a
// second listener that found nothing to guard would close the window while the
// first was still asking.
let listener: Promise<(() => void) | null> = Promise.resolve(null);

async function listen(): Promise<() => void> {
  const { getCurrentWindow } = await import("@tauri-apps/api/window");
  const { ask } = await import("@tauri-apps/plugin-dialog");
  return getCurrentWindow().onCloseRequested(async (event) => {
    const message = [...active.values()].at(-1);
    if (!message) return;
    event.preventDefault();
    if (asking) return;
    setAsking(true);
    try {
      const close = await ask(message, {
        title: "Quit while work is in progress?",
        kind: "warning",
        okLabel: "Quit",
        cancelLabel: "Keep Working",
      });
      if (close) await getCurrentWindow().destroy();
    } finally {
      setAsking(false);
    }
  });
}

function syncListener(): Promise<unknown> {
  listener = listener
    .then(async (unlisten) => {
      if (active.size > 0) return unlisten ?? (await listen());
      unlisten?.();
      return null;
    })
    .catch(() => {
      /* non-fatal: with no listener the window just closes without asking */
      return null;
    });
  return listener;
}

/** Holds the desktop window open, asking with `message`, until the returned release is called. */
export function holdWindowOpen(message: string): () => void {
  const key = Symbol(message);
  active.set(key, message);
  void syncListener();
  return () => {
    active.delete(key);
    void syncListener();
  };
}

/** Resolves once listener changes requested so far have been applied. */
export const settled = (): Promise<unknown> => listener;

/** While `when` is true, closing the window or tab asks first with `message`. */
export function useLeaveGuard(when: boolean, message: string): void {
  useEffect(() => {
    if (!when) return;
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
      return "";
    };
    window.addEventListener("beforeunload", onBeforeUnload);
    const release = config.isTauri ? holdWindowOpen(message) : undefined;
    return () => {
      window.removeEventListener("beforeunload", onBeforeUnload);
      release?.();
    };
  }, [when, message]);
}
