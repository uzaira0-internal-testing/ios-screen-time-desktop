/**
 * Wipe ALL local app data for the WASM-offline build.
 *
 * This is the "lifeboat" reset: it clears every place the offline app stores
 * state so a wedged instance (corrupt migration, quota-exhausted write, or a
 * dataset too large to boot on a weak machine) can recover to a clean first
 * run. It is DESTRUCTIVE and irreversible — callers must confirm with the user
 * and should offer a Workspace export first when the app is still reachable.
 *
 * Used by BOTH the Settings "Delete all local data" control and the
 * boot-error screen's recovery button, so the reset is identical whether the
 * app loaded or failed to start.
 *
 * Every step is best-effort and isolated: a failure in one (e.g. OPFS absent)
 * must not prevent the others from running, because the whole point is to get
 * back to a bootable state. Does NOT reload — the caller decides when to
 * reload so it can sequence UI (busy state, redirect) around the wipe.
 */
import { config } from "@/config";
import { forEachBoundedBestEffort } from "./browserMaintenance";

export async function wipeAllLocalData(): Promise<void> {
  // 1) The screenshot database and the language-pack fallback database.
  try {
    await forEachBoundedBestEffort(["ScreenshotProcessorDB", "language-packs"], (name) =>
      new Promise<void>((resolve) => {
        const req = indexedDB.deleteDatabase(name);
        req.onsuccess = () => resolve();
        req.onerror = () => resolve();
        req.onblocked = () => resolve();
      }));
  } catch { /* IndexedDB may be unavailable */ }

  // 2) Owned blob, language-pack, and migration-backup directories.
  try {
    const root = await navigator.storage.getDirectory();
    for (const name of ["screenshots", "language-packs", "db-backups"]) {
      // eslint-disable-next-line no-await-in-loop -- remove directories sequentially to bound cleanup
      await root.removeEntry(name, { recursive: true }).catch(() => { /* best-effort: the directory may not exist */ });
    }
  } catch { /* OPFS may be unavailable */ }

  // 3) Caches (service-worker precache + runtime caches).
  try {
    const keys = await caches.keys();
    await forEachBoundedBestEffort(keys.filter((key) => /^(shell|app|pipeline|runtime|share)-v2-/.test(key) || key === "transformers-cache"), async (k) => {
      await caches.delete(k);
    });
  } catch {
    // ignore
  }

  // 4) Local + session storage (theme/scoring prefs, dismissal flags, etc.).
  try {
    const ownedKeys = [
      "processing-settings", "theme", "username", "userId", "userRole", "sitePassword",
      "scorerId", "participant-id-regex", "annotate-last-params", "annotate-display-mode",
      "annotate-verification-filter", "annotation-help-dismissed", "shortcuts-hint-dismissed",
      "app-tour-seen-v1", "gridLockEnabled", "lastGridPosition", "unsaved-annotations",
      "crop-recent-configs", "phi-recent-labels", "phi-recent-redaction-method",
      "pp-filter", "pp-sort-col", "pp-sort-dir", "ocr.languagePacks.enabled",
      "wasm_workspace_import_in_progress", "desktop-last-import-folder", "desktop-auto-update-check",
      ...["annotation-filters", "annotation-tools", "annotation-view-mode", "annotation-reprocess", "annotation-notes"].map((key) => `collapsible:${key}`),
    ];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key?.startsWith("ios-screen-time:ocr-worker-memory-mb:")) ownedKeys.push(key);
    }
    for (const key of ownedKeys) localStorage.removeItem(key);
  } catch {
    // ignore
  }

  try {
    for (const key of ["wasm-abi-skew-recovered", "sw-last-auto-reload", "chunk-reload-at", "storagePressureDismissed"]) sessionStorage.removeItem(key);
  } catch { /* session storage may be unavailable */ }

  // 5) Unregister the service worker so the next visit starts from the network.
  try {
    const regs = await navigator.serviceWorker?.getRegistrations?.();
    if (regs) {
      const scope = new URL(`${config.basePath.replace(/\/$/, "")}/`, window.location.origin).href;
      await forEachBoundedBestEffort(regs.filter((registration) => registration.scope === scope), async (r) => {
        await r.unregister();
      });
    }
  } catch {
    // ignore
  }
}
