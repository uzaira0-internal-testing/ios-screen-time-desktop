/**
 * Service worker registration and update lifecycle.
 *
 * Only registers in browser (non-Tauri) environments.
 * Dispatches a custom 'sw-update-available' event when a new version is ready
 * so the UI can prompt the user to reload.
 */

export type SWUpdateCallback = () => void;

let updateCallback: SWUpdateCallback | null = null;
let updateFired = false;

export function onSWUpdate(cb: SWUpdateCallback) {
  updateCallback = cb;
}

function fireUpdate() {
  if (updateFired) return;
  updateFired = true;
  // Loop guard: never auto-reload twice in quick succession. The DevTools
  // "Update on reload" option reinstalls the SW on every reload, which would
  // otherwise feed back through controllerchange -> reload -> reinstall -> loop.
  try {
    const KEY = 'sw-last-auto-reload';
    const last = Number(sessionStorage.getItem(KEY) || 0);
    if (Date.now() - last < 10_000) return;
    sessionStorage.setItem(KEY, String(Date.now()));
  } catch {
    /* sessionStorage unavailable — fall through and reload once */
  }
  updateCallback?.();
}

export async function registerServiceWorker(): Promise<void> {
  if (typeof window === 'undefined') return;
  if ('__TAURI_INTERNALS__' in window) return; // Tauri handles assets natively
  if (!('serviceWorker' in navigator)) return;

  try {
    const reg = await navigator.serviceWorker.register('./sw.js', {
      scope: './',
      // Update check every time the page loads
      updateViaCache: 'none',
    });

    // Whether a SW already controlled this page at load. A controllerchange /
    // activation with hadController=false is the FIRST-EVER install taking
    // control (skipWaiting + claim) — not a deploy — so we must not reload for
    // it (that was a spurious first-visit reload). Only a genuine update
    // (hadController=true) auto-reloads.
    const hadController = !!navigator.serviceWorker.controller;

    // New SW found while page is open
    reg.addEventListener('updatefound', () => {
      const newWorker = reg.installing;
      if (!newWorker) return;

      newWorker.addEventListener('statechange', () => {
        // New SW activated — page is now controlled by the new version
        if (newWorker.state === 'activated' && navigator.serviceWorker.controller && hadController) {
          fireUpdate();
        }
      });
    });

    // Page reloads needed when controller switches (skipWaiting + claim)
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (!hadController) return;
      fireUpdate();
    });

    // Trigger a background update check (finds new SW without user action)
    reg.update().catch(() => undefined); // nosemgrep: silent-promise-catch-arrow-empty
  } catch (err) {
    // SW registration is non-critical — log and continue
    console.warn('[SW] Registration failed:', err);
  }
}
