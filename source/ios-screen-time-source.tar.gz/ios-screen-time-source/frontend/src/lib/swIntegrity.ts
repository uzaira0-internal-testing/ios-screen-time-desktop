/**
 * Pure helpers for the service worker's runtime integrity verification.
 *
 * Extracted from `service-worker.ts` so they can be unit-tested WITHOUT the
 * `ServiceWorkerGlobalScope` (`self`, `caches`, `crypto.subtle`, the
 * `__SW_BUILD_ID__` build define) that the worker touches at module load — none
 * of which exist under bun:test. The worker imports these and supplies the
 * impure pieces (the SHA-256 digest, the URL resolver, the cache writes).
 *
 * The install step already verifies every precached asset's SHA-256 against the
 * build-time digest in `sw-precache.json` (SEC-10). These helpers let the
 * runtime-repair path (`cacheFirst` on an install-time cache miss) enforce the
 * same guarantee, so a poisoned artifact fetched AFTER install can never be
 * persisted (nor, for executable WASM, served).
 */

/** A precache entry: public URL + integrity digest of the bytes the build emitted. */
export interface PrecacheEntry {
  url: string;
  sha256: string;
}

export interface PrecacheManifest {
  version: number;
  basePath: string;
  shellAssets: PrecacheEntry[];
  appAssets: PrecacheEntry[];
  pipelineAssets: PrecacheEntry[];
}

/**
 * Build an absolute-URL → expected-SHA-256 index from a precache manifest.
 *
 * `resolveUrl` maps a manifest URL (a base-prefixed path, possibly carrying a
 * `?v=<wasm-hash>` query for the ABI-coupled pipeline assets) to the absolute
 * form that matches `Request.url` at fetch time — so a lookup keyed on the live
 * request resolves to the right digest, query and all. Malformed entries
 * (missing url or sha256) are skipped rather than indexed with a blank key.
 */
export function buildIntegrityIndex(
  manifest: PrecacheManifest,
  resolveUrl: (url: string) => string,
): Map<string, string> {
  const index = new Map<string, string>();
  for (const group of [manifest.shellAssets, manifest.appAssets, manifest.pipelineAssets]) {
    for (const entry of group) {
      if (entry?.url && entry?.sha256) index.set(resolveUrl(entry.url), entry.sha256);
    }
  }
  return index;
}

export type IntegrityDecision = "serve-and-cache" | "serve-no-cache" | "reject";

/**
 * Decide what the runtime-repair (`cacheFirst`) path does with a freshly
 * fetched asset, given the manifest's expected digest and the actual digest:
 *
 *  - listed in the manifest + hashes match    → persist and serve;
 *  - listed in the manifest + hashes MISMATCH  → reject (never serve OR cache
 *    poisoned bytes — same posture as the install-time drop-on-mismatch);
 *  - absent from the manifest (or no manifest, expected === undefined):
 *      · `strict` (executable WASM pipeline) → serve once but DO NOT persist an
 *        unverifiable artifact;
 *      · non-strict (hashed app chunks, some — e.g. nerWorker — deliberately
 *        omitted from precache) → persist as before; the content-hashed filename
 *        is itself the integrity binding.
 *
 * `actual` is only computed (and only meaningful) when `expected` is defined.
 */
export function integrityDecision(
  expected: string | undefined,
  actual: string | undefined,
  strict: boolean,
): IntegrityDecision {
  if (expected !== undefined) {
    return actual === expected ? "serve-and-cache" : "reject";
  }
  return strict ? "serve-no-cache" : "serve-and-cache";
}
