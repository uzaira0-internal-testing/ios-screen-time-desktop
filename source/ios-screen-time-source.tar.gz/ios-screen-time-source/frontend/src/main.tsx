import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";
import {
  ServiceProvider,
  bootstrapServices,
  createConfig,
  presetGlobalContainer,
} from "./core";
import { registerServiceWorker, onSWUpdate } from "./lib/serviceWorker";
import { installChunkReloadHandler } from "./lib/chunkReload";

// Recover a tab still running a previous build that 404s on a renamed lazy
// chunk after a deploy ("Failed to fetch dynamically imported module").
installChunkReloadHandler();

// Desktop-only styling hooks (see index.css).
if (window.__TAURI_INTERNALS__) document.documentElement.dataset.desktop = "";

const rootElement = document.getElementById("root");

if (!rootElement) {
  throw new Error("Failed to find the root element");
}

// Eagerly bootstrap services BEFORE first render so route components can
// resolve via the DI container without waiting on a React effect. Server
// mode resolves synchronously inside the returned promise; WASM/Tauri use
// dynamic imports and resolve later via the normal ServiceProvider path.
const __cfg = createConfig();
void bootstrapServices(__cfg).then((c) => presetGlobalContainer(c, __cfg));

ReactDOM.createRoot(rootElement).render(
  <React.StrictMode>
    <ServiceProvider>
      <App />
    </ServiceProvider>
  </React.StrictMode>,
);

// Register SW after render so it doesn't block first paint.
void registerServiceWorker();
onSWUpdate(() => {
  window.location.reload();
});
