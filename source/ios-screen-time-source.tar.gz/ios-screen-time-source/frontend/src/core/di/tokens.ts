import {
  PREPROCESSING_STAGES,
  type PreprocessingStages,
} from "@/core/generated/constants";
import type {
  IScreenshotService,
  IAnnotationService,
  IConsensusService,
  IStorageService,
  IProcessingService,
  IPreprocessingService,
} from "../interfaces";
import type { SyncService } from "../implementations/wasm/sync/SyncService";

/**
 * A dependency-injection token that carries the service type it resolves to.
 *
 * The phantom `__type` field is never populated at runtime — it exists purely
 * so `Token<T>` is structurally distinct per `T`, letting `resolve(token)`
 * infer the service interface with zero casts and no token/interface drift.
 */
export interface Token<T> {
  readonly id: string;
  /** Phantom type marker — never read at runtime. */
  readonly __type?: T;
}

/** Create a typed token. The `T` parameter brands the token. */
export function makeToken<T>(id: string): Token<T> {
  return { id };
}

export const TOKENS = {
  SCREENSHOT_SERVICE: makeToken<IScreenshotService>("IScreenshotService"),
  ANNOTATION_SERVICE: makeToken<IAnnotationService>("IAnnotationService"),
  CONSENSUS_SERVICE: makeToken<IConsensusService>("IConsensusService"),
  STORAGE_SERVICE: makeToken<IStorageService>("IStorageService"),
  PROCESSING_SERVICE: makeToken<IProcessingService>("IProcessingService"),
  PREPROCESSING_PIPELINE_SERVICE: makeToken<IPreprocessingService>(
    "IPreprocessingService",
  ),
  SYNC_SERVICE: makeToken<SyncService>("SyncService"),
  FEATURES: makeToken<AppFeatures>("Features"),
} as const;

/** A token identifier string (the `.id` of any registered token). */
export type ServiceTokenId = (typeof TOKENS)[keyof typeof TOKENS]["id"];

/** @deprecated Tokens are now typed objects; use {@link ServiceTokenId} for the id string. */
export type ServiceToken = ServiceTokenId;

/**
 * Declares which high-level capabilities are available in the current mode.
 * Components query this via useFeatures() instead of checking config.isLocalMode.
 */
export interface AppFeatures {
  /** Server-side study groups with processing status breakdown */
  groups: boolean;
  /** Cross-rater consensus comparison (requires server) */
  consensusComparison: boolean;
  /** Admin user management (requires server) */
  admin: boolean;
  /** Server-side preprocessing pipeline */
  preprocessing: boolean;
  /**
   * PHI detection + redaction stages are exposed.
   * WASM (browser-only) builds disable this — the pipeline collapses to
   * device detection → cropping → OCR. Server and Tauri keep it on.
   */
  phiDetection: boolean;
}

/**
 * The PHI stages — gated by `AppFeatures.phiDetection`.
 * Single source of truth so service guards, UI gating, prereq computation,
 * and deep-link validation all agree on which stages disappear.
 */
export const PHI_STAGES: readonly PreprocessingStages[] = [
  "phi_detection",
  "phi_redaction",
];

/**
 * Returns the ordered list of preprocessing stages active in the given mode.
 * Stages absent from this list are not run, not shown in the wizard, and
 * are skipped when computing prerequisites for downstream stages.
 */
export function getActiveStages(
  features: AppFeatures,
): readonly PreprocessingStages[] {
  if (features.phiDetection) return PREPROCESSING_STAGES;
  return PREPROCESSING_STAGES.filter((s) => !PHI_STAGES.includes(s));
}
