import { ServiceContainer } from "./Container";
import { TOKENS, type AppFeatures } from "./tokens";
import type { AppConfig } from "../config";
import type { ProcessingSchedulerSnapshot } from "../interfaces/IProcessingService";
import type { PreprocessingStageSchedulerSnapshot } from "../interfaces/IPreprocessingService";
import type { UploadSchedulerSnapshot } from "../interfaces/IScreenshotService";
import { config as runtimeConfig } from "@/config";

import { IndexedDBStorageService } from "../implementations/wasm/storage/IndexedDBStorageService";
import { WASMScreenshotService } from "../implementations/wasm/WASMScreenshotService";
import { WASMAnnotationService } from "../implementations/wasm/WASMAnnotationService";
import { WASMConsensusService } from "../implementations/wasm/WASMConsensusService";
import { WASMProcessingService } from "../implementations/wasm/WASMProcessingService";
import { WASMPreprocessingService } from "../implementations/wasm/preprocessing/WASMPreprocessingService";
import { syncService } from "../implementations/wasm/sync/SyncService";

declare global {
  interface Window {
    __WASM_PROCESSING_DIAGNOSTICS__?: {
      getPoolSize: () => number;
      getSchedulerSnapshot: () => ProcessingSchedulerSnapshot;
      getUploadSchedulerSnapshot?: () => UploadSchedulerSnapshot;
      getStageSchedulerSnapshot?: () => PreprocessingStageSchedulerSnapshot;
    };
  }
}

function shouldExposeWasmProcessingDiagnostics(): boolean {
  if (typeof window === "undefined") return false;
  return (
    runtimeConfig.isDev ||
    window.location.hostname === "localhost" ||
    window.location.hostname === "127.0.0.1" ||
    window.location.hostname === "[::1]"
  );
}

/**
 * Bootstrap services for WASM (local-first) mode.
 * All processing happens client-side with IndexedDB storage.
 *
 * @param phiDetection - Whether PHI detection/redaction stages are enabled.
 *   Both the browser and the desktop app leave it `false`.
 */
export function bootstrapWasmServices(
  _config: AppConfig,
  phiDetection = false,
): ServiceContainer {
  const container = new ServiceContainer();

  if (runtimeConfig.isDev) {
    // eslint-disable-next-line no-console -- dev-only diagnostic, gated by runtimeConfig.isDev
    console.log("[Bootstrap] Registering WASM services (local-first mode)");
  }

  // Storage is the foundation - everything depends on it
  container.register(
    TOKENS.STORAGE_SERVICE,
    () => new IndexedDBStorageService(),
  );

  // Processing service handles OCR via Rust+leptess WASM Web Worker pool
  container.register(TOKENS.PROCESSING_SERVICE, () => {
    const service = new WASMProcessingService();
    if (shouldExposeWasmProcessingDiagnostics()) {
      window.__WASM_PROCESSING_DIAGNOSTICS__ = {
        getPoolSize: () => service.getPoolSize(),
        getSchedulerSnapshot: () => service.getSchedulerSnapshot(),
      };
    }
    return service;
  });

  // Screenshot service orchestrates storage + processing.
  // Factory closures resolve INTERFACE types — the concrete class is an
  // implementation detail the container should not leak.
  container.register(TOKENS.SCREENSHOT_SERVICE, () => {
    const storage = container.resolve(TOKENS.STORAGE_SERVICE);
    const processing = container.resolve(TOKENS.PROCESSING_SERVICE);
    const service = new WASMScreenshotService(storage, processing);
    if (shouldExposeWasmProcessingDiagnostics() && window.__WASM_PROCESSING_DIAGNOSTICS__) {
      window.__WASM_PROCESSING_DIAGNOSTICS__.getUploadSchedulerSnapshot = () =>
        service.getUploadSchedulerSnapshot();
    }
    return service;
  });

  container.register(TOKENS.ANNOTATION_SERVICE, () => {
    const storage = container.resolve(TOKENS.STORAGE_SERVICE);
    return new WASMAnnotationService(storage);
  });

  container.register(TOKENS.CONSENSUS_SERVICE, () => {
    const storage = container.resolve(TOKENS.STORAGE_SERVICE);
    return new WASMConsensusService(storage);
  });

  // WASM mode: local processing via Rust+leptess WASM + IndexedDB.
  // Server-only features: cross-rater comparison, admin.
  // PHI detection is off in the browser and in the desktop app, which runs
  // this same build: the pipeline is device detection → cropping → OCR.
  const features: AppFeatures = {
    groups: true,
    consensusComparison: false,
    admin: false,
    preprocessing: true,
    phiDetection,
  };
  container.register(TOKENS.FEATURES, features);

  container.register(TOKENS.PREPROCESSING_PIPELINE_SERVICE, () => {
    const storage = container.resolve(TOKENS.STORAGE_SERVICE);
    const processing = container.resolve(TOKENS.PROCESSING_SERVICE);
    const f = container.resolve(TOKENS.FEATURES);
    // ARC-3: WASMPreprocessingService's constructor still types `storage` as
    // the concrete IndexedDBStorageService rather than IStorageService. Until
    // that file is widened to the interface, the runtime instance (always an
    // IndexedDBStorageService in WASM mode) is asserted here.
    const service = new WASMPreprocessingService(
      storage as unknown as IndexedDBStorageService,
      processing,
      { enablePhi: f.phiDetection },
    );
    if (shouldExposeWasmProcessingDiagnostics() && window.__WASM_PROCESSING_DIAGNOSTICS__) {
      window.__WASM_PROCESSING_DIAGNOSTICS__.getStageSchedulerSnapshot = () =>
        service.getStageSchedulerSnapshot();
    }
    return service;
  });

  // SyncService is container-managed so its in-flight sync is aborted when
  // the container is destroyed (Container.destroy() invokes destroy()).
  // The factory returns the module-level `syncService` singleton so the
  // DI-registered instance and the one used by SyncStore are the same
  // object — destroy() therefore aborts the sync the UI actually started.
  container.register(TOKENS.SYNC_SERVICE, () => syncService);
  // Eagerly resolve so the instance is in the container's singleton map and
  // therefore reached by Container.destroy() even if nothing else resolved it.
  container.resolve(TOKENS.SYNC_SERVICE);

  if (runtimeConfig.isDev) {
    // eslint-disable-next-line no-console -- dev-only diagnostic, gated by runtimeConfig.isDev
    console.log("[Bootstrap] WASM services registered.");
  }

  return container;
}
