import type { Token } from "./tokens";

type Factory<T> = () => T;
type ServiceImplementation<T> = T | Factory<T>;

/**
 * Lightweight dependency-injection container.
 *
 * Tokens are typed (`Token<T>`), so `resolve(token)` infers the service type
 * with no runtime cast and no possibility of a token/interface mismatch.
 *
 * Every registration is a lazy singleton: the implementation (or the result
 * of the factory on first `resolve`) is cached and returned on every
 * subsequent `resolve`. There is no transient lifecycle.
 */
export class ServiceContainer {
  private services = new Map<string, ServiceImplementation<unknown>>();
  private singletons = new Map<string, unknown>();

  /**
   * Register a service. Accepts either a concrete value or a factory.
   * A factory is invoked lazily on first `resolve` and its result cached.
   */
  register<T>(token: Token<T>, implementation: ServiceImplementation<T>): void {
    this.services.set(token.id, implementation);
    // A previously-cached instance for this token is now stale.
    this.singletons.delete(token.id);
  }

  /** @deprecated Use {@link register} — all registrations are lazy singletons. */
  registerFactory<T>(token: Token<T>, factory: Factory<T>): void {
    this.register(token, factory);
  }

  /** @deprecated Use {@link register} — all registrations are lazy singletons. */
  registerSingleton<T>(
    token: Token<T>,
    implementation: ServiceImplementation<T>,
  ): void {
    this.register(token, implementation);
  }

  resolve<T>(token: Token<T>): T {
    if (this.singletons.has(token.id)) {
      return this.singletons.get(token.id) as T;
    }

    const implementation = this.services.get(token.id);

    if (implementation === undefined) {
      throw new Error(`Service not registered: ${token.id}`);
    }

    let instance: T;
    if (typeof implementation === "function") {
      instance = (implementation as Factory<T>)();
    } else {
      instance = implementation as T;
    }

    // Lazy-singleton cache: every token resolves to one instance.
    this.singletons.set(token.id, instance);
    return instance;
  }

  has<T>(token: Token<T>): boolean {
    return this.services.has(token.id);
  }

  clear(): void {
    this.services.clear();
    this.singletons.clear();
  }

  /**
   * Release the resources every instantiated service holds (workers, OPFS
   * handles, timers) WITHOUT dropping the registrations.
   *
   * This is the right call during page unload. `destroy()` additionally clears
   * the registration map, which makes every later `resolve()` throw
   * "Service not registered" — and on unload the React tree is still mounted
   * and can render at least one more frame, so those throws surfaced as
   * console errors and an ErrorBoundary flash on the outgoing page. Freeing
   * the map buys nothing there (the whole heap is about to go), so unload
   * terminates and leaves the container resolvable.
   */
  terminate(): void {
    // Call terminate/destroy on all singleton instances
    for (const [token, instance] of this.singletons.entries()) {
      // `"terminate" in instance` narrows the KEY, not its type — the value is
      // still `unknown`, so each hook is read through this shape after the
      // typeof check below confirms it is callable.
      const hooks = instance as Partial<
        Record<"terminate" | "destroy" | "cleanup", () => void>
      >;
      if (instance && typeof instance === "object") {
        // Check for common cleanup method names
        if (
          "terminate" in instance &&
          typeof instance.terminate === "function"
        ) {
          try {
            hooks.terminate?.();
          } catch (error) {
            console.error(
              `[ServiceContainer] Error terminating ${token}:`,
              error,
            );
          }
        } else if (
          "destroy" in instance &&
          typeof instance.destroy === "function"
        ) {
          try {
            hooks.destroy?.();
          } catch (error) {
            console.error(
              `[ServiceContainer] Error destroying ${token}:`,
              error,
            );
          }
        } else if (
          "cleanup" in instance &&
          typeof instance.cleanup === "function"
        ) {
          try {
            hooks.cleanup?.();
          } catch (error) {
            console.error(
              `[ServiceContainer] Error cleaning up ${token}:`,
              error,
            );
          }
        }
      }
    }

  }

  /**
   * Terminate every instantiated service AND drop the registrations.
   *
   * For genuine teardown (tests, mode switches) where the container must not
   * be reused. During page unload prefer {@link terminate} — see the note
   * there on the render-after-unload window.
   */
  destroy(): void {
    this.terminate();
    this.clear();
  }
}
