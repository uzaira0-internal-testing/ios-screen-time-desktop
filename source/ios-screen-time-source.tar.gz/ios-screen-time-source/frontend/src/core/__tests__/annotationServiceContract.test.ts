/**
 * Dual-mode behavioral contract for IAnnotationService (roadmap #14).
 *
 * Structural conformance (both classes `implements IAnnotationService`) is
 * guaranteed by the compiler. This suite goes further and asserts BEHAVIOUR —
 * and it asserts the *dual-mode* behaviour, not forced identity:
 *
 *   - local/WASM is fully functional: create → getByScreenshot round-trips,
 *     update edits in place, delete removes.
 *   - server is append-only (ARC-17): update() throws, getByScreenshot() → [].
 *
 * Both sides EXECUTE here. The WASM service runs against an in-memory
 * IStorageService double (its real delegation logic, no IndexedDB needed). The
 * server service's divergence methods (update / getByScreenshot) short-circuit
 * before any API call, so they run headless too. The server's API-backed methods
 * (create / getHistory / delete) are exercised against a live backend by the
 * persona/e2e suite — out of scope for this headless contract.
 */
import "./setup/domGlobals"; // MUST be first — provides window.__CONFIG__ for the server impl's config/apiClient import chain.
import { describe, it, expect } from "bun:test";
import type { Annotation, AnnotationCreate } from "@/types";
import type { IAnnotationService, IStorageService } from "@/core/interfaces";
import { WASMAnnotationService } from "@/core/implementations/wasm/WASMAnnotationService";
import { APIAnnotationService } from "@/core/implementations/server/APIAnnotationService";

/**
 * In-memory IStorageService double. Implements only the methods the annotation
 * service touches; everything else throws (and the contract never calls them),
 * so the REAL WASMAnnotationService logic runs without IndexedDB.
 */
class InMemoryStorage {
  private anns = new Map<number, Annotation>();
  private seq = 0;
  readonly screenshotUpdates: Array<[number, Partial<Annotation>]> = [];

  async saveAnnotation(a: Annotation): Promise<number> {
    const id = ++this.seq;
    this.anns.set(id, { ...a, id });
    return id;
  }
  async updateScreenshot(id: number, data: Partial<Annotation>): Promise<void> {
    this.screenshotUpdates.push([id, data]);
  }
  async updateAnnotation(id: number, data: Partial<Annotation>): Promise<Annotation> {
    const existing = this.anns.get(id);
    if (!existing) throw new Error(`no annotation ${id}`);
    const updated = { ...existing, ...data, id };
    this.anns.set(id, updated);
    return updated;
  }
  async getAnnotationsByScreenshot(screenshotId: number): Promise<Annotation[]> {
    return [...this.anns.values()].filter((a) => a.screenshot_id === screenshotId);
  }
  async getAnnotationHistory(skip: number, limit: number): Promise<Annotation[]> {
    return [...this.anns.values()].slice(skip, skip + limit);
  }
  async deleteAnnotation(id: number): Promise<void> {
    this.anns.delete(id);
  }
}

const sampleCreate = (screenshot_id = 1): AnnotationCreate =>
  ({ screenshot_id, hourly_values: { "0": 1, "1": 2 } }) as AnnotationCreate;

function annotationContract(
  label: string,
  mode: "local" | "server",
  makeService: () => IAnnotationService,
) {
  describe(`IAnnotationService contract — ${label} (${mode})`, () => {
    if (mode === "local") {
      it("create() then getByScreenshot() round-trips the annotation", async () => {
        const svc = makeService();
        const created = await svc.create(sampleCreate(7));
        expect(created.id).toBeGreaterThan(0);
        expect(created.screenshot_id).toBe(7);
        const found = await svc.getByScreenshot(7);
        expect(found.map((a) => a.id)).toContain(created.id);
      });

      it("update() edits in place and returns the updated annotation", async () => {
        const svc = makeService();
        const created = await svc.create(sampleCreate(3));
        const updated = await svc.update(created.id, { notes: "edited" });
        expect(updated.id).toBe(created.id);
        expect(updated.notes).toBe("edited");
      });

      it("delete() removes the annotation", async () => {
        const svc = makeService();
        const created = await svc.create(sampleCreate(5));
        await svc.delete(created.id);
        const found = await svc.getByScreenshot(5);
        expect(found.map((a) => a.id)).not.toContain(created.id);
      });

      it("getByScreenshot() returns [] for an unknown screenshot", async () => {
        const svc = makeService();
        expect(await svc.getByScreenshot(999)).toEqual([]);
      });
    } else {
      it("update() rejects — annotations are append-only server-side (ARC-17)", async () => {
        const svc = makeService();
        await expect(svc.update(1, { notes: "x" })).rejects.toThrow();
      });

      it("getByScreenshot() resolves to [] — per-screenshot reads go via consensus (ARC-17)", async () => {
        const svc = makeService();
        expect(await svc.getByScreenshot(1)).toEqual([]);
      });
    }
  });
}

annotationContract(
  "WASMAnnotationService",
  "local",
  () => new WASMAnnotationService(new InMemoryStorage() as unknown as IStorageService),
);

annotationContract("APIAnnotationService", "server", () => new APIAnnotationService());
