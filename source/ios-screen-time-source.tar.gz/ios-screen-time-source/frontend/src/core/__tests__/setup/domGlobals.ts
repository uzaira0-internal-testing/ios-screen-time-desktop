/**
 * Minimal browser globals for headless service-contract tests.
 *
 * Some modules read `window` at import time — e.g. `@/config` resolves
 * `window.__CONFIG__?.basePath`, which `@/services/apiClient` evaluates at module
 * load (and `APIAnnotationService` imports). Under bun's non-DOM test runtime
 * `window` is undefined, so importing those modules throws `ReferenceError:
 * window is not defined`.
 *
 * Import this module FIRST (before any impl import) — side-effect imports are
 * evaluated in source order, so these globals exist before the config/apiClient
 * chain is loaded. Real DOM behaviour is exercised by the Playwright suites; this
 * only unblocks importing server-mode code headlessly.
 */
const g = globalThis as unknown as { window?: unknown };
if (typeof g.window === "undefined") {
  g.window = g;
}
(g.window as { __CONFIG__?: unknown }).__CONFIG__ = { basePath: "", apiBaseUrl: "" };

export {};
