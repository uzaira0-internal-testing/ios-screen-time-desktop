import { describe, expect, test } from "bun:test";

import {
  assertDecodedPixelBudget,
  ImageTooLargeError,
  MAX_DECODED_PIXELS,
} from "../imageLimits";

describe("decoded image limits", () => {
  test("allows images at the decoded pixel cap", () => {
    expect(() => assertDecodedPixelBudget(MAX_DECODED_PIXELS, 1)).not.toThrow();
  });

  test("rejects images before downstream canvas allocations exceed the cap", () => {
    expect(() => assertDecodedPixelBudget(MAX_DECODED_PIXELS + 1, 1)).toThrow(
      ImageTooLargeError,
    );
  });
});
