/**
 * Pre-migration backup utility for IndexedDB.
 *
 * Before Dexie opens the database at a newer schema version (triggering an
 * upgrade transaction), this module snapshots all metadata tables into OPFS
 * so the user's data can be recovered if a migration goes wrong.
 *
 * Only metadata tables are backed up — `imageBlobs` is excluded because
 * binary blobs are too large for a JSON snapshot.
 */

import {
  browserResourceNumber,
  computeMetadataIoConcurrency,
} from "@/lib/resourceBudget";
import { writeOpfsFile } from "../opfsWrite";

const BACKUP_DIR = "db-backups";

/** Tables to include in the backup (everything except imageBlobs). */
const METADATA_TABLES = [
  "screenshots",
  "annotations",
  "groups",
  "settings",
  "processingQueue",
  "syncRecords",
] as const;

interface BackupPayload {
  version: number;
  timestamp: string;
  tables: { [tableName: string]: unknown[] };
}

function metadataIoConcurrency(): number {
  return computeMetadataIoConcurrency(
    browserResourceNumber("hardwareConcurrency"),
    browserResourceNumber("deviceMemory"),
  );
}

async function forEachBoundedSettled<T>(
  items: readonly T[],
  concurrency: number,
  mapper: (item: T, index: number) => Promise<void>,
): Promise<void> {
  if (items.length === 0) return;

  let cursor = 0;
  const runnerCount = Math.min(Math.max(1, Math.floor(concurrency)), items.length);

  async function runNext(): Promise<void> {
    const index = cursor;
    cursor += 1;
    if (index >= items.length) return;
    try {
      await mapper(items[index] as T, index);
    } catch {
      // Preserve best-effort cleanup semantics; individual delete failures are
      // logged by the mapper and should not fail a pre-migration backup.
    }
    await runNext();
  }

  await Promise.all(Array.from({ length: runnerCount }, () => runNext()));
}

async function forEachBounded<T>(
  items: readonly T[],
  concurrency: number,
  mapper: (item: T, index: number) => Promise<void>,
): Promise<void> {
  if (items.length === 0) return;

  let cursor = 0;
  const runnerCount = Math.min(Math.max(1, Math.floor(concurrency)), items.length);

  async function runNext(): Promise<void> {
    const index = cursor;
    cursor += 1;
    if (index >= items.length) return;
    await mapper(items[index] as T, index);
    await runNext();
  }

  await Promise.all(Array.from({ length: runnerCount }, () => runNext()));
}

/**
 * Scrub PHI-bearing free-text out of a screenshot row before it is serialized
 * into the plaintext OPFS backup JSON.
 *
 * The PHI carriers are `ocr_text` (full extracted screen text) and the
 * per-region `text` field, both nested under
 * `processing_metadata.preprocessing.events[]`. Structural metadata (bounding
 * boxes, labels, confidences, stage names) is retained — only verbatim text
 * is removed, so a restored backup keeps its shape but never resurrects
 * cleartext SSN/email/MRN strings.
 */
function scrubScreenshotPHI(row: unknown): unknown {
  if (!row || typeof row !== "object") return row;
  const screenshot = row as Record<string, unknown>;

  const meta = screenshot.processing_metadata;
  if (!meta || typeof meta !== "object") return row;
  const preprocessing = (meta as Record<string, unknown>).preprocessing;
  if (!preprocessing || typeof preprocessing !== "object") return row;
  const events = (preprocessing as Record<string, unknown>).events;
  if (!Array.isArray(events)) return row;

  const REDACTED = "[REDACTED]";

  for (const event of events) {
    if (!event || typeof event !== "object") continue;
    const ev = event as Record<string, unknown>;

    // Full OCR text dump.
    if (typeof ev.ocr_text === "string") ev.ocr_text = REDACTED;

    // Per-region detected PHI text (SSN/email/MRN verbatim strings).
    const regions = ev.regions;
    if (Array.isArray(regions)) {
      for (const region of regions) {
        if (region && typeof region === "object") {
          const r = region as Record<string, unknown>;
          if (typeof r.text === "string") r.text = REDACTED;
        }
      }
    }
    // Some event shapes carry detections under `entities` instead of `regions`.
    const entities = ev.entities;
    if (Array.isArray(entities)) {
      for (const entity of entities) {
        if (entity && typeof entity === "object") {
          const e = entity as Record<string, unknown>;
          if (typeof e.text === "string") e.text = REDACTED;
        }
      }
    }
  }

  return row;
}

/**
 * Create a JSON backup of all metadata tables in the given IndexedDB database.
 *
 * Opens the database via the raw `indexedDB.open()` API (no version argument)
 * so the current on-disk version is opened without triggering an upgrade.
 * Writes the backup to OPFS and prunes old backups to keep only the 2 most recent.
 */
export async function createPreMigrationBackup(dbName: string): Promise<void> {
  // ------- 1. Open the database at its current version -------
  const rawDb = await new Promise<IDBDatabase>((resolve, reject) => {
    const req = indexedDB.open(dbName);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("IndexedDB request failed"));
    // If onupgradeneeded fires it means the DB didn't exist yet — nothing to back up.
    req.onupgradeneeded = () => {
      req.transaction?.abort();
      reject(new Error("Database does not exist yet — nothing to back up"));
    };
  });

  try {
    const version = rawDb.version;
    const existingStores = Array.from(rawDb.objectStoreNames);

    // Only back up tables that actually exist in this version of the DB
    const tablesToBackup = METADATA_TABLES.filter((t) =>
      existingStores.includes(t),
    );

    if (tablesToBackup.length === 0) {
      return;
    }

    // ------- 2. Read all metadata tables -------
    const tables: BackupPayload["tables"] = {};

    const tx = rawDb.transaction([...tablesToBackup], "readonly");

    await forEachBounded(tablesToBackup, metadataIoConcurrency(), async (tableName) => {
      await new Promise<void>((resolve, reject) => {
        const store = tx.objectStore(tableName);
        const req = store.getAll();
        req.onsuccess = () => {
          // Scrub PHI free-text from screenshot rows before the backup is
          // written as plaintext JSON to OPFS. The IDBRequest result is a
          // fresh deserialized copy, so mutating it does not touch the DB.
          tables[tableName] =
            tableName === "screenshots"
              ? req.result.map(scrubScreenshotPHI)
              : req.result;
          resolve();
        };
        req.onerror = () => reject(req.error ?? new Error("IndexedDB request failed"));
      });
    });

    const timestamp = new Date().toISOString();
    const payload: BackupPayload = { version, timestamp, tables };
    const json = JSON.stringify(payload);

    // ------- 3. Write to OPFS -------
    await writeBackupToOPFS(version, timestamp, json);

    const totalRecords = Object.values(tables).reduce(
      (sum, arr) => sum + arr.length,
      0,
    );
    console.warn(
      `[Migration] Backup complete: v${version}, ${totalRecords} records across ${tablesToBackup.length} tables`,
    );
  } finally {
    rawDb.close();
  }
}

/**
 * Write backup JSON to OPFS and prune old backups, keeping only the 2 most recent.
 */
async function writeBackupToOPFS(
  version: number,
  timestamp: string,
  json: string,
): Promise<void> {
  if (
    typeof navigator === "undefined" ||
    !navigator.storage ||
    !("getDirectory" in navigator.storage)
  ) {
    console.warn("[Migration] OPFS not available — skipping backup write");
    return;
  }

  try {
    const root = await navigator.storage.getDirectory();
    let backupDir: FileSystemDirectoryHandle;

    try {
      backupDir = await root.getDirectoryHandle(BACKUP_DIR, { create: true });
    } catch (err) {
      console.warn("[Migration] Could not create OPFS backup directory:", err);
      return;
    }

    // Sanitise timestamp for filename: 2026-03-10T12:34:56.789Z → 2026-03-10T123456
    const safestamp = timestamp.replace(/[:.]/g, "").slice(0, 19);
    const paddedVersion = String(version).padStart(4, "0");
    const filename = `backup-v${paddedVersion}-${safestamp}.json`;

    await writeOpfsFile(backupDir, [BACKUP_DIR], filename, json);

    console.warn(`[Migration] Backup written to OPFS: ${BACKUP_DIR}/${filename}`);

    // ------- 4. Prune old backups (keep 2 most recent) -------
    await pruneOldBackups(backupDir, 2);
  } catch (err) {
    console.warn("[Migration] Failed to write backup to OPFS:", err);
  }
}

/**
 * Keep only the `keep` most recent backup files, deleting the rest.
 */
async function pruneOldBackups(
  dir: FileSystemDirectoryHandle,
  keep: number,
): Promise<void> {
  const entries: string[] = [];

  for await (const [name, handle] of dir as unknown as AsyncIterable<
    [string, FileSystemHandle]
  >) {
    if (handle.kind === "file" && name.startsWith("backup-") && name.endsWith(".json")) {
      entries.push(name);
    }
  }

  if (entries.length <= keep) return;

  // Sort lexicographically — filenames contain version + timestamp so this gives chronological order
  entries.sort();

  const toDelete = entries.slice(0, entries.length - keep);
  await forEachBoundedSettled(toDelete, metadataIoConcurrency(), async (name) => {
    try {
      await dir.removeEntry(name);
      console.warn(`[Migration] Pruned old backup: ${name}`);
    } catch (err) {
      console.warn(`[Migration] Failed to prune backup ${name}:`, err);
      throw err;
    }
  });
}
