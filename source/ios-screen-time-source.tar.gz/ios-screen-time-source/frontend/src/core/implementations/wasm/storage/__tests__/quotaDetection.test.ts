/**
 * Cross-browser quota-exceeded detection (Persona 7: Storage Pressure).
 *
 * `isQuotaExceeded` is the gate every WASM-mode write funnels through to turn a
 * full-disk failure into a recognizable `StorageQuotaExceededError` instead of
 * an opaque crash. The quota error shape differs per browser and the OPFS/Dexie
 * layers wrap it, so this locks in every shape the detector must recognize —
 * the exact cross-browser matrix the storage-pressure persona cares about.
 */
import { describe, it, expect } from "bun:test";
import {
  isQuotaExceeded,
  StorageQuotaExceededError,
} from "../opfsBlobStorage";

// A DOMException carrying a given `name` (Chrome/Firefox modern shape).
function domException(name: string): DOMException {
  return new DOMException("quota", name);
}

describe("isQuotaExceeded — cross-browser shapes", () => {
  it("detects the modern Chrome/Firefox DOMException name", () => {
    expect(isQuotaExceeded(domException("QuotaExceededError"))).toBe(true);
  });

  it("detects the legacy Safari/Firefox DOMException name", () => {
    expect(isQuotaExceeded(domException("QUOTA_EXCEEDED_ERR"))).toBe(true);
  });

  it("detects a plain Error whose name is a quota name", () => {
    const err = new Error("disk full");
    err.name = "QuotaExceededError";
    expect(isQuotaExceeded(err)).toBe(true);
  });

  it("detects the legacy numeric code 22 (older Safari)", () => {
    expect(isQuotaExceeded({ code: 22 })).toBe(true);
  });

  it("detects a quota error wrapped by Dexie via `inner`", () => {
    expect(
      isQuotaExceeded({ name: "AbortError", inner: domException("QuotaExceededError") }),
    ).toBe(true);
  });

  it("detects a quota error wrapped via the standard `cause` chain", () => {
    const outer = new Error("write failed");
    (outer as Error & { cause?: unknown }).cause = domException("QuotaExceededError");
    expect(isQuotaExceeded(outer)).toBe(true);
  });

  it("walks a nested chain within the depth budget", () => {
    const nested = { cause: { inner: { cause: domException("QuotaExceededError") } } };
    expect(isQuotaExceeded(nested)).toBe(true);
  });
});

describe("isQuotaExceeded — non-quota inputs return false", () => {
  it("returns false for an unrelated error", () => {
    expect(isQuotaExceeded(new TypeError("boom"))).toBe(false);
  });

  it("returns false for null / undefined", () => {
    expect(isQuotaExceeded(null)).toBe(false);
    expect(isQuotaExceeded(undefined)).toBe(false);
  });

  it("returns false for a plain object with no quota markers", () => {
    expect(isQuotaExceeded({ message: "nope", code: 13 })).toBe(false);
  });

  it("stops at the depth budget instead of looping forever on a cycle", () => {
    // A self-referential cause chain must not hang and must not false-positive.
    const cyclic: { cause?: unknown } = {};
    cyclic.cause = cyclic;
    expect(isQuotaExceeded(cyclic)).toBe(false);
  });

  it("does not detect a quota error buried deeper than the depth budget", () => {
    // 6 levels of nesting — beyond the 5-deep walk, so it is not found.
    const tooDeep = {
      cause: { cause: { cause: { cause: { cause: { cause: domException("QuotaExceededError") } } } } },
    };
    expect(isQuotaExceeded(tooDeep)).toBe(false);
  });
});

describe("StorageQuotaExceededError", () => {
  it("has a stable name and a default message", () => {
    const err = new StorageQuotaExceededError();
    expect(err).toBeInstanceOf(Error);
    expect(err.name).toBe("StorageQuotaExceededError");
    expect(err.message).toBe("Storage is full");
  });

  it("preserves a custom message", () => {
    expect(new StorageQuotaExceededError("out of space, delete files").message).toBe(
      "out of space, delete files",
    );
  });
});
