import type {
  GridCoordinates,
  HourlyData,
} from "@/types";
import type { ImageType } from "@/types";

/**
 * Source image passed to the worker.
 *
 * PERF-2: the worker accepts either a raw `ImageData` (already decoded) or a
 * `Blob`. When a `Blob` is passed, the worker itself runs
 * `createImageBitmap` + `OffscreenCanvas.getImageData` — the multi-MB pixel
 * readback happens off the main thread. `ImageData.data.buffer` is a
 * transferable; a `Blob` is structured-cloned by reference (no copy).
 */
export type WorkerImageInput = ImageData | Blob;
export type TessdataPayload = ArrayBuffer | Blob;

// ── Message payload types ────────────────────────────────────────────────────

export interface InitializePayload {
  /**
   * PERF-1/PERF-11: `eng.traineddata` fetched once on the main thread and
   * passed to every worker, so the pool does not trigger N parallel 4 MB
   * downloads on a cold cache. Prefer Blob here because it structured-clones
   * to workers by handle; a worker with no preloaded asset falls back to
   * fetching its own copy.
   */
  tessdata?: TessdataPayload;
  /**
   * PERF-1: the compiled `IosScreenTimePipeline.wasm` (~5.9 MB) compiled ONCE
   * on the main thread via `WebAssembly.compileStreaming` and posted to every
   * worker. `WebAssembly.Module` is structured-cloneable to dedicated workers
   * (sharing the compiled code; only linear memory stays per-instance), so the
   * pool no longer fetches+compiles N copies. Optional — a worker with no
   * preloaded module falls back to the Emscripten glue's own streaming
   * compile.
   */
  wasmModule?: WebAssembly.Module;
  /**
   * The user's enabled OCR languages as Tesseract's `+`-joined string
   * ("eng", "eng+heb", …). The enabled set is persisted in localStorage, which
   * does not exist in a worker, so the selection has to travel in the message
   * like the other main-thread-resolved inputs. The pack bytes themselves stay
   * in OPFS, which the worker can read directly.
   */
  languages?: string;
}

export interface ProcessImagePayload {
  imageData: WorkerImageInput;
  imageType: ImageType;
  gridCoordinates?: GridCoordinates;
  /**
   * When present, the worker first detects grid from the decoded ImageData and
   * then runs OCR/bar extraction in the same message, avoiding a second blob
   * decode for the common preprocessing OCR stage.
   */
  gridDetectionMethod?: "ocr_anchored" | "line_based";
  /**
   * Optional precompiled pipeline module for cold line-based combined
   * processing. The worker can detect geometry without fetching/compiling its
   * own module, and still avoids mounting tessdata until OCR is actually run.
   */
  wasmModule?: WebAssembly.Module;
  /**
   * Optional pre-fetched tessdata asset for cold line-based combined
   * processing. The worker keeps this local until grid detection succeeds, then
   * mounts it for OCR so valid parallel screenshots do not each fetch their own
   * `eng.traineddata` copy. Prefer Blob to avoid copying the full asset when
   * posting the message.
   */
  tessdata?: TessdataPayload;
  /**
   * The user's enabled OCR languages as Tesseract's `+`-joined string
   * ("eng", "eng+heb", …). The enabled set is persisted in localStorage, which
   * does not exist in a worker, so the selection has to travel in the message
   * like the other main-thread-resolved inputs. The pack bytes themselves stay
   * in OPFS, which the worker can read directly.
   */
  languages?: string;
  /** Max pixels to shift grid for optimization (0 = disabled, default = 0) */
  maxShift?: number;
  /** Apportionment + grid-registration knobs from the Settings UI. Omitted →
   *  the Rust pipeline uses its compiled SSoT defaults. Workers can't read the
   *  settings store (no localStorage off the main thread), so the main-thread
   *  service injects these into the message. */
  apportionMaxMinutes?: number;
  /** Apportionment cap as percent of OCR total; > 0 selects percentage mode and
   *  overrides apportionMaxMinutes. Omitted/0 → absolute mode. */
  apportionMaxPercent?: number;
  gridRegDeadband?: number;
  gridRegTol?: number;
}

export interface ExtractTitlePayload {
  imageData: WorkerImageInput;
}

export interface ExtractTotalPayload {
  imageData: WorkerImageInput;
}

export interface ExtractHourlyDataPayload {
  imageData: WorkerImageInput;
  gridCoordinates: GridCoordinates;
  imageType: ImageType;
}

export interface ExtractBarsPayload {
  imageData: WorkerImageInput;
  gridCoordinates: GridCoordinates;
  imageType: ImageType;
  totalText?: string | null;
  apportionMaxMinutes?: number;
  apportionMaxPercent?: number;
  gridRegDeadband?: number;
  gridRegTol?: number;
  /**
   * Reading direction recorded when this screenshot was first processed. Nothing
   * re-reads the hour labels on this path — the user dragged the grid — so a
   * mirrored (Hebrew/Arabic) chart would otherwise come back with its hours in
   * image order. Defaults to left-to-right.
   */
  axisDirection?: "ltr" | "rtl";
  /**
   * The chart's top-gridline value in minutes, recorded when this screenshot was
   * first processed. An "All Devices" chart is scaled in hours (`2h / 1h / 0`),
   * making its plot 120 minutes tall rather than 60. This path runs no OCR and
   * cannot re-read that label, so without it dragging the grid would halve every
   * bar the first pass got right. At or below 60 means the ordinary chart.
   */
  axisMaxMinutes?: number | null;
}

export interface DetectGridPayload {
  imageData: WorkerImageInput;
  imageType: ImageType;
  /** If "line_based", uses line-based detection (no OCR). Default is OCR-anchored. */
  method?: "ocr_anchored" | "line_based";
  /**
   * Optional precompiled pipeline module for LineBased grid detection before
   * full OCR initialization. Lets the cheap path reuse the shared compiled
   * module without mounting tessdata.
   */
  wasmModule?: WebAssembly.Module;
}

export interface MeasureColumnFillsPayload {
  imageData: WorkerImageInput;
  gridCoordinates: GridCoordinates;
  /** Shared precompiled pipeline module for a worker that has not been initialized. */
  wasmModule?: WebAssembly.Module;
}

// ── Request messages (discriminated union on `type`) ─────────────────────────

export interface InitializeMessage {
  type: "INITIALIZE";
  id: string;
  payload: InitializePayload;
}

export interface ProcessImageMessage {
  type: "PROCESS_IMAGE";
  id: string;
  payload: ProcessImagePayload;
}

export interface ExtractTitleMessage {
  type: "EXTRACT_TITLE";
  id: string;
  payload: ExtractTitlePayload;
}

export interface ExtractTotalMessage {
  type: "EXTRACT_TOTAL";
  id: string;
  payload: ExtractTotalPayload;
}

export interface ExtractHourlyDataMessage {
  type: "EXTRACT_HOURLY_DATA";
  id: string;
  payload: ExtractHourlyDataPayload;
}

export interface ExtractBarsMessage {
  type: "EXTRACT_BARS";
  id: string;
  payload: ExtractBarsPayload;
}

export interface DetectGridMessage {
  type: "DETECT_GRID";
  id: string;
  payload: DetectGridPayload;
}

export interface MeasureColumnFillsMessage {
  type: "MEASURE_COLUMN_FILLS";
  id: string;
  payload: MeasureColumnFillsPayload;
}

/**
 * ARC-13: discriminated union over `type` so the worker's `switch` is
 * exhaustive-checkable and adding a message is a compile error until handled.
 */
export type WorkerMessage =
  | InitializeMessage
  | ProcessImageMessage
  | ExtractTitleMessage
  | ExtractTotalMessage
  | ExtractHourlyDataMessage
  | ExtractBarsMessage
  | DetectGridMessage
  | MeasureColumnFillsMessage;

/** Payload union — kept for callers that need the shape independent of `type`. */
export type WorkerMessagePayload = WorkerMessage["payload"];

// ── Response payload types ───────────────────────────────────────────────────

/**
 * ARC-12: a processed image is either a success (full result) or a failure
 * (`ok: false` with an error). Encoding it as a discriminated union means a
 * caller physically cannot read `hourlyData` off a failed result.
 */
export type ProcessImageResultPayload =
  | {
      ok: true;
      hourlyData: HourlyData;
      title: string | null;
      total: string | null;
      gridCoordinates?: GridCoordinates;
      alignmentScore?: number | null;
      gridRegistrationScore?: number | null;
      /** Reading direction the detector established from the hour labels. The
       *  hourly data is already in clock order; this is stored so a later manual
       *  grid adjustment, which re-extracts bars without any detector, can
       *  re-apply the same orientation. */
      axisDirection?: "ltr" | "rtl";
      suspectedAllDevices?: boolean;
      axisMaxMinutes?: number | null;
      allDevicesReasons?: string[];
      ocrFailed?: boolean;
      ocrError?: string | null;
      /** True when this PROCESS_IMAGE left the worker with a reusable OCR runtime. */
      ocrInitialized?: boolean;
      /** Worker-reported Emscripten linear memory after OCR/tessdata warmup. */
      wasmHeapBytes?: number;
    }
  | {
      ok: false;
      error: string;
      /** Set when the failure was a WASM ABI mismatch (stale / mismatched cached
       *  pipeline bundle). The main thread self-heals on this — drops the bad
       *  caches and reloads once. See lib/wasmRecovery.ts. */
      abiMismatch?: boolean;
      /** Best-effort partial result for diagnostics — never treated as data. */
      title?: string | null;
      total?: string | null;
      gridCoordinates?: GridCoordinates;
      suspectedAllDevices?: boolean;
      axisMaxMinutes?: number | null;
      allDevicesReasons?: string[];
      ocrFailed?: boolean;
      ocrError?: string | null;
      /** True when this PROCESS_IMAGE left the worker with a reusable OCR runtime. */
      ocrInitialized?: boolean;
      /** Worker-reported Emscripten linear memory after OCR/tessdata warmup. */
      wasmHeapBytes?: number;
    };

export interface ProgressPayload {
  stage:
    | "loading"
    | "preprocessing"
    | "ocr_title"
    | "ocr_total"
    | "ocr_hourly"
    | "complete";
  progress: number;
  message?: string;
}

export interface InitializeCompletePayload {
  initialized: boolean;
  /** Worker-reported Emscripten linear memory after OCR/tessdata warmup. Used
   *  by the main thread to tighten future OCR pool sizing from runtime
   *  evidence instead of only a static estimate. */
  wasmHeapBytes?: number;
}

export interface ExtractTitleResponsePayload {
  title: string | null;
}

export interface ExtractTotalResponsePayload {
  total: string | null;
}

export interface ExtractHourlyDataResponsePayload {
  hourlyData: HourlyData;
}

export interface ExtractBarsResponsePayload {
  hourlyData: HourlyData;
  gridCoordinates?: GridCoordinates;
  alignmentScore?: number | null;
  gridRegistrationScore?: number | null;
}

export interface DetectGridResponsePayload {
  gridCoordinates: GridCoordinates | null;
  /** Failure reason from the Rust grid detector (e.g. weekly/landscape/unsupported),
   * surfaced so the UI can show an actionable message instead of a generic one. */
  error?: string;
  /** True when the detector positively identified the WEEKLY (7-column) view. */
  isWeekly?: boolean;
}

export interface MeasureColumnFillsResponsePayload {
  /** Fill ratio (0..1) per hourly column, null where it could not be measured. */
  fills: (number | null)[];
}

// ── Response messages (discriminated union on `type`) ────────────────────────

export interface ProcessImageResponse {
  type: "PROCESS_IMAGE_COMPLETE";
  id: string;
  payload: ProcessImageResultPayload;
}

export interface ProgressUpdate {
  type: "PROGRESS";
  id: string;
  payload: ProgressPayload;
}

export interface InitializeCompleteResponse {
  type: "INITIALIZE_COMPLETE";
  id: string;
  payload: InitializeCompletePayload;
}

export interface ExtractTitleResponse {
  type: "EXTRACT_TITLE_COMPLETE";
  id: string;
  payload: ExtractTitleResponsePayload;
}

export interface ExtractTotalResponse {
  type: "EXTRACT_TOTAL_COMPLETE";
  id: string;
  payload: ExtractTotalResponsePayload;
}

export interface ExtractHourlyDataResponse {
  type: "EXTRACT_HOURLY_DATA_COMPLETE";
  id: string;
  payload: ExtractHourlyDataResponsePayload;
}

export interface ExtractBarsResponse {
  type: "EXTRACT_BARS_COMPLETE";
  id: string;
  payload: ExtractBarsResponsePayload;
}

export interface DetectGridResponse {
  type: "DETECT_GRID_COMPLETE";
  id: string;
  payload: DetectGridResponsePayload;
}

export interface MeasureColumnFillsResponse {
  type: "MEASURE_COLUMN_FILLS_COMPLETE";
  id: string;
  payload: MeasureColumnFillsResponsePayload;
}

export interface ErrorResponse {
  abiMismatch?: boolean;
  type: "ERROR";
  id: string;
  error: string;
  errorName?: string;
  errorStack?: string;
  errorDetails?: string;
}

/**
 * ARC-13: discriminated union over `type` so the service's response handler
 * is exhaustive-checkable.
 */
export type WorkerResponse =
  | ProcessImageResponse
  | ProgressUpdate
  | InitializeCompleteResponse
  | ExtractTitleResponse
  | ExtractTotalResponse
  | ExtractHourlyDataResponse
  | ExtractBarsResponse
  | DetectGridResponse
  | MeasureColumnFillsResponse
  | ErrorResponse;

/** Payload union — kept for callers that need the shape independent of `type`. */
export type WorkerResponsePayload = Extract<
  WorkerResponse,
  { payload: unknown }
>["payload"];
