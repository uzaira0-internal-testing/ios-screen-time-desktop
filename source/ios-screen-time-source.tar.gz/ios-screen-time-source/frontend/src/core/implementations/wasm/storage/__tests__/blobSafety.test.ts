import "fake-indexeddb/auto";
import { afterEach, beforeEach, expect, test } from "bun:test";
import { db } from "../database";
import { IndexedDBStorageService } from "../IndexedDBStorageService";
import type { Screenshot } from "@/types";
import {
  clearAllOpfsBlobs, createObjectURL, deleteAllBlobsForScreenshot,
  retrieveImageBlob, retrieveStageBlob, revokeAllObjectURLs, storeImageBlob, storeStageBlob,
} from "../opfsBlobStorage";

const deps = (db as unknown as { _deps: { indexedDB: unknown; IDBKeyRange: unknown } })._deps;
deps.indexedDB = globalThis.indexedDB;
deps.IDBKeyRange = globalThis.IDBKeyRange;
const originalNavigator = Object.getOwnPropertyDescriptor(globalThis, "navigator");
const files = new Map<string, Blob>();
let writeFailure = false;
let deletionFailure = false;
let accessFailure = false;
const root = {
  getDirectoryHandle: async () => root,
  getFileHandle: async (name: string, options?: { create?: boolean }) => {
    if (!files.has(name)) {
      if (!options?.create) throw new DOMException("missing", "NotFoundError");
      files.set(name, new Blob());
    }
    return {
      getFile: async () => files.get(name)!,
      createWritable: async () => {
        if (writeFailure) throw new Error("write unavailable");
        return { write: async (blob: Blob) => { files.set(name, blob); }, close: async () => {}, abort: async () => {} };
      },
    };
  },
  removeEntry: async (name: string) => {
    if (deletionFailure) throw new DOMException("locked", "NoModificationAllowedError");
    if (!files.delete(name)) throw new DOMException("missing", "NotFoundError");
  },
  async *[Symbol.asyncIterator]() {
    for (const name of files.keys()) yield [name, { kind: "file", getFile: async () => files.get(name)! }];
  },
};

beforeEach(async () => {
  await db.delete();
  await db.open();
  files.clear();
  writeFailure = deletionFailure = accessFailure = false;
  Object.defineProperty(globalThis, "navigator", { configurable: true, value: {
    storage: { getDirectory: async () => {
      if (accessFailure) throw new Error("transient directory failure");
      return root;
    } },
  } });
});
afterEach(async () => {
  revokeAllObjectURLs();
  if (originalNavigator) Object.defineProperty(globalThis, "navigator", originalNavigator);
  else Reflect.deleteProperty(globalThis, "navigator");
  await db.delete();
});

test("clear-all aborts on a transient OPFS access failure before deleting IDB blobs", async () => {
  await db.imageBlobs.put({ screenshotId: 1, blob: new Blob(["keep"]), uploadedAt: new Date() });
  accessFailure = true;
  await expect(clearAllOpfsBlobs()).rejects.toThrow("transient");
  expect(await db.imageBlobs.count()).toBe(1);
});

test("failed OPFS main and stage writes cannot shadow successful IDB fallbacks", async () => {
  writeFailure = true;
  const blob = new Blob(["authoritative"]);
  await storeImageBlob(1, blob);
  await storeStageBlob(1, "cropping", blob);
  expect(await (await retrieveImageBlob(1))?.text()).toBe("authoritative");
  expect(await (await retrieveStageBlob(1, "cropping"))?.text()).toBe("authoritative");
});

test("blob deletion rejects real OPFS failures and keeps fallback data for retry", async () => {
  await storeImageBlob(1, new Blob(["keep"]));
  await db.screenshots.put({ id: 1, group_id: "g" } as Screenshot);
  await db.imageBlobs.put({ screenshotId: 1, blob: new Blob(["keep"]), uploadedAt: new Date() });
  deletionFailure = true;
  await expect(deleteAllBlobsForScreenshot(1)).rejects.toThrow("locked");
  const storage = new IndexedDBStorageService();
  await expect(storage.deleteScreenshot(1)).rejects.toThrow("locked");
  await expect(storage.deleteScreenshotsByGroup("g")).rejects.toThrow("locked");
  expect(await db.screenshots.get(1)).toBeDefined();
  expect(await db.imageBlobs.get(1)).toBeDefined();
  expect(files.has("1.img")).toBe(true);
});

test("a changed blob gets a fresh object URL for the same screenshot", async () => {
  const oldBlob = new Blob(["old"]);
  const first = await createObjectURL(1, oldBlob);
  expect(await createObjectURL(1, oldBlob)).toBe(first);
  expect(await createObjectURL(1, new Blob(["new"]))).not.toBe(first);
});

test("unchanged stored image revisions reuse URLs across fresh Blob reads", async () => {
  writeFailure = true;
  await storeImageBlob(1, new Blob(["old"]));
  const first = await createObjectURL(1, (await retrieveImageBlob(1))!);
  expect(await createObjectURL(1, (await retrieveImageBlob(1))!)).toBe(first);
  await storeImageBlob(1, new Blob(["new"]));
  expect(await createObjectURL(1, (await retrieveImageBlob(1))!)).not.toBe(first);
});
