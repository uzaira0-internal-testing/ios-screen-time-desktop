/**
 * Pure ZIP encode/decode for a workspace archive (roadmap #22).
 *
 * fflate is loaded via dynamic import so it lands in its own code-split chunk — the
 * cost is paid only when a user actually exports/imports, never on the critical path
 * (keeps the #5 bundle budget honest).
 */
import {
  ARCHIVE_PATHS,
  WORKSPACE_FORMAT_ID,
  type BlobIndexEntry,
  type WorkspaceManifest,
  type WorkspaceTables,
  type WorkspacePreferences,
} from "./workspaceTypes";

export class WorkspaceArchiveError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "WorkspaceArchiveError";
  }
}

export interface DecodedArchive {
  manifest: WorkspaceManifest;
  tables: WorkspaceTables;
  blobIndex: BlobIndexEntry[];
  preferences?: WorkspacePreferences;
  /** Raw bytes for a blob name (without the blobs/ prefix), or undefined if absent. */
  blob(name: string): Uint8Array | undefined;
}

export async function encodeWorkspaceArchive(
  manifest: WorkspaceManifest,
  tables: WorkspaceTables,
  blobIndex: BlobIndexEntry[],
  blobs: Map<string, Uint8Array>,
  preferences?: WorkspacePreferences,
): Promise<Blob> {
  const { zip, strToU8 } = await import("fflate");

  const files: Record<string, [Uint8Array, { level: 0 | 6 }]> = {
    [ARCHIVE_PATHS.manifest]: [strToU8(JSON.stringify(manifest, null, 2)), { level: 6 }],
    [ARCHIVE_PATHS.tables]: [strToU8(JSON.stringify(tables)), { level: 6 }],
    [ARCHIVE_PATHS.blobIndex]: [strToU8(JSON.stringify(blobIndex)), { level: 6 }],
  };
  if (preferences) files[ARCHIVE_PATHS.preferences] = [strToU8(JSON.stringify(preferences)), { level: 6 }];
  for (const [name, bytes] of blobs) {
    // Image blobs are already-compressed PNGs — store (level 0), don't waste CPU
    // re-deflating incompressible data.
    files[`${ARCHIVE_PATHS.blobDir}${name}`] = [bytes, { level: 0 }];
  }

  const zipped = await new Promise<Uint8Array>((resolve, reject) => {
    zip(files, (err, data) => (err ? reject(err) : resolve(data)));
  });
  return new Blob([zipped as BlobPart], { type: "application/zip" });
}

export async function decodeWorkspaceArchive(bytes: Uint8Array): Promise<DecodedArchive> {
  const { unzip, strFromU8 } = await import("fflate");

  const entries = await new Promise<Record<string, Uint8Array>>((resolve, reject) => {
    unzip(bytes, (err, data) => (err ? reject(err) : resolve(data)));
  });

  const readJson = <T>(path: string): T => {
    const raw = entries[path];
    if (!raw) throw new WorkspaceArchiveError(`archive is missing ${path}`);
    try {
      return JSON.parse(strFromU8(raw)) as T;
    } catch (e) {
      throw new WorkspaceArchiveError(`archive ${path} is not valid JSON: ${String(e)}`);
    }
  };

  const manifest = readJson<WorkspaceManifest>(ARCHIVE_PATHS.manifest);
  if (manifest?.format !== WORKSPACE_FORMAT_ID) {
    throw new WorkspaceArchiveError(
      `not an ios-screen-time workspace archive (format=${String(manifest?.format)})`,
    );
  }
  const tables = readJson<WorkspaceTables>(ARCHIVE_PATHS.tables);
  const blobIndex = readJson<BlobIndexEntry[]>(ARCHIVE_PATHS.blobIndex);

  return {
    manifest,
    tables,
    blobIndex,
    ...(entries[ARCHIVE_PATHS.preferences] ? { preferences: readJson<WorkspacePreferences>(ARCHIVE_PATHS.preferences) } : {}),
    blob: (name: string) => entries[`${ARCHIVE_PATHS.blobDir}${name}`],
  };
}
