/**
 * Compute a content hash for screenshot deduplication.
 *
 * Prefers SHA-256 via `crypto.subtle`. That API requires a secure context
 * (HTTPS or localhost) — and the default WASM Docker deployment serves over
 * plain HTTP, exactly where dedup is most needed. So when `crypto.subtle` is
 * unavailable we fall back to a non-cryptographic FNV-1a hash over the bytes.
 * It is not collision-proof against an adversary, but screenshot dedup only
 * needs to catch identical re-uploads — FNV-1a over the full byte stream is
 * more than sufficient for that and keeps dedup working over HTTP.
 *
 * Always returns a non-null hash so callers can dedup unconditionally; the
 * `algo` prefix keeps SHA-256 and FNV-1a hashes from ever colliding.
 */
const WEBCRYPTO_MAX_BUFFER_BYTES = 16 * 1024 * 1024;
const HASH_CHUNK_BYTES = 1024 * 1024;

function abortError(): Error {
  try {
    return new DOMException("Content hash aborted", "AbortError");
  } catch {
    const error = new Error("Content hash aborted");
    error.name = "AbortError";
    return error;
  }
}

function throwIfAborted(signal?: AbortSignal): void {
  if (signal?.aborted) throw abortError();
}

function fnv1aInit(): bigint {
  return 0xcbf29ce484222325n;
}

function fnv1aUpdate(hash: bigint, bytes: Uint8Array): bigint {
  const prime = 0x100000001b3n;
  const mask = 0xffffffffffffffffn;
  let out = hash;
  for (let i = 0; i < bytes.length; i++) {
    out = ((out ^ BigInt(bytes[i]!)) * prime) & mask;
  }
  return out;
}

function formatFnv1aHash(byteLength: number, hash: bigint): string {
  // Include the length so two streams that FNV-collide on a prefix still differ.
  return `fnv1a:${byteLength.toString(16)}:${hash.toString(16).padStart(16, "0")}`;
}

async function computeChunkedFnv1a(blob: Blob, signal?: AbortSignal): Promise<string> {
  let hash = fnv1aInit();
  for (let offset = 0; offset < blob.size; offset += HASH_CHUNK_BYTES) {
    throwIfAborted(signal);
    const chunk = blob.slice(offset, Math.min(blob.size, offset + HASH_CHUNK_BYTES));
    // eslint-disable-next-line no-await-in-loop -- sequential chunk reads keep peak memory bounded to one slice.
    const bytes = await chunk.arrayBuffer();
    throwIfAborted(signal);
    hash = fnv1aUpdate(hash, new Uint8Array(bytes));
  }
  return formatFnv1aHash(blob.size, hash);
}

export async function computeContentHash(blob: Blob, signal?: AbortSignal): Promise<string> {
  throwIfAborted(signal);
  const subtle = globalThis.crypto?.subtle;

  if (subtle && blob.size <= WEBCRYPTO_MAX_BUFFER_BYTES) {
    const buf = await blob.arrayBuffer();
    throwIfAborted(signal);
    const hash = await subtle.digest("SHA-256", buf);
    throwIfAborted(signal);
    return (
      "sha256:" +
      Array.from(new Uint8Array(hash))
        .map((b) => b.toString(16).padStart(2, "0"))
        .join("")
    );
  }

  // FNV-1a 64-bit over the full byte stream (BigInt for exact 64-bit math).
  // Read in bounded slices so large uploads never require a full-file ArrayBuffer
  // purely for dedup. WebCrypto SHA-256 has no browser streaming API.
  return computeChunkedFnv1a(blob, signal);
}
