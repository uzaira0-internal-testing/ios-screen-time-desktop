import { detectDevice, DEVICE_PROFILES } from "./deviceDetection";
import { cropPng, decodeImage } from "../processing/emscripten/pipelineLoader";
import {
  assertDecodedPixelBudget,
  type ImageDimensions,
  readImageDimensions,
} from "../utils/imageLimits";
import type { CropRect } from "./cropHistory";

export interface CropResult {
  croppedBlob: Blob;
  wasCropped: boolean;
  originalDimensions: { width: number; height: number };
  croppedDimensions: { width: number; height: number };
  deviceModel?: string | undefined;
}

export interface RectCropResult {
  croppedBlob: Blob;
  originalDimensions: { width: number; height: number };
  croppedDimensions: { width: number; height: number };
}

/**
 * Check if an image needs cropping based on its dimensions.
 * Returns true for iPad screenshots that have a sidebar to remove.
 */
export function shouldCrop(width: number, height: number): boolean {
  const result = detectDevice(width, height);
  return result.detected && result.needsCropping === true;
}

/**
 * Find the device profile matching the given dimensions within tolerance.
 * Returns the profile's crop coordinates, or null if no match.
 */
function findProfileCropCoords(
  width: number,
  height: number,
  tolerance: number = 10,
): {
  cropX: number;
  cropY: number;
  cropWidth: number;
  cropHeight: number;
} | null {
  // Ensure portrait orientation for matching
  const w = Math.min(width, height);
  const h = Math.max(width, height);

  for (const profile of DEVICE_PROFILES) {
    if (
      profile.category !== "ipad" ||
      profile.cropX === undefined ||
      profile.cropWidth === undefined ||
      profile.cropY === undefined ||
      profile.cropHeight === undefined
    ) {
      continue;
    }

    const pW = Math.min(profile.width, profile.height);
    const pH = Math.max(profile.width, profile.height);

    if (Math.abs(w - pW) <= tolerance && Math.abs(h - pH) <= tolerance) {
      return {
        cropX: profile.cropX,
        cropY: profile.cropY,
        cropWidth: profile.cropWidth,
        cropHeight: profile.cropHeight,
      };
    }
  }
  return null;
}

/**
 * The rectangle the pipeline's auto-crop would apply to an image of these
 * dimensions, in original-image coordinates — or null if the image isn't a
 * crop-needing iPad profile. Deterministic from dimensions alone, so the crop
 * undo/redo history can seed the auto-crop state without storing image bytes.
 */
export function autoCropRect(width: number, height: number): CropRect | null {
  const coords = findProfileCropCoords(width, height);
  if (!coords) return null;
  return {
    left: coords.cropX,
    top: coords.cropY,
    right: coords.cropX + coords.cropWidth,
    bottom: coords.cropY + coords.cropHeight,
  };
}

function abortError(message = "Crop operation aborted"): Error {
  try {
    return new DOMException(message, "AbortError");
  } catch {
    const error = new Error(message);
    error.name = "AbortError";
    return error;
  }
}

function throwIfAborted(abortSignal?: AbortSignal): void {
  if (abortSignal?.aborted) throw abortError();
}

/** Header-read dimensions, falling back to a full decode for files whose
 * header the lightweight parser cannot read. */
export async function readBlobDimensions(
  blob: Blob,
  abortSignal?: AbortSignal,
): Promise<ImageDimensions> {
  throwIfAborted(abortSignal);
  const dims = await readImageDimensions(blob);
  throwIfAborted(abortSignal);
  if (dims) return dims;

  const { width, height } = await decodeImage(new Uint8Array(await blob.arrayBuffer()));
  return { width, height };
}

/**
 * Crop a rectangle out of `blob` in the Rust pipeline, so every browser engine
 * produces the same pixels. PNG (lossless), NOT JPEG: the downstream bar
 * extraction matches coloured bars by pixel colour, and JPEG artifacts shift
 * those colours enough to wreck detection on multi-colour / dark-mode charts.
 */
async function cropToPng(
  blob: Blob,
  dims: ImageDimensions,
  x: number,
  y: number,
  width: number,
  height: number,
  abortSignal?: AbortSignal,
): Promise<Blob> {
  assertDecodedPixelBudget(dims.width, dims.height);
  const bytes = new Uint8Array(await blob.arrayBuffer());
  throwIfAborted(abortSignal);
  const png = await cropPng(bytes, x, y, width, height);
  throwIfAborted(abortSignal);
  return new Blob([png], { type: "image/png" });
}

function validateCropRect(
  rect: CropRect,
  originalDimensions: { width: number; height: number },
): { cropWidth: number; cropHeight: number } {
  const cropWidth = rect.right - rect.left;
  const cropHeight = rect.bottom - rect.top;
  if (cropWidth <= 0 || cropHeight <= 0) {
    throw new Error(`Invalid crop dimensions: ${cropWidth}x${cropHeight}`);
  }
  if (
    rect.left < 0 ||
    rect.top < 0 ||
    rect.right > originalDimensions.width ||
    rect.bottom > originalDimensions.height
  ) {
    throw new Error(
      `Crop rectangle ${rect.left},${rect.top},${rect.right},${rect.bottom} exceeds original image bounds ${originalDimensions.width}x${originalDimensions.height}`,
    );
  }
  assertDecodedPixelBudget(cropWidth, cropHeight);
  return { cropWidth, cropHeight };
}

/** Crop an arbitrary rectangle from a blob. */
export async function cropBlobToRect(
  imageBlob: Blob,
  rect: CropRect,
  knownDimensions?: { width: number; height: number },
  abortSignal?: AbortSignal,
): Promise<RectCropResult> {
  throwIfAborted(abortSignal);
  const originalDimensions = knownDimensions ?? await readBlobDimensions(imageBlob, abortSignal);
  const { cropWidth, cropHeight } = validateCropRect(rect, originalDimensions);
  const croppedBlob = await cropToPng(
    imageBlob,
    originalDimensions,
    rect.left,
    rect.top,
    cropWidth,
    cropHeight,
    abortSignal,
  );
  return {
    croppedBlob,
    originalDimensions,
    croppedDimensions: { width: cropWidth, height: cropHeight },
  };
}

/**
 * Crop an iPad screenshot by removing the left sidebar. Dimensions come from
 * the file header, so a screenshot that needs no crop is never decoded.
 */
export async function cropScreenshot(imageBlob: Blob, abortSignal?: AbortSignal): Promise<CropResult> {
  const { width, height } = await readBlobDimensions(imageBlob, abortSignal);
  const detection = detectDevice(width, height);
  const needsCrop = detection.detected && detection.needsCropping === true;
  const cropCoords = needsCrop ? findProfileCropCoords(width, height) : null;

  if (!cropCoords) {
    if (needsCrop) {
      console.warn(`[cropping] Device detection indicated cropping needed but no crop profile found for ${width}x${height}`);
    }
    return {
      croppedBlob: imageBlob,
      wasCropped: false,
      originalDimensions: { width, height },
      croppedDimensions: { width, height },
      deviceModel: detection.model,
    };
  }

  const { cropX, cropY, cropWidth, cropHeight } = cropCoords;
  const croppedBlob = await cropToPng(
    imageBlob,
    { width, height },
    cropX,
    cropY,
    cropWidth,
    cropHeight,
    abortSignal,
  );
  return {
    croppedBlob,
    wasCropped: true,
    originalDimensions: { width, height },
    croppedDimensions: { width: cropWidth, height: cropHeight },
    deviceModel: detection.model,
  };
}
