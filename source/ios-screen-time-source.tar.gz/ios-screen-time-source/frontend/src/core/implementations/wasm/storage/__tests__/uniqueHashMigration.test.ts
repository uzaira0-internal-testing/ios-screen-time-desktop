import "fake-indexeddb/auto";
import Dexie from "dexie";
import { expect, test } from "bun:test";
import { ScreenshotDB } from "../database/ScreenshotDB";

test("v6 duplicate content hashes are deduplicated before the v7 unique index", async () => {
  Dexie.dependencies.indexedDB = globalThis.indexedDB;
  Dexie.dependencies.IDBKeyRange = globalThis.IDBKeyRange;
  await Dexie.delete("ScreenshotProcessorDB");
  const old = new Dexie("ScreenshotProcessorDB");
  old.version(6).stores({
    screenshots: "++id, content_hash", annotations: "++id, screenshot_id",
    imageBlobs: "screenshotId", settings: "++id, &key", processingQueue: "++id",
    groups: "&id", syncRecords: "++id, &[entity_type+localId]",
  });
  await old.table("screenshots").bulkAdd([{ id: 1, content_hash: "same" }, { id: 2, content_hash: "same" }]);
  old.close();
  const upgraded = new ScreenshotDB();
  try {
    await upgraded.open();
    expect((await upgraded.screenshots.toArray()).map((s) => s.id)).toEqual([2]);
    expect(upgraded.verno).toBe(7);
  } finally {
    await upgraded.delete();
  }
});
