import { describe, expect, test } from "bun:test";

import { ImageTooLargeError } from "../../utils/imageLimits";
import { cropBlobToRect, cropScreenshot } from "../cropping";

function u32be(n: number): number[] {
  return [(n >>> 24) & 0xff, (n >>> 16) & 0xff, (n >>> 8) & 0xff, n & 0xff];
}

function pngBlob(width: number, height: number): Blob {
  return new Blob([
    new Uint8Array([
      0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
      ...u32be(13),
      0x49, 0x48, 0x44, 0x52,
      ...u32be(width),
      ...u32be(height),
      0x08, 0x06, 0x00, 0x00, 0x00,
    ]),
  ], { type: "image/png" });
}

// No pipeline module is loadable under bun, so any path that reaches a decode
// would reject: these tests pass only if the crop stops before decoding.
describe("cropScreenshot", () => {
  test("returns no-crop results from header dimensions without decoding pixels", async () => {
    const blob = pngBlob(1170, 2532);
    const result = await cropScreenshot(blob);

    expect(result.wasCropped).toBe(false);
    expect(result.croppedBlob).toBe(blob);
    expect(result.originalDimensions).toEqual({ width: 1170, height: 2532 });
    expect(result.croppedDimensions).toEqual({ width: 1170, height: 2532 });
  });

  test("rejects an already-aborted crop before decoding pixels", async () => {
    const controller = new AbortController();
    controller.abort();

    await expect(cropScreenshot(pngBlob(2048, 2732), controller.signal)).rejects.toMatchObject({
      name: "AbortError",
    });
  });

  test("rejects an oversized image before decoding pixels", async () => {
    await expect(
      cropBlobToRect(pngBlob(10_000, 10_000), { left: 0, top: 0, right: 10, bottom: 10 }),
    ).rejects.toThrow(ImageTooLargeError);
  });
});
