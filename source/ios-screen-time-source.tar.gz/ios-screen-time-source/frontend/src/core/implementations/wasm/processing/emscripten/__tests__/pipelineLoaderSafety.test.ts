import { afterEach, expect, it, mock, spyOn } from "bun:test";

type Loader = typeof import("../pipelineLoader");
const originalFetch = globalThis.fetch;
let sequence = 0;

afterEach(() => {
  globalThis.fetch = originalFetch;
  Reflect.deleteProperty(globalThis, "__pipelineSafetyModule");
  mock.restore();
});

async function fixture() {
  const mod = {
    HEAPU8: new Uint8Array(2 * 1024 * 1024),
    FS: {
      mkdir: mock((_path: string) => {}),
      writeFile: mock((_path: string, _bytes: Uint8Array) => {}),
      symlink: mock((_target: string, _path: string) => {}),
    },
    _pipeline_alloc: mock((_len: number) => 1024),
    _pipeline_free: mock((_ptr: number, _len: number) => {}),
    _pipeline_set_language: mock((_ptr: number) => {}),
    _pipeline_process: mock(() => 0),
    _pipeline_extract_bars: mock(() => 0),
    _pipeline_detect_grid: mock(() => 0),
    _pipeline_extract_ocr: mock(() => 0),
    _pipeline_phi_words: mock(() => 0),
    _pipeline_dhash: mock(() => 0),
    _pipeline_column_fills: mock((..._args: number[]) => 0),
    _pipeline_redact_png: mock(() => 0),
  };
  Reflect.set(globalThis, "__pipelineSafetyModule", mod);
  globalThis.fetch = mock(async (input: string | URL | Request) => {
    const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
    if (url.endsWith(".sha256")) return new Response(null, { status: 404 });
    return new Response("var IosScreenTimePipeline = async () => globalThis.__pipelineSafetyModule;");
  }) as unknown as typeof fetch;
  const path = `../pipelineLoader.ts?safety=${sequence++}`;
  const loader = await import(path) as Loader;
  loader.setPreloadedTessdata(new ArrayBuffer(4));
  loader.setPreloadedLanguages("eng");
  await loader.warmOcrRuntime();
  mod._pipeline_alloc.mockClear();
  mod._pipeline_free.mockClear();
  return { loader, mod };
}

it("rejects every null allocation before writes or exports and frees earlier buffers", async () => {
  const image = { width: 1, height: 1, data: new Uint8ClampedArray(4) } as ImageData;
  const grid = { upper_left: { x: 0, y: 0 }, lower_right: { x: 1, y: 1 } };
  const calls: [number, (loader: Loader) => Promise<unknown>][] = [
    [3, (l) => l.emPipelineProcess(image, "screen_time")],
    [5, (l) => l.emExtractBars(image, "screen_time", { gridCoordinates: grid })],
    [2, (l) => l.emDetectGrid(image, { method: 1 })],
    [2, (l) => l.emExtractOcr(image)],
    [2, (l) => l.emPhiWords(image)],
    [2, (l) => l.perceptualHashHex(new Uint8Array(4))],
    [2, (l) => l.emColumnFills(image, { x: 0, y: 0, w: 1, h: 1 })],
    [2, (l) => l.redactPng(new Uint8Array(4), [], "pixelate", 2)],
  ];
  for (const [count, call] of calls) {
    for (let failure = 0; failure < count; failure++) {
      // eslint-disable-next-line no-await-in-loop -- cases share the mocked module factory and must run sequentially
      const { loader, mod } = await fixture();
      let allocated = 0;
      const successful: [number, number][] = [];
      mod._pipeline_alloc.mockImplementation((len) => {
        if (allocated++ === failure) return 0;
        const ptr = 1024 * allocated;
        successful.push([ptr, len]);
        return ptr;
      });
      const writes = spyOn(mod.HEAPU8, "set");
      // eslint-disable-next-line no-await-in-loop -- each case must finish cleanup before the next module is installed
      await expect(call(loader)).rejects.toThrow(/allocat/i);
      expect(writes).not.toHaveBeenCalled();
      expect(mod._pipeline_free.mock.calls.sort()).toEqual(successful.sort());
      for (const method of [mod._pipeline_process, mod._pipeline_extract_bars, mod._pipeline_detect_grid,
        mod._pipeline_extract_ocr, mod._pipeline_phi_words, mod._pipeline_dhash, mod._pipeline_column_fills, mod._pipeline_redact_png]) {
        expect(method).not.toHaveBeenCalled();
      }
    }
  }
});

it("language remount accepts Emscripten EEXIST errno and rejects other mkdir errors", async () => {
  const { loader, mod } = await fixture();
  mod.FS.mkdir.mockImplementation(() => { throw Object.assign(new Error("File exists"), { errno: 20 }); });
  mod.FS.symlink.mockImplementation(() => { throw Object.assign(new Error("File exists"), { errno: 20 }); });
  loader.setPreloadedLanguages("eng+missing");
  await loader.warmOcrRuntime();
  expect(mod._pipeline_set_language).toHaveBeenCalledTimes(2);
  expect(mod.FS.writeFile.mock.calls.filter(([path]) => path === "/tesseract/eng.traineddata")).toHaveLength(0);
  mod.FS.mkdir.mockImplementation(() => { throw Object.assign(new Error("Permission denied"), { errno: 2 }); });
  loader.setPreloadedLanguages("eng");
  await expect(loader.warmOcrRuntime()).rejects.toThrow("Permission denied");
});

it("language allocation failure rejects mounting without heap writes or exports", async () => {
  const { loader, mod } = await fixture();
  mod._pipeline_alloc.mockImplementation(() => 0);
  mod._pipeline_set_language.mockClear();
  const writes = spyOn(mod.HEAPU8, "set");
  loader.setPreloadedLanguages("eng+missing");
  await expect(loader.warmOcrRuntime()).rejects.toThrow(/allocat/i);
  expect(writes).not.toHaveBeenCalled();
  expect(mod._pipeline_set_language).not.toHaveBeenCalled();
  expect(mod._pipeline_free).not.toHaveBeenCalled();
});

it("column fills decode 24 little-endian f64s and map a failed measurement to nulls", async () => {
  const { loader, mod } = await fixture();
  const image = { width: 1, height: 1, data: new Uint8ClampedArray(4) } as ImageData;
  mod._pipeline_alloc.mockImplementation((len) => (len === 24 * 8 ? 4096 : 1024));
  mod._pipeline_column_fills.mockImplementation((...args: number[]) => {
    const view = new DataView(mod.HEAPU8.buffer, args[8], 24 * 8);
    for (let i = 0; i < 24; i++) view.setFloat64(i * 8, i / 24, true);
    return 0;
  });
  const fills = await loader.emColumnFills(image, { x: 0.4, y: 0, w: 1.6, h: 1 });
  expect(fills).toEqual(Array.from({ length: 24 }, (_, i) => i / 24));
  expect(mod._pipeline_column_fills.mock.calls[0]!.slice(4, 8)).toEqual([0, 0, 2, 1]);
  expect(mod._pipeline_free.mock.calls.sort()).toEqual([[1024, 4], [4096, 24 * 8]]);

  mod._pipeline_column_fills.mockImplementation(() => -1);
  expect(await loader.emColumnFills(image, { x: 0, y: 0, w: 1, h: 1 })).toEqual(Array.from({ length: 24 }, () => null));
});
