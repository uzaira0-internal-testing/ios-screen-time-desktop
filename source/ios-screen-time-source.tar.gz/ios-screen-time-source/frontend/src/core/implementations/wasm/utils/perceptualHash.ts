/**
 * Perceptual (near-duplicate) hashing for screenshots.
 *
 * The exact-byte `content_hash` only catches identical files. Batch dumps often
 * contain the SAME screenshot re-encoded, re-saved, or screenshotted again —
 * different bytes, same picture — which slips past an exact hash. A perceptual
 * hash catches those: visually-similar images produce hashes a small Hamming
 * distance apart.
 *
 * Algorithm: dHash (difference hash) over a 33×32 greyscale downscale → 1024
 * bits. Much higher resolution than the usual 8×8 (64-bit) dHash on purpose:
 * iOS Screen Time screenshots all share the same chrome/layout, so a coarse
 * hash flags different days as duplicates. A 17×16 (256-bit) version smeared the
 * 24-column bar graph into ~16 columns — distinct days collapsed within the
 * threshold and ~65% of a real batch false-flagged. At 33×32 the chart spans
 * ~32 columns (≈one per bar), so day-to-day bar-height differences survive the
 * downscale and push distinct days well outside the threshold, while
 * "same image, re-encoded" stays a few bits apart.
 *
 * The decode, the area-average downscale and the bits are computed in the Rust
 * pipeline (`codec::dhash_hex`), so every browser engine hashes alike.
 */

import { perceptualHashHex } from "../processing/emscripten/pipelineLoader";

function abortError(): Error {
  try {
    return new DOMException("Perceptual hash aborted", "AbortError");
  } catch {
    const error = new Error("Perceptual hash aborted");
    error.name = "AbortError";
    return error;
  }
}

function isAbortError(error: unknown): boolean {
  return typeof error === "object" && error !== null && "name" in error && error.name === "AbortError";
}

function throwIfAborted(signal?: AbortSignal): void {
  if (signal?.aborted) throw abortError();
}

/**
 * Compute a 256-hex-char (1024-bit) perceptual hash, or null if the image cannot
 * be decoded. Throws AbortError when the caller cancels the upload.
 */
export async function computePerceptualHash(blob: Blob, signal?: AbortSignal): Promise<string | null> {
  try {
    throwIfAborted(signal);
    const bytes = new Uint8Array(await blob.arrayBuffer());
    throwIfAborted(signal);
    const hash = await perceptualHashHex(bytes);
    throwIfAborted(signal);
    return hash;
  } catch (error) {
    if (isAbortError(error)) throw error;
    return null;
  }
}

/**
 * Hamming distance (number of differing bits) between two hex perceptual hashes.
 * Returns Infinity if either is missing/malformed, so a bad hash never reads as
 * a match.
 */
export function hammingDistance(a: string | null | undefined, b: string | null | undefined): number {
  if (!a || !b) return Infinity;
  let x: bigint;
  try {
    x = BigInt("0x" + a) ^ BigInt("0x" + b);
  } catch {
    return Infinity;
  }
  let count = 0;
  while (x > 0n) {
    count += Number(x & 1n);
    x >>= 1n;
  }
  return count;
}

/**
 * Distance at/under which two screenshots are treated as near-duplicates.
 * 10 / 1024 bits (~1%) — tight enough that different days of the same app/view
 * don't trip it (they differ by far more at 33×32), loose enough to absorb
 * re-encoding/recompression noise on a genuinely identical image. Warn-only, so
 * a rare miss is harmless. Tune here if real-world batches over- or under-flag.
 */
export const NEAR_DUPLICATE_MAX_DISTANCE = 10;
