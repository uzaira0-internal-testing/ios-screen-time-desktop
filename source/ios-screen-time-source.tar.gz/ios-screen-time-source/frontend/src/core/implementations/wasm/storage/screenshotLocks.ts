import type { Screenshot } from "@/types";
import type { IStorageService } from "@/core/interfaces/IStorageService";

export function screenshotLockName(id: number): string {
  return `screenshot-mutation:${id}`;
}

export async function withScreenshotLock<T>(id: number, run: () => Promise<T>): Promise<T> {
  if (typeof navigator === "undefined" || !navigator.locks) return run();
  return navigator.locks.request(screenshotLockName(id), run);
}

export function screenshotInputRevision(screenshot: Screenshot): string {
  const meta = screenshot.processing_metadata;
  const preprocessing = meta?.preprocessing as { current_events?: Record<string, number> } | undefined;
  return JSON.stringify([
    meta?.crop_history,
    preprocessing?.current_events?.cropping,
    preprocessing?.current_events?.phi_redaction,
    screenshot.content_hash,
    screenshot.grid_upper_left_x, screenshot.grid_upper_left_y,
    screenshot.grid_lower_right_x, screenshot.grid_lower_right_y,
  ]);
}

export class ScreenshotInputChangedError extends Error {
  constructor() {
    super("Screenshot input changed during processing; retry with the current image");
    this.name = "ScreenshotInputChangedError";
  }
}

export async function assertScreenshotInput(
  storage: IStorageService, id: number, revision: string,
): Promise<void> {
  const fresh = await storage.getScreenshot(id);
  if (!fresh || screenshotInputRevision(fresh) !== revision) throw new ScreenshotInputChangedError();
}
