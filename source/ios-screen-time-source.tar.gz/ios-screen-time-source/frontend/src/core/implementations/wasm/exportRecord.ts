import type { Screenshot } from "@/types";
import {
  canonicalHourIndex,
  getBlockingFailureReasons,
  getDataQualityFlags,
  getReviewFlagLabels,
  hasCurrentBlockingProcessingIssue,
  isOcrFailed,
  MAX_REVIEW_HOURLY_MINUTES,
} from "@/utils/dataQuality";

/**
 * Canonical export-record builder (roadmap #21).
 *
 * One SSoT row shape feeds BOTH the CSV and JSON client-side exports, so the
 * two formats can never drift. The field order below is aligned 1:1 with
 * `EXPORT_CSV_HEADERS` (generated from `shared/export_columns.json`) and with
 * the server's `ExportRow` Pydantic model — the same canonical columns the
 * server `/export/csv` and `/export/rows.json` endpoints emit.
 *
 * This module intentionally does not import the generated headers; callers
 * pass the header list into the JSON envelope so record construction stays
 * independently testable.
 */

const META_KEYS = [
  "screenshot_id",
  "filename",
  "original_filepath",
  "group_id",
  "participant_id",
  "image_type",
  "screenshot_date",
  "uploaded_at",
  "processing_status",
  "ocr_failed",
  "failure_reasons",
  "review_flags",
  "chart_axis_max_minutes",
  "is_verified",
  "verified_by_count",
  "annotation_count",
  "has_consensus",
  "title",
  "ocr_total",
  "computed_total",
  "disagreement_count",
] as const;

export const HOUR_KEYS: readonly string[] = Array.from(
  { length: 24 },
  (_, i) => `hour_${i}`,
);

/** Canonical record keys, aligned 1:1 (and in order) with EXPORT_CSV_HEADERS. */
export const EXPORT_RECORD_KEYS: readonly string[] = [...META_KEYS, ...HOUR_KEYS];

export type ExportRecord = Record<string, string | number | null>;

export function finiteHourlyNumber(value: unknown): number | null {
  if (value == null || (typeof value === "string" && value.trim() === "")) return null;
  if (typeof value === "boolean") return null;
  const numeric = Number(value);
  return Number.isFinite(numeric) && numeric >= 0 && numeric <= MAX_REVIEW_HOURLY_MINUTES
    ? numeric
    : null;
}

/**
 * Export rows must carry actual hourly bar data. OCR-only rows with an
 * `extracted_total` but no hourly vector are preprocessing artifacts, not
 * annotation/export records.
 */
export function hasExportableHourlyValues(
  hourlyData: Record<string, unknown> | null | undefined,
): boolean {
  if (!hourlyData || Object.keys(hourlyData).length === 0) return false;
  return Object.entries(hourlyData).some(([key, val]) => {
    return canonicalHourIndex(key) !== null && finiteHourlyNumber(val) !== null;
  });
}

export function hasExportableHourlyData(s: Screenshot): boolean {
  const hourlyData = (s as Record<string, unknown>).extracted_hourly_data as Record<string, unknown> | null;
  return hasExportableHourlyValues(hourlyData);
}

/** Failed OCR rows are documentation records even when every hourly cell is blank. */
export function shouldIncludeInExport(s: Screenshot): boolean {
  const hourlyData = (s as Record<string, unknown>).extracted_hourly_data;
  const hasStoredHourlyEntries = Boolean(
    hourlyData && typeof hourlyData === "object" && Object.keys(hourlyData).length > 0,
  );
  return hasStoredHourlyEntries || getBlockingFailureReasons(s).length > 0 || isOcrFailed(s);
}

function hourlyExportFailureReasons(hourlyData: Record<string, unknown> | null): string[] {
  if (!hourlyData) return [];
  const invalidKeys: string[] = [];
  const invalidValues: string[] = [];
  for (const [key, value] of Object.entries(hourlyData)) {
    if (canonicalHourIndex(key) === null) {
      invalidKeys.push(JSON.stringify(key));
    } else if (finiteHourlyNumber(value) === null) {
      let rendered = "unserializable value";
      try {
        const json = JSON.stringify(value);
        if (json !== undefined) {
          rendered = json;
        } else if (["string", "number", "boolean", "bigint"].includes(typeof value)) {
          rendered = `${value as string | number | boolean | bigint}`;
        }
      } catch {
        // Keep deterministic fallback text for malformed legacy objects.
      }
      invalidValues.push(`${key}=${rendered}`);
    }
  }
  return [
    ...(invalidKeys.length > 0
      ? [`invalid_hour_key: Ignored non-canonical hour key(s): ${invalidKeys.join(", ")}`]
      : []),
    ...(invalidValues.length > 0
      ? [`invalid_hourly_value: Ignored invalid minute value(s): ${invalidValues.join(", ")}`]
      : []),
  ];
}

/**
 * Build one canonical export record from a screenshot. Pure — no I/O, no
 * `Date`/random — so it is fully unit-testable. Mirrors the server's
 * `_iter_export_rows` exactly (computed total, verified flag, hourly columns).
 */
export function buildExportRecord(s: Screenshot): ExportRecord {
  const sr = s as Record<string, unknown>;
  const hourlyData = sr.extracted_hourly_data as Record<string, number> | null;
  const hourly = Array.from({ length: 24 }, () => "");
  const numericHourly: Array<number | null> = Array.from({ length: 24 }, () => null);
  if (hourlyData) {
    for (const [key, val] of Object.entries(hourlyData)) {
      const idx = canonicalHourIndex(key);
      const numeric = finiteHourlyNumber(val);
      if (idx !== null && numeric !== null) {
        hourly[idx] = String(val);
        numericHourly[idx] = numeric;
      }
    }
  }
  const totalMinutes = numericHourly.reduce<number>(
    (total, value) => total + (value ?? 0),
    0,
  );
  const hours = Math.floor(totalMinutes / 60);
  const mins = Math.trunc(totalMinutes % 60);
  const computedTotal = hasExportableHourlyValues(hourlyData)
    ? (hours > 0 ? `${hours}h ${mins}m` : `${mins}m`)
    : "";
  const verifiedIds = (sr.verified_by_user_ids as number[] | null) || [];
  const quality = getDataQualityFlags(s);
  const failureReasons = [
    ...getBlockingFailureReasons(s),
    ...hourlyExportFailureReasons(hourlyData),
  ].join("; ");
  const storedProcessingStatus = (sr.processing_status as string) ?? "";
  const processingStatus =
    !["skipped", "deleted"].includes(storedProcessingStatus) &&
    hasCurrentBlockingProcessingIssue(s)
      ? "failed"
      : storedProcessingStatus;

  const record: ExportRecord = {
    screenshot_id: s.id ?? "",
    filename: (s.file_path ?? "").split(/[\\/]/).pop() || "",
    original_filepath: (sr.original_filepath as string) ?? "",
    group_id: s.group_id ?? "",
    participant_id: s.participant_id ?? "",
    image_type: (sr.image_type as string) ?? "screen_time",
    screenshot_date: (sr.screenshot_date as string) ?? "",
    uploaded_at: (sr.uploaded_at as string) ?? "",
    processing_status: processingStatus,
    ocr_failed: isOcrFailed(s) ? "Yes" : "No",
    failure_reasons: failureReasons,
    review_flags: getReviewFlagLabels(s).join("; "),
    chart_axis_max_minutes: quality.axis_max_minutes,
    is_verified: verifiedIds.length > 0 ? "Yes" : "No",
    verified_by_count: verifiedIds.length,
    annotation_count: (sr.current_annotation_count as number) ?? 0,
    has_consensus: sr.has_consensus ? "Yes" : "No",
    title: s.extracted_title ?? "",
    ocr_total: s.extracted_total ?? "",
    computed_total: computedTotal,
    disagreement_count: 0,
  };
  for (let i = 0; i < 24; i++) record[`hour_${i}`] = hourly[i] ?? "";
  return record;
}

/** Project a record into the positional CSV row (header order). */
export function recordToCsvRow(record: ExportRecord): (string | number)[] {
  return EXPORT_RECORD_KEYS.map((k) => record[k] ?? "");
}

export interface ExportJsonEnvelope {
  export_format_version: number;
  export_timestamp: string;
  total_screenshots: number;
  columns: readonly string[];
  screenshots: ExportRecord[];
}

/**
 * Assemble the JSON export envelope. Pure: the caller supplies `timestamp`
 * (so the function stays deterministic and testable) and `columns` (the SSoT
 * header list, kept out of this module to preserve its zero-dependency,
 * bundle-neutral footprint).
 */
export function buildExportJsonEnvelope(
  records: ExportRecord[],
  opts: { timestamp: string; columns: readonly string[] },
): string {
  const envelope: ExportJsonEnvelope = {
    export_format_version: 2,
    export_timestamp: opts.timestamp,
    total_screenshots: records.length,
    columns: opts.columns,
    screenshots: records,
  };
  return JSON.stringify(envelope, null, 2);
}
