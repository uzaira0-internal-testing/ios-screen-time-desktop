/**
 * Workspace export/import orchestration (roadmap #22).
 *
 * Export: read every Dexie table + every OPFS/IndexedDB blob, pack into one ZIP.
 * Import: validate the ENTIRE archive first, then (and only then) clear and restore,
 *         preserving record ids, recomputing the blob-size counter from disk, and
 *         leaving a crash-recovery sentinel set until the restore fully succeeds.
 */
import Dexie from "dexie";
import type { IStorageService } from "@/core/interfaces/IStorageService";
import { db } from "../storage/database/ScreenshotDB";
import {
  ALL_STAGES,
  recomputeBlobTotalFromDisk,
  retrieveImageBlob,
  retrieveStageBlob,
  storeImageBlob,
  storeStageBlob,
} from "../storage/opfsBlobStorage";
import {
  decodeWorkspaceArchive,
  encodeWorkspaceArchive,
  WorkspaceArchiveError,
} from "./workspaceArchive";
import {
  browserResourceNumber,
  computeWorkspaceBlobConcurrency,
  computeWorkspaceTableConcurrency,
} from "@/lib/resourceBudget";
import { clearImportSentinel, markImportStarted } from "./workspaceSentinel";
import {
  BLOB_TOTAL_SETTINGS_KEY,
  mainBlobName,
  stageBlobName,
  WORKSPACE_DB_VERSION,
  WORKSPACE_FORMAT_ID,
  WORKSPACE_FORMAT_VERSION,
  type BlobIndexEntry,
  type WorkspaceImportResult,
  type WorkspaceManifest,
  type WorkspaceTables,
} from "./workspaceTypes";

import { withScreenshotLock } from "../storage/screenshotLocks";
import { useSettingsStore } from "@/store/settingsStore";
import { LANGUAGE_PACKS } from "@/core/generated/constants";
import {
  enabledLanguageCodes, installedCodes, readLanguagePack, removeLanguagePack, restoreLanguagePack, restoreEnabledLanguageCodes,
} from "../languagePacks/languagePackStore";
import type { DecodedArchive } from "./workspaceArchive";
import type { WorkspacePreferences } from "./workspaceTypes";

// Injected by the production build (server/build.ts define); `typeof` guards the
// harness/test build where it is undefined.
declare const __APP_VERSION__: string;

export type ImportPhase =
  | "reading"
  | "validating"
  | "clearing"
  | "restoring-records"
  | "restoring-blobs"
  | "finalizing";

function workspaceBlobConcurrency(): number {
  return computeWorkspaceBlobConcurrency(
    browserResourceNumber("hardwareConcurrency"),
    browserResourceNumber("deviceMemory"),
  );
}

function workspaceTableConcurrency(): number {
  return computeWorkspaceTableConcurrency(
    browserResourceNumber("hardwareConcurrency"),
    browserResourceNumber("deviceMemory"),
  );
}

async function mapBounded<T, R>(
  items: readonly T[],
  concurrency: number,
  mapper: (item: T, index: number) => Promise<R>,
): Promise<R[]> {
  if (items.length === 0) return [];

  const results = new Array<R>(items.length);
  let cursor = 0;
  const runnerCount = Math.min(Math.max(1, Math.floor(concurrency)), items.length);

  async function runNext(): Promise<void> {
    const index = cursor;
    cursor += 1;
    if (index >= items.length) return;
    results[index] = await mapper(items[index] as T, index);
    await runNext();
  }

  await Promise.all(Array.from({ length: runnerCount }, () => runNext()));
  return results;
}

function validateArchive(archive: DecodedArchive): void {
  const { tables, manifest, blobIndex, preferences } = archive;
  const fail = (message: string): never => { throw new WorkspaceArchiveError(message); };
  const isObject = (value: unknown): value is Record<string, unknown> =>
    typeof value === "object" && value !== null && !Array.isArray(value);
  const positiveId = (value: unknown): boolean => typeof value === "number" && Number.isSafeInteger(value) && value > 0;
  if (!isObject(tables) || !isObject(manifest.counts) || !Array.isArray(blobIndex)) fail("Invalid workspace tables or blob index");
  // Keys import depends on (store keys, references, unique indexes) are required;
  // other fields are type-checked only when present, so archives from older
  // versions that never wrote them still restore.
  const required: Record<keyof WorkspaceTables, Record<string, string>> = {
    screenshots: { id: "id", file_path: "string?", image_type: "string?", uploaded_at: "string?", annotation_status: "string?", processing_status: "string?", target_annotations: "number?", current_annotation_count: "number?", has_consensus: "nullable_boolean?", uploaded_by_id: "nullable_id?", has_blocking_issues: "boolean?" },
    annotations: { id: "id", screenshot_id: "id", hourly_values: "object?", status: "string?", created_at: "string?", updated_at: "string?" },
    groups: { id: "string", name: "string?", image_type: "string?", created_at: "string?" },
    settings: { id: "id", key: "string", updatedAt: "string?" },
    processingQueue: { id: "id", screenshotId: "id", priority: "number?", status: "string?", createdAt: "string?" },
    syncRecords: { id: "id", entity_type: "string", localId: "id", sync_status: "string?" },
  };
  for (const name of Object.keys(required) as (keyof WorkspaceTables)[]) {
    const rows = tables[name];
    if (!Array.isArray(rows)) fail(`Invalid table ${name}: expected an array`);
    if (manifest.counts[name] !== rows.length) fail(`Invalid ${name} count`);
    const ids = new Set<unknown>();
    const unique = new Set<unknown>();
    for (const row of rows as unknown[]) {
      if (!isObject(row)) throw new WorkspaceArchiveError(`Invalid record in ${name}`);
      for (const [key, spec] of Object.entries(required[name])) {
        const value = row[key];
        if (spec.endsWith("?") && value === undefined) continue;
        const kind = spec.replace("?", "");
        const valid = kind === "id" ? positiveId(value)
          : kind === "nullable_id" ? value === null || positiveId(value)
          : kind === "nullable_boolean" ? value === null || typeof value === "boolean"
          : kind === "object" ? isObject(value)
          : kind === "number" ? typeof value === "number" && Number.isFinite(value)
          : kind === "string" ? typeof value === "string" && value.length > 0
          : typeof value === kind;
        if (!valid) fail(`Invalid ${name}.${key}`);
      }
      if (ids.has(row.id)) fail(`Duplicate ${name} id`);
      ids.add(row.id);
      const key = name === "screenshots" ? row.content_hash : name === "settings" ? row.key
        : name === "syncRecords" ? JSON.stringify([row.entity_type, row.localId]) : undefined;
      if (key !== undefined && key !== null) {
        if (unique.has(key)) fail(`Duplicate unique key in ${name}`);
        unique.add(key);
      }
      if (name === "settings" && !("value" in row)) fail("Missing settings.value");
      if ((name === "screenshots" || name === "groups") && row.image_type !== undefined) {
        if (typeof row.image_type !== "string" || !["battery", "screen_time"].includes(row.image_type)) fail("Invalid image_type");
      }
      if (name === "screenshots") {
        if (row.content_hash != null && typeof row.content_hash !== "string") fail("Invalid content_hash");
        if (row.processing_status !== undefined && (typeof row.processing_status !== "string" || !["pending", "processing", "completed", "failed", "skipped", "deleted"].includes(row.processing_status))) fail("Invalid processing_status");
        if (row.processing_metadata != null && !isObject(row.processing_metadata)) fail("Invalid processing_metadata");
      }
      if (name === "annotations" && isObject(row.hourly_values) &&
        Object.values(row.hourly_values).some((value) => typeof value !== "number" || !Number.isFinite(value))) fail("Invalid hourly_values");
    }
  }
  const screenshotIds = new Set(tables.screenshots.map((row) => row.id));
  const annotationIds = new Set(tables.annotations.map((row) => row.id));
  for (const row of tables.annotations) if (!screenshotIds.has(row.screenshot_id)) fail("Dangling annotation reference");
  for (const row of tables.processingQueue) if (!screenshotIds.has(row.screenshotId)) fail("Dangling queue reference");
  for (const row of tables.syncRecords) {
    const ids = row.entity_type === "screenshot" ? screenshotIds : row.entity_type === "annotation" ? annotationIds : null;
    if (!ids?.has(row.localId)) fail("Dangling sync reference");
  }
  const names = new Set<string>();
  if (manifest.counts.blobs !== blobIndex.length) fail("Invalid blob count");
  for (const entry of blobIndex) {
    if (!isObject(entry) || !screenshotIds.has(entry.screenshotId) ||
      !Number.isSafeInteger(entry.size) || entry.size <= 0 ||
      (entry.stage !== null && !(ALL_STAGES as readonly string[]).includes(entry.stage))) fail("Invalid blob entry");
    const expected = entry.stage === null ? mainBlobName(entry.screenshotId) : stageBlobName(entry.screenshotId, entry.stage);
    if (entry.name !== expected || names.has(entry.name)) fail("Invalid or duplicate blob name");
    names.add(entry.name);
  }
  for (const id of screenshotIds) if (!names.has(mainBlobName(id))) fail(`Missing required main image for screenshot ${id}`);
  if (preferences !== undefined) {
    if (!isObject(preferences) || !isObject(preferences.processing) || !Array.isArray(preferences.enabledLanguages) || !Array.isArray(preferences.languagePacks)) fail("Invalid preferences");
    for (const [key, defaultValue] of Object.entries(useSettingsStore.getState())) {
      if (typeof defaultValue === "function") continue;
      const value = (preferences.processing as unknown as Record<string, unknown>)[key];
      if (typeof value !== typeof defaultValue || (typeof value === "number" && !Number.isFinite(value))) fail(`Invalid processing preference ${key}`);
    }
    const allowedKeys = Object.entries(useSettingsStore.getState()).filter(([, value]) => typeof value !== "function").map(([key]) => key);
    if (Object.keys(preferences.processing).some((key) => !allowedKeys.includes(key))) fail("Unknown processing preference");
    const processing = preferences.processing;
    if (!["line_based", "ocr_anchored"].includes(processing.gridDetectionMethod) ||
      !["presidio", "gliner"].includes(processing.phiNerDetector) ||
      !["redbox", "blackbox", "pixelate"].includes(processing.phiRedactionMethod)) fail("Invalid processing method preference");
    for (const [value, lo, hi] of [
      [processing.maxShift, 0, 10], [processing.apportionMaxMinutes, 0, 10],
      [processing.apportionMaxPercent, 0, 20], [processing.gridRegDeadband, 0, 0.2], [processing.gridRegTol, 0.01, 0.3],
    ] as const) if (value < lo || value > hi) fail("Processing preference is out of range");
    if (!Number.isInteger(processing.maxShift) || !Number.isInteger(processing.apportionMaxMinutes)) fail("Processing preference must be an integer");
    const codes = new Set<string>();
    for (const pack of preferences.languagePacks) {
      if (!isObject(pack)) fail("Invalid language pack entry");
      const meta = LANGUAGE_PACKS.find((p) => p.code === pack.code);
      if (!meta || codes.has(pack.code) || pack.size !== meta.bytes || pack.name !== `language-packs/${pack.code}.traineddata` || archive.blob(pack.name)?.length !== pack.size) fail("Invalid or missing language pack bytes");
      codes.add(pack.code);
    }
    if (new Set(preferences.enabledLanguages).size !== preferences.enabledLanguages.length || preferences.enabledLanguages.some((code) => !codes.has(code))) fail("Enabled language is not installed");
  }
}

async function withWorkspaceScreenshotLocks<T>(ids: number[], run: () => Promise<T>, index = 0): Promise<T> {
  if (index === ids.length) return run();
  return withScreenshotLock(ids[index]!, () => withWorkspaceScreenshotLocks(ids, run, index + 1));
}

/** Serialize the full offline workspace to a downloadable ZIP Blob. */
export async function exportWorkspace(): Promise<Blob> {
  const ids = (await db.screenshots.toCollection().primaryKeys()).sort((a, b) => a - b);
  return withWorkspaceScreenshotLocks(ids, () => exportLockedWorkspace(new Set(ids)));
}

async function exportLockedWorkspace(lockedIds: Set<number>): Promise<Blob> {
  const tableEntries = await db.transaction("r",
    [db.screenshots, db.annotations, db.groups, db.settings, db.processingQueue, db.syncRecords],
    () => Dexie.waitFor(mapBounded(
    [
      { name: "screenshots", read: () => db.screenshots.toArray() },
      { name: "annotations", read: () => db.annotations.toArray() },
      { name: "groups", read: () => db.groups.toArray() },
      { name: "settings", read: () => db.settings.toArray() },
      { name: "processingQueue", read: () => db.processingQueue.toArray() },
      { name: "syncRecords", read: () => db.syncRecords.toArray() },
    ] as const,
    workspaceTableConcurrency(),
    async ({ name, read }) => [name, await read()] as const,
  )));
  const {
    screenshots,
    annotations,
    groups,
    settings,
    processingQueue,
    syncRecords,
  } = Object.fromEntries(tableEntries) as unknown as WorkspaceTables;

  if (screenshots.some((s) => !lockedIds.has(s.id))) throw new WorkspaceArchiveError("Workspace changed during export; retry the backup");

  // The blob-size counter is a derived cache — never round-trip it; it's rebuilt on import.
  const cleanSettings = settings.filter((s) => s.key !== BLOB_TOTAL_SETTINGS_KEY);

  // Enumerate every blob (main + each stage) for every screenshot, but bound the
  // Blob -> ArrayBuffer materialization. The final ZIP still owns the bytes, but
  // unbounded parallel reads add avoidable transient buffers on large workspaces.
  const tasks = screenshots.flatMap((s) => {
    const id = s.id;
    if (id === undefined || id === null) return [];
    return [
      { id, stage: null as string | null },
      ...ALL_STAGES.map((stage) => ({ id, stage: stage as string | null })),
    ];
  });
  const retrieved = await mapBounded(tasks, workspaceBlobConcurrency(), async ({ id, stage }) => {
    const blob = stage === null ? await retrieveImageBlob(id) : await retrieveStageBlob(id, stage);
    if (!blob && stage === null) throw new WorkspaceArchiveError(`Missing required main image for screenshot ${id}`);
    if (!blob) return null;
    const name = stage === null ? mainBlobName(id) : stageBlobName(id, stage);
    return { name, id, stage, bytes: new Uint8Array(await blob.arrayBuffer()), size: blob.size };
  });

  const blobs = new Map<string, Uint8Array>();
  const blobIndex: BlobIndexEntry[] = [];
  for (const r of retrieved) {
    if (!r) continue;
    blobs.set(r.name, r.bytes);
    blobIndex.push({ name: r.name, screenshotId: r.id, stage: r.stage, size: r.size });
  }

  const manifest: WorkspaceManifest = {
    format: WORKSPACE_FORMAT_ID,
    formatVersion: WORKSPACE_FORMAT_VERSION,
    dbVersion: WORKSPACE_DB_VERSION,
    appVersion: typeof __APP_VERSION__ === "string" ? __APP_VERSION__ : "unknown",
    exportedAt: new Date().toISOString(),
    counts: {
      screenshots: screenshots.length,
      annotations: annotations.length,
      groups: groups.length,
      settings: cleanSettings.length,
      processingQueue: processingQueue.length,
      syncRecords: syncRecords.length,
      blobs: blobIndex.length,
    },
  };
  const tables: WorkspaceTables = {
    screenshots,
    annotations,
    groups,
    settings: cleanSettings,
    processingQueue,
    syncRecords,
  };
  const processing = JSON.parse(JSON.stringify(useSettingsStore.getState())) as WorkspacePreferences["processing"];
  const packs = await mapBounded(await installedCodes(), workspaceBlobConcurrency(), async (code) => {
    const bytes = await readLanguagePack(code);
    if (!bytes) throw new WorkspaceArchiveError(`Missing installed language pack ${code}`);
    const name = `language-packs/${code}.traineddata`;
    blobs.set(name, bytes);
    return { code, name, size: bytes.length };
  });
  const preferences: WorkspacePreferences = { processing, enabledLanguages: enabledLanguageCodes().filter((code) => packs.some((pack) => pack.code === code)), languagePacks: packs };
  return encodeWorkspaceArchive(manifest, tables, blobIndex, blobs, preferences);
}

/**
 * Replace the current workspace with the one in `fileBytes` (a ZIP from exportWorkspace).
 *
 * Validate-before-destroy: the whole archive — format, schema version, and EVERY
 * referenced blob (present + exact size) — is checked before clearAll() runs, so a
 * corrupt/incomplete archive aborts with the existing workspace untouched.
 */
export async function importWorkspace(
  fileBytes: Uint8Array,
  storage: IStorageService,
  opts: { onProgress?: (phase: ImportPhase) => void } = {},
): Promise<WorkspaceImportResult> {
  const progress = opts.onProgress ?? (() => {});

  // 1) Decode + fully validate BEFORE touching any existing data.
  progress("reading");
  const archive = await decodeWorkspaceArchive(fileBytes);
  const { manifest, tables, blobIndex } = archive;

  if (manifest.formatVersion !== WORKSPACE_FORMAT_VERSION) {
    throw new WorkspaceArchiveError(
      `unsupported workspace format version ${manifest.formatVersion} (this app reads v${WORKSPACE_FORMAT_VERSION})`,
    );
  }
  if (manifest.dbVersion !== WORKSPACE_DB_VERSION) {
    throw new WorkspaceArchiveError(
      `this workspace was exported from database schema v${manifest.dbVersion}, but this app uses v${WORKSPACE_DB_VERSION}. Re-export from a matching app version.`,
    );
  }

  progress("validating");
  validateArchive(archive);
  for (const entry of blobIndex) {
    const bytes = archive.blob(entry.name);
    if (!bytes) {
      throw new WorkspaceArchiveError(
        `archive is missing blob "${entry.name}" — aborting before any change to your workspace`,
      );
    }
    if (bytes.length !== entry.size) {
      throw new WorkspaceArchiveError(
        `blob "${entry.name}" is truncated (${bytes.length} != ${entry.size} bytes) — aborting before any change`,
      );
    }
  }

  const ids = [...new Set([
    ...await db.screenshots.toCollection().primaryKeys(),
    ...tables.screenshots.map((row) => row.id),
  ])].sort((a, b) => a - b);
  return withWorkspaceScreenshotLocks(ids, async () => {
  // 2) Mark the operation: from here on a crash leaves a partial workspace that the
  //    next boot must flag. The sentinel is cleared only after a full success.
  markImportStarted(`${manifest.format}@${manifest.exportedAt}`);

  // 3) Replace the current workspace.
  progress("clearing");
  if (typeof localStorage !== "undefined") localStorage.removeItem("unsaved-annotations");
  await storage.clearAll();

  // 4) Restore records with original ids preserved (bulkPut keeps explicit keys, so
  //    annotation.screenshot_id and id-named blobs stay valid).
  progress("restoring-records");
  const settingsToRestore = tables.settings.filter((s) => s.key !== BLOB_TOTAL_SETTINGS_KEY);
  await db.transaction(
    "rw",
    [db.screenshots, db.annotations, db.groups, db.settings, db.processingQueue, db.syncRecords],
    async () => {
      await db.screenshots.bulkPut(tables.screenshots);
      await db.annotations.bulkPut(tables.annotations);
      await db.groups.bulkPut(tables.groups);
      await db.settings.bulkPut(settingsToRestore);
      await db.processingQueue.bulkPut(tables.processingQueue);
      await db.syncRecords.bulkPut(tables.syncRecords);
    },
  );

  // 5) Restore blobs to OPFS (or the IndexedDB fallback) under their original names.
  progress("restoring-blobs");
  await mapBounded(blobIndex, workspaceBlobConcurrency(), async (entry) => {
    const bytes = archive.blob(entry.name);
    if (!bytes) return; // already proven present in step 1; guard satisfies the type
    const blob = new Blob([bytes as BlobPart]);
    if (entry.stage === null) await storeImageBlob(entry.screenshotId, blob);
    else await storeStageBlob(entry.screenshotId, entry.stage, blob);
  });

  // 6) Rebuild the blob-size counter from disk — the parallel stores above adjust it
  //    incrementally and could drift; this is the authoritative resync.
  progress("finalizing");
  await recomputeBlobTotalFromDisk();

  if (archive.preferences) {
    const preferences = archive.preferences;
    await mapBounded(await installedCodes(), workspaceBlobConcurrency(), (code) => removeLanguagePack(code));
    await mapBounded(preferences.languagePacks, workspaceBlobConcurrency(), (pack) =>
      restoreLanguagePack(pack.code, archive.blob(pack.name)!),
    );
    restoreEnabledLanguageCodes(preferences.enabledLanguages);
    useSettingsStore.setState(preferences.processing);
    if (typeof localStorage !== "undefined") localStorage.setItem("processing-settings", JSON.stringify(preferences.processing));
  }

  // 7) Full success — drop the crash-recovery sentinel.
  clearImportSentinel();

  return {
    screenshots: tables.screenshots.length,
    annotations: tables.annotations.length,
    groups: tables.groups.length,
    settings: settingsToRestore.length,
    processingQueue: tables.processingQueue.length,
    syncRecords: tables.syncRecords.length,
    blobs: blobIndex.length,
  };
  });
}
