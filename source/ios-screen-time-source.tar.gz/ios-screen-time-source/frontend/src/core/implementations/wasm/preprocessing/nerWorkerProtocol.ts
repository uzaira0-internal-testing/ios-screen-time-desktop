/**
 * Message protocol for the NER worker (`nerWorker.ts`) and its only caller,
 * `phiDetection.ts`.
 *
 * `MessageEvent.data` is `any`, so without a declared protocol both ends read
 * and write untyped objects across the boundary and a renamed field would fail
 * silently at runtime: the worker would keep posting `entities`, the main
 * thread would keep reading `undefined`, and PHI detection would degrade to
 * regex-only with nothing logged. Declaring it here makes the two sides fail to
 * compile instead.
 */

/**
 * One aggregated entity span as the model reports it.
 *
 * `start`/`end` are character offsets into the submitted text and are REQUIRED:
 * the only consumer, `offsetToRegion`, maps them to an image bbox, so an entity
 * without offsets cannot be located. Such spans used to cross the boundary as
 * `any` and were then discarded deep inside `offsetToRegion` — both its overlap
 * comparisons are false against `undefined`, so it returned `null` and the
 * detection vanished with nothing logged. Requiring the offsets here moves that
 * discard to the worker, where it is counted and warned about instead of
 * silent. Coverage is unchanged; only its visibility improves.
 */
export interface NerEntity {
  entity_group: string;
  word: string;
  start: number;
  end: number;
  score: number;
}

/** Warm the model without submitting text. */
export interface NerInitRequest {
  type: "init";
}

/** Classify one text; `id` correlates the reply. */
export interface NerDetectRequest {
  type?: undefined;
  id: number;
  text: string;
}

export type NerRequest = NerInitRequest | NerDetectRequest;

/** Model finished loading; clears any recorded load failure. */
export interface NerReadyMessage {
  type: "ready";
}

/** Model failed to load — detection stays regex-only until it succeeds. */
export interface NerLoadErrorMessage {
  type: "error";
  error: string;
}

/** Reply to one `NerDetectRequest`. `error` set means inference failed. */
export interface NerResultMessage {
  type?: undefined;
  id: number;
  entities: NerEntity[];
  error?: string;
}

export type NerResponse =
  | NerReadyMessage
  | NerLoadErrorMessage
  | NerResultMessage;
