/**
 * OPFS write worker for engines without `FileSystemFileHandle.createWritable()`
 * (Safari before 26, including the macOS 13.3–15 WKWebView desktop shell).
 * `createSyncAccessHandle()` exists there from Safari 15.2 but only inside a
 * dedicated worker, so `opfsWrite.ts` posts the bytes here.
 *
 * Writes run one at a time: a second sync access handle on the same file
 * throws `NoModificationAllowedError`, and one write in flight bounds memory.
 */

import type { OpfsWriteRequest, OpfsWriteResponse, OpfsWriteErrorPayload } from "./opfsWrite";

// lib.dom does not declare the worker-only sync access handle.
interface SyncAccessHandle {
  truncate(size: number): void;
  write(buffer: ArrayBufferView | ArrayBuffer, options?: { at?: number }): number;
  flush(): void;
  close(): void;
}

type SyncFileHandle = FileSystemFileHandle & {
  createSyncAccessHandle(): Promise<SyncAccessHandle>;
};

function serializeError(error: unknown): OpfsWriteErrorPayload {
  if (error instanceof Error || error instanceof DOMException) {
    return {
      name: error.name,
      message: error.message,
      ...(error.stack ? { stack: error.stack } : {}),
    };
  }
  return { name: "Error", message: String(error) };
}

async function toBytes(data: OpfsWriteRequest["data"]): Promise<Uint8Array> {
  if (typeof data === "string") return new TextEncoder().encode(data);
  if (data instanceof Blob) return new Uint8Array(await data.arrayBuffer());
  if (data instanceof ArrayBuffer) return new Uint8Array(data);
  return data;
}

async function writeFile(request: OpfsWriteRequest): Promise<void> {
  let dir = await navigator.storage.getDirectory();
  for (const segment of request.path) {
    // eslint-disable-next-line no-await-in-loop -- sequential by nature: each directory is opened inside the previous one
    dir = await dir.getDirectoryHandle(segment, { create: true });
  }
  const file = (await dir.getFileHandle(request.name, { create: true })) as SyncFileHandle;
  if (typeof file.createSyncAccessHandle !== "function") {
    throw new DOMException("This browser cannot write files to its private storage", "NotSupportedError");
  }
  const bytes = await toBytes(request.data);
  const access = await file.createSyncAccessHandle();
  try {
    access.truncate(0);
    let offset = 0;
    while (offset < bytes.byteLength) {
      const written = access.write(bytes.subarray(offset), { at: offset });
      if (written <= 0) {
        throw new DOMException(`Wrote ${offset} of ${bytes.byteLength} bytes`, "QuotaExceededError");
      }
      offset += written;
    }
    access.flush();
  } catch (error) {
    try { access.close(); } catch { /* already closed */ }
    // A file truncated or half-written in place is worse than none.
    await dir.removeEntry(request.name).catch(() => { /* non-fatal: the write error below is what the caller needs */ });
    throw error;
  }
  access.close();
}

let queue: Promise<void> = Promise.resolve();

self.onmessage = (event: MessageEvent<OpfsWriteRequest>) => {
  const request = event.data;
  queue = queue.then(async () => {
    try {
      await writeFile(request);
      self.postMessage({ id: request.id, type: "result" } satisfies OpfsWriteResponse);
    } catch (error) {
      self.postMessage({
        id: request.id,
        type: "error",
        error: serializeError(error),
      } satisfies OpfsWriteResponse);
    }
  });
};
