import type {
  Screenshot,
  Annotation,
  Group,
  GridCoordinates,
  ProcessingResult,
  QueueStats,
  ScreenshotListResponse,
  ScreenshotListParams,
  NavigationResponse,
  NavigationParams,
} from "@/types";
import type { ImageType } from "@/types";
import type { IScreenshotService } from "@/core/interfaces";
import type {
  UploadDedupeStats,
  UploadSchedulerSnapshot,
  UploadSchedulerStageStats,
} from "@/core/interfaces/IScreenshotService";
import type { IStorageService } from "@/core/interfaces";
import {
  withScreenshotLock, screenshotInputRevision, assertScreenshotInput, ScreenshotInputChangedError,
} from "./storage/screenshotLocks";
import { extractGridCoords } from "@/store/slices/helpers";
import type { IProcessingService, ProcessingProgress } from "@/core/interfaces";
import { createObjectURL, readImageDimensions } from "./storage/opfsBlobStorage";
import { mostUncertain } from "./queueOrdering";
import {
  buildExportRecord,
  recordToCsvRow,
  buildExportJsonEnvelope,
  hasExportableHourlyValues,
  shouldIncludeInExport,
  type ExportRecord,
} from "./exportRecord";
import { computeContentHash } from "./utils/contentHash";
import { computePerceptualHash, NEAR_DUPLICATE_MAX_DISTANCE } from "./utils/perceptualHash";
import { createSemaphore, type Semaphore } from "./utils/semaphore";
import { useAuthStore } from "@/store/authStore";
import { DuplicateScreenshotError } from "@/core/errors";
import {
  browserResourceNumber,
  computeUploadContentHashConcurrency,
  computeUploadImportConcurrency,
  computeUploadPerceptualHashConcurrency,
} from "@/lib/resourceBudget";
import {
  assertValidHourlyData,
  getDataQualityFlags,
  hasCurrentBlockingProcessingIssue,
  isOcrFailed,
  mergeDataQualityEvidence,
  readAxisDirection,
  reconcileDataQualityIssues,
  withAxisDirection,
  withDataQualityFlags,
  withOcrFailureHistory,
} from "@/utils/dataQuality";

function abortError(message = "Screenshot import aborted"): Error {
  try {
    return new DOMException(message, "AbortError");
  } catch {
    const error = new Error(message);
    error.name = "AbortError";
    return error;
  }
}

function throwIfAborted(signal?: AbortSignal): void {
  if (signal?.aborted) throw abortError();
}

function monotonicNow(): number {
  return typeof performance !== "undefined" && typeof performance.now === "function"
    ? performance.now()
    : Date.now();
}

function isAbortLike(error: unknown, signal?: AbortSignal): boolean {
  return signal?.aborted === true || (error instanceof Error && error.name === "AbortError");
}

/**
 * Shape check for a grid saved in localStorage. Mirrors the original inline
 * validation exactly (all four corner fields merely present) so that behavior
 * is unchanged — it only replaces `any` member access with a typed narrowing.
 */
function isGridCoordinatesShape(value: unknown): value is GridCoordinates {
  const candidate = value as
    | { upper_left?: { x?: unknown; y?: unknown }; lower_right?: { x?: unknown; y?: unknown } }
    | null
    | undefined;
  return (
    candidate?.upper_left?.x !== undefined &&
    candidate?.upper_left?.y !== undefined &&
    candidate?.lower_right?.x !== undefined &&
    candidate?.lower_right?.y !== undefined
  );
}

function rate(numerator: number, denominator: number): number {
  return denominator > 0 ? numerator / denominator : 0;
}

function overlaySingleAuthoritativeAnnotation(
  screenshot: Screenshot,
  annotationsByScreenshot: ReadonlyMap<number, Annotation[]>,
): Screenshot {
  const annotations = annotationsByScreenshot.get(screenshot.id) ?? [];
  if (annotations.length !== 1) return screenshot;
  const annotation = annotations[0]!;
  return {
    ...screenshot,
    extracted_hourly_data: annotation.hourly_values,
    extracted_title: annotation.extracted_title ?? null,
    extracted_total: annotation.extracted_total ?? null,
    current_annotation_count: 1,
  };
}

type UploadStage = "import" | "content_hash" | "perceptual_hash";

interface MutableUploadStageStats {
  configuredConcurrency: number;
  accepted: number;
  dispatched: number;
  completed: number;
  skipped: number;
  failed: number;
  cancelled: number;
  currentQueued: number;
  currentInFlight: number;
  maxQueueDepth: number;
  maxInFlight: number;
  totalRunMs: number;
  maxRunMs: number;
}

export class WASMScreenshotService implements IScreenshotService {
  private storageService: IStorageService;
  private processingService: IProcessingService;
  private processingInProgress = new Set<number>();
  // Guards against concurrent uploads of the same content hash
  private uploadingHashes = new Set<string>();
  private uploadImportGate: Semaphore | null = null;
  private contentHashGate: Semaphore | null = null;
  private perceptualHashGate: Semaphore | null = null;
  private uploadSchedulerStats: Partial<Record<UploadStage, MutableUploadStageStats>> = {};
  private readonly uploadDedupeStats: UploadDedupeStats = {
    exactDuplicatesSkipped: 0,
    inFlightDuplicatesRejected: 0,
    constraintDuplicatesRejected: 0,
    nearDuplicatesFlagged: 0,
  };

  constructor(
    storageService: IStorageService,
    processingService: IProcessingService,
  ) {
    this.storageService = storageService;
    this.processingService = processingService;
  }

  private getUploadImportGate(): Semaphore {
    if (!this.uploadImportGate) {
      this.uploadImportGate = createSemaphore(
        computeUploadImportConcurrency(
          browserResourceNumber("hardwareConcurrency"),
          browserResourceNumber("deviceMemory"),
        ),
      );
    }
    return this.uploadImportGate;
  }

  private getContentHashGate(): Semaphore {
    if (!this.contentHashGate) {
      this.contentHashGate = createSemaphore(
        computeUploadContentHashConcurrency(
          browserResourceNumber("hardwareConcurrency"),
          browserResourceNumber("deviceMemory"),
        ),
      );
    }
    return this.contentHashGate;
  }

  private getPerceptualHashGate(): Semaphore {
    if (!this.perceptualHashGate) {
      this.perceptualHashGate = createSemaphore(
        computeUploadPerceptualHashConcurrency(
          browserResourceNumber("hardwareConcurrency"),
          browserResourceNumber("deviceMemory"),
        ),
      );
    }
    return this.perceptualHashGate;
  }

  getUploadSchedulerSnapshot(): UploadSchedulerSnapshot {
    const stages: Record<string, UploadSchedulerStageStats> = {};
    for (const stage of ["import", "content_hash", "perceptual_hash"] as const) {
      const stats = this.uploadStageStats(stage);
      const attempted = stats.completed + stats.failed;
      const accounted = stats.completed + stats.skipped + stats.failed + stats.cancelled;
      stages[stage] = {
        ...stats,
        averageRunMs: stats.dispatched > 0 ? stats.totalRunMs / stats.dispatched : 0,
        averageItemsPerSecond: rate(accounted, stats.totalRunMs / 1000),
        failureRate: rate(stats.failed, attempted),
        cancellationRate: rate(stats.cancelled, accounted),
      };
    }
    return { stages, dedupe: { ...this.uploadDedupeStats } };
  }

  private uploadStageConcurrency(stage: UploadStage): number {
    const cores = browserResourceNumber("hardwareConcurrency");
    const deviceMemoryGb = browserResourceNumber("deviceMemory");
    if (stage === "content_hash") {
      return computeUploadContentHashConcurrency(cores, deviceMemoryGb);
    }
    if (stage === "perceptual_hash") {
      return computeUploadPerceptualHashConcurrency(cores, deviceMemoryGb);
    }
    return computeUploadImportConcurrency(cores, deviceMemoryGb);
  }

  private uploadStageStats(stage: UploadStage): MutableUploadStageStats {
    const existing = this.uploadSchedulerStats[stage];
    if (existing) return existing;
    const fresh: MutableUploadStageStats = {
      configuredConcurrency: this.uploadStageConcurrency(stage),
      accepted: 0,
      dispatched: 0,
      completed: 0,
      skipped: 0,
      failed: 0,
      cancelled: 0,
      currentQueued: 0,
      currentInFlight: 0,
      maxQueueDepth: 0,
      maxInFlight: 0,
      totalRunMs: 0,
      maxRunMs: 0,
    };
    this.uploadSchedulerStats[stage] = fresh;
    return fresh;
  }

  private async runUploadGate<T>(
    stage: UploadStage,
    gate: Semaphore,
    fn: () => Promise<T>,
    signal?: AbortSignal,
  ): Promise<T> {
    const stats = this.uploadStageStats(stage);
    stats.accepted++;
    stats.currentQueued++;
    stats.maxQueueDepth = Math.max(stats.maxQueueDepth, stats.currentQueued);
    let started = false;
    try {
      const result = await gate.run(async () => {
        started = true;
        stats.currentQueued = Math.max(0, stats.currentQueued - 1);
        stats.dispatched++;
        stats.currentInFlight++;
        stats.maxInFlight = Math.max(stats.maxInFlight, stats.currentInFlight);
        const startedAt = monotonicNow();
        try {
          return await fn();
        } finally {
          const runMs = Math.max(0, monotonicNow() - startedAt);
          stats.currentInFlight = Math.max(0, stats.currentInFlight - 1);
          stats.totalRunMs += runMs;
          stats.maxRunMs = Math.max(stats.maxRunMs, runMs);
        }
      }, signal);
      stats.completed++;
      return result;
    } catch (error) {
      if (!started) {
        stats.currentQueued = Math.max(0, stats.currentQueued - 1);
      }
      if (isAbortLike(error, signal)) {
        stats.cancelled++;
      } else if (error instanceof DuplicateScreenshotError) {
        stats.skipped++;
      } else {
        stats.failed++;
      }
      throw error;
    }
  }

  async getNext(
    groupId?: string,
    processingStatus?: string,
  ): Promise<Screenshot | null> {
    const filter: {
      annotation_status: string;
      group_id?: string;
      processing_status?: string;
    } = {
      annotation_status: "pending",
    };

    if (groupId) {
      filter.group_id = groupId;
    }

    if (processingStatus) {
      filter.processing_status = processingStatus;
    }

    const screenshots = await this.storageService.getAllScreenshots(filter);
    const annotatableScreenshots = processingStatus
      ? screenshots
      : screenshots.filter((s) =>
          s.processing_status === "pending" ||
          s.processing_status === "completed" ||
          s.processing_status === "failed"
        );

    // #20 uncertainty-ordered queue: serve the screenshot the automated
    // pipeline is least confident about first (lowest alignment score, then
    // lowest grid-detection confidence, then oldest). Mirrors the server-side
    // ordering in queue_repository.py.
    return mostUncertain(annotatableScreenshots);
  }

  async getById(id: number): Promise<Screenshot> {
    const screenshot = await this.storageService.getScreenshot(id);

    if (!screenshot) {
      throw new Error(`Screenshot with ID ${id} not found`);
    }

    return screenshot;
  }

  async getAll(status?: string, skip = 0, limit = 50): Promise<Screenshot[]> {
    const filter = status ? { annotation_status: status } : undefined;
    const allScreenshots = await this.storageService.getAllScreenshots(filter);

    // Ensure we always return an array, even if storage returns null/undefined
    const screenshots = Array.isArray(allScreenshots) ? allScreenshots : [];
    return screenshots.slice(skip, skip + limit);
  }

  async addScreenshots(
    file: File,
    imageType: ImageType,
    options?: {
      groupId?: string;
      participantId?: string;
      screenshotDate?: string;
      originalFilepath?: string;
      abortSignal?: AbortSignal;
    },
  ): Promise<Screenshot> {
    return this.addScreenshotInImportSlot(file, imageType, options);
  }

  private async addScreenshotInImportSlot(
    file: File,
    imageType: ImageType,
    options?: {
      groupId?: string;
      participantId?: string;
      screenshotDate?: string;
      originalFilepath?: string;
      abortSignal?: AbortSignal;
    },
  ): Promise<Screenshot> {
    // File extends Blob — no need to copy
    const uploadedAt = new Date().toISOString();
    const signal = options?.abortSignal;

    // Content-hash dedup: compute a content hash (SHA-256, or FNV-1a over
    // plain HTTP) and reject re-uploads of an identical file.
    const contentHash = await this.runUploadGate("content_hash", this.getContentHashGate(), async () => {
      throwIfAborted(signal);
      const hash = await computeContentHash(file, signal);
      throwIfAborted(signal);
      return hash;
    }, signal);
    throwIfAborted(signal);
    // `addedHash` records whether THIS call owns the in-flight guard entry,
    // so the finally block never deletes another concurrent upload's entry.
    let addedHash = false;
    // Check-and-add atomically (synchronous) to guard against concurrent batch
    // uploads. Must happen before the IndexedDB await to prevent the TOCTOU race.
    if (this.uploadingHashes.has(contentHash)) {
      this.uploadDedupeStats.inFlightDuplicatesRejected++;
      throw new DuplicateScreenshotError(0);
    }
    this.uploadingHashes.add(contentHash);
    addedHash = true;

    try {
      const existing =
        await this.storageService.findScreenshotByContentHash(contentHash);
      throwIfAborted(signal);
      if (existing) {
        this.uploadDedupeStats.exactDuplicatesSkipped++;
        throw new DuplicateScreenshotError(existing.id);
      }

      // Perceptual near-duplicate detection (warn-only). The exact content hash
      // above already rejected byte-identical files; this catches the SAME image
      // re-encoded/re-saved (different bytes), which is common in batch dumps. We
      // don't reject — we tag the new screenshot so the annotation UI surfaces a
      // dismissible "possible duplicate of #N" warning.
      const perceptualHash = await this.runUploadGate("perceptual_hash", this.getPerceptualHashGate(), async () => {
        throwIfAborted(signal);
        const hash = await computePerceptualHash(file, signal);
        throwIfAborted(signal);
        return hash;
      }, signal);
      throwIfAborted(signal);
      let nearDuplicateOf: number | null = null;
      if (perceptualHash) {
        const near = await this.storageService.findNearDuplicate(
          perceptualHash,
          options?.groupId ?? null,
          NEAR_DUPLICATE_MAX_DISTANCE,
        );
        throwIfAborted(signal);
        if (near) {
          this.uploadDedupeStats.nearDuplicatesFlagged++;
          nearDuplicateOf = near.id;
        }
      }

      const imageDimensions = await readImageDimensions(file).catch(() => {
        /* non-fatal: dimensions are optional metadata. A file the browser cannot
           decode here is still recorded and still fails loudly later in the
           pipeline, which is where an undecodable image belongs. */
        return null;
      });

      // Create screenshot record without ID (let IndexedDB auto-increment)
      // Omit id by using Partial and type assertion
      const screenshotData: Omit<Screenshot, "id"> & {
        id?: number;
        content_hash?: string | null;
        perceptual_hash?: string | null;
      } = {
        file_path: options?.originalFilepath || file.name,
        original_filepath: options?.originalFilepath ?? null,
        image_type: imageType,
        uploaded_at: uploadedAt,
        uploaded_by_id: null,
        current_annotation_count: 0,
        target_annotations: 1,
        has_consensus: null,
        annotation_status: "pending",
        processed_at: null,
        processing_status: "pending",
        extracted_title: null,
        extracted_total: null,
        extracted_hourly_data: null,
        title_y_position: null,
        grid_upper_left_x: null,
        grid_upper_left_y: null,
        grid_lower_right_x: null,
        grid_lower_right_y: null,
        processing_issues: null,
        has_blocking_issues: false,
        alignment_score: null,
        grid_registration_score: null,
        // Folder structure metadata
        participant_id: options?.participantId ?? null,
        group_id: options?.groupId ?? null,
        screenshot_date: options?.screenshotDate ?? null,
        source_id: null,
        device_type: null,
        verified_by_user_ids: null,
        // Computed readonly properties (provided as null for WASM mode)
        processing_time_seconds: null,
        alignment_score_status: null,
        grid_registration_status: null,
        // Content hash for exact dedup
        content_hash: contentHash,
        // Perceptual hash for near-duplicate detection (warn-only)
        perceptual_hash: perceptualHash,
        // Near-duplicate warning: points at the existing similar screenshot so
        // the annotation UI's DuplicateWarning can render. null when unique.
        potential_duplicate_of: nearDuplicateOf,
        duplicate_status: nearDuplicateOf != null ? "potential" : null,
        processing_metadata: imageDimensions
          ? {
              source_image: {
                dimensions: {
                  width: imageDimensions.width,
                  height: imageDimensions.height,
                },
                byte_size: file.size,
                mime_type: file.type || null,
              },
            }
          : null,
      };

      const id = await this.runUploadGate("import", this.getUploadImportGate(), async () => {
        // Save to IndexedDB - this will assign a unique auto-incremented ID.
        // Treat metadata + blob storage as one app-level import unit so aborts
        // cannot leave resumable-processing state pointing at a missing image.
        let savedId: number | undefined;
        try {
          throwIfAborted(signal);
          savedId = await this.storageService.saveScreenshot(screenshotData as Screenshot);
          throwIfAborted(signal);
          await this.storageService.saveImageBlob(savedId, file);
          throwIfAborted(signal);
        } catch (saveErr) {
          if (savedId !== undefined) {
            await this.storageService.deleteScreenshot(savedId).catch(() => { /* best-effort rollback cleanup */ });
            throw saveErr;
          }
          // A concurrent cross-tab insert can win the race on the unique
          // content_hash index (ScreenshotDB v7) — surface the resulting
          // ConstraintError as a clean DuplicateScreenshotError instead of a
          // raw Dexie error / unhandled rejection.
          if (saveErr instanceof Error && saveErr.name === "ConstraintError") {
            this.uploadDedupeStats.constraintDuplicatesRejected++;
            const existing = await this.storageService.findScreenshotByContentHash(contentHash);
            throw new DuplicateScreenshotError(existing?.id ?? 0);
          }
          throw saveErr;
        }
        if (savedId === undefined) {
          throw new Error("Screenshot import did not return an ID");
        }
        return savedId;
      }, signal);

      return { ...screenshotData, id };
    } finally {
      // Only release the guard entry this call owns — see `addedHash`.
      if (addedHash) {
        this.uploadingHashes.delete(contentHash);
      }
    }
  }

  async getImageUrl(screenshotId: number): Promise<string> {
    const imageBlob = await this.storageService.getImageBlob(screenshotId);

    if (!imageBlob) {
      throw new Error(`Image blob not found for screenshot ${screenshotId}`);
    }

    // Use LRU-cached blob URLs to avoid leaking memory
    const url = await createObjectURL(screenshotId, imageBlob);
    if (!url) {
      throw new Error(`Failed to create object URL for screenshot ${screenshotId}`);
    }
    return url;
  }

  async getProcessingResult(screenshotId: number): Promise<ProcessingResult> {
    const screenshot = await this.getById(screenshotId);
    const quality = getDataQualityFlags(screenshot);
    const issues = reconcileDataQualityIssues(screenshot.processing_issues, quality);
    const hasBlockingIssues = hasCurrentBlockingProcessingIssue({
      ...screenshot,
      processing_issues: issues,
    });
    const processingStatus =
      !["skipped", "deleted"].includes(screenshot.processing_status) && hasBlockingIssues
        ? "failed"
        : screenshot.processing_status;

    return {
      success: ["completed", "skipped"].includes(processingStatus) && !hasBlockingIssues,
      processing_status: processingStatus,
      ocr_failed: isOcrFailed(screenshot),
      ocr_error: issues.find(
        (issue) => ["ocr_processing_failed", "ocr_extraction_failed", "ocr_error"].includes(
          issue.issue_type,
        ),
      )?.description ?? null,
      skipped: processingStatus === "skipped",
      extracted_title: screenshot.extracted_title ?? null,
      extracted_total: screenshot.extracted_total ?? null,
      extracted_hourly_data: screenshot.extracted_hourly_data ?? null,
      issues,
      has_blocking_issues: hasBlockingIssues,
      is_daily_total:
        processingStatus === "skipped" && screenshot.extracted_title === "Daily Total",
      suspected_all_devices: quality.suspected_all_devices,
      axis_max_minutes: quality.axis_max_minutes,
      all_devices_reasons: quality.all_devices_reasons,
    };
  }

  async reprocess(
    screenshotId: number,
    coords: GridCoordinates,
    onProgress?: (progress: ProcessingProgress) => void,
    _maxShift?: number, // Ignored in WASM mode - optimization is server-side only
  ): Promise<ProcessingResult> {
    return withScreenshotLock(screenshotId, () => this.reprocessLocked(screenshotId, coords, onProgress, _maxShift));
  }

  private async reprocessLocked(
    screenshotId: number,
    coords: GridCoordinates,
    onProgress?: (progress: ProcessingProgress) => void,
    _maxShift?: number, // Ignored in WASM mode - optimization is server-side only
  ): Promise<ProcessingResult> {
    const screenshot = await this.getById(screenshotId);
    const inputRevision = screenshotInputRevision(screenshot);
    const imageBlob = await this.storageService.getImageBlob(screenshotId);

    if (!imageBlob) {
      throw new Error("Image blob not found for screenshot " + screenshotId);
    }

    // Re-run bar extraction against the USER-PROVIDED grid. Title and total do
    // not move with grid framing, so the local WASM path recomputes hourly bars
    // and framing scores without re-running title/total OCR. Implementations
    // without that fast path fall back to processImage.
    if (onProgress) {
      onProgress({
        stage: "ocr_hourly",
        progress: 50,
        message: "Extracting hourly data...",
      });
    }

    const result = this.processingService.extractBarsOnly
      ? {
          ...(await this.processingService.extractBarsOnly(imageBlob, coords, screenshot.image_type, {
            totalText: screenshot.extracted_total ?? null,
            // No detector runs here, so a mirrored chart's direction has to come
            // from what the original processing pass recorded.
            axisDirection: readAxisDirection(
              screenshot.processing_metadata as Record<string, unknown> | null,
            ),
            // Likewise the y-axis ceiling. An "All Devices" chart is scaled in
            // hours, so its plot is 120 minutes tall; without this, dragging the
            // grid would hand back half of every value the first pass measured.
            axisMaxMinutes: getDataQualityFlags(screenshot).axis_max_minutes,
          })),
          title: screenshot.extracted_title ?? null,
          total: screenshot.extracted_total ?? null,
          gridDetectionFailed: false,
        }
      : await this.processingService.processImage(imageBlob, {
          imageType: screenshot.image_type,
          gridCoordinates: coords,
        });

    if (onProgress) {
      onProgress({
        stage: "complete",
        progress: 100,
        message: "Processing complete",
      });
    }

    // Match the old extract-only path's contract: a grid the user placed on a
    // region with no extractable bars is a failure — throw so useGridProcessing
    // surfaces the retry toast, and persist nothing (the bad grid isn't saved).
    if (result.gridDetectionFailed === true || !hasExportableHourlyValues(result.hourlyData)) {
      throw new Error(
        result.gridDetectionError ?? "No hourly bar data could be extracted from the selected grid",
      );
    }

    const hourlyData = result.hourlyData;
    const quality = mergeDataQualityEvidence(
      screenshot.processing_metadata as Record<string, unknown> | null,
      {},
      hourlyData,
      screenshot.image_type,
    );
    const remainingIssues = (screenshot.processing_issues ?? []).filter(
      (issue) => ![
        "grid_detection_failed",
        "GridDetectionIssue",
        "BarExtractionError",
        "no_hourly_data",
      ].includes(issue.issue_type),
    );
    const qualityIssues = reconcileDataQualityIssues(remainingIssues, quality);
    const hasBlockingIssues = qualityIssues.some((issue) => issue.severity === "blocking");
    const processingStatus = hasBlockingIssues ? "failed" : "completed";

    // Keep existing title/total; update grid, hourly data, and the framing scores
    // (alignment + grid registration change with grid position — recomputing them
    // here is what keeps the "Grid Misframed" warning live across adjustments).
    await assertScreenshotInput(this.storageService, screenshotId, inputRevision);
    await this.storageService.updateScreenshot(screenshotId, {
      extracted_hourly_data: hourlyData,
      grid_upper_left_x: coords.upper_left.x,
      grid_upper_left_y: coords.upper_left.y,
      grid_lower_right_x: coords.lower_right.x,
      grid_lower_right_y: coords.lower_right.y,
      alignment_score: result.alignmentScore ?? null,
      grid_registration_score: result.gridRegistrationScore ?? null,
      processing_metadata: withOcrFailureHistory(
        withDataQualityFlags(
          screenshot.processing_metadata as Record<string, unknown> | null,
          quality,
          hourlyData,
          screenshot.image_type,
        ),
        false,
      ),
      processing_issues: qualityIssues,
      has_blocking_issues: hasBlockingIssues,
      processing_status: processingStatus,
      processed_at: new Date().toISOString(),
    });

    return {
      success: !hasBlockingIssues,
      processing_status: processingStatus,
      ocr_failed: isOcrFailed({ ...screenshot, processing_issues: qualityIssues }),
      ocr_error: qualityIssues.find(
        (issue) => issue.issue_type === "ocr_processing_failed",
      )?.description ?? null,
      skipped: false,
      extracted_title: screenshot.extracted_title ?? null, // Preserve existing
      extracted_total: screenshot.extracted_total ?? null, // Preserve existing
      extracted_hourly_data: hourlyData,
      issues: qualityIssues,
      has_blocking_issues: hasBlockingIssues,
      is_daily_total: false,
      alignment_score: result.alignmentScore ?? null,
      grid_registration_score: result.gridRegistrationScore ?? null,
      suspected_all_devices: quality.suspected_all_devices,
      axis_max_minutes: quality.axis_max_minutes,
      all_devices_reasons: quality.all_devices_reasons,
    };
  }

  async reprocessWithMethod(
    screenshotId: number,
    method: "ocr_anchored" | "line_based",
    _onProgress?: (progress: ProcessingProgress) => void,
    maxShift?: number,
  ): Promise<ProcessingResult> {
    return withScreenshotLock(screenshotId, () => this.reprocessWithMethodLocked(screenshotId, method, _onProgress, maxShift));
  }

  private async reprocessWithMethodLocked(
    screenshotId: number,
    method: "ocr_anchored" | "line_based",
    _onProgress?: (progress: ProcessingProgress) => void,
    maxShift?: number,
  ): Promise<ProcessingResult> {
    const screenshot = await this.getById(screenshotId);
    const inputRevision = screenshotInputRevision(screenshot);
    const imageBlob = await this.storageService.getImageBlob(screenshotId);

    if (!imageBlob) {
      throw new Error("Image blob not found for screenshot " + screenshotId);
    }

    const result = this.processingService.processImageWithGridDetection
      ? await this.processingService.processImageWithGridDetection(imageBlob, {
          imageType: screenshot.image_type,
          gridDetectionMethod: method,
          ...(maxShift && maxShift > 0 ? { maxShift } : {}),
        })
      : await (async () => {
          // Detect grid with the requested method, then fall back to the other if it fails.
          const fallbackMethod = method === "line_based" ? "ocr_anchored" : "line_based";
          const gridCoordinates =
            await this.processingService.detectGrid(imageBlob, screenshot.image_type, method)
            ?? await this.processingService.detectGrid(imageBlob, screenshot.image_type, fallbackMethod)
            ?? undefined;

          return this.processingService.processImage(imageBlob, {
            imageType: screenshot.image_type,
            ...(gridCoordinates ? { gridCoordinates } : {}),
            ...(maxShift && maxShift > 0 ? { maxShift } : {}),
          });
        })();

    if (result) {
      // Check if grid detection specifically failed
      const gridFailed = result.gridDetectionFailed === true;
      const hasHourlyData = hasExportableHourlyValues(result.hourlyData);
      const effectiveHourlyData = hasHourlyData
        ? result.hourlyData
        : screenshot.extracted_hourly_data ?? null;
      const effectiveTitle = result.title?.trim()
        ? result.title
        : screenshot.extracted_title ?? null;
      const effectiveTotal = result.total?.trim()
        ? result.total
        : screenshot.extracted_total ?? null;
      const effectiveGrid = result.gridCoordinates ?? (
        screenshot.grid_upper_left_x != null &&
        screenshot.grid_upper_left_y != null &&
        screenshot.grid_lower_right_x != null &&
        screenshot.grid_lower_right_y != null
          ? {
              upper_left: { x: screenshot.grid_upper_left_x, y: screenshot.grid_upper_left_y },
              lower_right: { x: screenshot.grid_lower_right_x, y: screenshot.grid_lower_right_y },
            }
          : undefined
      );
      const processingStatus =
        hasHourlyData && !gridFailed && result.ocrFailed !== true
          ? "completed"
          : "failed";

      // Build issues list with proper typing
      const issues: Array<{ issue_type: string; description: string; severity: "blocking" | "non_blocking" }> = [];
      if (result.ocrFailed) {
        issues.push({
          issue_type: "ocr_processing_failed",
          description: result.ocrError?.trim() || "OCR engine failed while extracting text",
          severity: "blocking",
        });
      }
      if (gridFailed) {
        issues.push({
          issue_type: "grid_detection_failed",
          description: result.gridDetectionError || "Could not automatically detect the graph grid. Please manually select the grid area.",
          severity: "blocking",
        });
      }
      if (!hasHourlyData) {
        issues.push({
          issue_type: "no_hourly_data",
          description: "No hourly bar data could be extracted. Please adjust the grid manually.",
          severity: "blocking",
        });
      }
      const quality = mergeDataQualityEvidence(
        screenshot.processing_metadata as Record<string, unknown> | null,
        {
          suspected_all_devices: result.suspectedAllDevices === true,
          axis_max_minutes: result.axisMaxMinutes ?? null,
          all_devices_reasons: result.allDevicesReasons ?? [],
        },
        effectiveHourlyData,
        screenshot.image_type,
      );
      if (quality.suspected_all_devices) {
        issues.push({
          issue_type: "suspected_all_devices",
          description: quality.all_devices_reasons.join("; "),
          severity: "non_blocking",
        });
      }

      await assertScreenshotInput(this.storageService, screenshotId, inputRevision);
      await this.storageService.updateScreenshot(screenshotId, {
        extracted_title: effectiveTitle,
        extracted_total: effectiveTotal,
        extracted_hourly_data: effectiveHourlyData,
        grid_upper_left_x: effectiveGrid?.upper_left.x ?? null,
        grid_upper_left_y: effectiveGrid?.upper_left.y ?? null,
        grid_lower_right_x: effectiveGrid?.lower_right.x ?? null,
        grid_lower_right_y: effectiveGrid?.lower_right.y ?? null,
        alignment_score: result.alignmentScore ?? screenshot.alignment_score ?? null,
        grid_registration_score:
          result.gridRegistrationScore ?? screenshot.grid_registration_score ?? null,
        processing_metadata: withAxisDirection(
          withOcrFailureHistory(
            withDataQualityFlags(
              screenshot.processing_metadata as Record<string, unknown> | null,
              quality,
              effectiveHourlyData,
              screenshot.image_type,
            ),
            result.ocrFailed === true,
          ),
          result.axisDirection,
        ),
        processing_issues: issues,
        has_blocking_issues: processingStatus === "failed",
        processing_status: processingStatus,
        processed_at: new Date().toISOString(),
      });

      return {
        success: processingStatus === "completed" && !gridFailed,
        processing_status: processingStatus,
        ocr_failed: result.ocrFailed === true,
        ocr_error: result.ocrError ?? null,
        skipped: false,
        extracted_title: effectiveTitle,
        extracted_total: effectiveTotal,
        extracted_hourly_data: effectiveHourlyData,
        issues: issues,
        has_blocking_issues: processingStatus === "failed",
        is_daily_total: false,
        alignment_score: result.alignmentScore ?? screenshot.alignment_score ?? null,
        grid_registration_score:
          result.gridRegistrationScore ?? screenshot.grid_registration_score ?? null,
        suspected_all_devices: quality.suspected_all_devices,
        axis_max_minutes: quality.axis_max_minutes,
        all_devices_reasons: quality.all_devices_reasons,
        processing_method: method,
        grid_detection_confidence: null,
        grid_upper_left_x: effectiveGrid?.upper_left.x ?? null,
        grid_upper_left_y: effectiveGrid?.upper_left.y ?? null,
        grid_lower_right_x: effectiveGrid?.lower_right.x ?? null,
        grid_lower_right_y: effectiveGrid?.lower_right.y ?? null,
      };
    }

    return {
      success: false,
      processing_status: "failed",
      ocr_failed: false,
      ocr_error: null,
      skipped: false,
      extracted_title: null,
      extracted_total: null,
      extracted_hourly_data: null,
      issues: [{
        issue_type: "processing_error",
        description: "Image processing returned no result.",
        severity: "blocking",
        message: null,
      }],
      has_blocking_issues: true,
      is_daily_total: false,
      suspected_all_devices: false,
      axis_max_minutes: null,
      all_devices_reasons: [],
    };
  }

  async skip(screenshotId: number, reason?: string): Promise<void> {
    const screenshot = await this.getById(screenshotId);
    const meta = (screenshot.processing_metadata ?? {}) as Record<string, unknown>;
    const update: Record<string, unknown> = {
      annotation_status: "skipped",
      processing_status: "skipped",
      processing_metadata: {
        ...meta,
        pre_skip_status:
          screenshot.processing_status === "skipped"
            ? (meta.pre_skip_status ?? "completed")
            : screenshot.processing_status,
        ...(reason ? { skip_reason: reason } : {}),
      },
    };
    await this.storageService.updateScreenshot(screenshotId, update);
  }

  async updateTitle(screenshotId: number, title: string): Promise<void> {
    await this.storageService.updateScreenshot(screenshotId, {
      extracted_title: title,
    });
  }

  async updateHourlyData(
    screenshotId: number,
    hourlyData: Record<string, number>,
  ): Promise<Screenshot> {
    assertValidHourlyData(hourlyData);
    const screenshot = await this.getById(screenshotId);
    const quality = mergeDataQualityEvidence(
      screenshot.processing_metadata as Record<string, unknown> | null,
      {},
      hourlyData,
      screenshot.image_type,
    );
    const processingMetadata = withDataQualityFlags(
      screenshot.processing_metadata as Record<string, unknown> | null,
      quality,
      hourlyData,
      screenshot.image_type,
    );
    await this.storageService.updateScreenshot(screenshotId, {
      extracted_hourly_data: hourlyData,
      processing_metadata: processingMetadata,
      processing_issues: reconcileDataQualityIssues(
        screenshot.processing_issues,
        quality,
      ),
    });
    return this.getById(screenshotId);
  }

  async processIfNeeded(screenshot: Screenshot): Promise<Screenshot> {
    return withScreenshotLock(screenshot.id, async () => {
      const fresh = await this.storageService.getScreenshot(screenshot.id);
      if (!fresh) throw new ScreenshotInputChangedError();
      return this.processIfNeededLocked(fresh);
    });
  }

  private async processIfNeededLocked(screenshot: Screenshot): Promise<Screenshot> {
    // Skip if already being processed
    if (this.processingInProgress.has(screenshot.id)) {
      return screenshot;
    }

    // IMPORTANT: Never reprocess verified screenshots - they are frozen
    const isVerified =
      screenshot.verified_by_user_ids &&
      screenshot.verified_by_user_ids.length > 0;

    if (isVerified) {
      return screenshot;
    }

    // A failed queue item is intentionally reviewable as-is. Retrying here
    // would delay annotation and could move it out of the explicit Failed
    // filter before the reviewer sees it; Reprocess remains an explicit action.
    if (screenshot.processing_status === "failed") {
      return screenshot;
    }

    // Skip re-processing if we already have hourly data (the expensive part).
    // Title/total may be null if OCR missed them — that's OK, the user can see the data.
    const needsProcessing = !screenshot.extracted_hourly_data;

    if (!needsProcessing) {
      return screenshot;
    }

    const inputRevision = screenshotInputRevision(screenshot);
    this.processingInProgress.add(screenshot.id);
    try {
      const imageBlob = await this.storageService.getImageBlob(screenshot.id);

      if (!imageBlob) {
        console.warn(
          `[WASMScreenshotService.processIfNeeded] No image blob for screenshot ${screenshot.id}, marking as failed`,
        );
        const failureUpdates: Partial<Screenshot> = {
          processing_status: "failed",
          processing_metadata: withOcrFailureHistory(
            screenshot.processing_metadata as Record<string, unknown> | null,
            false,
          ),
          processing_issues: [{
            issue_type: "image_blob_missing",
            description: "The stored image could not be loaded.",
            severity: "blocking",
          }],
          has_blocking_issues: true,
          processed_at: new Date().toISOString(),
        };
        await assertScreenshotInput(this.storageService, screenshot.id, inputRevision);
      await this.storageService.updateScreenshot(screenshot.id, failureUpdates);
        return { ...screenshot, ...failureUpdates };
      }

      // Determine grid coordinates to use (priority: locked > existing > auto-detect)
      let gridCoordsToUse: GridCoordinates | undefined = undefined;
      
      // Priority 1: Check if there's a locked grid saved in localStorage
      const lockEnabled = localStorage.getItem("gridLockEnabled") === "true";
      if (lockEnabled) {
        const savedGrid = localStorage.getItem("lastGridPosition");
        if (savedGrid) {
          try {
            const parsed: unknown = JSON.parse(savedGrid);
            // Validate shape before using — malformed JSON would crash the worker
            if (isGridCoordinatesShape(parsed)) {
              gridCoordsToUse = parsed;
            } else {
              console.warn(
                `[WASMScreenshotService.processIfNeeded] Invalid grid shape in localStorage, ignoring:`,
                parsed,
              );
            }
          } catch (e) {
            console.warn(
              `[WASMScreenshotService.processIfNeeded] Failed to parse saved grid position, clearing corrupted data:`,
              savedGrid, e,
            );
            localStorage.removeItem("lastGridPosition");
          }
        }
      }
      
      // Priority 2: Use existing screenshot grid coordinates if available
      if (!gridCoordsToUse) {
        gridCoordsToUse = extractGridCoords(screenshot);
      }

      // Use full processImage to get title, total, grid, and hourly data. When
      // no trusted grid is available, use the combined worker path so one worker
      // decodes once, tries line-based detection with OCR fallback, then runs OCR.
      const result = gridCoordsToUse
        ? await this.processingService.processImage(imageBlob, {
            imageType: screenshot.image_type,
            gridCoordinates: gridCoordsToUse,
          })
        : this.processingService.processImageWithGridDetection
          ? await this.processingService.processImageWithGridDetection(imageBlob, {
              imageType: screenshot.image_type,
              gridDetectionMethod: "line_based",
            })
          : await (async () => {
              // Fallback for implementations without the combined local path.
              const detectedGrid =
                await this.processingService.detectGrid(imageBlob, screenshot.image_type, "line_based")
                ?? await this.processingService.detectGrid(imageBlob, screenshot.image_type, "ocr_anchored")
                ?? undefined;
              if (!detectedGrid) {
                console.warn(
                  `[WASMScreenshotService.processIfNeeded] Grid detection failed for screenshot ${screenshot.id}`,
                );
              }
              return this.processingService.processImage(imageBlob, {
                imageType: screenshot.image_type,
                ...(detectedGrid ? { gridCoordinates: detectedGrid } : {}),
              });
            })();

      if (result) {
        const hasHourlyData = hasExportableHourlyValues(result.hourlyData);
        const processingStatus =
          hasHourlyData &&
          result.gridDetectionFailed !== true &&
          result.ocrFailed !== true
            ? "completed"
            : "failed";
        const quality = mergeDataQualityEvidence(
          screenshot.processing_metadata as Record<string, unknown> | null,
          {
            suspected_all_devices: result.suspectedAllDevices === true,
            axis_max_minutes: result.axisMaxMinutes ?? null,
            all_devices_reasons: result.allDevicesReasons ?? [],
          },
          result.hourlyData,
          screenshot.image_type,
        );
        const issues: NonNullable<Screenshot["processing_issues"]> = [];
        if (result.ocrFailed === true) {
          issues.push({
            issue_type: "ocr_processing_failed",
            description: result.ocrError?.trim() || "OCR engine failed while extracting text",
            severity: "blocking",
            message: null,
          });
        }
        if (result.gridDetectionFailed === true) {
          issues.push({
            issue_type: "grid_detection_failed",
            description: result.gridDetectionError || "Could not automatically detect the graph grid.",
            severity: "blocking",
            message: null,
          });
        }
        if (!hasHourlyData) {
          issues.push({
            issue_type: "no_hourly_data",
            description: "No hourly bar data could be extracted.",
            severity: "blocking",
            message: null,
          });
        }
        const reconciledIssues = reconcileDataQualityIssues(issues, quality);

        const updates: Partial<Screenshot> = {
          extracted_title: result.title || screenshot.extracted_title || null,
          extracted_total: result.total || screenshot.extracted_total || null,
          extracted_hourly_data:
            result.hourlyData || screenshot.extracted_hourly_data || null,
          grid_upper_left_x:
            result.gridCoordinates?.upper_left?.x ??
            screenshot.grid_upper_left_x ?? null,
          grid_upper_left_y:
            result.gridCoordinates?.upper_left?.y ??
            screenshot.grid_upper_left_y ?? null,
          grid_lower_right_x:
            result.gridCoordinates?.lower_right?.x ??
            screenshot.grid_lower_right_x ?? null,
          grid_lower_right_y:
            result.gridCoordinates?.lower_right?.y ??
            screenshot.grid_lower_right_y ?? null,
          alignment_score: result.alignmentScore ?? null,
          grid_registration_score: result.gridRegistrationScore ?? null,
          processing_status: processingStatus,
          processing_metadata: withAxisDirection(
            withOcrFailureHistory(
              withDataQualityFlags(
                screenshot.processing_metadata as Record<string, unknown> | null,
                quality,
                result.hourlyData,
                screenshot.image_type,
              ),
              result.ocrFailed === true,
            ),
            result.axisDirection,
          ),
          processing_issues: reconciledIssues,
          has_blocking_issues: processingStatus === "failed",
          processed_at: new Date().toISOString(),
        };

        await assertScreenshotInput(this.storageService, screenshot.id, inputRevision);
      await this.storageService.updateScreenshot(screenshot.id, updates);

        // Return updated screenshot
        return { ...screenshot, ...updates };
      }

      // processImage returned null — mark as failed to prevent infinite reprocess loop
      const failureUpdates: Partial<Screenshot> = {
        processing_status: "failed",
        processing_metadata: withOcrFailureHistory(
          screenshot.processing_metadata as Record<string, unknown> | null,
          false,
        ),
        processing_issues: [{
          issue_type: "processing_error",
          description: "Image processing returned no result.",
          severity: "blocking",
        }],
        has_blocking_issues: true,
        processed_at: new Date().toISOString(),
      };
      await assertScreenshotInput(this.storageService, screenshot.id, inputRevision);
      await this.storageService.updateScreenshot(screenshot.id, failureUpdates);
      return { ...screenshot, ...failureUpdates };
    } catch (error) {
      if (error instanceof ScreenshotInputChangedError) throw error;
      console.error(
        `[WASMScreenshotService.processIfNeeded] Failed for screenshot ${screenshot.id}:`,
        error,
      );
      try {
        const failureUpdates: Partial<Screenshot> = {
          processing_status: "failed",
          processing_metadata: withOcrFailureHistory(
            screenshot.processing_metadata as Record<string, unknown> | null,
            false,
          ),
          processing_issues: [{
            issue_type: "processing_error",
            description: error instanceof Error ? error.message : "Image processing failed.",
            severity: "blocking",
          }],
          has_blocking_issues: true,
        };
        await assertScreenshotInput(this.storageService, screenshot.id, inputRevision);
      await this.storageService.updateScreenshot(screenshot.id, failureUpdates);
        return { ...screenshot, ...failureUpdates };
      } catch (updateError) {
        console.error(
          `[WASMScreenshotService.processIfNeeded] Failed to update status:`,
          updateError,
        );
        return {
          ...screenshot,
          processing_status: "failed",
          processing_issues: [{
            issue_type: "processing_error",
            description: error instanceof Error ? error.message : "Image processing failed.",
            severity: "blocking",
          }],
          has_blocking_issues: true,
        };
      }
    } finally {
      this.processingInProgress.delete(screenshot.id);
    }
  }

  async getStats(): Promise<QueueStats> {
    // Indexed counts via the storage layer (no direct Dexie access).
    const counts = await this.storageService.getStatusCounts();

    const totalScreenshots = counts.totalScreenshots;
    const totalAnnotations = counts.totalAnnotations;
    const completedScreenshots =
      (counts.annotation.annotated ?? 0) + (counts.annotation.verified ?? 0);
    const averageAnnotations =
      totalScreenshots > 0 ? totalAnnotations / totalScreenshots : 0;

    return {
      total_screenshots: totalScreenshots,
      pending_screenshots: counts.annotation.pending ?? 0,
      completed_screenshots: completedScreenshots,
      total_annotations: totalAnnotations,
      screenshots_with_consensus: 0,
      screenshots_with_disagreements: 0,
      average_annotations_per_screenshot:
        Math.round(averageAnnotations * 100) / 100,
      users_active: 1,
      auto_processed: counts.processing.completed ?? 0,
      pending: counts.processing.pending ?? 0,
      failed: counts.processing.failed ?? 0,
      skipped: counts.processing.skipped ?? 0,
      deleted: counts.processing.deleted ?? 0,
    };
  }

  async getList(params: ScreenshotListParams): Promise<ScreenshotListResponse> {
    // Use optimized query that only fetches the page we need
    const page = params.page || 1;
    const pageSize = params.page_size || 50;
    const sortBy = params.sort_by || "id";
    const sortOrder = params.sort_order || "asc";

    // Build the query using Dexie's efficient indexed queries
    const result = await this.storageService.getScreenshotsPaginated({
      ...(params.group_id != null && { group_id: params.group_id }),
      ...(params.processing_status != null && { processing_status: params.processing_status }),
      ...(params.verified_by_me != null && { verified_by_me: params.verified_by_me }),
      ...(params.verified_by_others != null && { verified_by_others: params.verified_by_others }),
      ...(params.totals_mismatch != null && { totals_mismatch: params.totals_mismatch }),
      ...(params.search != null && { search: params.search }),
      sort_by: sortBy,
      sort_order: sortOrder,
      page,
      page_size: pageSize,
    });

    return result;
  }

  async navigate(
    screenshotId: number,
    params: NavigationParams,
  ): Promise<NavigationResponse> {
    // Use optimized navigation that doesn't load all screenshots
    const result = await this.storageService.navigateScreenshots(screenshotId, {
      ...(params.group_id != null && { group_id: params.group_id }),
      ...(params.processing_status != null && { processing_status: params.processing_status }),
      ...(params.verified_by_me != null && { verified_by_me: params.verified_by_me }),
      ...(params.verified_by_others != null && { verified_by_others: params.verified_by_others }),
      ...(params.totals_mismatch != null && { totals_mismatch: params.totals_mismatch }),
      ...(params.search != null && { search: params.search }),
      ...(params.direction != null && { direction: params.direction }),
    });

    return result;
  }

  async verify(
    screenshotId: number,
    gridCoords?: GridCoordinates,
  ): Promise<Screenshot> {
    const screenshot = await this.getById(screenshotId);
    const verifiedIds = screenshot.verified_by_user_ids || [];
    const verifiedUsernames = screenshot.verified_by_usernames || [];

    const updates: Partial<Screenshot> = {};

    // Use local user ID and username for WASM mode
    const userId = useAuthStore.getState().userId ?? 1;
    const username = useAuthStore.getState().username ?? "local";

    if (!verifiedIds.includes(userId)) {
      verifiedIds.push(userId);
      updates.verified_by_user_ids = verifiedIds;
    }
    if (!verifiedUsernames.includes(username)) {
      verifiedUsernames.push(username);
      updates.verified_by_usernames = verifiedUsernames;
    }

    // Mark as verified
    updates.annotation_status = "verified";

    // Save grid coordinates if provided (freeze grid at verification time)
    if (gridCoords) {
      updates.grid_upper_left_x = gridCoords.upper_left.x;
      updates.grid_upper_left_y = gridCoords.upper_left.y;
      updates.grid_lower_right_x = gridCoords.lower_right.x;
      updates.grid_lower_right_y = gridCoords.lower_right.y;
    }

    if (Object.keys(updates).length > 0) {
      await this.storageService.updateScreenshot(screenshotId, updates);
    }

    return {
      ...screenshot,
      ...updates,
      verified_by_user_ids: verifiedIds,
      verified_by_usernames: verifiedUsernames,
    };
  }

  async unverify(screenshotId: number): Promise<Screenshot> {
    const screenshot = await this.getById(screenshotId);
    const userId = useAuthStore.getState().userId ?? 1;
    const username = useAuthStore.getState().username ?? "local";

    let verifiedIds = screenshot.verified_by_user_ids || [];
    let verifiedUsernames = screenshot.verified_by_usernames || [];

    verifiedIds = verifiedIds.filter((id) => id !== userId);
    verifiedUsernames = verifiedUsernames.filter((u) => u !== username);

    const hasVerifiers = verifiedIds.length > 0;
    await this.storageService.updateScreenshot(screenshotId, {
      verified_by_user_ids: hasVerifiers ? verifiedIds : null,
      verified_by_usernames: hasVerifiers ? verifiedUsernames : null,
      // Revert to "annotated" if no verifiers remain
      annotation_status: hasVerifiers ? "verified" : "annotated",
    });

    return {
      ...screenshot,
      verified_by_user_ids: hasVerifiers ? verifiedIds : null,
      verified_by_usernames: hasVerifiers ? verifiedUsernames : null,
      annotation_status: hasVerifiers ? "verified" : "annotated",
    };
  }

  async recalculateOcr(screenshotId: number): Promise<string | null> {
    const imageBlob = await this.storageService.getImageBlob(screenshotId);

    if (!imageBlob) {
      console.warn(
        `[WASMScreenshotService.recalculateOcr] No image blob for screenshot ${screenshotId}`,
      );
      return null;
    }

    try {
      // Use processing service to extract total
      const total = await this.processingService.extractTotal(imageBlob);

      if (total) {
        await this.storageService.updateScreenshot(screenshotId, {
          extracted_total: total,
        });
        return total;
      }
    } catch (error) {
      console.error(
        `[WASMScreenshotService.recalculateOcr] Failed for screenshot ${screenshotId}:`,
        error,
      );
      const message = error instanceof Error ? error.message : String(error);
      if (/^OCR processing failed:/i.test(message)) {
        const screenshot = await this.getById(screenshotId);
        const quality = getDataQualityFlags(screenshot);
        const nonOcrIssues = (screenshot.processing_issues ?? []).filter((issue) => (
          !["ocr_processing_failed", "ocr_extraction_failed", "ocr_error"].includes(
            issue.issue_type,
          )
        ));
        await this.storageService.updateScreenshot(screenshotId, {
          processing_status: "failed",
          processing_metadata: withOcrFailureHistory(
            (screenshot.processing_metadata ?? {}) as Record<string, unknown>,
            true,
          ),
          processing_issues: reconcileDataQualityIssues(
            [
              ...nonOcrIssues,
              {
                issue_type: "ocr_processing_failed",
                severity: "blocking",
                description: message.replace(/^OCR processing failed:\s*/i, "") || message,
                message: null,
              },
            ],
            quality,
          ),
          has_blocking_issues: true,
          processed_at: new Date().toISOString(),
        });
      }
    }

    return null;
  }

  async getGroups(): Promise<Group[]> {
    // Single shared full-table aggregation pass (see IStorageService.getGroupAggregation).
    const rows = await this.storageService.getGroupAggregation();
    return rows.map((data) => ({
      id: data.id,
      name: data.id === "ungrouped" ? "Ungrouped" : data.id,
      image_type: data.image_type as "battery" | "screen_time",
      created_at: data.created_at,
      screenshot_count: data.count,
      processing_pending: data.processing_pending,
      processing_completed: data.processing_completed,
      processing_failed: data.processing_failed,
      processing_skipped: data.processing_skipped,
      processing_deleted: data.processing_deleted,
      totals_mismatch_count: data.totals_mismatch,
    }));
  }

  async deleteGroup(groupId: string): Promise<{ screenshots_deleted: number; annotations_deleted: number }> {
    return this.storageService.deleteScreenshotsByGroup(groupId);
  }

  async updateGridCoords(screenshotId: number, coords: GridCoordinates | null): Promise<void> {
    if (coords) {
      await this.storageService.updateScreenshot(screenshotId, {
        grid_upper_left_x: coords.upper_left.x,
        grid_upper_left_y: coords.upper_left.y,
        grid_lower_right_x: coords.lower_right.x,
        grid_lower_right_y: coords.lower_right.y,
      });
    } else {
      await this.storageService.updateScreenshot(screenshotId, {
        grid_upper_left_x: null,
        grid_upper_left_y: null,
        grid_lower_right_x: null,
        grid_lower_right_y: null,
      });
    }
  }

  /**
   * Export all screenshots to CSV.
   *
   * NOTE FOR CALLERS: the CSV may contain PHI (extracted titles, original
   * filenames) and, once downloaded, it leaves the encrypted-at-rest browser
   * storage for the device filesystem. The export UI should warn the user
   * before triggering the download.
   */
  async exportCSV(): Promise<string> {
    // Import column headers from generated constants (single source of truth: shared/export_columns.json)
    const { EXPORT_CSV_HEADERS } = await import("@/core/generated/constants");
    const headers = EXPORT_CSV_HEADERS;
    const annotationsByScreenshot = new Map<number, Annotation[]>();
    for (const annotation of await this.storageService.getAllAnnotations()) {
      const annotations = annotationsByScreenshot.get(annotation.screenshot_id) ?? [];
      annotations.push(annotation);
      annotationsByScreenshot.set(annotation.screenshot_id, annotations);
    }

    /**
     * CSV cell escaping. Two concerns:
     *  1. Structural: quote cells containing commas/quotes/newlines.
     *  2. Spreadsheet formula injection: a cell beginning with = + - @ (or a
     *     control char) is interpreted as a formula by Excel/Sheets. Prefix
     *     such cells with a single quote so they render as literal text.
     */
    const escapeCell = (v: ExportRecord[string]): string => {
      let s = String(v ?? "");
      if (/^[=+\-@\t\r]/.test(s)) {
        s = `'${s}`;
      }
      return s.includes(",") || s.includes('"') || s.includes("\n")
        ? `"${s.replace(/"/g, '""')}"`
        : s;
    };

    // Stream screenshots through a cursor, building the CSV incrementally \u2014
    // the whole screenshots table (event logs included) is never materialized.
    const csvLines: string[] = ["\ufeff" + headers.map(escapeCell).join(",")];
    await this.storageService.streamScreenshots((s) => {
      const exportScreenshot = overlaySingleAuthoritativeAnnotation(s, annotationsByScreenshot);
      if (!shouldIncludeInExport(exportScreenshot)) return;
      csvLines.push(recordToCsvRow(buildExportRecord(exportScreenshot)).map(escapeCell).join(","));
    });

    return csvLines.join("\n");
  }

  /**
   * Export all screenshots as JSON (roadmap #21).
   *
   * Emits the SAME canonical SSoT records as {@link exportCSV} (see
   * exportRecord.ts) wrapped in a small envelope (format version, timestamp,
   * the column list, and the row objects). Same PHI caveat as CSV: once
   * downloaded the file leaves the app's managed storage.
   */
  async exportJSON(): Promise<string> {
    const { EXPORT_CSV_HEADERS } = await import("@/core/generated/constants");
    const annotationsByScreenshot = new Map<number, Annotation[]>();
    for (const annotation of await this.storageService.getAllAnnotations()) {
      const annotations = annotationsByScreenshot.get(annotation.screenshot_id) ?? [];
      annotations.push(annotation);
      annotationsByScreenshot.set(annotation.screenshot_id, annotations);
    }
    const records: ExportRecord[] = [];
    await this.storageService.streamScreenshots((s) => {
      const exportScreenshot = overlaySingleAuthoritativeAnnotation(s, annotationsByScreenshot);
      if (!shouldIncludeInExport(exportScreenshot)) return;
      records.push(buildExportRecord(exportScreenshot));
    });
    return buildExportJsonEnvelope(records, {
      timestamp: new Date().toISOString(),
      columns: EXPORT_CSV_HEADERS,
    });
  }
}
