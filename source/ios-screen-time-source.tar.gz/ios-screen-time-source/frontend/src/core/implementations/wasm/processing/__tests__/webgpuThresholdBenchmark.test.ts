import { describe, expect, it } from "bun:test";

import {
  benchmarkRgbaThreshold,
  thresholdRgbaCpu,
  thresholdRgbaWithWebGpuFallback,
} from "../webgpuThresholdBenchmark";

describe("WebGPU threshold benchmark", () => {
  const rgba = new Uint8Array([
    0, 0, 0, 255,
    255, 255, 255, 255,
    255, 0, 0, 255,
  ]);

  it("uses the same integer luma contract as the compute shader", () => {
    expect(Array.from(thresholdRgbaCpu(rgba, 3, 1, 128))).toEqual([0, 1, 0]);
  });

  it("fails safely to the CPU when WebGPU is unavailable", async () => {
    const execution = await thresholdRgbaWithWebGpuFallback(rgba, 3, 1, 128);
    expect(execution.backend).toBe("cpu");
    expect(execution.parityMismatches).toBe(0);
    expect(execution.fallbackReason).toBeTruthy();
    expect(Array.from(execution.mask)).toEqual([0, 1, 0]);
  });

  it("rejects inconsistent dimensions before either backend runs", () => {
    expect(() => thresholdRgbaCpu(rgba, 4, 1)).toThrow("RGBA buffer size");
  });

  it("bounds synthetic benchmark allocations", async () => {
    await expect(benchmarkRgbaThreshold(4097, 4097, 1)).rejects.toThrow("at most");
  });
});
