import { afterEach, beforeEach, describe, expect, test } from "bun:test";

import { WASMProcessingService } from "../WASMProcessingService";
import type { WorkerResponse } from "../processing/workers/types";

type WorkerHandler = (event: MessageEvent<WorkerResponse>) => void;

const originalWorker = globalThis.Worker;
const originalFetch = globalThis.fetch;
const originalNavigator = Object.getOwnPropertyDescriptor(globalThis, "navigator");
const originalLocalStorage = Object.getOwnPropertyDescriptor(globalThis, "localStorage");
const originalImageData = Object.getOwnPropertyDescriptor(globalThis, "ImageData");
const originalCompileStreaming = WebAssembly.compileStreaming;

async function flushMicrotasks(times = 5): Promise<void> {
  if (times <= 0) return;
  await Promise.resolve();
  return flushMicrotasks(times - 1);
}

class MockWorker {
  static instances: MockWorker[] = [];
  static autoCompleteDetectGrid = true;
  static autoCompleteInitialize = true;
  static initializeHeapBytes: number | undefined;

  onmessage: WorkerHandler | null = null;
  onerror: ((event: Event | ErrorEvent) => void) | null = null;
  onmessageerror: ((event: MessageEvent) => void) | null = null;
  readonly initializeMessages: Array<{
    id: string;
    hasTessdata: boolean;
    tessdataIsBlob: boolean;
    hasWasmModule: boolean;
  }> = [];
  readonly processMessages: Array<{
    id: string;
    // Recorded verbatim from the posted payload, so an absent method is
    // stored as `undefined` rather than omitted.
    gridDetectionMethod?: string | undefined;
    hasWasmModule: boolean;
    hasTessdata: boolean;
    tessdataIsBlob: boolean;
  }> = [];
  readonly transferLists: Transferable[][] = [];
  readonly extractBarsMessages: Array<{ id: string }>;
  readonly detectGridMessages: Array<{
    id: string;
    method?: string | undefined;
    hasWasmModule: boolean;
  }> = [];
  readonly detectGridHistory: Array<{ id: string; method?: string | undefined }> = [];
  readonly detectGridModuleHistory: boolean[] = [];
  private completedInitializeCount = 0;
  terminated = false;

  constructor() {
    this.extractBarsMessages = [];
    MockWorker.instances.push(this);
  }

  postMessage(message: { id: string; type: string }, transfer?: Transferable[]): void {
    this.transferLists.push(transfer ?? []);
    if (message.type === "INITIALIZE") {
      const payload = (message as {
        payload?: { tessdata?: ArrayBuffer | Blob; wasmModule?: WebAssembly.Module };
      }).payload;
      this.initializeMessages.push({
        id: message.id,
        hasTessdata: payload?.tessdata !== undefined,
        tessdataIsBlob: payload?.tessdata instanceof Blob,
        hasWasmModule: payload?.wasmModule !== undefined,
      });
      if (MockWorker.autoCompleteInitialize) {
        queueMicrotask(() => this.completeNextInitialize());
      }
      return;
    }

    if (message.type === "PROCESS_IMAGE") {
      const payload = (message as {
        payload?: {
          gridDetectionMethod?: string;
          wasmModule?: WebAssembly.Module;
          tessdata?: ArrayBuffer | Blob;
        };
      }).payload;
      this.processMessages.push({
        id: message.id,
        gridDetectionMethod: payload?.gridDetectionMethod,
        hasWasmModule: payload?.wasmModule !== undefined,
        hasTessdata: payload?.tessdata !== undefined,
        tessdataIsBlob: payload?.tessdata instanceof Blob,
      });
    }

    if (message.type === "DETECT_GRID") {
      const payload = (message as { payload?: { method?: string; wasmModule?: WebAssembly.Module } }).payload;
      const entry = {
        id: message.id,
        method: payload?.method,
        hasWasmModule: payload?.wasmModule !== undefined,
      };
      this.detectGridMessages.push(entry);
      this.detectGridHistory.push({ id: entry.id, method: entry.method });
      this.detectGridModuleHistory.push(entry.hasWasmModule);
      if (MockWorker.autoCompleteDetectGrid) {
        queueMicrotask(() => this.completeNextDetectGrid());
      }
    }

    if (message.type === "EXTRACT_BARS") {
      this.extractBarsMessages.push({ id: message.id });
      queueMicrotask(() => this.completeNextExtractBars());
    }
  }

  terminate(): void {
    this.terminated = true;
  }

  pendingInitializeCount(): number {
    return this.initializeMessages.length - this.completedInitializeCount;
  }

  completeNextInitialize(): void {
    const message = this.initializeMessages[this.completedInitializeCount++];
    if (!message) throw new Error("No INITIALIZE message is pending");
    this.emit({
      type: "INITIALIZE_COMPLETE",
      id: message.id,
      payload: {
        initialized: true,
        ...(MockWorker.initializeHeapBytes !== undefined && {
          wasmHeapBytes: MockWorker.initializeHeapBytes,
        }),
      },
    });
  }

  completeNextProcess(payload?: Extract<WorkerResponse, { type: "PROCESS_IMAGE_COMPLETE" }>["payload"]): void {
    const message = this.processMessages.shift();
    if (!message) throw new Error("No PROCESS_IMAGE message is pending");
    this.emit({
      type: "PROCESS_IMAGE_COMPLETE",
      id: message.id,
      payload: payload ?? {
        ok: true,
        hourlyData: {},
        title: null,
        total: null,
        ocrInitialized: true,
        ...(MockWorker.initializeHeapBytes !== undefined && {
          wasmHeapBytes: MockWorker.initializeHeapBytes,
        }),
      },
    });
  }

  completeNextDetectGrid(): void {
    const message = this.detectGridMessages.shift();
    if (!message) throw new Error("No DETECT_GRID message is pending");
    this.emit({
      type: "DETECT_GRID_COMPLETE",
      id: message.id,
      payload: {
        gridCoordinates: null,
      },
    });
  }

  completeNextExtractBars(): void {
    const message = this.extractBarsMessages.shift();
    if (!message) throw new Error("No EXTRACT_BARS message is pending");
    this.emit({
      type: "EXTRACT_BARS_COMPLETE",
      id: message.id,
      payload: {
        hourlyData: { 0: 12 },
        alignmentScore: 0.99,
        gridRegistrationScore: 0.98,
      },
    });
  }

  emitWorkerError(event: Event | ErrorEvent = new Event("error")): void {
    this.onerror?.(event);
  }

  emitMessageError(data?: unknown): void {
    this.onmessageerror?.({ data, type: "messageerror" } as MessageEvent);
  }

  emit(data: WorkerResponse): void {
    this.onmessage?.({ data } as MessageEvent<WorkerResponse>);
  }
}

/** URL of a `fetch` argument. `String(new Request(...))` is `[object Request]`. */
function requestUrl(input: RequestInfo | URL): string {
  if (typeof input === "string") return input;
  return input instanceof URL ? input.href : input.url;
}

describe("WASM scheduler metrics", () => {
  beforeEach(() => {
    MockWorker.instances = [];
    MockWorker.autoCompleteDetectGrid = true;
    MockWorker.autoCompleteInitialize = true;
    MockWorker.initializeHeapBytes = undefined;
    const localStorageValues = new Map<string, string>();
    Object.defineProperty(globalThis, "localStorage", {
      configurable: true,
      value: {
        getItem: (key: string) => localStorageValues.get(key) ?? null,
        setItem: (key: string, value: string) => localStorageValues.set(key, value),
        removeItem: (key: string) => localStorageValues.delete(key),
        clear: () => localStorageValues.clear(),
        key: (index: number) => Array.from(localStorageValues.keys())[index] ?? null,
        get length() {
          return localStorageValues.size;
        },
      },
    });
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        hardwareConcurrency: 2,
        deviceMemory: 1,
      },
    });
    Object.defineProperty(globalThis, "Worker", {
      configurable: true,
      value: MockWorker,
    });
    Object.defineProperty(globalThis, "fetch", {
      configurable: true,
      value: () =>
        Promise.resolve({
          ok: true,
          arrayBuffer: () => Promise.resolve(new ArrayBuffer(8)),
          blob: () => Promise.resolve(new Blob(["tessdata"])),
        }),
    });
    Object.defineProperty(WebAssembly, "compileStreaming", {
      configurable: true,
      value: () => Promise.resolve({} as WebAssembly.Module),
    });
  });

  afterEach(() => {
    Object.defineProperty(globalThis, "Worker", {
      configurable: true,
      value: originalWorker,
    });
    Object.defineProperty(globalThis, "fetch", {
      configurable: true,
      value: originalFetch,
    });
    if (originalNavigator) {
      Object.defineProperty(globalThis, "navigator", originalNavigator);
    } else {
      delete (globalThis as { navigator?: Navigator }).navigator;
    }
    if (originalLocalStorage) {
      Object.defineProperty(globalThis, "localStorage", originalLocalStorage);
    } else {
      delete (globalThis as { localStorage?: Storage }).localStorage;
    }
    if (originalImageData) {
      Object.defineProperty(globalThis, "ImageData", originalImageData);
    } else {
      delete (globalThis as { ImageData?: typeof ImageData }).ImageData;
    }
    Object.defineProperty(WebAssembly, "compileStreaming", {
      configurable: true,
      value: originalCompileStreaming,
    });
  });

  test("keeps queued OCR work in the service queue and records scheduler timing", async () => {
    const service = new WASMProcessingService();
    expect(MockWorker.instances).toHaveLength(0);
    expect(service.getPoolSize()).toBe(1);
    expect(service.getSchedulerSnapshot().poolSize).toBe(0);

    await service.initialize();
    const worker = MockWorker.instances[0]!;

    const first = service.processImage(
      new Blob(["first"], { type: "image/png" }),
      { imageType: "screen_time" },
    );
    await Promise.resolve();

    const second = service.processImage(
      new Blob(["second"], { type: "image/png" }),
      { imageType: "screen_time" },
    );
    await Promise.resolve();

    expect(worker.processMessages).toHaveLength(1);
    let snapshot = service.getSchedulerSnapshot();
    expect(snapshot.poolSize).toBe(1);
    expect(snapshot.pendingRequests).toBe(1);
    expect(snapshot.queuedRequests).toBe(1);
    expect(snapshot.maxQueueDepth).toBe(1);
    expect(snapshot.messages.PROCESS_IMAGE?.accepted).toBe(2);
    expect(snapshot.messages.PROCESS_IMAGE?.dispatched).toBe(1);
    expect(snapshot.messages.PROCESS_IMAGE?.currentInFlight).toBe(1);
    expect(snapshot.messages.PROCESS_IMAGE?.maxInFlight).toBe(1);

    worker.completeNextProcess();
    await first;
    await Promise.resolve();

    expect(worker.processMessages).toHaveLength(1);
    snapshot = service.getSchedulerSnapshot();
    expect(snapshot.queuedRequests).toBe(0);
    expect(snapshot.pendingRequests).toBe(1);
    expect(snapshot.messages.PROCESS_IMAGE?.completed).toBe(1);
    expect(snapshot.messages.PROCESS_IMAGE?.dispatched).toBe(2);
    expect(snapshot.messages.PROCESS_IMAGE?.currentInFlight).toBe(1);

    worker.completeNextProcess();
    await second;

    snapshot = service.getSchedulerSnapshot();
    expect(snapshot.pendingRequests).toBe(0);
    expect(snapshot.messages.PROCESS_IMAGE?.completed).toBe(2);
    expect(snapshot.messages.PROCESS_IMAGE?.currentInFlight).toBe(0);
    expect(snapshot.messages.PROCESS_IMAGE?.maxInFlight).toBe(1);
    expect(snapshot.messages.PROCESS_IMAGE?.averageQueueWaitMs).toBeGreaterThanOrEqual(0);
    expect(snapshot.messages.PROCESS_IMAGE?.averageWorkerRunMs).toBeGreaterThanOrEqual(0);

    service.terminate();
  });

  test("transfers ImageData buffers to processing workers instead of cloning pixels", async () => {
    class MockImageData {
      data: Uint8ClampedArray;
      width = 1;
      height = 1;

      constructor(data: Uint8ClampedArray) {
        this.data = data;
      }
    }
    Object.defineProperty(globalThis, "ImageData", {
      configurable: true,
      value: MockImageData,
    });

    const service = new WASMProcessingService();
    await service.initialize();
    const worker = MockWorker.instances[0]!;
    const pixels = new Uint8ClampedArray([1, 2, 3, 4]);

    const running = service.processImage(
      new MockImageData(pixels) as unknown as ImageData,
      { imageType: "screen_time" },
    );
    await flushMicrotasks();

    expect(worker.processMessages).toHaveLength(1);
    const latestTransferList = worker.transferLists.at(-1) ?? [];
    expect(latestTransferList).toContain(pixels.buffer);

    worker.completeNextProcess();
    await running;
    service.terminate();
  });

  test("cancels queued OCR work before it reaches the worker", async () => {
    const service = new WASMProcessingService();
    await service.initialize();
    const worker = MockWorker.instances[0]!;
    const abortController = new AbortController();

    const first = service.processImage(
      new Blob(["first"], { type: "image/png" }),
      { imageType: "screen_time" },
    );
    await Promise.resolve();

    const second = service.processImage(
      new Blob(["second"], { type: "image/png" }),
      { imageType: "screen_time", abortSignal: abortController.signal },
    );
    await Promise.resolve();

    expect(worker.processMessages).toHaveLength(1);
    expect(service.getSchedulerSnapshot().queuedRequests).toBe(1);

    abortController.abort();
    await expect(second).rejects.toThrow("Processing request aborted");

    const afterAbort = service.getSchedulerSnapshot();
    expect(afterAbort.queuedRequests).toBe(0);
    expect(afterAbort.pendingRequests).toBe(1);
    expect(afterAbort.messages.PROCESS_IMAGE?.cancelled).toBe(1);
    expect(afterAbort.messages.PROCESS_IMAGE?.dispatched).toBe(1);
    expect(worker.processMessages).toHaveLength(1);

    worker.completeNextProcess();
    await first;

    service.terminate();
  });

  test("reports a useful message when a worker crashes without browser details", async () => {
    const service = new WASMProcessingService();
    await service.initialize();
    const worker = MockWorker.instances[0]!;

    const running = service.processImage(
      new Blob(["first"], { type: "image/png" }),
      { imageType: "screen_time" },
    );
    await flushMicrotasks();
    expect(worker.processMessages).toHaveLength(1);

    const rejection = running.then(
      () => null,
      (error: unknown) => error,
    );
    worker.emitWorkerError(new Event("error"));

    const error = await rejection;
    expect(error).toBeInstanceOf(Error);
    expect((error as Error).message).toBe("Worker crashed before reporting an error (error)");
    expect((error as Error).message).not.toContain("undefined");

    const snapshot = service.getSchedulerSnapshot();
    expect(snapshot.pendingRequests).toBe(0);
    expect(snapshot.messages.PROCESS_IMAGE?.failed).toBe(1);

    service.terminate();
  });

  test("reports message deserialization failures without hanging pending OCR", async () => {
    const service = new WASMProcessingService();
    await service.initialize();
    const worker = MockWorker.instances[0]!;

    const running = service.processImage(
      new Blob(["first"], { type: "image/png" }),
      { imageType: "screen_time" },
    );
    await flushMicrotasks();
    expect(worker.processMessages).toHaveLength(1);

    const rejection = running.then(
      () => null,
      (error: unknown) => error,
    );
    worker.emitMessageError({ reason: "clone failed" });

    const error = await rejection;
    expect(error).toBeInstanceOf(Error);
    expect((error as Error).message).toContain("Worker message could not be deserialized");
    expect((error as Error).message).toContain("clone failed");

    const snapshot = service.getSchedulerSnapshot();
    expect(snapshot.pendingRequests).toBe(0);
    expect(snapshot.messages.PROCESS_IMAGE?.failed).toBe(1);

    service.terminate();
  });

  test("aborts in-flight OCR without creating a replacement until new demand arrives", async () => {
    const service = new WASMProcessingService();
    await service.initialize();
    const worker = MockWorker.instances[0]!;
    const abortController = new AbortController();

    const running = service.processImage(
      new Blob(["running"], { type: "image/png" }),
      { imageType: "screen_time", abortSignal: abortController.signal },
    );
    await flushMicrotasks();

    expect(worker.processMessages).toHaveLength(1);
    expect(service.getSchedulerSnapshot().pendingRequests).toBe(1);

    abortController.abort();
    await expect(running).rejects.toThrow("Processing request aborted");
    await flushMicrotasks(8);

    expect(worker.terminated).toBe(true);
    expect(service.getSchedulerSnapshot().pendingRequests).toBe(0);
    expect(service.getSchedulerSnapshot().messages.PROCESS_IMAGE?.cancelled).toBe(1);
    expect(service.getSchedulerSnapshot().messages.PROCESS_IMAGE?.terminated).toBe(1);
    expect(service.getSchedulerSnapshot().poolSize).toBe(0);
    expect(MockWorker.instances).toHaveLength(1);
    expect(service.getSchedulerSnapshot().messages.INITIALIZE?.accepted).toBe(1);

    const next = service.processImage(
      new Blob(["next"], { type: "image/png" }),
      { imageType: "screen_time" },
    );
    await flushMicrotasks(8);

    const nextWorker = MockWorker.instances[1]!;
    expect(nextWorker.processMessages).toHaveLength(1);
    expect(nextWorker.initializeMessages).toHaveLength(1);
    nextWorker.completeNextProcess();
    await next;

    expect(service.getSchedulerSnapshot().messages.PROCESS_IMAGE?.completed).toBe(1);

    service.terminate();
  });

  test("does not create replacement OCR workers after a fully aborted batch", async () => {
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        hardwareConcurrency: 4,
        deviceMemory: 8,
      },
    });
    const service = new WASMProcessingService();
    await service.initialize();
    MockWorker.autoCompleteInitialize = false;

    const firstWorker = MockWorker.instances[0]!;
    const secondWorker = MockWorker.instances[1]!;
    const firstAbort = new AbortController();
    const secondAbort = new AbortController();

    const first = service.processImage(
      new Blob(["first"], { type: "image/png" }),
      { imageType: "screen_time", abortSignal: firstAbort.signal },
    );
    const second = service.processImage(
      new Blob(["second"], { type: "image/png" }),
      { imageType: "screen_time", abortSignal: secondAbort.signal },
    );
    await flushMicrotasks(8);

    expect(firstWorker.processMessages).toHaveLength(1);
    expect(secondWorker.processMessages).toHaveLength(1);

    const firstResult = first.then(
      () => null,
      (error: unknown) => error,
    );
    const secondResult = second.then(
      () => null,
      (error: unknown) => error,
    );
    firstAbort.abort();
    secondAbort.abort();
    expect((await firstResult) as { name?: string }).toMatchObject({ name: "AbortError" });
    expect((await secondResult) as { name?: string }).toMatchObject({ name: "AbortError" });
    await flushMicrotasks(8);

    expect(firstWorker.terminated).toBe(true);
    expect(secondWorker.terminated).toBe(true);
    expect(MockWorker.instances).toHaveLength(2);
    expect(service.getSchedulerSnapshot().poolSize).toBe(0);
    expect(service.getSchedulerSnapshot().readyWorkers).toBe(0);
    expect(service.getSchedulerSnapshot().messages.PROCESS_IMAGE?.cancelled).toBe(2);
    expect(service.getSchedulerSnapshot().messages.PROCESS_IMAGE?.terminated).toBe(2);
    expect(service.getSchedulerSnapshot().messages.INITIALIZE?.completed).toBe(2);
    expect(service.getSchedulerSnapshot().messages.INITIALIZE?.currentInFlight).toBe(0);
    expect(service.getSchedulerSnapshot().messages.INITIALIZE?.maxInFlight).toBe(1);

    service.terminate();
  });

  test("failed replacement initialization rejects queued OCR requests", async () => {
    const service = new WASMProcessingService();
    try {
      await service.initialize();
      MockWorker.autoCompleteInitialize = false;
      const abortController = new AbortController();
      const first = service.processImage(new Blob(["first"]), { imageType: "screen_time", abortSignal: abortController.signal });
      const firstResult = first.catch((error: unknown) => error);
      await flushMicrotasks();
      const second = service.processImage(new Blob(["second"]), { imageType: "screen_time" });
      const secondResult = second.then(() => "resolved", () => "rejected");
      await flushMicrotasks();
      abortController.abort();
      await firstResult;
      await flushMicrotasks(8);
      const replacement = MockWorker.instances[1]!;
      replacement.emit({ type: "ERROR", id: replacement.initializeMessages[0]!.id, error: "init failed" });
      const result = await Promise.race([secondResult, new Promise<string>((resolve) => { setTimeout(() => resolve("hung"), 50); })]);
      expect(result).toBe("rejected");
      expect(service.getSchedulerSnapshot().queuedRequests).toBe(0);
    } finally {
      service.terminate();
    }
  });

  test("bars-only ABI errors preserve the flag and trigger recovery", async () => {
    const originalWindow = Object.getOwnPropertyDescriptor(globalThis, "window");
    const originalSessionStorage = Object.getOwnPropertyDescriptor(globalThis, "sessionStorage");
    const originalComplete = Object.getOwnPropertyDescriptor(MockWorker.prototype, "completeNextExtractBars")!;
    let reloads = 0;
    Object.defineProperty(globalThis, "window", { configurable: true, value: { location: { reload: () => { reloads++; } } } });
    Object.defineProperty(globalThis, "sessionStorage", { configurable: true, value: { getItem: () => null, setItem: () => {} } });
    MockWorker.prototype.completeNextExtractBars = function () {
      const message = this.extractBarsMessages.shift()!;
      this.emit({ type: "ERROR", id: message.id, error: "stale WASM", abiMismatch: true } as WorkerResponse);
    };
    const service = new WASMProcessingService();
    try {
      const error = await service.extractBarsOnly(new Blob(["png"]), {
        upper_left: { x: 0, y: 0 }, lower_right: { x: 10, y: 10 },
      }, "screen_time").catch((reason: unknown) => reason);
      await flushMicrotasks(8);
      expect(error).toMatchObject({ abiMismatch: true });
      expect(reloads).toBe(1);
    } finally {
      service.terminate();
      Object.defineProperty(MockWorker.prototype, "completeNextExtractBars", originalComplete);
      if (originalWindow) Object.defineProperty(globalThis, "window", originalWindow);
      else Reflect.deleteProperty(globalThis, "window");
      if (originalSessionStorage) Object.defineProperty(globalThis, "sessionStorage", originalSessionStorage);
      else Reflect.deleteProperty(globalThis, "sessionStorage");
    }
  });

  test("initializes one replacement OCR worker when queued OCR demand remains after abort", async () => {
    const service = new WASMProcessingService();
    await service.initialize();
    MockWorker.autoCompleteInitialize = false;
    const firstWorker = MockWorker.instances[0]!;
    const abortController = new AbortController();

    const first = service.processImage(
      new Blob(["first"], { type: "image/png" }),
      { imageType: "screen_time", abortSignal: abortController.signal },
    );
    await flushMicrotasks();
    const second = service.processImage(
      new Blob(["second"], { type: "image/png" }),
      { imageType: "screen_time" },
    );
    await flushMicrotasks();

    expect(firstWorker.processMessages).toHaveLength(1);
    expect(service.getSchedulerSnapshot().queuedRequests).toBe(1);

    const firstResult = first.then(
      () => null,
      (error: unknown) => error,
    );
    abortController.abort();
    expect((await firstResult) as { name?: string }).toMatchObject({ name: "AbortError" });
    await flushMicrotasks(8);

    const replacement = MockWorker.instances[1]!;
    expect(firstWorker.terminated).toBe(true);
    expect(replacement.pendingInitializeCount()).toBe(1);
    expect(service.getSchedulerSnapshot().messages.INITIALIZE?.currentInFlight).toBe(1);
    replacement.completeNextInitialize();
    await flushMicrotasks(8);

    expect(replacement.processMessages).toHaveLength(1);
    replacement.completeNextProcess();
    await second;

    expect(service.getSchedulerSnapshot().messages.PROCESS_IMAGE?.completed).toBe(1);
    expect(service.getSchedulerSnapshot().messages.PROCESS_IMAGE?.cancelled).toBe(1);
    expect(service.getSchedulerSnapshot().messages.PROCESS_IMAGE?.terminated).toBe(1);
    expect(service.getSchedulerSnapshot().queuedRequests).toBe(0);
    expect(service.getSchedulerSnapshot().pendingRequests).toBe(0);

    service.terminate();
  });

  test("runs line-based grid detection without initializing OCR runtime", async () => {
    const service = new WASMProcessingService();
    expect(MockWorker.instances).toHaveLength(0);

    await service.detectGridDetailed(
      new Blob(["grid"], { type: "image/png" }),
      "screen_time",
      "line_based",
    );

    const worker = MockWorker.instances[0]!;
    expect(worker.initializeMessages).toHaveLength(0);
    expect(worker.detectGridHistory).toEqual(
      // bun-types declares `expect.arrayContaining` as returning `any`.
      expect.arrayContaining([
        { id: (expect.any(String) as string), method: "line_based" },
      ]) as Array<{ id: string; method?: string | undefined }>,
    );
    const snapshot = service.getSchedulerSnapshot();
    expect(snapshot.messages.INITIALIZE?.accepted ?? 0).toBe(0);
    expect(snapshot.messages.DETECT_GRID?.completed).toBe(1);
    expect(service.isInitialized()).toBe(false);

    service.terminate();
  });

  test("extracts hourly bars from a known grid without initializing OCR runtime", async () => {
    const service = new WASMProcessingService();
    expect(MockWorker.instances).toHaveLength(0);

    const hourlyData = await service.extractHourlyData(
      new Blob(["bars"], { type: "image/png" }),
      {
        upper_left: { x: 10, y: 20 },
        lower_right: { x: 210, y: 320 },
      },
      "screen_time",
    );

    const worker = MockWorker.instances[0]!;
    expect(hourlyData).toEqual({ 0: 12 });
    expect(worker.initializeMessages).toHaveLength(0);
    expect(worker.extractBarsMessages).toHaveLength(0);
    const snapshot = service.getSchedulerSnapshot();
    expect(snapshot.messages.INITIALIZE?.accepted ?? 0).toBe(0);
    expect(snapshot.messages.EXTRACT_BARS?.completed).toBe(1);
    expect(snapshot.messages.EXTRACT_HOURLY_DATA?.accepted ?? 0).toBe(0);
    expect(service.isInitialized()).toBe(false);

    service.terminate();
  });

  test("allocates one module worker for line-based detection, then scales to the OCR pool on initialize", async () => {
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        hardwareConcurrency: 16,
        deviceMemory: 8,
      },
    });
    MockWorker.autoCompleteDetectGrid = false;
    const service = new WASMProcessingService();

    expect(service.getPoolSize()).toBe(8);
    expect(MockWorker.instances).toHaveLength(0);

    const grid = service.detectGridDetailed(
      new Blob(["grid"], { type: "image/png" }),
      "screen_time",
      "line_based",
    );
    await flushMicrotasks();

    expect(MockWorker.instances).toHaveLength(1);
    const firstWorker = MockWorker.instances[0]!;
    expect(firstWorker.detectGridMessages).toHaveLength(1);
    expect(service.getSchedulerSnapshot().poolSize).toBe(1);

    const initialize = service.initialize();
    await flushMicrotasks(8);

    expect(MockWorker.instances.length).toBeGreaterThan(1);
    expect(MockWorker.instances.length).toBeLessThan(8);
    expect(firstWorker.initializeMessages).toHaveLength(0);
    firstWorker.completeNextDetectGrid();
    await grid;
    await initialize;

    expect(firstWorker.initializeMessages).toHaveLength(1);
    expect(service.getSchedulerSnapshot().poolSize).toBe(8);
    expect(service.isInitialized()).toBe(true);

    service.terminate();
  });

  test("keeps OCR pool conservative when browser memory is not reported", async () => {
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        hardwareConcurrency: 32,
      },
    });
    const service = new WASMProcessingService();

    expect(service.getPoolSize()).toBe(1);
    await service.initialize();

    expect(MockWorker.instances).toHaveLength(1);
    expect(service.getSchedulerSnapshot().poolSize).toBe(1);
    expect(service.getSchedulerSnapshot().readyWorkers).toBe(1);

    service.terminate();
  });

  test("uses measured OCR worker memory to tighten future pool planning", async () => {
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        hardwareConcurrency: 16,
        deviceMemory: 4,
      },
    });
    MockWorker.initializeHeapBytes = 768 * 1024 * 1024;
    const service = new WASMProcessingService();

    expect(service.getPoolSize()).toBe(6);
    await service.initialize();

    expect(service.getSchedulerSnapshot().poolSize).toBe(3);
    expect(service.getSchedulerSnapshot().readyWorkers).toBe(3);
    expect(service.getSchedulerSnapshot().measuredOcrWorkerCostMb).toBe(768);
    expect(service.getPoolSize()).toBe(3);
    expect(MockWorker.instances).toHaveLength(3);
    expect(MockWorker.instances.filter((worker) => worker.terminated)).toHaveLength(0);
    service.terminate();

    const nextService = new WASMProcessingService();
    expect(nextService.getPoolSize()).toBe(3);
    expect(nextService.getSchedulerSnapshot().measuredOcrWorkerCostMb).toBe(768);
    nextService.terminate();
  });

  test("fetches tessdata and compiles the WASM module once for OCR pool initialization", async () => {
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        hardwareConcurrency: 16,
        deviceMemory: 8,
      },
    });
    let fetchCalls = 0;
    let compileCalls = 0;
    Object.defineProperty(globalThis, "fetch", {
      configurable: true,
      value: () => {
        fetchCalls++;
        return Promise.resolve({
          ok: true,
          arrayBuffer: () => Promise.resolve(new ArrayBuffer(8)),
          blob: () => Promise.resolve(new Blob(["tessdata"])),
        });
      },
    });
    Object.defineProperty(WebAssembly, "compileStreaming", {
      configurable: true,
      value: () => {
        compileCalls++;
        return Promise.resolve({} as WebAssembly.Module);
      },
    });
    const service = new WASMProcessingService();

    await service.initialize();

    expect(MockWorker.instances).toHaveLength(8);
    expect(fetchCalls).toBe(2);
    expect(compileCalls).toBe(1);
    expect(
      MockWorker.instances.reduce((sum, worker) => sum + worker.initializeMessages.length, 0),
    ).toBe(8);
    for (const worker of MockWorker.instances) {
      expect(worker.initializeMessages).toEqual([
        {
          id: (expect.any(String) as string),
          hasTessdata: true,
          tessdataIsBlob: true,
          hasWasmModule: true,
        },
      ]);
    }

    service.terminate();
  });

  test("initializes OCR workers one at a time to avoid startup memory spikes", async () => {
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        hardwareConcurrency: 16,
        deviceMemory: 8,
      },
    });
    MockWorker.autoCompleteInitialize = false;
    const service = new WASMProcessingService();

    const initialize = service.initialize();
    await flushMicrotasks(8);

    expect(MockWorker.instances).toHaveLength(1);
    expect(
      MockWorker.instances.reduce((sum, worker) => sum + worker.initializeMessages.length, 0),
    ).toBe(1);
    expect(
      MockWorker.instances.reduce((sum, worker) => sum + worker.pendingInitializeCount(), 0),
    ).toBe(1);

    for (let completed = 1; completed < 8; completed++) {
      const active = MockWorker.instances.find(
        (worker) => worker.pendingInitializeCount() > 0,
      );
      expect(active).toBeDefined();
      active!.completeNextInitialize();
      // eslint-disable-next-line no-await-in-loop -- the test verifies sequential worker startup one completion at a time
      await flushMicrotasks(8);
      expect(MockWorker.instances).toHaveLength(completed + 1);
      expect(
        MockWorker.instances.reduce((sum, worker) => sum + worker.initializeMessages.length, 0),
      ).toBe(completed + 1);
      expect(
        MockWorker.instances.reduce((sum, worker) => sum + worker.pendingInitializeCount(), 0),
      ).toBe(1);
    }

    const lastActive = MockWorker.instances.find(
      (worker) => worker.pendingInitializeCount() > 0,
    );
    expect(lastActive).toBeDefined();
    lastActive!.completeNextInitialize();
    await initialize;

    expect(service.isInitialized()).toBe(true);
    expect(service.getSchedulerSnapshot().messages.INITIALIZE?.completed).toBe(8);
    expect(service.getSchedulerSnapshot().messages.INITIALIZE?.currentInFlight).toBe(0);
    expect(service.getSchedulerSnapshot().messages.INITIALIZE?.maxInFlight).toBe(1);

    service.terminate();
  });

  test("cold line-based grid detection shares the compiled module without fetching tessdata", async () => {
    let fetchCalls = 0;
    let tessdataFetches = 0;
    let compileCalls = 0;
    Object.defineProperty(globalThis, "fetch", {
      configurable: true,
      value: (input: RequestInfo | URL) => {
        fetchCalls++;
        if (requestUrl(input).includes("eng.traineddata")) tessdataFetches++;
        return Promise.resolve({
          ok: true,
          arrayBuffer: () => Promise.resolve(new ArrayBuffer(8)),
          blob: () => Promise.resolve(new Blob(["tessdata"])),
        });
      },
    });
    Object.defineProperty(WebAssembly, "compileStreaming", {
      configurable: true,
      value: () => {
        compileCalls++;
        return Promise.resolve({} as WebAssembly.Module);
      },
    });
    const service = new WASMProcessingService();

    await service.detectGridDetailed(
      new Blob(["grid"], { type: "image/png" }),
      "screen_time",
      "line_based",
    );

    const worker = MockWorker.instances[0]!;
    expect(worker.initializeMessages).toHaveLength(0);
    expect(worker.detectGridHistory).toEqual([
      { id: (expect.any(String) as string), method: "line_based" },
    ]);
    expect(worker.detectGridModuleHistory).toEqual([true]);
    expect(fetchCalls).toBe(1);
    expect(tessdataFetches).toBe(0);
    expect(compileCalls).toBe(1);
    expect(service.isInitialized()).toBe(false);

    service.terminate();
  });

  test("queues targeted initialization instead of posting to a busy line-based worker", async () => {
    MockWorker.autoCompleteDetectGrid = false;
    const service = new WASMProcessingService();

    const grid = service.detectGridDetailed(
      new Blob(["grid"], { type: "image/png" }),
      "screen_time",
      "line_based",
    );
    await flushMicrotasks();

    const worker = MockWorker.instances[0]!;
    expect(worker.detectGridMessages).toHaveLength(1);
    expect(worker.initializeMessages).toHaveLength(0);

    const initialize = service.initialize();
    await flushMicrotasks(8);

    expect(worker.initializeMessages).toHaveLength(0);
    let snapshot = service.getSchedulerSnapshot();
    expect(snapshot.pendingRequests).toBe(1);
    expect(snapshot.queuedRequests).toBe(1);
    expect(snapshot.messages.INITIALIZE?.accepted).toBe(1);
    expect(snapshot.messages.INITIALIZE?.dispatched ?? 0).toBe(0);

    worker.completeNextDetectGrid();
    await grid;
    await initialize;

    snapshot = service.getSchedulerSnapshot();
    expect(snapshot.pendingRequests).toBe(0);
    expect(snapshot.queuedRequests).toBe(0);
    expect(snapshot.messages.INITIALIZE?.dispatched).toBe(1);
    expect(worker.initializeMessages).toHaveLength(1);
    expect(service.isInitialized()).toBe(true);

    service.terminate();
  });

  test("cold line-based combined grid failure avoids OCR initialization", async () => {
    const service = new WASMProcessingService();
    expect(MockWorker.instances).toHaveLength(0);

    const result = service.processImageWithGridDetection(
      new Blob(["weekly"], { type: "image/png" }),
      {
        imageType: "screen_time",
        gridDetectionMethod: "line_based",
      },
    );
    await flushMicrotasks(8);

    const worker = MockWorker.instances[0]!;
    expect(worker.initializeMessages).toHaveLength(0);
    expect(worker.detectGridHistory).toHaveLength(0);
    expect(worker.processMessages).toEqual([
      {
        id: (expect.any(String) as string),
        gridDetectionMethod: "line_based",
        hasWasmModule: true,
        hasTessdata: true,
        tessdataIsBlob: true,
      },
    ]);

    worker.completeNextProcess({
      ok: false,
      error: "Weekly view detected",
      title: null,
      total: null,
    });
    const processed = await result;
    await flushMicrotasks(8);

    const snapshot = service.getSchedulerSnapshot();
    expect(processed.gridDetectionFailed).toBe(true);
    expect(snapshot.messages.INITIALIZE?.accepted ?? 0).toBe(0);
    expect(snapshot.messages.PROCESS_IMAGE?.completed).toBe(1);
    expect(snapshot.messages.DETECT_GRID?.accepted ?? 0).toBe(0);
    expect(service.isInitialized()).toBe(false);

    service.terminate();
  });

  test("cold line-based combined success keeps OCR warmup to observed demand", async () => {
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        hardwareConcurrency: 16,
        deviceMemory: 8,
      },
    });
    const service = new WASMProcessingService();
    expect(service.getPoolSize()).toBe(8);
    expect(MockWorker.instances).toHaveLength(0);

    const result = service.processImageWithGridDetection(
      new Blob(["ocr"], { type: "image/png" }),
      {
        imageType: "screen_time",
        gridDetectionMethod: "line_based",
      },
    );
    await flushMicrotasks(8);

    const worker = MockWorker.instances[0]!;
    expect(MockWorker.instances).toHaveLength(1);
    expect(worker.initializeMessages).toHaveLength(0);
    expect(worker.detectGridHistory).toHaveLength(0);
    expect(worker.processMessages).toEqual([
      {
        id: (expect.any(String) as string),
        gridDetectionMethod: "line_based",
        hasWasmModule: true,
        hasTessdata: true,
        tessdataIsBlob: true,
      },
    ]);

    worker.completeNextProcess();
    await result;
    await flushMicrotasks(30);

    const snapshot = service.getSchedulerSnapshot();
    expect(snapshot.messages.PROCESS_IMAGE?.completed).toBe(1);
    expect(snapshot.messages.DETECT_GRID?.accepted ?? 0).toBe(0);
    expect(snapshot.messages.INITIALIZE?.accepted ?? 0).toBe(0);
    expect(snapshot.poolSize).toBe(1);
    expect(snapshot.readyWorkers).toBe(1);
    expect(service.isInitialized()).toBe(true);

    service.terminate();
  });

  test("concurrent cold line-based OCR scales workers to queue demand, not the full cap", async () => {
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        hardwareConcurrency: 16,
        deviceMemory: 8,
      },
    });
    let fetchCalls = 0;
    let tessdataFetches = 0;
    let compileCalls = 0;
    Object.defineProperty(globalThis, "fetch", {
      configurable: true,
      value: (input: RequestInfo | URL) => {
        fetchCalls++;
        if (requestUrl(input).includes("eng.traineddata")) tessdataFetches++;
        return Promise.resolve({
          ok: true,
          arrayBuffer: () => Promise.resolve(new ArrayBuffer(8)),
          blob: () => Promise.resolve(new Blob(["tessdata"])),
        });
      },
    });
    Object.defineProperty(WebAssembly, "compileStreaming", {
      configurable: true,
      value: () => {
        compileCalls++;
        return Promise.resolve({} as WebAssembly.Module);
      },
    });
    const service = new WASMProcessingService();
    expect(service.getPoolSize()).toBe(8);

    const results = Array.from({ length: 4 }, (_, i) =>
      service.processImageWithGridDetection(
        new Blob([`ocr-${i}`], { type: "image/png" }),
        {
          imageType: "screen_time",
          gridDetectionMethod: "line_based",
        },
      ),
    );
    await flushMicrotasks(8);

    expect(MockWorker.instances).toHaveLength(4);
    expect(
      MockWorker.instances.reduce((sum, worker) => sum + worker.processMessages.length, 0),
    ).toBe(4);
    expect(fetchCalls).toBe(2);
    expect(tessdataFetches).toBe(1);
    expect(compileCalls).toBe(1);
    for (const worker of MockWorker.instances) {
      expect(
        worker.processMessages.length,
        "Each OCR worker must receive at most one PROCESS_IMAGE before it completes",
      ).toBeLessThanOrEqual(1);
      expect(worker.processMessages[0]?.hasWasmModule).toBe(true);
      expect(worker.processMessages[0]?.hasTessdata).toBe(true);
      expect(worker.processMessages[0]?.tessdataIsBlob).toBe(true);
    }
    expect(
      MockWorker.instances.reduce((sum, worker) => sum + worker.initializeMessages.length, 0),
    ).toBe(0);

    for (const worker of MockWorker.instances) {
      worker.completeNextProcess();
    }
    await Promise.all(results);

    const snapshot = service.getSchedulerSnapshot();
    expect(snapshot.poolSize).toBe(4);
    expect(snapshot.readyWorkers).toBe(4);
    expect(snapshot.messages.PROCESS_IMAGE?.maxInFlight).toBe(4);
    expect(snapshot.messages.INITIALIZE?.accepted ?? 0).toBe(0);
    expect(service.isInitialized()).toBe(true);

    service.terminate();
  });
});
