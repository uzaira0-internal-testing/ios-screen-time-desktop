import type { ScreenshotDB } from './ScreenshotDB';

/**
 * Schema migration logic lives in the Dexie `version().stores()` / `.upgrade()`
 * declarations inside `ScreenshotDB`. The cross-tab `versionchange` handler
 * (close + reload so a newer schema can open) is attached in the
 * `ScreenshotDB` constructor — that is where Dexie expects it and where it
 * actually fires.
 *
 * This module only keeps DB-wide utility helpers.
 */

export async function clearDatabase(db: ScreenshotDB): Promise<void> {
  await db.transaction('rw', [db.screenshots, db.annotations, db.imageBlobs, db.processingQueue, db.groups, db.syncRecords, db.settings], async () => {
    await Promise.all([
      db.screenshots.clear(),
      db.annotations.clear(),
      db.imageBlobs.clear(),
      db.processingQueue.clear(),
      db.groups.clear(),
      db.syncRecords.clear(),
      db.settings.clear(),
    ]);
  });
}

export async function exportDatabaseInfo(db: ScreenshotDB): Promise<{
  name: string;
  version: number;
  tableStats: { name: string; count: number }[];
}> {
  const tables = ['screenshots', 'annotations', 'imageBlobs', 'settings', 'processingQueue', 'groups', 'syncRecords'] as const;

  const tableStats = await Promise.all(
    tables.map(async (tableName) => ({
      name: tableName,
      count: await db.table(tableName).count()
    }))
  );

  return {
    name: db.name,
    version: db.verno,
    tableStats
  };
}
