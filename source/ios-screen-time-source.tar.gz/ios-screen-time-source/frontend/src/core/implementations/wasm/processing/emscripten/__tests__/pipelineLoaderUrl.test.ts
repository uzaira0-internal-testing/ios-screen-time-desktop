/**
 * The loader stamps the ABI-coupled pipeline asset URLs with `?v=<wasm-hash>`
 * (the structural fix for the JS↔wasm ABI skew). The hash is a build-time
 * `define` (__PIPELINE_WASM_HASH__) that is absent in dev/test, where the
 * `typeof … !== "undefined"` guard must fall back to BARE URLs — never
 * `?v=undefined`, which would miss every precache key and break offline.
 *
 * This pins that fallback: if the guard ever regresses (e.g. someone drops the
 * `typeof` and references the bare identifier, or stamps unconditionally), these
 * fail instead of shipping a silent offline cache miss.
 */
import { describe, it, expect } from "bun:test";

import { getWasmUrl, getTessdataUrl } from "../pipelineLoader";

describe("pipelineLoader asset URLs (dev/test: no build-time hash)", () => {
  it("getWasmUrl() is the bare wasm URL — no ?v= stamp without a define", () => {
    const url = getWasmUrl();
    expect(url.endsWith("IosScreenTimePipeline.wasm")).toBe(true);
    expect(url).not.toContain("?v=");
    expect(url).not.toContain("undefined");
  });

  it("getTessdataUrl() is always bare (eng.traineddata is ABI-independent)", () => {
    const url = getTessdataUrl();
    expect(url.endsWith("eng.traineddata")).toBe(true);
    expect(url).not.toContain("?v=");
  });
});
