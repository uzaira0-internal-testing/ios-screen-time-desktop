/**
 * Unit tests for perceptual-hash distance math (the pure, DOM-free half). The
 * hash itself is computed in Rust (`codec::dhash_hex`, with its own tests) and
 * exercised end to end by the WASM persona suite.
 */
import { describe, it, expect } from "bun:test";
import { computePerceptualHash, hammingDistance, NEAR_DUPLICATE_MAX_DISTANCE } from "../perceptualHash";

describe("hammingDistance", () => {
  it("is 0 for identical hashes", () => {
    const h = "ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000";
    expect(hammingDistance(h, h)).toBe(0);
  });

  it("counts differing bits", () => {
    // 0x0 vs 0xf = 0b0000 vs 0b1111 → 4 bits differ.
    expect(hammingDistance("0", "f")).toBe(4);
    // single bit
    expect(hammingDistance("0", "1")).toBe(1);
    // 0xff vs 0x00 → 8 bits
    expect(hammingDistance("ff", "00")).toBe(8);
  });

  it("handles full-width 1024-bit hashes", () => {
    const zero = "0".repeat(256);
    const allOnes = "f".repeat(256);
    expect(hammingDistance(zero, zero)).toBe(0);
    expect(hammingDistance(zero, allOnes)).toBe(1024);
  });

  it("returns Infinity when either hash is missing or malformed", () => {
    expect(hammingDistance(null, "ff")).toBe(Infinity);
    expect(hammingDistance("ff", undefined)).toBe(Infinity);
    expect(hammingDistance("", "ff")).toBe(Infinity);
    expect(hammingDistance("xyz", "ff")).toBe(Infinity);
  });

  it("near-duplicate threshold is a small fraction of 1024 bits", () => {
    expect(NEAR_DUPLICATE_MAX_DISTANCE).toBeGreaterThan(0);
    expect(NEAR_DUPLICATE_MAX_DISTANCE).toBeLessThan(52); // well under 5% of 1024
  });
});

describe("computePerceptualHash", () => {
  it("rejects an already-aborted upload before hashing", async () => {
    await expect(computePerceptualHash(new Blob(), AbortSignal.abort())).rejects.toThrow("Perceptual hash aborted");
  });
});
