/**
 * Regression: advancing the annotation queue after the current item LEAVES the
 * "needs attention" (totals_mismatch) filter.
 *
 * The verify/submit auto-advance calls navigateScreenshots(currentId, {…,
 * direction:"next"}). When the user corrects + verifies an item, it drops out
 * of the needsAttention filter. The cursor walk then looked only for the first
 * remaining item with id GREATER than currentId and returned an empty result
 * when none existed — sending the user to the empty-queue page even though
 * lower-id items were still flagged. This locks the fix: it must land on a
 * remaining flagged item whenever any exist.
 */
import "fake-indexeddb/auto";
import { describe, it, expect, beforeEach } from "bun:test";
import { db } from "../database";
import { IndexedDBStorageService } from "../IndexedDBStorageService";
import type { Screenshot } from "@/types";

// The `db` Dexie singleton is constructed at module import, which can capture
// the indexedDB dependency before fake-indexeddb/auto wires the global. Point
// its deps at the fake factory so the test runs against an in-memory IndexedDB.
const deps = (db as unknown as { _deps: { indexedDB: unknown; IDBKeyRange: unknown } })._deps;
deps.indexedDB = globalThis.indexedDB;
deps.IDBKeyRange = globalThis.IDBKeyRange;

/** Completed row that needs attention (missing title) unless overridden. */
function make(id: number, overrides: Partial<Screenshot>): Screenshot {
  return {
    id,
    group_id: "g1",
    processing_status: "completed",
    annotation_status: "pending",
    extracted_hourly_data: { 0: 30, 1: 30 }, // sums to 60
    extracted_title: null, // missing title → needsAttention
    extracted_total: "1h", // 60 min — matches bar sum
    content_hash: `h-${id}`,
    verified_by_user_ids: null,
    ...overrides,
  } as Screenshot;
}

async function reset() {
  await db.delete();
  await db.open();
}

describe("navigateScreenshots after the current item leaves the needs-attention filter", () => {
  let storage: IndexedDBStorageService;

  beforeEach(async () => {
    await reset();
    storage = new IndexedDBStorageService();
  });

  it("advances to a remaining flagged item when the verified one had the highest id (was: empty page)", async () => {
    // ids 1 & 2 still need attention; id 3 was just corrected + verified so it
    // no longer needs attention and has the highest id in the queue.
    await db.screenshots.bulkPut([
      make(1, {}),
      make(2, {}),
      make(3, { extracted_title: "Instagram" }), // corrected → needsAttention false
    ]);

    const res = await storage.navigateScreenshots(3, {
      group_id: "g1",
      totals_mismatch: true,
      direction: "next",
    });

    expect(res.screenshot).not.toBeNull();
    expect([1, 2]).toContain(res.screenshot!.id);
    expect(res.total_in_filter).toBe(2);
  });

  it("control: verifying a middle item advances to the next greater flagged item", async () => {
    await db.screenshots.bulkPut([
      make(1, {}),
      make(2, { extracted_title: "Instagram" }), // corrected
      make(3, {}),
    ]);

    const res = await storage.navigateScreenshots(2, {
      group_id: "g1",
      totals_mismatch: true,
      direction: "next",
    });

    expect(res.screenshot?.id).toBe(3);
  });

  it("returns empty only when the queue is genuinely drained", async () => {
    await db.screenshots.bulkPut([
      make(1, { extracted_title: "A" }), // all corrected
      make(2, { extracted_title: "B" }),
    ]);

    const res = await storage.navigateScreenshots(2, {
      group_id: "g1",
      totals_mismatch: true,
      direction: "next",
    });

    expect(res.screenshot).toBeNull();
    expect(res.total_in_filter).toBe(0);
  });
});
