/**
 * OPFS (Origin Private File System) Blob Storage
 *
 * Primary storage for image blobs. Falls back to IndexedDB blob table
 * if OPFS is unavailable (older browsers without OPFS support).
 *
 * Also provides utility functions for storage quota management and blob
 * info retrieval.
 */

import { db } from "./database";
import { readImageDimensions } from "../utils/imageLimits";
import type { ImageDimensions } from "../utils/imageLimits";
import {
  browserResourceNumber,
  computeImageUrlCacheSize,
  computeMetadataIoConcurrency,
} from "@/lib/resourceBudget";
import { displayText } from "@/lib/displayText";
import { writeOpfsFile } from "./opfsWrite";

export { readImageDimensions };
export type { ImageDimensions };

let opfsRoot: FileSystemDirectoryHandle | null = null;

function storedBlobSize(value: Blob | ArrayBuffer): number {
  return value instanceof Blob ? value.size : value.byteLength;
}

function materializeStoredBlob(
  record: { blob: Blob | ArrayBuffer; mimeType?: string; revision?: string; uploadedAt?: Date | string } | undefined,
): Blob | null {
  if (!record) return null;
  const blob = record.blob instanceof Blob
    ? record.blob
    : new Blob([record.blob], { type: record.mimeType ?? "application/octet-stream" });
  if (record.revision) blobRevisions.set(blob, record.revision);
  else if (record.uploadedAt) blobRevisions.set(blob, `idb:${new Date(record.uploadedAt).getTime()}:${blob.size}`);
  return blob;
}

async function indexedDbBlobRecord(screenshotId: number, blob: Blob) {
  return {
    screenshotId,
    blob: await blob.arrayBuffer(),
    mimeType: blob.type,
    revision: typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}:${Math.random()}`,
    uploadedAt: new Date(),
  };
}

function metadataIoConcurrency(): number {
  return computeMetadataIoConcurrency(
    browserResourceNumber("hardwareConcurrency"),
    browserResourceNumber("deviceMemory"),
  );
}

async function mapBoundedSettled<T>(
  items: readonly T[],
  concurrency: number,
  mapper: (item: T, index: number) => Promise<void>,
): Promise<PromiseSettledResult<void>[]> {
  const results = new Array<PromiseSettledResult<void>>(items.length);
  let cursor = 0;
  const runner = async (): Promise<void> => {
    const index = cursor++;
    if (index >= items.length) return;
    try {
      await mapper(items[index]!, index);
      results[index] = { status: "fulfilled", value: undefined };
    } catch (reason) {
      results[index] = { status: "rejected", reason };
    }
    return runner();
  };
  await Promise.all(
    Array.from({ length: Math.min(Math.max(1, concurrency), items.length) }, () => runner()),
  );
  return results;
}

/** Thrown when a write fails because the browser storage quota is exhausted. */
export class StorageQuotaExceededError extends Error {
  constructor(message = "Storage is full") {
    super(message);
    this.name = "StorageQuotaExceededError";
  }
}

/**
 * Cross-browser detection of a quota-exceeded failure. Chrome and Firefox
 * throw a `DOMException` named `QuotaExceededError`; older Safari used code 22
 * / name `QUOTA_EXCEEDED_ERR`. Dexie and the OPFS layer wrap errors, so the
 * cause chain (`inner` / `cause`) is walked too.
 */
export function isQuotaExceeded(err: unknown): boolean {
  let e: unknown = err;
  for (let depth = 0; e != null && depth < 5; depth++) {
    if (
      (e instanceof DOMException || e instanceof Error) &&
      (e.name === "QuotaExceededError" || e.name === "QUOTA_EXCEEDED_ERR")
    ) {
      return true;
    }
    if (typeof e === "object" && (e as { code?: number }).code === 22) {
      return true;
    }
    const next = e as { inner?: unknown; cause?: unknown };
    e = next.inner ?? next.cause;
  }
  return false;
}

/**
 * A revoking LRU cache of object URLs. When an entry is evicted (over capacity)
 * or explicitly revoked, the underlying blob URL is released via
 * `URL.revokeObjectURL` — preventing the monotonic memory leak that an unbounded
 * `Map<…, string>` of blob URLs causes.
 */
export interface RevokingURLCache<K> {
  get(key: K): string | undefined;
  set(key: K, url: string): void;
  has(key: K): boolean;
  revoke(key: K): void;
  clear(): void;
  readonly size: number;
}

export function createRevokingURLCache<K>(maxSize: number): RevokingURLCache<K> {
  const cache = new Map<K, string>();
  const accessOrder: K[] = [];

  const touch = (key: K): void => {
    const idx = accessOrder.indexOf(key);
    if (idx > -1) accessOrder.splice(idx, 1);
    accessOrder.push(key);
  };

  const evict = (): void => {
    while (accessOrder.length > maxSize) {
      const oldest = accessOrder.shift();
      if (oldest !== undefined) {
        const url = cache.get(oldest);
        if (url) {
          URL.revokeObjectURL(url);
          cache.delete(oldest);
        }
      }
    }
  };

  return {
    get(key) {
      const url = cache.get(key);
      if (url) touch(key);
      return url;
    },
    set(key, url) {
      // Revoke any prior URL for this exact key — overwriting without
      // revoking is precisely the leak this cache exists to prevent.
      const prev = cache.get(key);
      if (prev && prev !== url) URL.revokeObjectURL(prev);
      cache.set(key, url);
      touch(key);
      evict();
    },
    has(key) {
      return cache.has(key);
    },
    revoke(key) {
      const url = cache.get(key);
      if (url) {
        URL.revokeObjectURL(url);
        cache.delete(key);
        const idx = accessOrder.indexOf(key);
        if (idx > -1) accessOrder.splice(idx, 1);
      }
    },
    clear() {
      for (const url of cache.values()) URL.revokeObjectURL(url);
      cache.clear();
      accessOrder.length = 0;
    },
    get size() {
      return cache.size;
    },
  };
}

// LRU cache for screenshot image object URLs (number-keyed by screenshot ID).
// Each cached blob: URL pins its backing Blob in memory. The grid/queue views
// are virtualized (only visible rows mint URLs), so cache residency can be sized
// as a RAM budget. Unknown-memory browsers use the same conservative 1 GB
// fallback as OCR/upload scheduling.
const MAX_CACHE_SIZE = computeImageUrlCacheSize(browserResourceNumber("deviceMemory"));
const imageURLCache = createRevokingURLCache<number>(MAX_CACHE_SIZE);
// In-flight requests to prevent duplicate blob URL creation for the same ID
const inFlight = new Map<number, Promise<string | null>>();
const blobRevisions = new WeakMap<Blob, string | number>();
const urlRevisions = new Map<number, string | number>();
let nextBlobRevision = 0;

// ---------------------------------------------------------------------------
// Running blob-size total — avoids an O(N) OPFS file walk on every getStats().
// ---------------------------------------------------------------------------

const BLOB_SIZE_KEY = "opfs_blob_total_size";
/** Cached running total, lazily initialized. null = not yet computed. */
let cachedBlobTotal: number | null = null;
let blobTotalInitPromise: Promise<number> | null = null;

/** Read the size of an existing OPFS/IndexedDB blob, 0 if it does not exist. */
async function existingBlobSize(name: string, fallbackKey: number): Promise<number> {
  const fallback = await db.imageBlobs.get(fallbackKey);
  if (fallback) return storedBlobSize(fallback.blob);
  const root = await getOpfsRoot();
  if (root) {
    try {
      const handle = await root.getFileHandle(name);
      return (await handle.getFile()).size;
    } catch {
      // A previous write may have fallen back to IndexedDB even though OPFS
      // itself is detectable (notably WebKit implementations with incomplete
      // writable-file support).
      const entry = await db.imageBlobs.get(fallbackKey);
      return entry ? storedBlobSize(entry.blob) : 0;
    }
  }
  const entry = await db.imageBlobs.get(fallbackKey);
  return entry ? storedBlobSize(entry.blob) : 0;
}

/**
 * Adjust the persisted running blob-size total by `delta`. No-op until the
 * total has been initialized (first getTotalBlobSize call) — a partial counter
 * is worse than recomputing once. Persisted to the `settings` table so it
 * survives reloads. Wrapped in a settings-table transaction to avoid lost
 * updates between concurrent writers.
 */
async function adjustBlobTotal(delta: number): Promise<void> {
  if (delta === 0) return;
  if (cachedBlobTotal === null) return; // not yet initialized — recompute later
  try {
    await db.transaction("rw", db.settings, async () => {
      const row = await db.settings.where("key").equals(BLOB_SIZE_KEY).first();
      const current = typeof row?.value === "number" ? row.value : (cachedBlobTotal ?? 0);
      const next = Math.max(0, current + delta);
      cachedBlobTotal = next;
      if (row?.id !== undefined) {
        await db.settings.update(row.id, { value: next, updatedAt: new Date().toISOString() });
      } else {
        await db.settings.add({ key: BLOB_SIZE_KEY, value: next, updatedAt: new Date().toISOString() });
      }
    });
  } catch (err) {
    // A failed counter update must not break the actual blob write — just
    // invalidate the cache so the next getTotalBlobSize recomputes from disk.
    console.warn("[opfsBlobStorage] Failed to update blob-size counter:", err);
    // eslint-disable-next-line require-atomic-updates -- invalidating an idempotent cache; next read recomputes from disk
    cachedBlobTotal = null;
  }
}

async function getOpfsRoot(strict = false): Promise<FileSystemDirectoryHandle | null> {
  if (opfsRoot && !strict) return opfsRoot;

  // OPFS unsupported (old browser). Checked on every call rather than cached:
  // the check is a property lookup, and a cached "unsupported" would outlive
  // the environment that produced it.
  if (typeof navigator === "undefined" || !navigator.storage?.getDirectory) return null;

  try {
    const root = await navigator.storage.getDirectory();
    // eslint-disable-next-line require-atomic-updates -- idempotent singleton init; getDirectoryHandle is stable across concurrent calls
    opfsRoot = await root.getDirectoryHandle("screenshots", { create: true });
    return opfsRoot;
  } catch (error) {
    if (strict) throw error;
    // A transient failure (load race, one-off SecurityError) must NOT
    // permanently downgrade the session to the IndexedDB fallback; nothing
    // is cached, so the next call re-probes.
    console.warn(
      "[opfsBlobStorage] OPFS probe failed, will retry on next access:",
      error instanceof Error ? error.message : error,
    );
    return null;
  }
}

// ---------------------------------------------------------------------------
// Per-stage snapshot storage (e.g., "123_stage_cropping.img")
// ---------------------------------------------------------------------------

export async function storeStageBlob(id: number, stage: string, blob: Blob): Promise<void> {
  const root = await getOpfsRoot();
  // Capture the size being replaced so the running total stays accurate.
  const prevSize = await existingBlobSize(
    `${id}_stage_${stage}.img`,
    -(id * 100 + stageIndex(stage)),
  );
  if (root) {
    try {
      await writeOpfsFile(root, ["screenshots"], `${id}_stage_${stage}.img`, blob);
      await db.imageBlobs.delete(-(id * 100 + stageIndex(stage)));
      await adjustBlobTotal(blob.size - prevSize);
      return;
    } catch (error) {
      if (isQuotaExceeded(error)) {
        throw new StorageQuotaExceededError(
          `Storage is full — could not save the ${stage} stage of screenshot ${id}. ` +
            `Free space by deleting screenshots or exporting and clearing data.`,
        );
      }
      console.warn(
        `[opfsBlobStorage] OPFS stage write unavailable for ${id}/${stage}; using IndexedDB fallback:`,
        error instanceof Error ? error.message : error,
      );
    }
  }
  // IndexedDB fallback — use a composite key. This also handles browsers that
  // expose navigator.storage.getDirectory but cannot create writable files.
  try {
    await db.imageBlobs.put(
      await indexedDbBlobRecord(-(id * 100 + stageIndex(stage)), blob),
    );
  } catch (error) {
    if (isQuotaExceeded(error)) {
      throw new StorageQuotaExceededError(
        `Storage is full — could not save the ${stage} stage of screenshot ${id}.`,
      );
    }
    console.warn(
      `[opfsBlobStorage] IndexedDB stage fallback failed for ${id}/${stage}: ` +
        `${error instanceof Error ? `${error.name}: ${error.message}` : String(error)}`,
    );
    throw error;
  }
  await adjustBlobTotal(blob.size - prevSize);
}

export async function retrieveStageBlob(id: number, stage: string): Promise<Blob | null> {
  const fallback = await db.imageBlobs.get(-(id * 100 + stageIndex(stage)));
  if (fallback) return materializeStoredBlob(fallback);
  const root = await getOpfsRoot();
  if (root) {
    try {
      const fileHandle = await root.getFileHandle(`${id}_stage_${stage}.img`);
      const file = await fileHandle.getFile();
      return file;
    } catch (error) {
      if (!(error instanceof DOMException && error.name === "NotFoundError")) {
        console.warn(`[opfsBlobStorage] Error retrieving stage blob for ${id}/${stage}; trying IndexedDB:`, error);
      }
    }
  }
  const entry = await db.imageBlobs.get(-(id * 100 + stageIndex(stage)));
  return materializeStoredBlob(entry);
}

/** Map stage names to numeric indices for IndexedDB fallback key encoding. */
function stageIndex(stage: string): number {
  const stages: Record<string, number> = { original: 0, device_detection: 1, cropping: 2, phi_detection: 3, phi_redaction: 4 };
  const idx = stages[stage];
  if (idx === undefined) {
    throw new Error(`Unknown preprocessing stage: "${stage}"`);
  }
  return idx;
}

export async function storeImageBlob(id: number, blob: Blob): Promise<void> {
  // Invalidate any cached object URL for this ID — the underlying blob is changing
  revokeObjectURL(id);

  const root = await getOpfsRoot();
  const prevSize = await existingBlobSize(`${id}.img`, id);
  if (root) {
    try {
      await writeOpfsFile(root, ["screenshots"], `${id}.img`, blob);
      await db.imageBlobs.delete(id);
      await adjustBlobTotal(blob.size - prevSize);
      return;
    } catch (error) {
      if (isQuotaExceeded(error)) {
        throw new StorageQuotaExceededError(
          `Storage is full — could not save screenshot ${id}. ` +
            `Free space by deleting screenshots or exporting and clearing data.`,
        );
      }
      console.warn(
        `[opfsBlobStorage] OPFS image write unavailable for ${id}; using IndexedDB fallback:`,
        error instanceof Error ? error.message : error,
      );
    }
  }
  try {
    await db.imageBlobs.put(await indexedDbBlobRecord(id, blob));
  } catch (error) {
    if (isQuotaExceeded(error)) {
      throw new StorageQuotaExceededError(`Storage is full — could not save screenshot ${id}.`);
    }
    console.warn(
      `[opfsBlobStorage] IndexedDB image fallback failed for ${id}: ` +
        `${error instanceof Error ? `${error.name}: ${error.message}` : String(error)}`,
    );
    throw error;
  }
  await adjustBlobTotal(blob.size - prevSize);
}

export async function retrieveImageBlob(id: number): Promise<Blob | null> {
  const fallback = await db.imageBlobs.get(id);
  if (fallback) return materializeStoredBlob(fallback);
  const root = await getOpfsRoot();
  if (root) {
    try {
      const fileHandle = await root.getFileHandle(`${id}.img`);
      const file = await fileHandle.getFile();
      if (typeof file.lastModified === "number") blobRevisions.set(file, `opfs:${file.lastModified}:${file.size}`);
      return file;
    } catch (error) {
      if (!(error instanceof DOMException && error.name === "NotFoundError")) {
        console.warn(`[opfsBlobStorage] Error retrieving blob for screenshot ${id}; trying IndexedDB:`, error);
      }
    }
  }
  const entry = await db.imageBlobs.get(id);
  return materializeStoredBlob(entry);
}

export async function deleteImageBlob(id: number): Promise<void> {
  // Revoke any cached URL
  revokeObjectURL(id);

  const root = await getOpfsRoot(true);
  const prevSize = await existingBlobSize(`${id}.img`, id);
  if (root) {
    try {
      await root.removeEntry(`${id}.img`);
    } catch (error) {
      if (!(error instanceof DOMException && error.name === "NotFoundError")) {
        throw error;
      }
    }
  }
  // Delete a possible per-blob fallback as well; OPFS availability does not
  // imply that this particular write succeeded there.
  await db.imageBlobs.delete(id);
  await adjustBlobTotal(-prevSize);
}

/** All known preprocessing stage names — must match stageIndex(). */
export const ALL_STAGES = ["original", "device_detection", "cropping", "phi_detection", "phi_redaction"] as const;

/**
 * Delete a single stage snapshot blob. Used to securely drop the pre-redaction
 * source images (`original`, `device_detection`, `cropping`, `phi_detection`)
 * once redaction has produced a clean blob — otherwise the un-redacted PHI
 * imagery survives indefinitely and is one `getStageBlob` call away.
 * A missing blob is not an error; other deletion failures propagate.
 */
export async function deleteStageBlob(id: number, stage: string): Promise<void> {
  const root = await getOpfsRoot(true);
  const prevSize = await existingBlobSize(
    `${id}_stage_${stage}.img`,
    -(id * 100 + stageIndex(stage)),
  );
  if (root) {
    try {
      await root.removeEntry(`${id}_stage_${stage}.img`);
    } catch (error) {
      if (!(error instanceof DOMException && error.name === "NotFoundError")) {
        throw error;
      }
    }
  }
  await db.imageBlobs.delete(-(id * 100 + stageIndex(stage)));
  await adjustBlobTotal(-prevSize);
}

/**
 * Delete the main image blob AND all stage blobs for a screenshot.
 * Handles both OPFS and IndexedDB fallback paths; deletion failures propagate.
 */
export async function deleteAllBlobsForScreenshot(id: number): Promise<void> {
  revokeObjectURL(id);

  await deleteImageBlob(id);
  const results = await mapBoundedSettled(
    ALL_STAGES,
    metadataIoConcurrency(),
    (stage) => deleteStageBlob(id, stage),
  );
  const failure = results.find((result) => result.status === "rejected");
  if (failure?.status === "rejected") throw failure.reason;
}

/**
 * Create an object URL for a screenshot image.
 *
 * If a blob is provided, it is used directly. Otherwise the blob is
 * retrieved from storage. Returns null when no blob can be found.
 */
export async function createObjectURL(
  id: number,
  blob?: Blob,
): Promise<string | null> {
  // Deduplicate concurrent requests for the same ID to prevent leaked blob URLs.
  // Skip dedup when an explicit blob is provided — the caller has the data already
  // and a concurrent no-blob request might resolve to null.
  if (!blob) {
    const pending = inFlight.get(id);
    if (pending) return pending;
  }

  const promise = (async () => {
    const resolvedBlob = blob ?? (await retrieveImageBlob(id));
    if (!resolvedBlob) {
      return null;
    }

    const cached = imageURLCache.get(id);
    let revision = blobRevisions.get(resolvedBlob);
    if (revision === undefined) {
      revision = ++nextBlobRevision;
      blobRevisions.set(resolvedBlob, revision);
    }
    if (cached && urlRevisions.get(id) === revision) return cached;
    const url = URL.createObjectURL(resolvedBlob);
    imageURLCache.set(id, url);
    urlRevisions.set(id, revision);
    for (const key of urlRevisions.keys()) if (!imageURLCache.has(key)) urlRevisions.delete(key);
    return url;
  })();

  inFlight.set(id, promise);
  try {
    return await promise;
  } finally {
    inFlight.delete(id);
  }
}

export function revokeObjectURL(id: number): void {
  imageURLCache.revoke(id);
  urlRevisions.delete(id);
}

export function revokeAllObjectURLs(): void {
  imageURLCache.clear();
  urlRevisions.clear();
}

/**
 * Delete all image blobs from OPFS storage.
 * Falls back to clearing IndexedDB imageBlobs table if OPFS is unavailable.
 *
 * Purges both the `screenshots/` directory (image + stage blobs) AND the
 * sibling `db-backups/` directory under the true OPFS root, which holds
 * pre-migration metadata backups (PHI-bearing). Reports partial failure by
 * throwing — a caller that goes on to wipe IndexedDB metadata after a silent
 * partial failure would strand un-enumerable PHI blobs on disk.
 */
export async function clearAllOpfsBlobs(): Promise<void> {
  revokeAllObjectURLs();
  const root = await getOpfsRoot(true);
  if (!root) {
    await db.imageBlobs.clear();
    await recomputeBlobTotalFromDisk();
    return;
  }

  const failures: string[] = [];

  // `root` is the `screenshots/` subdirectory — remove every file inside it.
  const entries: string[] = [];
  for await (const [name] of root as unknown as AsyncIterable<[string, FileSystemHandle]>) {
    entries.push(name);
  }
  const results = await mapBoundedSettled(
    entries,
    metadataIoConcurrency(),
    (name) => root.removeEntry(name),
  );
  results.forEach((r, i) => {
    if (r.status === "rejected") failures.push(`screenshots/${entries[i]}: ${r.reason}`);
  });

  // Purge sibling directories under the true OPFS root that also hold PHI.
  try {
    const trueRoot = await navigator.storage.getDirectory();
    for (const dir of ["db-backups"]) {
      // eslint-disable-next-line no-await-in-loop -- loop kept for extensibility; currently one known sibling dir
      await trueRoot.removeEntry(dir, { recursive: true }).catch((err: unknown) => {
        if (!(err instanceof DOMException && err.name === "NotFoundError")) {
          failures.push(`${dir}/: ${err instanceof Error ? err.message : String(err)}`);
        }
      });
    }
  } catch (err) {
    failures.push(`true-root access: ${err instanceof Error ? err.message : String(err)}`);
  }

  if (failures.length > 0) {
    throw new Error(
      `clearAllOpfsBlobs: ${failures.length} OPFS entr(ies) failed to delete — ` +
        `PHI may remain on disk:\n${failures.join("\n")}`,
    );
  }
  await db.imageBlobs.clear();
  await recomputeBlobTotalFromDisk();
}

// ---------------------------------------------------------------------------
// Utility functions for storage quota and blob info
// ---------------------------------------------------------------------------

export async function getImageBlobInfo(screenshotId: number): Promise<{
  size: number;
  type: string;
  uploadedAt: string;
} | null> {
  const blob = await retrieveImageBlob(screenshotId);
  if (!blob) {
    return null;
  }

  return {
    size: blob.size,
    type: blob.type,
    // OPFS doesn't store uploadedAt metadata; approximate with current time
    uploadedAt: "",
  };
}

/**
 * Full O(N) recompute of total blob size by walking every file. Used once to
 * seed the running counter, and as a fallback when the counter is invalidated.
 *
 * Signals partial failure by throwing: a mid-iteration error previously
 * returned a confidently-wrong partial total, which the storage UI then
 * displayed as fact. Callers that need a best-effort number catch this.
 */
async function recomputeTotalBlobSize(): Promise<number> {
  const root = await getOpfsRoot();
  if (root) {
    let total = 0;
    let failure: unknown = null;
    try {
      for await (const [, handle] of root as unknown as AsyncIterable<
        [string, FileSystemHandle]
      >) {
        if (handle.kind === "file") {
          try {
            const file = await (handle as FileSystemFileHandle).getFile();
            total += file.size;
          } catch (err) {
            // Record the first per-file failure but keep walking so the
            // thrown error carries the most complete count we could get.
            failure ??= err;
          }
        }
      }
    } catch (err) {
      failure ??= err;
    }
    if (failure) {
      throw new Error(
        `getTotalBlobSize: OPFS walk failed partway — reported size ` +
          `(${total} bytes) is incomplete: ${failure instanceof Error ? failure.message : displayText(failure)}`,
      );
    }
    // OPFS can be available while individual writes still require the
    // IndexedDB fallback, so the authoritative total spans both stores.
    const fallbackBlobs = await db.imageBlobs.toArray();
    return total + fallbackBlobs.reduce((sum, record) => sum + storedBlobSize(record.blob), 0);
  } else {
    const allBlobs = await db.imageBlobs.toArray();
    return allBlobs.reduce((sum, record) => sum + storedBlobSize(record.blob), 0);
  }
}

/**
 * Total size of all stored image blobs. Reads a persisted running counter
 * (maintained on every store/delete) instead of walking every OPFS file on
 * each call. The counter is lazily seeded from a one-time full walk; if that
 * walk fails partway it propagates the error rather than caching a wrong total.
 */
export async function getTotalBlobSize(): Promise<number> {
  if (cachedBlobTotal !== null) return cachedBlobTotal;
  if (blobTotalInitPromise) return blobTotalInitPromise;

  blobTotalInitPromise = (async () => {
    // Trust a previously persisted counter if one exists.
    try {
      const row = await db.settings.where("key").equals(BLOB_SIZE_KEY).first();
      if (row && typeof row.value === "number") {
        cachedBlobTotal = row.value;
        return row.value;
      }
    } catch {
      // settings table unreadable — fall through to a full recompute.
    }
    // No counter yet — compute it once and persist.
    const total = await recomputeTotalBlobSize();
    cachedBlobTotal = total;
    try {
      await db.settings.add({
        key: BLOB_SIZE_KEY,
        value: total,
        updatedAt: new Date().toISOString(),
      });
    } catch {
      // Concurrent seed or quota — counter still valid in memory.
    }
    return total;
  })();

  try {
    return await blobTotalInitPromise;
  } catch (err) {
    // Recompute failed — leave the counter uninitialized so the next call
    // retries, and propagate so the UI can flag the figure as unavailable.
    blobTotalInitPromise = null;
    throw err;
  }
}

/**
 * Force a fresh O(N) recompute of the blob-size total from disk and persist it,
 * discarding any cached or persisted counter. Use after a bulk restore (workspace
 * import) where many incremental `adjustBlobTotal` calls — possibly racing — may
 * have drifted the running counter from the on-disk truth.
 */
export async function recomputeBlobTotalFromDisk(): Promise<number> {
  cachedBlobTotal = null;
  blobTotalInitPromise = null;
  try {
    const row = await db.settings.where("key").equals(BLOB_SIZE_KEY).first();
    if (row?.id !== undefined) await db.settings.delete(row.id);
  } catch {
    // settings unreadable — getTotalBlobSize() will still walk disk and reseed.
  }
  return getTotalBlobSize();
}

export async function checkStorageQuota(): Promise<{
  usage: number;
  quota: number;
  percentUsed: number;
  available: number;
}> {
  if (!navigator.storage || !navigator.storage.estimate) {
    console.warn("[opfsBlobStorage] Storage estimation API unavailable");
    return {
      usage: 0,
      quota: Infinity,
      percentUsed: 0,
      available: Infinity,
    };
  }

  const estimate = await navigator.storage.estimate();
  const usage = estimate.usage || 0;
  const quota = estimate.quota || 0;
  const percentUsed = quota > 0 ? (usage / quota) * 100 : 0;
  const available = quota - usage;

  return {
    usage,
    quota,
    percentUsed,
    available,
  };
}

export async function canStoreBlob(blob: Blob): Promise<boolean> {
  const quota = await checkStorageQuota();
  const blobSize = blob.size;

  const SAFETY_MARGIN = 10 * 1024 * 1024;

  return quota.available > blobSize + SAFETY_MARGIN;
}
