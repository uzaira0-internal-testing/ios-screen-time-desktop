/**
 * Runtime primitives shared by the browser preprocessing stage coordinator.
 *
 * Keeping concurrency, cancellation, and accounting outside the service makes
 * the orchestration class responsible for stage behavior instead of also being
 * the implementation of its scheduler.
 */
import {
  browserResourceNumber,
  computeCropDecodeConcurrency as computeBudgetedCropDecodeConcurrency,
  computeDeviceDetectionConcurrency as computeBudgetedDeviceDetectionConcurrency,
  computeDeviceCropConcurrency as computeBudgetedDeviceCropConcurrency,
  computeMetadataIoConcurrency,
} from "@/lib/resourceBudget";

export interface StageRunAccounting {
  queuedItems: number;
  configuredConcurrency: number;
  completedItems: number;
  failedItems: number;
  abortedItems: number;
  cacheHits: number;
  currentInFlightItems: number;
  maxInFlightItems: number;
  totalItemMs: number;
  maxItemMs: number;
}

export interface MutablePreprocessingStageStats {
  runs: number;
  totalQueuedItems: number;
  totalCompletedItems: number;
  totalFailedItems: number;
  totalAbortedItems: number;
  totalCacheHits: number;
  totalRunMs: number;
  maxRunMs: number;
  totalItemMs: number;
  maxItemMs: number;
  maxInFlightItems: number;
  lastQueuedItems: number;
  lastCompletedItems: number;
  lastFailedItems: number;
  lastAbortedItems: number;
  lastCacheHits: number;
  lastRunMs: number;
  lastConfiguredConcurrency: number;
  lastMaxInFlightItems: number;
}

export const FALLBACK_PREPROCESS_CORES = 4;

export function monotonicNow(): number {
  return typeof performance !== "undefined" && typeof performance.now === "function"
    ? performance.now()
    : Date.now();
}

function abortError(message = "Preprocessing stage aborted"): Error {
  try {
    return new DOMException(message, "AbortError");
  } catch {
    const error = new Error(message);
    error.name = "AbortError";
    return error;
  }
}

export function throwIfAborted(signal?: AbortSignal): void {
  if (signal?.aborted) throw abortError();
}

export function isAbortLike(reason: unknown, signal?: AbortSignal): boolean {
  return signal?.aborted === true || (reason instanceof Error && reason.name === "AbortError");
}

export async function mapBounded<T, R>(
  items: readonly T[],
  concurrency: number,
  mapper: (item: T, index: number) => Promise<R>,
): Promise<R[]> {
  const results = new Array<R>(items.length);
  let cursor = 0;
  const runner = async (): Promise<void> => {
    const index = cursor++;
    if (index >= items.length) return;
    results[index] = await mapper(items[index]!, index);
    return runner();
  };
  await Promise.all(
    Array.from({ length: Math.min(Math.max(1, concurrency), items.length) }, () => runner()),
  );
  return results;
}

export function computeCropDecodeConcurrency(
  cores = FALLBACK_PREPROCESS_CORES,
  deviceMemoryGb?: number,
): number {
  return computeBudgetedCropDecodeConcurrency(cores, deviceMemoryGb);
}

export function computeDeviceDetectionConcurrency(
  cores = FALLBACK_PREPROCESS_CORES,
  deviceMemoryGb?: number,
): number {
  return computeBudgetedDeviceDetectionConcurrency(cores, deviceMemoryGb);
}

export function computeDeviceCropConcurrency(
  cores = FALLBACK_PREPROCESS_CORES,
  deviceMemoryGb?: number,
): number {
  return computeBudgetedDeviceCropConcurrency(cores, deviceMemoryGb);
}

export function metadataIoConcurrency(): number {
  return computeMetadataIoConcurrency(
    browserResourceNumber("hardwareConcurrency") ?? FALLBACK_PREPROCESS_CORES,
    browserResourceNumber("deviceMemory"),
  );
}
