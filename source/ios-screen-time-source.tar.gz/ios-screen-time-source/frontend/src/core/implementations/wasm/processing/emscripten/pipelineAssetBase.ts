/**
 * Base URL for the pipeline's static assets (`pipeline-em/`).
 *
 * Its own module so the Settings UI can resolve language-pack URLs without
 * importing `pipelineLoader` — that module pulls in the Emscripten glue and is
 * deliberately kept out of the main bundle.
 *
 * Resolved against the bundled chunk URL rather than an absolute `/pipeline-em/`
 * so a GitHub Pages subpath deploy works: the chunk lands at
 * `https://<host>/<repo>/assets/<chunk>.js`, so `../pipeline-em/` becomes
 * `<repo>/pipeline-em/`. An absolute path would break the subpath.
 */
export const PIPELINE_ASSET_BASE = new URL("../pipeline-em/", import.meta.url).href;

/** URL of a downloadable OCR language pack. Packs sit beside the bundled
 *  `eng.traineddata` so every Tesseract asset shares one directory and one
 *  cache policy. */
export function languagePackUrl(code: string): string {
  return `${PIPELINE_ASSET_BASE}tessdata/${code}.traineddata`;
}
