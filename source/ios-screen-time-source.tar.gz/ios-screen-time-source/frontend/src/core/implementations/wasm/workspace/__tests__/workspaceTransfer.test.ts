import "fake-indexeddb/auto";
import { afterEach, beforeEach, describe, expect, test } from "bun:test";
import { db } from "../../storage/database";
import { encodeWorkspaceArchive, decodeWorkspaceArchive } from "../workspaceArchive";
import type { WorkspaceManifest, WorkspaceTables } from "../workspaceTypes";
import type { IStorageService } from "@/core/interfaces";
import { IndexedDBStorageService } from "../../storage/IndexedDBStorageService";
import { useSettingsStore } from "@/store/settingsStore";
import { setPackEnabled, readLanguagePack, removeLanguagePack } from "../../languagePacks/languagePackStore";
import { LANGUAGE_PACKS } from "@/core/generated/constants";
import Dexie from "dexie";
import { importWorkspace, exportWorkspace } from "../workspaceTransfer";

const deps = (db as unknown as { _deps: { indexedDB: unknown; IDBKeyRange: unknown } })._deps;
deps.indexedDB = globalThis.indexedDB;
deps.IDBKeyRange = globalThis.IDBKeyRange;

const originalLocalStorage = Object.getOwnPropertyDescriptor(globalThis, "localStorage");
const values = new Map<string, string>();
const originalNavigator = Object.getOwnPropertyDescriptor(globalThis, "navigator");

function restoreNavigator(): void {
  if (originalNavigator) {
    Object.defineProperty(globalThis, "navigator", originalNavigator);
  } else {
    Reflect.deleteProperty(globalThis, "navigator");
  }
}

describe("exportWorkspace", () => {
  beforeEach(async () => {
    values.clear();
    Object.defineProperty(globalThis, "localStorage", { configurable: true, value: {
      getItem: (key: string) => values.get(key) ?? null,
      setItem: (key: string, value: string) => values.set(key, value),
      removeItem: (key: string) => values.delete(key),
    } });
    await db.delete();
    await db.open();
  });

  afterEach(async () => {
    restoreNavigator();
    if (originalLocalStorage) Object.defineProperty(globalThis, "localStorage", originalLocalStorage);
    else Reflect.deleteProperty(globalThis, "localStorage");
    await db.delete();
  });

  test("malformed tables, duplicate keys, dangling references and missing images never clear the workspace", async () => {
    const empty: WorkspaceTables = { screenshots: [], annotations: [], groups: [], settings: [], processingQueue: [], syncRecords: [] };
    const variants = [
      { ...empty, settings: undefined },
      { ...empty, screenshots: [null] },
      { ...empty, settings: [{ id: 1, key: "same", value: 1, updatedAt: "now" }, { id: 2, key: "same", value: 2, updatedAt: "now" }] },
      { ...empty, processingQueue: [{ id: 1, screenshotId: 99, status: "pending", priority: 0, createdAt: "now" }] },
      { ...empty, screenshots: [{ id: 1, file_path: "one.png", image_type: "screen_time", uploaded_at: "now", annotation_status: "pending", processing_status: "pending", target_annotations: 1, current_annotation_count: 0, has_consensus: null, uploaded_by_id: null, has_blocking_issues: false }] },
    ];
    let cleared = 0;
    const storage = { clearAll: async () => { cleared++; } } as unknown as IStorageService;
    await Promise.all(variants.map(async (tables) => {
      const manifest = { format: "ios-screen-time-workspace", formatVersion: 1, dbVersion: 7, exportedAt: "now", counts: { screenshots: tables.screenshots.length, annotations: tables.annotations.length, groups: tables.groups.length, settings: tables.settings?.length ?? 0, processingQueue: tables.processingQueue.length, syncRecords: tables.syncRecords.length, blobs: 0 } } as WorkspaceManifest;
      const archive = await encodeWorkspaceArchive(manifest, tables as unknown as WorkspaceTables, [], new Map());
      await expect(importWorkspace(new Uint8Array(await archive.arrayBuffer()), storage)).rejects.toThrow();
    }));
    expect(cleared).toBe(0);
  });

  test("export reads all tables in one transaction and rejects a missing main image", async () => {
    let transactions = 0;
    const originalDescriptor = Object.getOwnPropertyDescriptor(db.settings, "toArray");
    const original = db.settings.toArray.bind(db.settings);
    db.settings.toArray = (async () => {
      if (Dexie.currentTransaction) transactions++;
      return original();
    }) as unknown as typeof db.settings.toArray;
    try {
      await exportWorkspace();
      expect(transactions).toBe(1);
      await db.screenshots.put({ id: 7 } as WorkspaceTables["screenshots"][number]);
      await expect(exportWorkspace()).rejects.toThrow("main image");
    } finally {
      if (originalDescriptor) Object.defineProperty(db.settings, "toArray", originalDescriptor);
      else Reflect.deleteProperty(db.settings, "toArray");
    }
  });

  test("replacement clears previous annotation recovery drafts and groups", async () => {
    const archive = await exportWorkspace();
    values.set("unsaved-annotations", "[{\"screenshot_id\":7}]");
    await db.groups.put({ id: "old", name: "Old" } as WorkspaceTables["groups"][number]);
    await importWorkspace(new Uint8Array(await archive.arrayBuffer()), new IndexedDBStorageService());
    expect(values.has("unsaved-annotations")).toBe(false);
    expect(await db.groups.count()).toBe(0);
  });

  test("clearAll removes the groups table", async () => {
    await db.groups.put({ id: "old", name: "Old" } as WorkspaceTables["groups"][number]);
    await new IndexedDBStorageService().clearAll();
    expect(await db.groups.count()).toBe(0);
  });

  test("workspace round-trips processing preferences, enabled languages and installed bytes", async () => {
    const pack = LANGUAGE_PACKS[0]!;
    const packBytes = new Uint8Array(pack.bytes);
    packBytes[0] = 77;
    await new Promise<void>((resolve, reject) => {
      const req = indexedDB.open("language-packs", 1);
      req.onupgradeneeded = () => req.result.createObjectStore("packs");
      req.onsuccess = () => {
        const tx = req.result.transaction("packs", "readwrite");
        tx.objectStore("packs").put(packBytes.buffer, pack.code);
        tx.oncomplete = () => { req.result.close(); resolve(); };
        tx.onerror = () => reject(tx.error ?? new Error("pack fixture write failed"));
      };
    });
    await setPackEnabled(pack.code, true);
    useSettingsStore.getState().set("apportionMaxMinutes", 9);
    const archive = await exportWorkspace();
    const decoded = await decodeWorkspaceArchive(new Uint8Array(await archive.arrayBuffer()));
    expect(decoded).toHaveProperty("preferences");
    useSettingsStore.getState().set("apportionMaxMinutes", 1);
    values.delete("ocr.languagePacks.enabled");
    await importWorkspace(new Uint8Array(await archive.arrayBuffer()), new IndexedDBStorageService());
    expect(useSettingsStore.getState().apportionMaxMinutes).toBe(9);
    expect(JSON.parse(values.get("ocr.languagePacks.enabled") ?? "[]")).toContain(pack.code);
    expect((await readLanguagePack(pack.code))?.[0]).toBe(77);
    await removeLanguagePack(pack.code);
  });

  test("bounds full-table materialization by the workspace table budget", async () => {
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        hardwareConcurrency: 8,
      },
    });

    const tables = [
      db.screenshots,
      db.annotations,
      db.groups,
      db.settings,
      db.processingQueue,
      db.syncRecords,
    ] as const;
    const originals = tables.map((table) => table.toArray.bind(table));

    let activeReads = 0;
    let peakReads = 0;

    tables.forEach((table, index) => {
      (table as unknown as { toArray: typeof table.toArray }).toArray = (async () => {
        activeReads += 1;
        peakReads = Math.max(peakReads, activeReads);
        try {
          await Dexie.waitFor(new Promise<void>((resolve) => { setTimeout(resolve, 0); }));
          return await originals[index]!();
        } finally {
          activeReads -= 1;
        }
      }) as typeof table.toArray;
    });

    try {
      await exportWorkspace();
      expect(peakReads).toBe(2);
    } finally {
      tables.forEach((table, index) => {
        table.toArray = originals[index]!;
      });
    }
  });
});
