/**
 * "Needs attention" (totals_mismatch) predicate — the offline port of the
 * server's `needs_attention_conditions()` (screenshot_repository.py). This
 * locks the WASM ↔ server parity for the "Needs attention" annotation queue:
 * a COMPLETED screenshot needs attention when it has no exportable hourly bars,
 * its bar total disagrees with the OCR total by >= 1 minute (seconds-only totals
 * excluded), OR its app title was never extracted. Drift here silently
 * mis-populates the queue.
 */
import { describe, it, expect } from "bun:test";
import type { Screenshot } from "@/types";
import { needsAttention } from "../IndexedDBStorageService";

/** Minimal Screenshot carrying only the fields the predicate reads. */
function make(overrides: Partial<Screenshot>): Screenshot {
  return {
    processing_status: "completed",
    extracted_hourly_data: { 0: 30, 1: 30 }, // sums to 60
    extracted_title: "Instagram",
    extracted_total: "1h",
    ...overrides,
  } as Screenshot;
}

describe("needsAttention", () => {
  it("returns false when not completed (even with a mismatch)", () => {
    expect(needsAttention(make({ processing_status: "pending", extracted_total: "5h" }))).toBe(false);
    expect(needsAttention(make({ processing_status: "failed", extracted_total: "5h" }))).toBe(false);
  });

  it("flags completed rows without exportable hourly data", () => {
    expect(needsAttention(make({ extracted_hourly_data: null }))).toBe(true);
    expect(needsAttention(make({ extracted_hourly_data: {} }))).toBe(true);
    expect(needsAttention(make({ extracted_hourly_data: { total: 60 } as unknown as Record<number, number> }))).toBe(true);
  });

  it("flags a missing or empty title (with hourly data, completed)", () => {
    expect(needsAttention(make({ extracted_title: null }))).toBe(true);
    expect(needsAttention(make({ extracted_title: "" }))).toBe(true);
  });

  it("does not flag a matching bar/OCR total", () => {
    // bar sum 60 == OCR "1h" (60)
    expect(needsAttention(make({ extracted_total: "1h" }))).toBe(false);
    // within < 1 minute is not a mismatch
    expect(needsAttention(make({ extracted_hourly_data: { 0: 30, 1: 30, 2: 0 }, extracted_total: "1h" }))).toBe(false);
  });

  it("flags a bar/OCR total mismatch of >= 1 minute", () => {
    // bar sum 60 vs OCR "2h" (120) -> diff 60
    expect(needsAttention(make({ extracted_total: "2h" }))).toBe(true);
    // bar sum 60 vs OCR "59m" -> diff 1
    expect(needsAttention(make({ extracted_total: "59m" }))).toBe(true);
    // h+m combined: "1h 1m" = 61 vs 60 -> diff 1
    expect(needsAttention(make({ extracted_total: "1h 1m" }))).toBe(true);
  });

  it("ignores seconds-only and unparseable totals (no h/m component)", () => {
    // "9s" -> parseOcrTotalMinutes returns null -> not evaluable -> false
    expect(needsAttention(make({ extracted_total: "9s" }))).toBe(false);
    expect(needsAttention(make({ extracted_total: null }))).toBe(false);
    expect(needsAttention(make({ extracted_total: "" }))).toBe(false);
  });

  it("flags invalid stored entries instead of silently ignoring them", () => {
    const s = make({
      extracted_hourly_data: { 0: 30.4, 1: 29.4, total: 999 } as unknown as Record<number, number>,
      extracted_total: "1h", // 60; bar = 59.8 -> diff 0.2 < 1 -> no mismatch
    });
    expect(needsAttention(s)).toBe(true);
    expect(needsAttention(make({ extracted_hourly_data: { 0: 60, "+0": 20 } as unknown as Record<number, number> }))).toBe(true);
    expect(needsAttention(make({ extracted_hourly_data: { 0: 60, 1: true } as unknown as Record<number, number> }))).toBe(true);
    expect(needsAttention(make({ extracted_hourly_data: { 0: 60, 1: 1441 } }))).toBe(true);
  });
});
