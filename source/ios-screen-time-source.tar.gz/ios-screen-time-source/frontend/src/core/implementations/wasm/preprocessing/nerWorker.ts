/**
 * Web Worker for running BERT NER model via Transformers.js.
 * Runs off the main thread to avoid UI blocking.
 *
 * Usage: Post { text, id } messages, receive { id, entities } responses.
 * First message triggers model download (~111MB, cached after first use).
 */

import { pipeline, env, type TokenClassificationOutput } from "@huggingface/transformers";
import type {
  NerEntity,
  NerRequest,
  NerResponse,
} from "./nerWorkerProtocol";

/** Typed `postMessage` so every reply is checked against the protocol. */
function reply(message: NerResponse): void {
  self.postMessage(message);
}

// Model source. By default the ~111 MB NER model is fetched from the
// HuggingFace CDN — a cross-origin request that a strict CSP (`connect-src
// 'self'`) blocks, silently degrading PHI detection to regex-only.
//
// Set VITE_NER_MODEL_PATH at build time to a same-origin path (e.g. "/models/")
// where a copy of `bert-base-NER` is hosted. When set, Transformers.js loads
// the model from that origin and no cross-origin request is made.
// (Accessed via an index read — VITE_* keys are not declared on ImportMetaEnv.)
const NER_MODEL_PATH: string | undefined = (
  import.meta.env as unknown as Record<string, string | undefined>
)["VITE_NER_MODEL_PATH"];
const NER_MODEL_ID = NER_MODEL_PATH ? "bert-base-NER" : "Xenova/bert-base-NER";

if (NER_MODEL_PATH) {
  env.allowLocalModels = true;
  env.localModelPath = NER_MODEL_PATH;
  // Don't also hit the remote CDN when a local copy is configured.
  env.allowRemoteModels = false;
} else {
  env.allowLocalModels = false;
}

// Minimal callable structural type for the token-classification pipeline. The
// full Awaited<ReturnType<typeof pipeline<...>>> union is too complex for TS
// (TS2590); we only need the call signature anyway.
type NerPipeline = (
  text: string,
  options?: { aggregation_strategy?: string },
) => Promise<unknown>;
let nerPipeline: NerPipeline | null = null;
let initPromise: Promise<void> | null = null;

async function initPipeline() {
  if (nerPipeline) return;
  if (initPromise) {
    await initPromise;
    return;
  }

  initPromise = (async () => {
    try {
      // Prefer WebGPU for sub-30ms inference, fall back to WASM (~2-5s)
      const device = typeof navigator !== "undefined" && "gpu" in navigator ? "webgpu" : "wasm";

      nerPipeline = await pipeline("token-classification", NER_MODEL_ID, {
        device: device,
        dtype: "q8",
      }) as unknown as NerPipeline;

      reply({ type: "ready" });
    } catch (err) {
      // A failed model load (CDN blocked by CSP, offline, missing local copy)
      // must be VISIBLE — the caller surfaces this as "PHI detection degraded
      // to regex-only" rather than silently dropping NER coverage.
      const detail = NER_MODEL_PATH
        ? `local model load from "${NER_MODEL_PATH}" failed`
        : `remote model load failed (HuggingFace CDN may be blocked by CSP connect-src)`;
      console.error(`[nerWorker] Failed to initialize NER pipeline — ${detail}:`, err);
      reply({ type: "error", error: `${detail}: ${String(err)}` });
      // Reset so the next request retries initialization
      initPromise = null;
    }
  })();

  await initPromise;
}

self.onmessage = async (e: MessageEvent<NerRequest>) => {
  const request = e.data;

  if (request.type === "init") {
    await initPipeline();
    return;
  }
  const { text, id } = request;

  try {
    await initPipeline();
    if (!nerPipeline) {
      reply({ id, entities: [], error: "Pipeline not initialized" });
      return;
    }

    const result = await nerPipeline(text, {
      aggregation_strategy: "simple",
    }) as TokenClassificationOutput;

    // Filter to relevant entity types (PERSON, ORG, LOC, MISC)
    // With aggregation_strategy: "simple", results include entity_group (not in base type)
    // `aggregation_strategy: "simple"` adds `entity_group` and the character
    // offsets, but the offsets are optional in the upstream type and absent for
    // some spans. Such a span cannot be mapped to an image region, so drop it
    // here instead of handing the main thread an unusable entity.
    const aggregated = result as unknown as Array<Partial<NerEntity>>;
    const entities: NerEntity[] = [];
    let withoutOffsets = 0;
    for (const e of aggregated) {
      if ((e.score ?? 0) < 0.85) continue;
      if (typeof e.start !== "number" || typeof e.end !== "number") {
        withoutOffsets++;
        continue;
      }
      entities.push({
        entity_group: e.entity_group ?? "",
        word: e.word ?? "",
        start: e.start,
        end: e.end,
        score: e.score ?? 0,
      });
    }
    if (withoutOffsets > 0) {
      console.warn(
        `[nerWorker] dropped ${withoutOffsets} NER entit${withoutOffsets === 1 ? "y" : "ies"} with no character offsets`,
      );
    }

    reply({ id, entities });
  } catch (err) {
    console.error("[nerWorker] NER inference error:", err);
    reply({ id, entities: [], error: String(err) });
  }
};
