import Dexie, { type Table } from "dexie";
import type { Screenshot, Annotation, Group } from "@/types";

export interface ImageBlob {
  screenshotId: number;
  /** Blob in legacy/compatible browsers; ArrayBuffer avoids WebKit's IndexedDB
   * "Error preparing Blob/File data" failure when OPFS is unavailable. */
  blob: Blob | ArrayBuffer;
  mimeType?: string;
  revision?: string;
  uploadedAt: Date | string;
}

export interface Settings {
  id?: number;
  key: string;
  value: string | number | boolean | object | null;
  updatedAt: string;
}

export interface QueueItem {
  id?: number;
  screenshotId: number;
  priority: number;
  status: "pending" | "processing" | "completed" | "failed";
  createdAt: string;
  processedAt?: string;
}

export type SyncStatus = "local" | "synced" | "remote" | "conflict";

export interface SyncRecord {
  id?: number;
  entity_type: "screenshot" | "annotation";
  localId: number;
  serverId?: number;
  content_hash?: string;
  sync_status: SyncStatus;
  syncedAt?: string;
}

export class ScreenshotDB extends Dexie {
  screenshots!: Table<Screenshot, number>;
  annotations!: Table<Annotation, number>;
  imageBlobs!: Table<ImageBlob, number>;
  settings!: Table<Settings, number>;
  processingQueue!: Table<QueueItem, number>;
  groups!: Table<Group, string>;
  syncRecords!: Table<SyncRecord, number>;

  constructor() {
    super("ScreenshotProcessorDB");

    this.version(1).stores({
      screenshots:
        "++id, status, image_type, uploaded_at, processing_status, has_blocking_issues",
      annotations: "++id, screenshot_id, created_at, status",
      imageBlobs: "screenshotId, uploadedAt",
      settings: "++id, &key",
      processingQueue: "++id, screenshotId, priority, status, createdAt",
    });

    this.version(2).stores({
      screenshots:
        "++id, status, image_type, uploaded_at, processing_status, has_blocking_issues, [status+processing_status]",
      annotations:
        "++id, screenshot_id, annotator_id, created_at, status, [screenshot_id+status]",
    });

    // Add group_id, participant_id indexes and groups table
    this.version(3).stores({
      screenshots:
        "++id, status, image_type, uploaded_at, processing_status, has_blocking_issues, [status+processing_status], group_id, participant_id, [group_id+status]",
      annotations:
        "++id, screenshot_id, annotator_id, created_at, status, [screenshot_id+status]",
      groups: "&id, name, created_at",
    });

    // Version 4: Add compound indexes for efficient pagination and filtering
    this.version(4).stores({
      screenshots:
        "++id, status, image_type, uploaded_at, processing_status, has_blocking_issues, " +
        "[status+processing_status], group_id, participant_id, [group_id+status], " +
        // New indexes for pagination efficiency
        "[group_id+processing_status], " + // Filter by group and processing status
        "[processing_status+id], " + // Sorted pagination by processing status
        "[group_id+id]", // Sorted pagination by group
      annotations:
        "++id, screenshot_id, annotator_id, created_at, status, [screenshot_id+status]",
      groups: "&id, name, created_at",
    });

    // Version 5: Rename status to annotation_status for clarity
    this.version(5)
      .stores({
        screenshots:
          "++id, annotation_status, image_type, uploaded_at, processing_status, has_blocking_issues, " +
          "[annotation_status+processing_status], group_id, participant_id, [group_id+annotation_status], " +
          "[group_id+processing_status], " +
          "[processing_status+id], " +
          "[group_id+id]",
        annotations:
          "++id, screenshot_id, annotator_id, created_at, status, [screenshot_id+status]",
        groups: "&id, name, created_at",
      })
      .upgrade((tx) => {
        // Migrate existing data: rename status to annotation_status
        return tx
          .table("screenshots")
          .toCollection()
          .modify((screenshot: Screenshot & { status?: string }) => {
            if (screenshot.status && !screenshot.annotation_status) {
              // Map old status values to new annotation_status values
              const statusMap: Record<string, string> = {
                pending: "pending",
                completed: "annotated",
                skipped: "skipped",
                in_progress: "pending",
              };
              screenshot.annotation_status =
                (statusMap[
                  screenshot.status
                ] as Screenshot["annotation_status"]) || "pending";
              delete screenshot.status;
            }
          });
      });
    // Version 6: Add content_hash, sync_status indexes and syncRecords table
    this.version(6).stores({
      screenshots:
        "++id, annotation_status, image_type, uploaded_at, processing_status, has_blocking_issues, " +
        "[annotation_status+processing_status], group_id, participant_id, [group_id+annotation_status], " +
        "[group_id+processing_status], " +
        "[processing_status+id], " +
        "[group_id+id], " +
        "content_hash, sync_status",
      annotations:
        "++id, screenshot_id, annotator_id, created_at, status, [screenshot_id+status], sync_status",
      groups: "&id, name, created_at",
      syncRecords: "++id, &[entity_type+localId], serverId, content_hash, sync_status",
    });

    // Clean v6 duplicates before IndexedDB builds the v7 unique index.
    this.version(6.5).stores({})
      .upgrade(async (tx) => {
        // De-duplicate existing screenshots by content_hash before the unique
        // index is built. Keep the newest row (highest id) per hash, drop the
        // rest — consistent with cross-tab "second insert wins".
        const seen = new Map<string, number>();
        const idsToDelete: number[] = [];
        await tx
          .table("screenshots")
          .toCollection()
          .each((row: { id?: number; content_hash?: string | null }) => {
            const hash = row.content_hash;
            const id = row.id;
            if (!hash || id === undefined) return;
            const prev = seen.get(hash);
            if (prev === undefined) {
              seen.set(hash, id);
            } else if (id >= prev) {
              idsToDelete.push(prev);
              seen.set(hash, id);
            } else {
              idsToDelete.push(id);
            }
          });
        if (idsToDelete.length > 0) {
          await tx.table("screenshots").bulkDelete(idsToDelete);
          console.warn(
            `[Migration v7] Removed ${idsToDelete.length} duplicate screenshot(s) ` +
              `before applying the unique content_hash index.`,
          );
        }
      });

    // Version 7 retains its unique content_hash schema for existing users.
    this.version(7)
      .stores({
        screenshots:
          "++id, annotation_status, image_type, uploaded_at, processing_status, has_blocking_issues, " +
          "[annotation_status+processing_status], group_id, participant_id, [group_id+annotation_status], " +
          "[group_id+processing_status], " +
          "[processing_status+id], " +
          "[group_id+id], " +
          "&content_hash, sync_status",
        annotations:
          "++id, screenshot_id, annotator_id, created_at, status, [screenshot_id+status], sync_status",
        groups: "&id, name, created_at",
        syncRecords: "++id, &[entity_type+localId], serverId, content_hash, sync_status",
      });

    // Cross-tab schema-change handler. When another tab opens the DB at a
    // newer schema version, IndexedDB blocks the upgrade until every other
    // connection closes. Close this connection and reload so the tab picks
    // up the new schema instead of silently operating on a blocked DB.
    this.on("versionchange", () => {
      this.close();
      if (typeof window !== "undefined") {
        window.location.reload();
      }
    });
  }
}

export const db = new ScreenshotDB();
