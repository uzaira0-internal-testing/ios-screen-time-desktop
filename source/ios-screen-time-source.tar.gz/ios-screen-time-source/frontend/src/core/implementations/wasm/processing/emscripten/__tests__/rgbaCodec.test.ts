import { describe, expect, it } from "bun:test";

import { ImageTooLargeError } from "@/core/implementations/wasm/utils/imageLimits";
import { decodeToRgba, pngFromRust } from "../rgbaCodec";

function fakeModule(result: "success" | "tooLarge" | "undecodable") {
  const heap = new Uint8Array(128);
  const allocations: Array<{ ptr: number; len: number }> = [];
  const frees: Array<{ ptr: number; len: number }> = [];
  let nextPtr = 8;
  const alloc = (len: number) => {
    const ptr = nextPtr;
    nextPtr += Math.max(len, 1) + 8;
    allocations.push({ ptr, len });
    return ptr;
  };
  return {
    allocations,
    frees,
    heap,
    mod: {
      HEAPU8: heap,
      _pipeline_alloc: alloc,
      _pipeline_free: (ptr: number, len: number) => frees.push({ ptr, len }),
      _pipeline_decode: (bytesPtr: number, bytesLen: number, dimsPtr: number) => {
        expect([...heap.subarray(bytesPtr, bytesPtr + bytesLen)]).toEqual([1, 2]);
        const dims = new DataView(heap.buffer);
        if (result === "tooLarge") {
          dims.setUint32(dimsPtr, 10_000, true);
          dims.setUint32(dimsPtr + 4, 10_000, true);
          return 0;
        }
        if (result === "undecodable") {
          dims.setUint32(dimsPtr, 0, true);
          dims.setUint32(dimsPtr + 4, 0, true);
          return 0;
        }
        dims.setUint32(dimsPtr, 1, true);
        dims.setUint32(dimsPtr + 4, 1, true);
        const rgbaPtr = alloc(4);
        heap.set([10, 20, 30, 255], rgbaPtr);
        return rgbaPtr;
      },
    },
  };
}

describe("decodeToRgba", () => {
  it("copies RGBA out of the heap and frees every allocation once", () => {
    const fake = fakeModule("success");
    const decoded = decodeToRgba(fake.mod, Uint8Array.of(1, 2));

    expect(decoded.width).toBe(1);
    expect(decoded.height).toBe(1);
    expect([...decoded.data]).toEqual([10, 20, 30, 255]);
    expect(fake.frees).toHaveLength(3);
    expect(fake.frees).toEqual([...fake.allocations].reverse());
    fake.heap.fill(0);
    expect([...decoded.data]).toEqual([10, 20, 30, 255]);
  });

  it("reports too-large dimensions and releases input allocations", () => {
    const fake = fakeModule("tooLarge");
    expect(() => decodeToRgba(fake.mod, Uint8Array.of(1, 2))).toThrow(ImageTooLargeError);
    expect(fake.frees).toHaveLength(2);
    expect(fake.frees).toEqual([...fake.allocations].reverse());
  });

  it("reports undecodable input and releases input allocations", () => {
    const fake = fakeModule("undecodable");
    expect(() => decodeToRgba(fake.mod, Uint8Array.of(1, 2))).toThrow("Unable to decode image");
    expect(fake.frees).toHaveLength(2);
    expect(fake.frees).toEqual([...fake.allocations].reverse());
  });
});

describe("pngFromRust", () => {
  it("copies the PNG out of the heap and frees every allocation once", () => {
    const fake = fakeModule("success");
    const png = pngFromRust(fake.mod, Uint8Array.of(1, 2), (bytesPtr, bytesLen, outLenPtr) => {
      expect([...fake.heap.subarray(bytesPtr, bytesPtr + bytesLen)]).toEqual([1, 2]);
      const out = fake.mod._pipeline_alloc(3);
      fake.heap.set([7, 8, 9], out);
      new DataView(fake.heap.buffer).setUint32(outLenPtr, 3, true);
      return out;
    });

    expect([...png]).toEqual([7, 8, 9]);
    expect(fake.frees).toEqual([...fake.allocations].reverse());
  });

  it("reports a failed export and releases input allocations", () => {
    const fake = fakeModule("success");
    expect(() => pngFromRust(fake.mod, Uint8Array.of(1, 2), () => 0)).toThrow("Unable to process image");
    expect(fake.frees).toHaveLength(2);
    expect(fake.frees).toEqual([...fake.allocations].reverse());
  });
});
