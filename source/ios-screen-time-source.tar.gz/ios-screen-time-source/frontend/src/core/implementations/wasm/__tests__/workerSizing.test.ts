import { describe, expect, test } from "bun:test";

import { computeWasmWorkerPoolSize } from "../WASMProcessingService";
import {
  computeCropDecodeConcurrency,
  computeDeviceDetectionConcurrency,
  computeDeviceCropConcurrency,
  WASMPreprocessingService,
} from "../preprocessing/WASMPreprocessingService";

describe("WASM worker sizing", () => {
  test("OCR pool uses a conservative memory fallback when memory is not reported", () => {
    expect(computeWasmWorkerPoolSize(2)).toBe(1);
    expect(computeWasmWorkerPoolSize(8)).toBe(1);
    expect(computeWasmWorkerPoolSize(32)).toBe(1);
  });

  test("OCR pool scales down from the memory budget without a hard memory branch", () => {
    expect(computeWasmWorkerPoolSize(8, 1)).toBe(1);
    expect(computeWasmWorkerPoolSize(8, 2)).toBe(3);
    expect(computeWasmWorkerPoolSize(8, 4)).toBe(4);
    expect(computeWasmWorkerPoolSize(16, 8)).toBe(8);
  });

  test("OCR pool accepts measured worker cost as a conservative memory input", () => {
    expect(computeWasmWorkerPoolSize(16, 4, 768)).toBe(3);
    expect(computeWasmWorkerPoolSize(16, 4, 128)).toBe(6);
  });

  test("crop decode slots use a separate decode memory budget", () => {
    expect(computeCropDecodeConcurrency(8)).toBe(2);
    expect(computeCropDecodeConcurrency(8, 1)).toBe(2);
    expect(computeCropDecodeConcurrency(8, 2)).toBe(4);
    expect(computeCropDecodeConcurrency(16, 4)).toBe(6);
  });

  test("device detection uses a wider cheap-stage budget than crop decode", () => {
    expect(computeDeviceDetectionConcurrency(8)).toBe(6);
    expect(computeDeviceDetectionConcurrency(2, 1)).toBe(4);
    expect(computeDeviceDetectionConcurrency(4, 2)).toBe(8);
    expect(computeDeviceDetectionConcurrency(16, 8)).toBe(12);
  });

  test("crop item concurrency stays wider than OCR but still decode-aware", () => {
    expect(computeDeviceCropConcurrency(8)).toBe(2);
    expect(computeDeviceCropConcurrency(2, 1)).toBe(2);
    expect(computeDeviceCropConcurrency(4, 2)).toBe(5);
    expect(computeDeviceCropConcurrency(16, 8)).toBe(12);
  });

  test("preprocessing diagnostics use the conservative crop fallback when memory is not reported", () => {
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        hardwareConcurrency: 32,
      },
    });

    const service = new WASMPreprocessingService({} as never, {} as never, { enablePhi: false });
    const snapshot = service.getStageSchedulerSnapshot();

    expect(snapshot.cropWorkerPool?.maxWorkers).toBe(2);
    expect(snapshot.cropWorkerPool?.poolSize).toBe(0);
    expect(snapshot.cropWorkerPool?.queuedRequests).toBe(0);
    expect(snapshot.cropWorkerPool?.busyWorkers).toBe(0);
  });
});
