/**
 * Image Processor Worker — Emscripten Path B
 *
 * Uses the wasm32-unknown-emscripten build of the Rust pipeline which
 * includes native leptess OCR linked directly into the WASM module.
 *
 * PERF-2: the worker accepts a `Blob` and decodes it HERE through the Rust
 * pipeline. An already-decoded `ImageData` is still accepted unchanged
 * (transferred zero-copy).
 *
 * Pipeline: Blob → Rust RGBA decode → _pipeline_process
 */

import type {
  WorkerMessage,
  WorkerResponse,
  WorkerImageInput,
  ProcessImagePayload,
  ProcessImageResultPayload,
  TessdataPayload,
} from "./types";

import type { GridCoordinates, HourlyData, HourlyValues } from "@/types";
import {
  emPipelineProcess,
  emDetectGrid,
  emExtractOcr,
  emExtractBars,
  emColumnFills,
  decodeImage,
  setPreloadedTessdata,
  setPreloadedLanguages,
  setPreloadedWasmModule,
  warmOcrRuntime,
  wasmLinearMemoryBytes,
} from "../emscripten/pipelineLoader";
import {
  assertDecodedPixelBudget,
  readImageDimensions,
} from "../../utils/imageLimits";

let initialized = false;
let currentMessageId: string | undefined;
let messageQueue: Promise<void> = Promise.resolve();

function safeStringify(value: unknown): string | undefined {
  try {
    const json = JSON.stringify(value);
    return json && json !== "{}" ? json : undefined;
  } catch {
    return undefined;
  }
}

export function serializeUnknownError(error: unknown): Pick<
  Extract<WorkerResponse, { type: "ERROR" }>,
  "error" | "errorName" | "errorStack" | "errorDetails" | "abiMismatch"
> {
  if (error instanceof Error) {
    return {
      ...((error as Error & { abiMismatch?: boolean }).abiMismatch === true ? { abiMismatch: true } : {}),
      error: error.message || error.name || "Worker failed without an error message",
      ...(error.name ? { errorName: error.name } : {}),
      ...(error.stack ? { errorStack: error.stack } : {}),
    };
  }

  if (typeof error === "string" && error.trim()) {
    return { error };
  }

  const details = safeStringify(error);
  return {
    ...(typeof error === "object" && error !== null && "abiMismatch" in error && error.abiMismatch === true ? { abiMismatch: true } : {}),
    error: details ?? `Worker failed with a non-Error value: ${String(error)}`,
    ...(details ? { errorDetails: details } : {}),
  };
}

function postProgress(
  stage: "loading" | "preprocessing" | "ocr_title" | "ocr_total" | "ocr_hourly" | "complete",
  progress: number,
  message?: string,
): void {
  self.postMessage({ type: "PROGRESS", id: currentMessageId, payload: { stage, progress, message } });
}

/**
 * PERF-2: decode a Blob off the main thread. An ImageData is returned as-is.
 */
async function toImageData(input: WorkerImageInput): Promise<ImageData> {
  if (!(input instanceof Blob)) return input;
  const headerDims = await readImageDimensions(input);
  if (headerDims) {
    assertDecodedPixelBudget(headerDims.width, headerDims.height);
  }

  const { width, height, data } = await decodeImage(new Uint8Array(await input.arrayBuffer()));
  return {
    width,
    height,
    data: new Uint8ClampedArray(data.buffer as ArrayBuffer, data.byteOffset, data.byteLength),
    colorSpace: "srgb",
  };
}

function hourlyValuesToData(values: number[] | undefined): HourlyValues {
  const data: HourlyValues = {};
  const src = values ?? [];
  for (let i = 0; i < 24; i++) data[i] = src[i] ?? 0;
  return data;
}

/**
 * A pipeline result is only trustworthy if it returned a full 24-element
 * hourly vector. A missing or short vector means extraction did not actually
 * complete — it must NOT be zero-padded and reported as a successful result,
 * or a botched extraction becomes indistinguishable from a genuinely empty
 * screenshot and is never reprocessed.
 */
function hasValidHourlyVector(values: number[] | undefined): values is number[] {
  return Array.isArray(values) && values.length >= 24;
}

function gridBoundsToCoordinates(bounds: {
  upper_left_x: number;
  upper_left_y: number;
  lower_right_x: number;
  lower_right_y: number;
}): GridCoordinates {
  return {
    upper_left: { x: bounds.upper_left_x, y: bounds.upper_left_y },
    lower_right: { x: bounds.lower_right_x, y: bounds.lower_right_y },
  };
}

async function runPipeline(
  imageData: ImageData,
  payload: ProcessImagePayload,
): Promise<ProcessImageResultPayload> {
  if (payload.tessdata && !initialized) {
    setPreloadedTessdata(payload.tessdata);
  }
  if (payload.languages) setPreloadedLanguages(payload.languages);
  const result = await emPipelineProcess(imageData, payload.imageType ?? "screen_time", {
    ...(payload.maxShift !== undefined && { maxShift: payload.maxShift }),
    ...(payload.gridCoordinates !== undefined && {
      gridCoordinates: payload.gridCoordinates,
    }),
    ...(payload.apportionMaxMinutes !== undefined && {
      apportionMaxMinutes: payload.apportionMaxMinutes,
    }),
    ...(payload.apportionMaxPercent !== undefined && {
      apportionMaxPercent: payload.apportionMaxPercent,
    }),
    ...(payload.gridRegDeadband !== undefined && {
      gridRegDeadband: payload.gridRegDeadband,
    }),
    ...(payload.gridRegTol !== undefined && {
      gridRegTol: payload.gridRegTol,
    }),
  });
  // emPipelineProcess loads the module and mounts tessdata before it calls into
  // Rust. If cold line-based processing reaches this point, this worker now has
  // a reusable OCR runtime even though it never received INITIALIZE first.
  // eslint-disable-next-line require-atomic-updates -- worker messages are serialized by messageQueue; this flag records the completed warmup.
  initialized = true;

  const hourlyValid = hasValidHourlyVector(result.hourly_values);
  const gridCoords: GridCoordinates | undefined = result.grid_bounds
    ? gridBoundsToCoordinates(result.grid_bounds)
    : undefined;

  // Surface ocr_error to the main thread (and console) so a silent Tesseract
  // failure doesn't just look like 'OCR found no title'.
  if (result.ocr_error) {
    console.warn("[imageProcessor.worker] OCR error from pipeline_em:", result.ocr_error);
  }

  if (!result.success || !hourlyValid) {
    return {
      ok: false,
      error:
        result.error ??
        result.ocr_error ??
        (!hourlyValid
          ? "Pipeline returned no complete 24-hour usage vector"
          : "Pipeline reported failure"),
      ...(result.abiMismatch && { abiMismatch: true }),
      title: result.title ?? null,
      total: result.total_text ?? null,
      ...(gridCoords !== undefined && { gridCoordinates: gridCoords }),
      suspectedAllDevices: result.suspected_all_devices ?? false,
      axisMaxMinutes: result.axis_max_minutes ?? null,
      allDevicesReasons: result.all_devices_reasons ?? [],
      ocrFailed: Boolean(result.ocr_error),
      ocrError: result.ocr_error ?? null,
    };
  }

  return {
    ok: true,
    hourlyData: hourlyValuesToData(result.hourly_values),
    title: result.title ?? null,
    total: result.total_text ?? null,
    ...(gridCoords !== undefined && { gridCoordinates: gridCoords }),
    alignmentScore: result.alignment_score ?? null,
    gridRegistrationScore: result.grid_registration_score ?? null,
    axisDirection: result.axis_direction ?? "ltr",
    suspectedAllDevices: result.suspected_all_devices ?? false,
    axisMaxMinutes: result.axis_max_minutes ?? null,
    allDevicesReasons: result.all_devices_reasons ?? [],
    // OCR failure is independent of grid/bar extraction. Keep the partial bars
    // so reviewers can annotate them, but let the caller persist a failed audit state.
    ocrFailed: Boolean(result.ocr_error),
    ocrError: result.ocr_error ?? null,
  };
}

async function detectGridForPipeline(
  imageData: ImageData,
  payload: ProcessImagePayload,
): Promise<{
  gridCoordinates: GridCoordinates | null;
  error?: string;
  isWeekly?: boolean;
  ocrError?: string;
}> {
  const method = payload.gridDetectionMethod === "line_based" ? 1 : 0;
  if (method === 0) {
    await initialize();
  }

  const primary = await emDetectGrid(imageData, { method });
  if (primary.success && primary.bounds) {
    return {
      gridCoordinates: gridBoundsToCoordinates(primary.bounds),
      ...(primary.ocr_error ? { ocrError: primary.ocr_error } : {}),
    };
  }
  if (primary.is_weekly) {
    return {
      gridCoordinates: null,
      ...(primary.error ? { error: primary.error } : {}),
      ...(primary.ocr_error ? { ocrError: primary.ocr_error } : {}),
      isWeekly: true,
    };
  }

  // If the requested detector misses, try the other detector in the SAME worker
  // against the SAME decoded ImageData. This preserves the old service fallback
  // behavior without a second Blob decode or a second queued worker job.
  const fallbackMethod = method === 1 ? 0 : 1;
  if (fallbackMethod === 0) {
    await initialize();
  }
  const fallback = await emDetectGrid(imageData, { method: fallbackMethod });
  return {
    gridCoordinates: fallback.success && fallback.bounds
      ? gridBoundsToCoordinates(fallback.bounds)
      : null,
    ...(fallback.error ? { error: fallback.error } : {}),
    ...(fallback.is_weekly ? { isWeekly: true } : {}),
    ...((fallback.ocr_error ?? primary.ocr_error)
      ? { ocrError: (fallback.ocr_error ?? primary.ocr_error) as string }
      : {}),
  };
}

async function initialize(
  tessdata?: TessdataPayload,
  wasmModule?: WebAssembly.Module,
  languages?: string,
): Promise<number | undefined> {
  if (initialized) return wasmLinearMemoryBytes();
  // PERF-1/PERF-11: if the main thread supplied a shared eng.traineddata
  // buffer, hand it to the loader before the module load so the worker does
  // not issue its own 4 MB fetch.
  if (tessdata) setPreloadedTessdata(tessdata);
  if (languages) setPreloadedLanguages(languages);
  // PERF-1: if the main thread compiled IosScreenTimePipeline.wasm once and
  // shared the WebAssembly.Module, hand it to the loader so Emscripten reuses
  // the compiled code via its `instantiateWasm` hook instead of fetching +
  // compiling its own ~5.9 MB copy.
  if (wasmModule) setPreloadedWasmModule(wasmModule);
  postProgress("loading", 10, "Loading Emscripten pipeline...");
  // Warm up the module load + tessdata mount (singleton, cached after first call).
  await warmOcrRuntime();
  // eslint-disable-next-line require-atomic-updates -- module-load is an idempotent cached singleton; concurrent INITIALIZE calls are benign
  initialized = true;
  postProgress("complete", 100, "Emscripten pipeline ready");
  return wasmLinearMemoryBytes();
}

self.onmessage = (e: MessageEvent<WorkerMessage>) => {
  const msg = e.data;
  messageQueue = messageQueue.then(
    () => handleMessage(msg),
    () => handleMessage(msg),
  );
};

async function handleMessage(msg: WorkerMessage): Promise<void> {
  const { id } = msg;
  currentMessageId = id;

  try {
    switch (msg.type) {
      case "INITIALIZE": {
        const wasmHeapBytes = await initialize(
          msg.payload.tessdata,
          msg.payload.wasmModule,
          msg.payload.languages,
        );
        const response: WorkerResponse = {
          type: "INITIALIZE_COMPLETE",
          id,
          payload: {
            initialized: true,
            ...(wasmHeapBytes !== undefined && { wasmHeapBytes }),
          },
        };
        self.postMessage(response);
        break;
      }

      case "PROCESS_IMAGE": {
        if (msg.payload.wasmModule && !initialized) {
          setPreloadedWasmModule(msg.payload.wasmModule);
        }
        if (msg.payload.tessdata && !initialized) {
          setPreloadedTessdata(msg.payload.tessdata);
        }
        if (msg.payload.languages) setPreloadedLanguages(msg.payload.languages);
        const imageData = await toImageData(msg.payload.imageData);
        let pipelinePayload = msg.payload;
        let gridDetectionOcrError: string | undefined;

        if (msg.payload.gridDetectionMethod) {
          postProgress("preprocessing", 15, "Detecting grid...");
          const grid = await detectGridForPipeline(imageData, msg.payload);
          gridDetectionOcrError = grid.ocrError;
          if (!grid.gridCoordinates) {
            const issue = grid.isWeekly
              ? "Weekly view detected — capture the daily (24-hour) Screen Time chart (Day view, not Week)"
              : grid.error ?? "Could not detect a daily Screen Time chart";
            const wasmHeapBytes = initialized ? await wasmLinearMemoryBytes() : undefined;
            const response: WorkerResponse = {
              type: "PROCESS_IMAGE_COMPLETE",
              id,
              payload: {
                ok: false,
                error: issue,
                title: null,
                total: null,
                ...(gridDetectionOcrError && {
                  ocrFailed: true,
                  ocrError: gridDetectionOcrError,
                }),
                ocrInitialized: initialized,
                ...(wasmHeapBytes !== undefined && { wasmHeapBytes }),
              },
            };
            self.postMessage(response);
            break;
          }
          pipelinePayload = {
            ...msg.payload,
            gridCoordinates: grid.gridCoordinates,
          };
        } else if (!initialized) {
          await initialize();
        }

        postProgress("preprocessing", 20, "Running pipeline...");
        const pipelineResult = await runPipeline(imageData, pipelinePayload);
        const payload = gridDetectionOcrError
          ? {
              ...pipelineResult,
              ocrFailed: true,
              ocrError: pipelineResult.ocrError ?? gridDetectionOcrError,
            }
          : pipelineResult;
        postProgress("complete", 100, "Done");
        const wasmHeapBytes = initialized ? await wasmLinearMemoryBytes() : undefined;

        const response: WorkerResponse = {
          type: "PROCESS_IMAGE_COMPLETE",
          id,
          payload: {
            ...payload,
            ocrInitialized: initialized,
            ...(wasmHeapBytes !== undefined && { wasmHeapBytes }),
          },
        };
        self.postMessage(response);
        break;
      }

      case "EXTRACT_TITLE": {
        const imageData = await toImageData(msg.payload.imageData);
        const result = await emExtractOcr(imageData);
        if (result.ocr_error) {
          throw new Error(`OCR processing failed: ${result.ocr_error}`);
        }
        const response: WorkerResponse = {
          type: "EXTRACT_TITLE_COMPLETE",
          id,
          payload: { title: result.title ?? null },
        };
        self.postMessage(response);
        break;
      }

      case "EXTRACT_TOTAL": {
        const imageData = await toImageData(msg.payload.imageData);
        const result = await emExtractOcr(imageData);
        if (result.ocr_error) {
          throw new Error(`OCR processing failed: ${result.ocr_error}`);
        }
        const response: WorkerResponse = {
          type: "EXTRACT_TOTAL_COMPLETE",
          id,
          payload: { total: result.total_text ?? null },
        };
        self.postMessage(response);
        break;
      }

      case "EXTRACT_HOURLY_DATA": {
        const imageData = await toImageData(msg.payload.imageData);
        const result = await emPipelineProcess(imageData, msg.payload.imageType ?? "screen_time", {
          gridCoordinates: msg.payload.gridCoordinates,
        });
        if (result.ocr_error) {
          console.warn("[imageProcessor.worker] OCR error from pipeline (hourly):", result.ocr_error);
        }
        if (!hasValidHourlyVector(result.hourly_values)) {
          // No complete vector — fail loudly rather than returning zeros the
          // caller would treat as a valid extraction.
          throw new Error(
            result.error ?? "Pipeline returned no complete 24-hour usage vector",
          );
        }
        const hourlyData: HourlyData = hourlyValuesToData(result.hourly_values);
        const response: WorkerResponse = {
          type: "EXTRACT_HOURLY_DATA_COMPLETE",
          id,
          payload: { hourlyData },
        };
        self.postMessage(response);
        break;
      }

      case "EXTRACT_BARS": {
        const imageData = await toImageData(msg.payload.imageData);
        const result = await emExtractBars(imageData, msg.payload.imageType ?? "screen_time", {
          gridCoordinates: msg.payload.gridCoordinates,
          ...(msg.payload.totalText !== undefined && { totalText: msg.payload.totalText }),
          ...(msg.payload.apportionMaxMinutes !== undefined && {
            apportionMaxMinutes: msg.payload.apportionMaxMinutes,
          }),
          ...(msg.payload.apportionMaxPercent !== undefined && {
            apportionMaxPercent: msg.payload.apportionMaxPercent,
          }),
          ...(msg.payload.gridRegDeadband !== undefined && {
            gridRegDeadband: msg.payload.gridRegDeadband,
          }),
          ...(msg.payload.gridRegTol !== undefined && { gridRegTol: msg.payload.gridRegTol }),
          ...(msg.payload.axisDirection !== undefined && {
            axisDirection: msg.payload.axisDirection,
          }),
          ...(msg.payload.axisMaxMinutes !== undefined && {
            axisMaxMinutes: msg.payload.axisMaxMinutes,
          }),
        });
        if (!result.success || !hasValidHourlyVector(result.hourly_values)) {
          // Preserve the ABI-skew signal the way PROCESS_IMAGE does. This entry
          // point only became skewable when `pipeline_extract_bars` gained the
          // `axis_max_minutes` parameter; discarding the flag turns a recoverable
          // stale-wasm mismatch into a permanent "no hourly bar data" toast, and
          // the service-worker self-heal never runs.
          const err = new Error(
            result.error ?? "Bars-only extraction returned no complete 24-hour usage vector",
          ) as Error & { abiMismatch?: boolean };
          if (result.abiMismatch) err.abiMismatch = true;
          throw err;
        }
        const response: WorkerResponse = {
          type: "EXTRACT_BARS_COMPLETE",
          id,
          payload: {
            hourlyData: hourlyValuesToData(result.hourly_values),
            ...(result.grid_bounds !== undefined && {
              gridCoordinates: gridBoundsToCoordinates(result.grid_bounds),
            }),
            alignmentScore: result.alignment_score ?? null,
            gridRegistrationScore: result.grid_registration_score ?? null,
          },
        };
        self.postMessage(response);
        break;
      }

      case "DETECT_GRID": {
        if (msg.payload.wasmModule && !initialized) {
          setPreloadedWasmModule(msg.payload.wasmModule);
        }
        const imageData = await toImageData(msg.payload.imageData);
        const method = msg.payload.method === "line_based" ? 1 : 0;
        const result = await emDetectGrid(imageData, { method });
        const gridCoords: GridCoordinates | null = result.success && result.bounds
          ? gridBoundsToCoordinates(result.bounds)
          : null;
        const response: WorkerResponse = {
          type: "DETECT_GRID_COMPLETE",
          id,
          payload: {
            gridCoordinates: gridCoords,
            ...(result.error ? { error: result.error } : {}),
            ...(result.is_weekly ? { isWeekly: true } : {}),
          },
        };
        self.postMessage(response);
        break;
      }

      case "MEASURE_COLUMN_FILLS": {
        if (msg.payload.wasmModule && !initialized) {
          setPreloadedWasmModule(msg.payload.wasmModule);
        }
        const imageData = await toImageData(msg.payload.imageData);
        const { upper_left, lower_right } = msg.payload.gridCoordinates;
        const fills = await emColumnFills(imageData, {
          x: upper_left.x,
          y: upper_left.y,
          w: lower_right.x - upper_left.x,
          h: lower_right.y - upper_left.y,
        });
        const response: WorkerResponse = {
          type: "MEASURE_COLUMN_FILLS_COMPLETE",
          id,
          payload: { fills },
        };
        self.postMessage(response);
        break;
      }

      default: {
        // ARC-13: exhaustiveness check — adding a new message type without a
        // case here is now a compile error.
        const _exhaustive: never = msg;
        throw new Error(`Unknown message type: ${(_exhaustive as { type: string }).type}`);
      }
    }
  } catch (error) {
    const serialized = serializeUnknownError(error);
    console.error("[imageProcessor.worker] Unhandled message failure:", serialized, error);
    const response: WorkerResponse = {
      type: "ERROR",
      id,
      ...serialized,
    };
    self.postMessage(response);
  } finally {
    currentMessageId = undefined;
  }
}

export {};
