import { afterEach, describe, expect, test } from "bun:test";
import { IndexedDBStorageService } from "../IndexedDBStorageService";
import { createPreMigrationBackup } from "../database/preMigrationBackup";

const TABLES = [
  "screenshots",
  "annotations",
  "groups",
  "settings",
  "processingQueue",
  "syncRecords",
] as const;

const originalIndexedDB = Object.getOwnPropertyDescriptor(globalThis, "indexedDB");
const originalNavigator = Object.getOwnPropertyDescriptor(globalThis, "navigator");

function restoreGlobal(name: "indexedDB" | "navigator", descriptor: PropertyDescriptor | undefined): void {
  if (descriptor) {
    Object.defineProperty(globalThis, name, descriptor);
  } else {
    Reflect.deleteProperty(globalThis, name);
  }
}

describe("createPreMigrationBackup", () => {
  afterEach(() => {
    restoreGlobal("indexedDB", originalIndexedDB);
    restoreGlobal("navigator", originalNavigator);
  });

  test("native IDB version 60 triggers a pre-migration backup for Dexie v7", async () => {
    let written = 0;
    const backupDir = {
      getFileHandle: async () => ({ createWritable: async () => ({
        write: async () => { written++; }, close: async () => {},
      }) }),
      async *[Symbol.asyncIterator]() {},
    };
    Object.defineProperty(globalThis, "navigator", { configurable: true, value: {
      storage: { getDirectory: async () => ({ getDirectoryHandle: async () => backupDir }) },
    } });
    const rawDb = { version: 60, objectStoreNames: ["screenshots"], close: () => {},
      transaction: () => ({ objectStore: () => ({ getAll: () => {
        const request = { result: [], onsuccess: null as (() => void) | null };
        queueMicrotask(() => request.onsuccess?.());
        return request;
      } }) }),
    };
    Object.defineProperty(globalThis, "indexedDB", { configurable: true, value: {
      open: () => {
        const request = { result: rawDb, onsuccess: null as (() => void) | null };
        queueMicrotask(() => request.onsuccess?.());
        return request;
      },
    } });
    const prototype = IndexedDBStorageService.prototype as unknown as { maybeBackupBeforeMigration(): Promise<void> };
    await prototype.maybeBackupBeforeMigration.call({});
    expect(written).toBe(1);
  });

  test("bounds metadata table reads by the resource budget", async () => {
    let activeReads = 0;
    let peakReads = 0;

    const stores = new Map<string, unknown[]>(
      TABLES.map((tableName) => [tableName, [{ id: tableName }]]),
    );

    const rawDb = {
      version: 7,
      objectStoreNames: TABLES,
      transaction: () => ({
        objectStore: (tableName: string) => ({
          getAll: () => {
            activeReads += 1;
            peakReads = Math.max(peakReads, activeReads);
            const req: {
              result: unknown[];
              error: Error | null;
              onsuccess: (() => void) | null;
              onerror: (() => void) | null;
            } = {
              result: stores.get(tableName) ?? [],
              error: null,
              onsuccess: null,
              onerror: null,
            };
            setTimeout(() => {
              activeReads -= 1;
              req.onsuccess?.();
            }, 0);
            return req;
          },
        }),
      }),
      close: () => {},
    };

    Object.defineProperty(globalThis, "indexedDB", {
      configurable: true,
      value: {
        open: () => {
          const req: {
            result: typeof rawDb;
            error: Error | null;
            onsuccess: (() => void) | null;
            onerror: (() => void) | null;
            onupgradeneeded: (() => void) | null;
            transaction: { abort: () => void } | null;
          } = {
            result: rawDb,
            error: null,
            onsuccess: null,
            onerror: null,
            onupgradeneeded: null,
            transaction: null,
          };
          setTimeout(() => req.onsuccess?.(), 0);
          return req;
        },
      },
    });

    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        hardwareConcurrency: 8,
        deviceMemory: 0.5,
      },
    });

    await createPreMigrationBackup("ScreenshotProcessorDB");

    expect(peakReads).toBe(2);
  });
});
