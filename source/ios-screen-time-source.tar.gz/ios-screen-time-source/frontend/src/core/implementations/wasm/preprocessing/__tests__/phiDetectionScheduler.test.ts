import { describe, expect, mock, test } from "bun:test";

type Release = () => void;

const ocrState = {
  active: 0,
  calls: 0,
  maxActive: 0,
  releases: [] as Release[],
};

void mock.module("@/core/implementations/wasm/processing/emscripten/pipelineLoader", () => ({
  decodeImage: async () => ({ width: 8, height: 8, data: new Uint8Array(8 * 8 * 4) }),
  emPhiWords: async () => {
    ocrState.calls++;
    ocrState.active++;
    ocrState.maxActive = Math.max(ocrState.maxActive, ocrState.active);
    await new Promise<void>((resolve) => {
      ocrState.releases.push(resolve);
    });
    ocrState.active--;
    return {
      success: true,
      words: [],
      full_text: "",
      avg_confidence: 0,
    };
  },
}));

async function waitFor(predicate: () => boolean, attempts = 20): Promise<void> {
  if (predicate()) return;
  if (attempts <= 0) {
    throw new Error("Timed out waiting for condition");
  }
  await Promise.resolve();
  return waitFor(predicate, attempts - 1);
}

describe("detectPHI scheduler", () => {
  test("serializes PHI OCR calls through the singleton runtime", async () => {
    ocrState.active = 0;
    ocrState.calls = 0;
    ocrState.maxActive = 0;
    ocrState.releases.length = 0;
    const { detectPHI } = await import("../phiDetection");

    const first = detectPHI(new Blob(["first"]));
    const second = detectPHI(new Blob(["second"]));

    await waitFor(() => ocrState.calls === 1);
    expect(ocrState.active).toBe(1);
    expect(ocrState.maxActive).toBe(1);
    expect(ocrState.releases).toHaveLength(1);

    ocrState.releases.shift()?.();
    await first;

    await waitFor(() => ocrState.calls === 2);
    expect(ocrState.active).toBe(1);
    expect(ocrState.maxActive).toBe(1);

    ocrState.releases.shift()?.();
    await second;

    expect(ocrState.calls).toBe(2);
    expect(ocrState.active).toBe(0);
    expect(ocrState.maxActive).toBe(1);
  });
});
