import type { PHIRegion } from "@/core/interfaces/IPreprocessingService";
import { redactPng } from "../processing/emscripten/pipelineLoader";
import { assertDecodedPixelBudget, readImageDimensions } from "../utils/imageLimits";
export type { PHIRegion };

export type RedactionMethod = "redbox" | "blackbox" | "pixelate";

function abortError(message = "PHI redaction aborted"): Error {
  try {
    return new DOMException(message, "AbortError");
  } catch {
    const error = new Error(message);
    error.name = "AbortError";
    return error;
  }
}

function throwIfAborted(signal?: AbortSignal): void {
  if (signal?.aborted) throw abortError();
}

/**
 * Redact PHI regions in an image using the specified method. The pixels are
 * decoded, redacted and re-encoded in the Rust pipeline, so every browser
 * engine produces the same output.
 *
 * @param imageBlob - Source image as Blob
 * @param regions - PHI regions to redact
 * @param method - Redaction method (redbox, blackbox, pixelate)
 * @param padding - Extra pixels around each region (default 2)
 * @returns New Blob with regions redacted
 */
export async function redactImage(
  imageBlob: Blob,
  regions: PHIRegion[],
  method: RedactionMethod = "redbox",
  padding: number = 2,
  abortSignal?: AbortSignal,
): Promise<Blob> {
  throwIfAborted(abortSignal);
  if (regions.length === 0) {
    return imageBlob;
  }

  const dims = await readImageDimensions(imageBlob);
  if (dims) assertDecodedPixelBudget(dims.width, dims.height);
  // Rust takes whole pixels: grow each region outward so a fractional edge is
  // still covered.
  const pixelRegions = regions.map((r) => {
    const x = Math.floor(r.x);
    const y = Math.floor(r.y);
    return { x, y, w: Math.ceil(r.x + r.w) - x, h: Math.ceil(r.y + r.h) - y };
  });
  const bytes = new Uint8Array(await imageBlob.arrayBuffer());
  throwIfAborted(abortSignal);
  const png = await redactPng(bytes, pixelRegions, method, Math.ceil(padding));
  throwIfAborted(abortSignal);
  return new Blob([png], { type: "image/png" });
}
