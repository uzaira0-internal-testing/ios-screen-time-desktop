import { describe, expect, it } from "bun:test";

import {
  REQUIRED_PIPELINE_SCHEMA_VERSION,
  validatePipelineResultContract,
  type EmPipelineResult,
} from "../pipelineLoader";

describe("Emscripten pipeline result contract", () => {
  it("accepts the current schema", () => {
    const result: EmPipelineResult = {
      pipeline_schema_version: REQUIRED_PIPELINE_SCHEMA_VERSION,
      success: true,
      suspected_all_devices: true,
    };

    expect(validatePipelineResultContract(result)).toBe(result);
  });

  it("rejects a stale artifact instead of defaulting missing quality fields", () => {
    const result = validatePipelineResultContract({ success: true });

    expect(result.success).toBe(false);
    expect(result.abiMismatch).toBe(true);
    expect(result.error).toContain("Incompatible OCR pipeline schema");
  });
});
