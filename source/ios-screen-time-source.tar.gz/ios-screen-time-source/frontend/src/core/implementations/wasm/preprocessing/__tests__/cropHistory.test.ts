/**
 * Unit tests for the pure crop undo/redo reducer. No storage/canvas — just the
 * stack math: seeding, push-truncates-redo-tail, bounds, and the MAX cap.
 */
import { describe, it, expect } from "bun:test";
import {
  emptyHistory,
  seedHistory,
  pushCrop,
  undo,
  redo,
  canUndo,
  canRedo,
  currentEntry,
  rectDimensions,
  MAX_CROP_HISTORY,
  type CropHistoryEntry,
} from "../cropHistory";

const NO_GRID = { ulx: null, uly: null, lrx: null, lry: null };

const entry = (left: number, source: "none" | "auto" | "manual" = "manual"): CropHistoryEntry => ({
  crop: source === "none" ? null : { left, top: 0, right: left + 100, bottom: 100 },
  grid: NO_GRID,
  source,
});

describe("cropHistory reducer", () => {
  it("empty history allows neither undo nor redo", () => {
    const h = emptyHistory();
    expect(canUndo(h)).toBe(false);
    expect(canRedo(h)).toBe(false);
    expect(currentEntry(h)).toBeNull();
  });

  it("seed sets a single current entry, no undo yet", () => {
    const h = seedHistory(entry(0, "auto"));
    expect(h.index).toBe(0);
    expect(canUndo(h)).toBe(false);
    expect(canRedo(h)).toBe(false);
    expect(currentEntry(h)?.source).toBe("auto");
  });

  it("push makes the prior state undoable and advances the index", () => {
    let h = seedHistory(entry(0, "auto"));
    h = pushCrop(h, entry(10));
    expect(h.index).toBe(1);
    expect(canUndo(h)).toBe(true);
    expect(canRedo(h)).toBe(false);
    expect(currentEntry(h)?.crop?.left).toBe(10);
  });

  it("undo then redo round-trips to the same entry", () => {
    let h = seedHistory(entry(0, "auto"));
    h = pushCrop(h, entry(10));
    h = undo(h);
    expect(h.index).toBe(0);
    expect(canRedo(h)).toBe(true);
    expect(currentEntry(h)?.source).toBe("auto");
    h = redo(h);
    expect(h.index).toBe(1);
    expect(currentEntry(h)?.crop?.left).toBe(10);
  });

  it("a new crop after undo truncates the redo tail", () => {
    let h = seedHistory(entry(0, "auto"));
    h = pushCrop(h, entry(10));
    h = pushCrop(h, entry(20));
    h = undo(h); // back to entry(10)
    expect(canRedo(h)).toBe(true);
    h = pushCrop(h, entry(30)); // supersedes the undone entry(20)
    expect(canRedo(h)).toBe(false);
    expect(h.entries.map((e) => e.crop?.left)).toEqual([0, 10, 30]);
    expect(h.index).toBe(2);
  });

  it("undo/redo are no-ops at the bounds", () => {
    let h = seedHistory(entry(0, "auto"));
    expect(undo(h)).toBe(h); // already at start
    h = pushCrop(h, entry(10));
    expect(redo(h)).toBe(h); // already at end
  });

  it("evicts the oldest entries past MAX_CROP_HISTORY, keeping the newest current", () => {
    let h = seedHistory(entry(0, "auto"));
    for (let i = 1; i <= MAX_CROP_HISTORY + 5; i++) {
      h = pushCrop(h, entry(i));
    }
    expect(h.entries.length).toBe(MAX_CROP_HISTORY);
    expect(h.index).toBe(MAX_CROP_HISTORY - 1);
    // newest applied crop is preserved
    expect(currentEntry(h)?.crop?.left).toBe(MAX_CROP_HISTORY + 5);
  });

  it("rectDimensions returns null for uncropped, w/h otherwise", () => {
    expect(rectDimensions(null)).toBeNull();
    expect(rectDimensions({ left: 10, top: 20, right: 110, bottom: 220 })).toEqual({
      width: 100,
      height: 200,
    });
  });
});
