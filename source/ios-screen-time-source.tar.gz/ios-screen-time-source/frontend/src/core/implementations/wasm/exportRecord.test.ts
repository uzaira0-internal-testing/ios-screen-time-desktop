/**
 * Canonical export-record builder (roadmap #21) — the SSoT row shape shared by
 * the client-side CSV and JSON exports.
 */
import { describe, it, expect } from "bun:test";
import type { Screenshot } from "@/types";
import { EXPORT_CSV_HEADERS } from "@/core/generated/constants";
import {
  EXPORT_RECORD_KEYS,
  buildExportRecord,
  hasExportableHourlyData,
  hasExportableHourlyValues,
  shouldIncludeInExport,
  recordToCsvRow,
  buildExportJsonEnvelope,
} from "./exportRecord";

const mk = (over: Partial<Screenshot>): Screenshot =>
  ({
    id: 1,
    file_path: "/uploads/a/b/shot.png",
    image_type: "screen_time",
    uploaded_at: "2026-01-01T00:00:00Z",
    extracted_hourly_data: null,
    ...over,
  }) as Screenshot;

describe("export record SSoT (#21)", () => {
  it("keeps the record keys aligned 1:1 with EXPORT_CSV_HEADERS", () => {
    expect(EXPORT_RECORD_KEYS.length).toBe(EXPORT_CSV_HEADERS.length);
    expect(EXPORT_RECORD_KEYS.length).toBe(45); // 21 metadata + 24 hourly
    expect(EXPORT_RECORD_KEYS.slice(-24)).toEqual(
      Array.from({ length: 24 }, (_, i) => `hour_${i}`),
    );
  });

  it("derives filename, verified flag, hourly columns and computed total", () => {
    const rec = buildExportRecord(
      mk({
        id: 42,
        file_path: "/deep/path/screen.png",
        group_id: "g1",
        participant_id: "p7",
        extracted_title: "Instagram",
        verified_by_user_ids: [3, 9],
        extracted_hourly_data: { "0": 30, "1": 60 },
      } as Partial<Screenshot>),
    );
    expect(rec.screenshot_id).toBe(42);
    expect(rec.filename).toBe("screen.png"); // basename of file_path
    expect(rec.group_id).toBe("g1");
    expect(rec.participant_id).toBe("p7");
    expect(rec.title).toBe("Instagram");
    expect(rec.is_verified).toBe("Yes");
    expect(rec.verified_by_count).toBe(2);
    expect(rec.hour_0).toBe("30");
    expect(rec.hour_1).toBe("60");
    expect(rec.hour_2).toBe(""); // unset hours blank
    expect(rec.computed_total).toBe("1h 30m"); // 30 + 60 = 90 min
  });

  it("formats sub-hour and empty totals", () => {
    expect(buildExportRecord(mk({ extracted_hourly_data: { "5": 45 } } as Partial<Screenshot>)).computed_total).toBe("45m");
    expect(buildExportRecord(mk({})).computed_total).toBe(""); // no hourly data
    expect(buildExportRecord(mk({})).is_verified).toBe("No");
  });

  it("ignores out-of-range, null, and non-finite hourly entries without crashing", () => {
    const rec = buildExportRecord(
      mk({
        extracted_hourly_data: { "0": 10, "99": 5, "3": null, "4": Number.NaN, "5": Infinity },
      } as unknown as Partial<Screenshot>),
    );
    expect(rec.hour_0).toBe("10");
    expect(rec.hour_3).toBe(""); // null dropped
    expect(rec.hour_4).toBe("");
    expect(rec.hour_5).toBe("");
    expect(rec.computed_total).toBe("10m"); // 99 ignored, null ignored
    expect(rec.failure_reasons).toContain("invalid_hour_key");
    expect(rec.failure_reasons).toContain("invalid_hourly_value");
  });

  it("matches the server's truncation for fractional computed totals", () => {
    const rec = buildExportRecord(
      mk({ extracted_hourly_data: { "0": 10.9, "1": 50.9 } } as Partial<Screenshot>),
    );

    expect(rec.computed_total).toBe("1h 1m");
  });

  it("does not consider OCR-total-only rows exportable", () => {
    expect(
      hasExportableHourlyData(
        mk({
          processing_status: "completed",
          extracted_title: null,
          extracted_total: "1h 43m",
          extracted_hourly_data: null,
        } as Partial<Screenshot>),
      ),
    ).toBe(false);
    expect(
      hasExportableHourlyData(
        mk({
          processing_status: "completed",
          extracted_total: "1h 43m",
          extracted_hourly_data: { "0": 60, "1": 43 },
        } as Partial<Screenshot>),
      ),
    ).toBe(true);
    expect(hasExportableHourlyValues(null)).toBe(false);
    expect(hasExportableHourlyValues({ total: 103 })).toBe(false);
    expect(hasExportableHourlyValues({ "2": "15" })).toBe(true);
    expect(hasExportableHourlyValues({ "2 trailing": 15 })).toBe(false);
    expect(hasExportableHourlyValues({ "+2": 15 })).toBe(false);
    expect(hasExportableHourlyValues({ "02": 15 })).toBe(false);
    expect(hasExportableHourlyValues({ "2": "" })).toBe(false);
    expect(hasExportableHourlyValues({ "2": true })).toBe(false);
    expect(hasExportableHourlyValues({ "2": -1 })).toBe(false);
    expect(hasExportableHourlyValues({ "2": 1441 })).toBe(false);
    expect(hasExportableHourlyValues({ "2": 180 })).toBe(true);
    expect(shouldIncludeInExport(mk({
      processing_status: "completed",
      extracted_hourly_data: { "2": 1441 },
    } as Partial<Screenshot>))).toBe(true);
  });

  it("never lets alias keys overwrite a cell or inflate the computed total", () => {
    const rec = buildExportRecord(
      mk({ extracted_hourly_data: { "1": 10, "+1": 20, "01": 30 } } as Partial<Screenshot>),
    );

    expect(rec.hour_1).toBe("10");
    expect(rec.computed_total).toBe("10m");
  });

  it("matches the server's computed total for an all-zero hourly vector", () => {
    const rec = buildExportRecord(
      mk({ extracted_hourly_data: { "0": 0, "1": 0 } } as Partial<Screenshot>),
    );

    expect(rec.computed_total).toBe("0m");
  });

  it("documents failed OCR rows and All Devices flags without hourly data", () => {
    const screenshot = mk({
      processing_status: "failed",
      file_path: "/uploads/failed.png",
      processing_issues: [{
        issue_type: "ocr_processing_failed",
        description: "OCR engine unavailable",
        severity: "blocking",
        message: null,
      }],
      processing_metadata: {
        ocr_ever_failed: true,
        quality_flags: {
          suspected_all_devices: true,
          axis_max_minutes: 120,
          all_devices_reasons: ["Chart axis exceeds 1 hour (120 min)"],
        },
      },
    } as Partial<Screenshot>);
    expect(shouldIncludeInExport(screenshot)).toBe(true);
    const rec = buildExportRecord(screenshot);
    expect(rec.filename).toBe("failed.png");
    expect(rec.ocr_failed).toBe("Yes");
    expect(rec.failure_reasons).toBe("ocr_processing_failed: OCR engine unavailable");
    expect(rec.review_flags).toBe("Suspected All Devices");
    expect(rec.chart_axis_max_minutes).toBe(120);
    expect(rec.computed_total).toBe("");
    expect(rec.hour_0).toBe("");
  });

  it("flags an impossible >60-minute hourly value as a secondary signal", () => {
    const rec = buildExportRecord(
      mk({
        processing_status: "completed",
        extracted_hourly_data: { "8": 75 },
      } as Partial<Screenshot>),
    );

    expect(rec.ocr_failed).toBe("No");
    expect(rec.review_flags).toBe("Suspected All Devices");
  });

  it("exports a direct All Devices selector match distinctly from heuristics", () => {
    const rec = buildExportRecord(mk({
      processing_status: "completed",
      processing_metadata: {
        quality_flags: {
          suspected_all_devices: true,
          axis_max_minutes: null,
          all_devices_reasons: ["OCR found 'All Devices' text"],
        },
      },
    } as Partial<Screenshot>));

    expect(rec.review_flags).toBe("All Devices Detected");
  });

  it("treats a legacy All Devices issue as review evidence, not failure", () => {
    const rec = buildExportRecord(mk({
      processing_status: "completed",
      extracted_hourly_data: { "8": 20 },
      processing_issues: [{
        issue_type: "suspected_all_devices",
        description: "Chart axis exceeds 1 hour (120 min)",
      } as unknown as NonNullable<Screenshot["processing_issues"]>[number]],
    } as Partial<Screenshot>));

    expect(rec.review_flags).toBe("Suspected All Devices");
    expect(rec.chart_axis_max_minutes).toBe(120);
    expect(rec.failure_reasons).toBe("");
  });

  it("exports a grid failure without falsely labeling it as OCR failure", () => {
    const rec = buildExportRecord(mk({
      processing_status: "failed",
      processing_issues: [{
        issue_type: "grid_detection_failed",
        description: "No chart grid found",
        severity: "blocking",
        message: null,
      }],
    } as Partial<Screenshot>));

    expect(rec.processing_status).toBe("failed");
    expect(rec.ocr_failed).toBe("No");
    expect(rec.failure_reasons).toBe("grid_detection_failed: No chart grid found");
  });

  it("keeps failure documentation after an operator skips the record", () => {
    const screenshot = mk({
      processing_status: "skipped",
      processing_metadata: { pre_skip_status: "failed" },
      processing_issues: [{
        issue_type: "grid_detection_failed",
        description: "No chart grid found",
        severity: "blocking",
        message: null,
      }],
    } as Partial<Screenshot>);

    expect(shouldIncludeInExport(screenshot)).toBe(true);
    const rec = buildExportRecord(screenshot);
    expect(rec.processing_status).toBe("skipped");
    expect(rec.ocr_failed).toBe("No");
    expect(rec.failure_reasons).toBe("grid_detection_failed: No chart grid found");
  });

  it("normalizes a legacy completed row with a current blocker to failed", () => {
    const rec = buildExportRecord(mk({
      processing_status: "completed",
      has_blocking_issues: true,
      processing_issues: [{
        issue_type: "bar_extraction_failed",
        description: "No usable bars found",
        severity: "blocking",
        message: null,
      }],
    } as Partial<Screenshot>));

    expect(rec.processing_status).toBe("failed");
    expect(rec.failure_reasons).toBe("bar_extraction_failed: No usable bars found");
  });

  it("never emits a failed legacy row with a blank failure reason", () => {
    const rec = buildExportRecord(mk({
      processing_status: "failed",
      processing_issues: [],
    } as Partial<Screenshot>));

    expect(rec.ocr_failed).toBe("No");
    expect(rec.failure_reasons).toBe(
      "processing_failed: Automated processing failed; detailed reason was not recorded",
    );
  });

  it("recordToCsvRow projects values in header order (45 columns)", () => {
    const rec = buildExportRecord(mk({ id: 7 }));
    const row = recordToCsvRow(rec);
    expect(row.length).toBe(EXPORT_CSV_HEADERS.length);
    expect(row[0]).toBe(7); // screenshot_id is the first column
  });

  it("builds a JSON envelope carrying the SSoT columns and a deterministic timestamp", () => {
    const records = [buildExportRecord(mk({ id: 1 })), buildExportRecord(mk({ id: 2 }))];
    const json = buildExportJsonEnvelope(records, {
      timestamp: "2026-06-05T00:00:00.000Z",
      columns: EXPORT_CSV_HEADERS,
    });
    const parsed = JSON.parse(json) as {
      export_format_version: number;
      export_timestamp: string;
      total_screenshots: number;
      columns: string[];
      screenshots: Array<{ screenshot_id: number }>;
    };
    expect(parsed.export_format_version).toBe(2);
    expect(parsed.export_timestamp).toBe("2026-06-05T00:00:00.000Z");
    expect(parsed.total_screenshots).toBe(2);
    expect(parsed.columns).toEqual([...EXPORT_CSV_HEADERS]);
    expect(parsed.screenshots).toHaveLength(2);
    expect(parsed.screenshots[0]?.screenshot_id).toBe(1);
  });
});
