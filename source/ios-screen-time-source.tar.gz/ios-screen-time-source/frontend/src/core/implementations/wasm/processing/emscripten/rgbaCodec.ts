import { ImageTooLargeError } from "@/core/implementations/wasm/utils/imageLimits";

/** The part of the pipeline module that {@link decodeToRgba} calls. */
export interface DecodeModule {
  HEAPU8: Uint8Array;
  _pipeline_alloc(len: number): number;
  _pipeline_free(ptr: number, len: number): void;
  _pipeline_decode(bytesPtr: number, bytesLen: number, outDimsPtr: number): number;
}

/** Decode encoded image bytes through Rust and copy RGBA out of wasm memory. */
export function decodeToRgba(
  mod: DecodeModule,
  bytes: Uint8Array,
): { width: number; height: number; data: Uint8Array } {
  let bytesPtr = 0;
  let dimsPtr = 0;
  let rgbaPtr = 0;
  let rgbaLen = 0;
  try {
    bytesPtr = mod._pipeline_alloc(bytes.length);
    if (!bytesPtr) throw new Error("Failed to allocate image input");
    dimsPtr = mod._pipeline_alloc(8);
    if (!dimsPtr) throw new Error("Failed to allocate image dimensions");
    mod.HEAPU8.set(bytes, bytesPtr);
    rgbaPtr = mod._pipeline_decode(bytesPtr, bytes.length, dimsPtr);
    // Read HEAPU8 again: the decode may have grown (and replaced) wasm memory.
    const dims = new DataView(mod.HEAPU8.buffer);
    const width = dims.getUint32(dimsPtr, true);
    const height = dims.getUint32(dimsPtr + 4, true);
    if (!width || !height) throw new Error("Unable to decode image");
    if (!rgbaPtr) throw new ImageTooLargeError(width, height);
    rgbaLen = width * height * 4;
    return { width, height, data: mod.HEAPU8.slice(rgbaPtr, rgbaPtr + rgbaLen) };
  } finally {
    if (rgbaPtr) mod._pipeline_free(rgbaPtr, rgbaLen);
    if (dimsPtr) mod._pipeline_free(dimsPtr, 8);
    if (bytesPtr) mod._pipeline_free(bytesPtr, bytes.length);
  }
}

/**
 * Copy `bytes` into wasm memory, run one PNG-returning export on them, and copy
 * the PNG out. `run` gets the input pointer and length and the out-length pointer.
 */
export function pngFromRust(
  mod: Omit<DecodeModule, "_pipeline_decode">,
  bytes: Uint8Array,
  run: (bytesPtr: number, bytesLen: number, outLenPtr: number) => number,
): Uint8Array<ArrayBuffer> {
  let bytesPtr = 0;
  let lenPtr = 0;
  let pngPtr = 0;
  let pngLen = 0;
  try {
    bytesPtr = mod._pipeline_alloc(bytes.length);
    if (!bytesPtr) throw new Error("Failed to allocate image input");
    lenPtr = mod._pipeline_alloc(4);
    if (!lenPtr) throw new Error("Failed to allocate image length");
    mod.HEAPU8.set(bytes, bytesPtr);
    pngPtr = run(bytesPtr, bytes.length, lenPtr);
    pngLen = new DataView(mod.HEAPU8.buffer).getUint32(lenPtr, true);
    if (!pngPtr || !pngLen) throw new Error("Unable to process image");
    return mod.HEAPU8.slice(pngPtr, pngPtr + pngLen);
  } finally {
    if (pngPtr) mod._pipeline_free(pngPtr, pngLen);
    if (lenPtr) mod._pipeline_free(lenPtr, 4);
    if (bytesPtr) mod._pipeline_free(bytesPtr, bytes.length);
  }
}
