import { createSemaphore, type Semaphore } from "../utils/semaphore";
import {
  cropBlobToRect as cropBlobToRectInThread,
  cropScreenshot as cropScreenshotInThread,
  readBlobDimensions as readBlobDimensionsInThread,
  type CropResult,
  type RectCropResult,
} from "./cropping";
import type { ImageDimensions } from "../utils/imageLimits";
import type { CropRect } from "./cropHistory";

type CropWorkerTaskType = "cropScreenshot" | "cropBlobToRect" | "readBlobDimensions";

interface CropWorkerRequest {
  id: string;
  type: CropWorkerTaskType;
  blob: Blob;
  rect?: CropRect;
  knownDimensions?: { width: number; height: number };
}

interface CropWorkerErrorPayload {
  name: string;
  message: string;
  stack?: string;
}

type CropWorkerResponse =
  | {
      id: string;
      type: "result";
      result: unknown;
    }
  | {
      id: string;
      type: "error";
      error: CropWorkerErrorPayload;
    };

interface PendingCropRequest extends CropWorkerRequest {
  resolve: (value: unknown) => void;
  reject: (reason?: unknown) => void;
  abortSignal?: AbortSignal | undefined;
  abortHandler?: (() => void) | undefined;
}

interface CropWorkerSlot {
  worker: Worker;
  current: PendingCropRequest | null;
}

export interface CropWorkerPoolSnapshot {
  maxWorkers: number;
  poolSize: number;
  busyWorkers: number;
  queuedRequests: number;
  accepted: number;
  dispatched: number;
  completed: number;
  failed: number;
  cancelled: number;
  terminated: number;
  fallbackRuns: number;
  maxQueueDepth: number;
  maxBusyWorkers: number;
}

interface MutableCropWorkerPoolStats {
  accepted: number;
  dispatched: number;
  completed: number;
  failed: number;
  cancelled: number;
  terminated: number;
  fallbackRuns: number;
  maxQueueDepth: number;
  maxBusyWorkers: number;
}

function abortError(message = "Crop request aborted"): Error {
  try {
    return new DOMException(message, "AbortError");
  } catch {
    const error = new Error(message);
    error.name = "AbortError";
    return error;
  }
}

function deserializeWorkerError(error: CropWorkerErrorPayload): Error {
  const err = new Error(error.message);
  err.name = error.name || "Error";
  if (error.stack) err.stack = error.stack;
  return err;
}

function canUseCropWorkers(): boolean {
  return typeof window !== "undefined" && typeof Worker !== "undefined";
}

let nextCropRequestId = 1;

export class CropWorkerPool {
  private readonly maxWorkers: number;
  private readonly fallbackGate: Semaphore;
  private readonly slots: CropWorkerSlot[] = [];
  private readonly queue: PendingCropRequest[] = [];
  private readonly stats: MutableCropWorkerPoolStats = {
    accepted: 0,
    dispatched: 0,
    completed: 0,
    failed: 0,
    cancelled: 0,
    terminated: 0,
    fallbackRuns: 0,
    maxQueueDepth: 0,
    maxBusyWorkers: 0,
  };

  constructor(maxWorkers: number) {
    this.maxWorkers = Math.max(1, Math.floor(maxWorkers));
    this.fallbackGate = createSemaphore(this.maxWorkers);
  }

  cropScreenshot(blob: Blob, abortSignal?: AbortSignal): Promise<CropResult> {
    if (!canUseCropWorkers()) {
      return this.runFallback(() => cropScreenshotInThread(blob, abortSignal), abortSignal);
    }
    return this.enqueue<CropResult>({ type: "cropScreenshot", blob }, abortSignal);
  }

  cropBlobToRect(
    blob: Blob,
    rect: CropRect,
    knownDimensions?: { width: number; height: number },
    abortSignal?: AbortSignal,
  ): Promise<RectCropResult> {
    if (!canUseCropWorkers()) {
      return this.runFallback(
        () => cropBlobToRectInThread(blob, rect, knownDimensions, abortSignal),
        abortSignal,
      );
    }
    return this.enqueue<RectCropResult>(
      {
        type: "cropBlobToRect",
        blob,
        rect,
        ...(knownDimensions ? { knownDimensions } : {}),
      },
      abortSignal,
    );
  }

  readBlobDimensions(blob: Blob, abortSignal?: AbortSignal): Promise<ImageDimensions> {
    if (!canUseCropWorkers()) {
      return this.runFallback(() => readBlobDimensionsInThread(blob, abortSignal), abortSignal);
    }
    return this.enqueue<ImageDimensions>({ type: "readBlobDimensions", blob }, abortSignal);
  }

  getSnapshot(): CropWorkerPoolSnapshot {
    const busyWorkers = this.busyWorkerCount();
    return {
      maxWorkers: this.maxWorkers,
      poolSize: this.slots.length,
      busyWorkers,
      queuedRequests: this.queue.length,
      accepted: this.stats.accepted,
      dispatched: this.stats.dispatched,
      completed: this.stats.completed,
      failed: this.stats.failed,
      cancelled: this.stats.cancelled,
      terminated: this.stats.terminated,
      fallbackRuns: this.stats.fallbackRuns,
      maxQueueDepth: this.stats.maxQueueDepth,
      maxBusyWorkers: this.stats.maxBusyWorkers,
    };
  }

  terminate(): void {
    const queued = this.queue.splice(0);
    for (const request of queued) {
      this.cleanupAbortHandler(request);
      this.stats.cancelled++;
      request.reject(abortError());
    }
    for (const slot of this.slots.splice(0)) {
      if (slot.current) {
        this.cleanupAbortHandler(slot.current);
        this.stats.cancelled++;
        slot.current.reject(abortError());
        slot.current = null;
      }
      this.stats.terminated++;
      slot.worker.terminate();
    }
  }

  private async runFallback<T>(
    fn: () => Promise<T>,
    abortSignal?: AbortSignal,
  ): Promise<T> {
    this.stats.accepted++;
    this.stats.fallbackRuns++;
    try {
      const result = await this.fallbackGate.run(async () => {
        this.stats.dispatched++;
        this.recordBusyDepth();
        return fn();
      }, abortSignal);
      this.stats.completed++;
      return result;
    } catch (error) {
      if (abortSignal?.aborted || (error instanceof Error && error.name === "AbortError")) {
        this.stats.cancelled++;
      } else {
        this.stats.failed++;
      }
      throw error;
    }
  }

  private enqueue<T>(
    request: Omit<CropWorkerRequest, "id">,
    abortSignal?: AbortSignal,
  ): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      this.stats.accepted++;
      const pending: PendingCropRequest = {
        ...request,
        id: `crop-${nextCropRequestId++}`,
        resolve: (value: unknown) => resolve(value as T),
        reject,
        ...(abortSignal ? { abortSignal } : {}),
      };
      if (!this.attachAbortHandler(pending)) {
        this.stats.cancelled++;
        return;
      }
      this.queue.push(pending);
      this.stats.maxQueueDepth = Math.max(this.stats.maxQueueDepth, this.queue.length);
      this.drain();
    });
  }

  private attachAbortHandler(request: PendingCropRequest): boolean {
    const signal = request.abortSignal;
    if (!signal) return true;
    if (signal.aborted) {
      request.reject(abortError());
      return false;
    }

    request.abortHandler = () => {
      const queuedIndex = this.queue.findIndex((queued) => queued.id === request.id);
      if (queuedIndex >= 0) {
        const [queued] = this.queue.splice(queuedIndex, 1);
        if (queued) {
          this.cleanupAbortHandler(queued);
          this.stats.cancelled++;
          queued.reject(abortError());
        }
        return;
      }

      const slot = this.slots.find((candidate) => candidate.current?.id === request.id);
      if (!slot) return;
      this.rejectCurrentAndRemoveSlot(slot, abortError());
      this.drain();
    };
    signal.addEventListener("abort", request.abortHandler, { once: true });
    return true;
  }

  private cleanupAbortHandler(request: PendingCropRequest): void {
    if (request.abortSignal && request.abortHandler) {
      request.abortSignal.removeEventListener("abort", request.abortHandler);
      request.abortHandler = undefined;
    }
  }

  private drain(): void {
    while (this.queue.length > 0) {
      const slot = this.idleSlot() ?? this.createSlotIfNeeded();
      if (!slot) return;
      const request = this.queue.shift();
      if (!request) return;
      this.dispatch(slot, request);
    }
  }

  private idleSlot(): CropWorkerSlot | null {
    return this.slots.find((slot) => !slot.current) ?? null;
  }

  private createSlotIfNeeded(): CropWorkerSlot | null {
    if (this.slots.length >= this.maxWorkers) return null;
    const worker = new Worker(new URL("./crop.worker.ts", import.meta.url), { type: "module" });
    const slot: CropWorkerSlot = { worker, current: null };
    worker.onmessage = (event: MessageEvent<CropWorkerResponse>) => {
      this.handleWorkerMessage(slot, event.data);
    };
    worker.onerror = (event) => {
      const message = event.message || "Crop worker failed";
      this.rejectCurrentAndRemoveSlot(slot, new Error(message));
      this.drain();
    };
    this.slots.push(slot);
    return slot;
  }

  private dispatch(slot: CropWorkerSlot, request: PendingCropRequest): void {
    if (request.abortSignal?.aborted) {
      this.cleanupAbortHandler(request);
      this.stats.cancelled++;
      request.reject(abortError());
      return;
    }
    slot.current = request;
    this.stats.dispatched++;
    this.recordBusyDepth();
    slot.worker.postMessage({
      id: request.id,
      type: request.type,
      blob: request.blob,
      ...(request.rect ? { rect: request.rect } : {}),
      ...(request.knownDimensions ? { knownDimensions: request.knownDimensions } : {}),
    } satisfies CropWorkerRequest);
  }

  private handleWorkerMessage(slot: CropWorkerSlot, response: CropWorkerResponse): void {
    const request = slot.current;
    if (!request || request.id !== response.id) return;
    slot.current = null;
    this.cleanupAbortHandler(request);
    if (response.type === "error") {
      this.stats.failed++;
      request.reject(deserializeWorkerError(response.error));
    } else {
      this.stats.completed++;
      request.resolve(response.result);
    }
    this.drain();
  }

  private rejectCurrentAndRemoveSlot(slot: CropWorkerSlot, reason: unknown): void {
    const index = this.slots.indexOf(slot);
    if (index >= 0) this.slots.splice(index, 1);
    if (slot.current) {
      this.cleanupAbortHandler(slot.current);
      if (reason instanceof Error && reason.name === "AbortError") {
        this.stats.cancelled++;
      } else {
        this.stats.failed++;
      }
      slot.current.reject(reason);
      slot.current = null;
    }
    this.stats.terminated++;
    slot.worker.terminate();
  }

  private busyWorkerCount(): number {
    return this.slots.filter((slot) => slot.current !== null).length;
  }

  private recordBusyDepth(): void {
    this.stats.maxBusyWorkers = Math.max(this.stats.maxBusyWorkers, this.busyWorkerCount());
  }
}
