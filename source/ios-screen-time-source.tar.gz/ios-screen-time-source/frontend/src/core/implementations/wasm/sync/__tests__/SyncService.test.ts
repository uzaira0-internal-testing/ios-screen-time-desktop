import "fake-indexeddb/auto";
import { afterEach, beforeEach, describe, expect, test } from "bun:test";
import { db } from "../../storage/database";
import { SyncService } from "../SyncService";
import type { Screenshot } from "@/types";

const deps = (db as unknown as { _deps: { indexedDB: unknown; IDBKeyRange: unknown } })._deps;
deps.indexedDB = globalThis.indexedDB;
deps.IDBKeyRange = globalThis.IDBKeyRange;

const originalFetch = Object.getOwnPropertyDescriptor(globalThis, "fetch");
const originalNavigator = Object.getOwnPropertyDescriptor(globalThis, "navigator");

function restoreGlobal(name: "fetch" | "navigator", descriptor: PropertyDescriptor | undefined): void {
  if (descriptor) {
    Object.defineProperty(globalThis, name, descriptor);
  } else {
    Reflect.deleteProperty(globalThis, name);
  }
}

/**
 * Build a deliberately partial `Screenshot` fixture. SyncService reads only the
 * fields set below, and `Partial<Screenshot>` keeps every key and value type
 * checked — which `as unknown as Screenshot` would not.
 */
function asScreenshot(partial: Partial<Screenshot>): Screenshot {
  return partial as Screenshot;
}

function makeScreenshot(id: number): Screenshot {
  return asScreenshot({
    id,
    group_id: "g1",
    processing_status: "completed",
    annotation_status: "pending",
    extracted_hourly_data: { 0: 15 },
    extracted_title: "Weather",
    extracted_total: "15m",
    content_hash: `sync-${id}`,
    verified_by_user_ids: null,
  });
}

describe("SyncService", () => {
  beforeEach(async () => {
    await db.delete();
    await db.open();
  });

  afterEach(async () => {
    restoreGlobal("fetch", originalFetch);
    restoreGlobal("navigator", originalNavigator);
    await db.delete();
  });

  test("bounds pulled consensus annotation inserts by the metadata resource budget", async () => {
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: {
        hardwareConcurrency: 8,
        deviceMemory: 0.5,
      },
    });

    await db.screenshots.put(makeScreenshot(1));
    await db.syncRecords.add({
      entity_type: "screenshot",
      localId: 1,
      serverId: 101,
      sync_status: "synced",
      syncedAt: new Date().toISOString(),
    });

    Object.defineProperty(globalThis, "fetch", {
      configurable: true,
      value: async () =>
        ({
          ok: true,
          json: async () => ({
            annotations: Array.from({ length: 6 }, (_, index) => ({
              id: 1000 + index,
              user_id: 2000 + index,
              hourly_values: { 0: index + 1 },
            })),
          }),
        }) as Response,
    });

    const originalAdd = db.annotations.add.bind(db.annotations);
    let activeAdds = 0;
    let peakAdds = 0;
    (db.annotations as unknown as { add: typeof db.annotations.add }).add = (async (...args) => {
      activeAdds += 1;
      peakAdds = Math.max(peakAdds, activeAdds);
      try {
        const key = await originalAdd(...args);
        await Promise.resolve();
        return key;
      } finally {
        activeAdds -= 1;
      }
    }) as typeof db.annotations.add;

    try {
      const service = new SyncService();
      service.configure({ serverUrl: "https://sync.example", username: "tester" });

      const result = await service.sync();

      expect(result.pulled.annotations).toBe(6);
      expect(await db.annotations.count()).toBe(6);
      expect(peakAdds).toBe(2);
    } finally {
      // eslint-disable-next-line require-atomic-updates -- restoring the spy after the awaited sync is exactly the intent; no other task touches it
      db.annotations.add = originalAdd;
    }
  });
});
