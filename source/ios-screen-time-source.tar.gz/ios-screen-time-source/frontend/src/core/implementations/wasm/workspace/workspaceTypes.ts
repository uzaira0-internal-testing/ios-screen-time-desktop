/**
 * Types + constants for the WASM workspace import/export (roadmap #22).
 *
 * A workspace archive is a single ZIP that round-trips the ENTIRE offline state —
 * every Dexie table plus every OPFS/IndexedDB image blob — so a user can move their
 * work between browsers/machines, or back it up, with zero server.
 *
 * Archive layout:
 *   manifest.json   — WorkspaceManifest (format/version/db-version/counts)
 *   tables.json     — WorkspaceTables (all non-blob records, ids preserved)
 *   blobs.json      — BlobIndexEntry[] (one per binary blob, for pre-clear validation)
 *   blobs/<name>    — raw blob bytes, named exactly as OPFS names them
 */
import type { Screenshot, Annotation, Group } from "@/types";
import type { Settings, QueueItem, SyncRecord } from "../storage/database/ScreenshotDB";
import type { ProcessingSettings } from "@/store/settingsStore";

export const WORKSPACE_FORMAT_ID = "ios-screen-time-workspace";
/** Bump only on a breaking change to the archive container itself. */
export const WORKSPACE_FORMAT_VERSION = 1;
/**
 * The Dexie schema version this build reads/writes (ScreenshotDB.version). Import
 * requires an EXACT match — a workspace exported under a different schema is refused
 * with a clear message rather than silently mis-restored. Bump in lockstep with the
 * ScreenshotDB version when the on-disk shape changes.
 */
export const WORKSPACE_DB_VERSION = 7;

/** The derived blob-size cache key — never round-tripped; rebuilt from disk on import. */
export const BLOB_TOTAL_SETTINGS_KEY = "opfs_blob_total_size";

export const ARCHIVE_PATHS = {
  manifest: "manifest.json",
  tables: "tables.json",
  blobIndex: "blobs.json",
  blobDir: "blobs/",
  preferences: "preferences.json",
} as const;

export interface WorkspaceManifest {
  format: typeof WORKSPACE_FORMAT_ID;
  formatVersion: number;
  dbVersion: number;
  appVersion: string;
  exportedAt: string;
  counts: {
    screenshots: number;
    annotations: number;
    groups: number;
    settings: number;
    processingQueue: number;
    syncRecords: number;
    blobs: number;
  };
}

/** All non-blob table records, serialized as JSON. Record `id`s are preserved verbatim. */
export interface WorkspaceTables {
  screenshots: Screenshot[];
  annotations: Annotation[];
  groups: Group[];
  settings: Settings[];
  processingQueue: QueueItem[];
  syncRecords: SyncRecord[];
}

export interface WorkspacePreferences {
  processing: ProcessingSettings;
  enabledLanguages: string[];
  languagePacks: { code: string; name: string; size: number }[];
}

/** Index entry for one binary blob in the archive — drives validate-before-clear. */
export interface BlobIndexEntry {
  /** File name under blobs/, e.g. "123.img" or "123_stage_cropping.img". */
  name: string;
  screenshotId: number;
  /** null = the main image blob; otherwise a pipeline stage name. */
  stage: string | null;
  size: number;
}

export interface WorkspaceImportResult {
  screenshots: number;
  annotations: number;
  groups: number;
  settings: number;
  processingQueue: number;
  syncRecords: number;
  blobs: number;
}

export function mainBlobName(id: number): string {
  return `${id}.img`;
}

export function stageBlobName(id: number, stage: string): string {
  return `${id}_stage_${stage}.img`;
}
