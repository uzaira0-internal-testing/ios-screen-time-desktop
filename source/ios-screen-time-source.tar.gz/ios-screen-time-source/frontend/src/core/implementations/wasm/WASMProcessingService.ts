import type { HourlyData, GridCoordinates } from "@/types";
import type { ImageType } from "@/types";
import type {
  IProcessingService,
  ProcessingConfig,
  ProcessingProgressCallback,
  GridDetectionDetail,
  ProcessingSchedulerMessageStats,
  ProcessingSchedulerSnapshot,
} from "@/core/interfaces";
import type {
  WorkerMessage,
  WorkerResponse,
  ProcessImageResultPayload,
  InitializePayload,
  DetectGridPayload,
  ProcessImagePayload,
} from "./processing/workers/types";
import { getTessdataUrl, getWasmUrl } from "./processing/emscripten/pipelineLoader";
import { effectiveScoringKnobs, useSettingsStore } from "@/store/settingsStore";
import {
  BUNDLED_LANGUAGE,
  enabledLanguageCodes,
  tesseractLanguageString,
} from "@/core/implementations/wasm/languagePacks/languagePackStore";
import { recoverFromWasmAbiSkew } from "@/lib/wasmRecovery";
import { displayText } from "@/lib/displayText";
import {
  browserResourceNumber,
  computeOcrWorkerMemoryBudgetMb,
  computeOcrWorkerConcurrency,
} from "@/lib/resourceBudget";

/**
 * One worker slot in the pool. Each slot holds its own Web Worker. The worker
 * can run module-only LineBased grid detection before OCR initialization; once
 * initialized it also holds its own LepTess instance + tessdata mount in
 * Emscripten heap. The slot tracks whether it can receive one message and how
 * many messages are currently in-flight.
 */
interface WorkerSlot {
  worker: Worker;
  inFlight: number;
  ocrReady: boolean;
  ready: boolean;
}

interface QueuedWorkerRequest<T = unknown> {
  id: string;
  message: Omit<WorkerMessage, "id">;
  createdAt: number;
  targetSlot?: WorkerSlot | undefined;
  resolve: (value: T) => void;
  reject: (error: Error) => void;
  onProgress?: ProcessingProgressCallback | undefined;
  abortSignal?: AbortSignal | undefined;
  abortHandler?: (() => void) | undefined;
}

type WorkerMessageType = WorkerMessage["type"];

interface MutableSchedulerMessageStats {
  accepted: number;
  dispatched: number;
  currentInFlight: number;
  maxInFlight: number;
  completed: number;
  failed: number;
  timedOut: number;
  cancelled: number;
  terminated: number;
  totalQueueWaitMs: number;
  maxQueueWaitMs: number;
  totalWorkerRunMs: number;
  maxWorkerRunMs: number;
}

const FALLBACK_CORES = 4;

function monotonicNow(): number {
  return typeof performance !== "undefined" && typeof performance.now === "function"
    ? performance.now()
    : Date.now();
}

function abortError(message = "Processing request aborted"): Error {
  try {
    return new DOMException(message, "AbortError");
  } catch {
    const error = new Error(message);
    error.name = "AbortError";
    return error;
  }
}

function nonEmptyString(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() ? value.trim() : undefined;
}

function stringifyDetails(value: unknown): string | undefined {
  if (value === undefined || value === null) return undefined;
  if (typeof value === "string") return nonEmptyString(value);
  try {
    const json = JSON.stringify(value);
    return json && json !== "{}" ? json : displayText(value);
  } catch {
    return displayText(value);
  }
}

function workerResponseErrorMessage(data: Extract<WorkerResponse, { type: "ERROR" }>): string {
  const message = nonEmptyString(data.error);
  if (message) return message;

  const name = nonEmptyString(data.errorName);
  const details = nonEmptyString(data.errorDetails);
  if (name && details) return `${name}: ${details}`;
  if (name) return name;
  if (details) return details;
  return "Worker failed without an error message";
}

function workerCrashErrorMessage(event: Event | ErrorEvent | MessageEvent): string {
  if (typeof ErrorEvent !== "undefined" && event instanceof ErrorEvent) {
    const message = nonEmptyString(event.message);
    if (message) return `Worker error: ${message}`;

    const nested = event.error instanceof Error
      ? nonEmptyString(event.error.message) ?? nonEmptyString(event.error.name)
      : stringifyDetails(event.error);
    if (nested) return `Worker error: ${nested}`;

    const location = [
      nonEmptyString(event.filename),
      event.lineno ? `line ${event.lineno}` : undefined,
      event.colno ? `col ${event.colno}` : undefined,
    ].filter(Boolean).join(": ");
    if (location) {
      return `Worker crashed before reporting an error (${location})`;
    }
  }

  if (event.type === "messageerror") {
    const details = stringifyDetails((event as MessageEvent).data);
    return details
      ? `Worker message could not be deserialized: ${details}`
      : "Worker message could not be deserialized";
  }

  const eventType = nonEmptyString(event.type);
  return eventType
    ? `Worker crashed before reporting an error (${eventType})`
    : "Worker crashed before reporting an error";
}

export function computeWasmWorkerPoolSize(
  cores = FALLBACK_CORES,
  deviceMemoryGb?: number,
  measuredWorkerMb?: number,
): number {
  return computeOcrWorkerConcurrency(cores, deviceMemoryGb, measuredWorkerMb);
}

function ocrWorkerMemoryKey(): string {
  return `ios-screen-time:ocr-worker-memory-mb:${getWasmUrl()}`;
}

function readMeasuredOcrWorkerMemoryMb(): number | undefined {
  if (typeof localStorage === "undefined") return undefined;
  try {
    const value = Number(localStorage.getItem(ocrWorkerMemoryKey()));
    return Number.isFinite(value) && value > 0 ? value : undefined;
  } catch {
    return undefined;
  }
}

function persistMeasuredOcrWorkerMemoryMb(wasmHeapBytes: number | undefined): void {
  if (typeof localStorage === "undefined" || wasmHeapBytes === undefined) return;
  const heapMb = Math.ceil(wasmHeapBytes / (1024 * 1024));
  if (!Number.isFinite(heapMb) || heapMb <= 0) return;
  const budgetedWorkerMb = computeOcrWorkerMemoryBudgetMb(heapMb);
  try {
    const existing = readMeasuredOcrWorkerMemoryMb() ?? 0;
    localStorage.setItem(ocrWorkerMemoryKey(), String(Math.max(existing, budgetedWorkerMb)));
  } catch {
    // Storage can be unavailable in private contexts; the static budget remains conservative.
  }
}

/** PERF-1: the compiled WASM module is shared across the pool, but each worker
 *  still owns Tesseract/leptess state, Emscripten linear memory, decoded image
 *  buffers, and full pipeline transients. Size the pool by both CPU and the
 *  browser's coarse deviceMemory bucket instead of a fixed low-memory branch. */
function poolSize(): number {
  return computeWasmWorkerPoolSize(
    browserResourceNumber("hardwareConcurrency") ?? FALLBACK_CORES,
    browserResourceNumber("deviceMemory"),
    readMeasuredOcrWorkerMemoryMb(),
  );
}

/** The user's enabled OCR languages, or plain English if the selection can't be
 *  read. Never throws: an unreadable selection must not stop processing. */
async function resolveLanguages(): Promise<string> {
  try {
    return await tesseractLanguageString();
  } catch (err) {
    console.warn("[WASMProcessingService] could not resolve OCR languages:", err);
    return "eng";
  }
}

/** The same selection, read synchronously from localStorage.
 *
 * `processImage` is the hot dispatch path — awaiting the OPFS installed-pack
 * check here would push the worker message a microtask later, which is both
 * needless latency and an observable change in dispatch ordering. The loader
 * already skips any pack whose bytes it cannot read and names only the packs it
 * actually mounted, so an uninstalled code in this list is harmless. */
function selectedLanguages(): string {
  try {
    return [BUNDLED_LANGUAGE, ...enabledLanguageCodes()].join("+");
  } catch (err) {
    console.warn("[WASMProcessingService] could not read OCR language selection:", err);
    return BUNDLED_LANGUAGE;
  }
}

export class WASMProcessingService implements IProcessingService {
  private workers: WorkerSlot[] = [];
  private initialized = false;
  private initializationPromise: Promise<void> | null = null;
  private initializationTarget = 0;
  private messageIdCounter = 0;
  /** PERF-1/PERF-11: eng.traineddata is fetched ONCE on the main thread and
   *  handed to every worker via INITIALIZE. Keep it as a Blob so worker
   *  postMessage clones a blob handle instead of copying a 4 MB ArrayBuffer.
   *  Cached so a pool respawn (after a worker crash) reuses it without a
   *  re-fetch. */
  private tessdataPromise: Promise<Blob> | null = null;
  /** PERF-1: IosScreenTimePipeline.wasm is `compileStreaming`-compiled ONCE on
   *  the main thread and the resulting `WebAssembly.Module` handed to every
   *  worker via INITIALIZE. `WebAssembly.Module` is structured-cloneable to
   *  dedicated workers, so the pool shares one compiled module (~5.9 MB of
   *  compiled code) — only linear memory stays per-instance. Cached so a pool
   *  respawn reuses it without a re-compile. */
  private wasmModulePromise: Promise<WebAssembly.Module> | null = null;
  /** Maps message id → the slot it was dispatched to + handlers. We
   *  need to know the slot to decrement inFlight when the message
   *  completes (success, error, or timeout). */
  private pendingRequests = new Map<
    string,
    {
      slot: WorkerSlot;
      messageType: WorkerMessageType;
      dispatchedAt: number;
      resolve: (value: unknown) => void;
      reject: (error: Error) => void;
      onProgress?: ProcessingProgressCallback | undefined;
      abortSignal?: AbortSignal | undefined;
      abortHandler?: (() => void) | undefined;
    }
  >();
  private dispatchQueue: QueuedWorkerRequest[] = [];
  private maxQueueDepth = 0;
  private schedulerStats: Partial<Record<WorkerMessageType, MutableSchedulerMessageStats>> = {};
  private slotInitializationTail: Promise<void> = Promise.resolve();

  /** Number of workers in the pool. Used by the preprocessing service
   *  to size its OCR concurrency exactly to the pool. */
  getPoolSize(): number {
    return poolSize();
  }

  getSchedulerSnapshot(): ProcessingSchedulerSnapshot {
    const messages: Record<string, ProcessingSchedulerMessageStats> = {};
    for (const [type, stats] of Object.entries(this.schedulerStats)) {
      const completedRuns = stats.completed + stats.failed + stats.timedOut;
      messages[type] = {
        ...stats,
        averageQueueWaitMs:
          stats.dispatched > 0 ? stats.totalQueueWaitMs / stats.dispatched : 0,
        averageWorkerRunMs:
          completedRuns > 0 ? stats.totalWorkerRunMs / completedRuns : 0,
      };
    }

    return {
      poolSize: this.workers.length,
      readyWorkers: this.workers.filter((slot) => slot.ready).length,
      busyWorkers: this.workers.filter((slot) => slot.inFlight > 0).length,
      queuedRequests: this.dispatchQueue.length,
      pendingRequests: this.pendingRequests.size,
      maxQueueDepth: this.maxQueueDepth,
      measuredOcrWorkerCostMb: readMeasuredOcrWorkerMemoryMb() ?? null,
      messages,
    };
  }

  private messageStats(type: WorkerMessageType): MutableSchedulerMessageStats {
    const existing = this.schedulerStats[type];
    if (existing) return existing;
    const fresh: MutableSchedulerMessageStats = {
      accepted: 0,
      dispatched: 0,
      currentInFlight: 0,
      maxInFlight: 0,
      completed: 0,
      failed: 0,
      timedOut: 0,
      cancelled: 0,
      terminated: 0,
      totalQueueWaitMs: 0,
      maxQueueWaitMs: 0,
      totalWorkerRunMs: 0,
      maxWorkerRunMs: 0,
    };
    this.schedulerStats[type] = fresh;
    return fresh;
  }

  private recordAccepted(type: WorkerMessageType): void {
    this.messageStats(type).accepted++;
  }

  private recordQueuedDepth(): void {
    this.maxQueueDepth = Math.max(this.maxQueueDepth, this.dispatchQueue.length);
  }

  private recordDispatch(type: WorkerMessageType, queueWaitMs: number): void {
    const stats = this.messageStats(type);
    stats.dispatched++;
    stats.currentInFlight++;
    stats.maxInFlight = Math.max(stats.maxInFlight, stats.currentInFlight);
    stats.totalQueueWaitMs += queueWaitMs;
    stats.maxQueueWaitMs = Math.max(stats.maxQueueWaitMs, queueWaitMs);
  }

  private recordInFlightEnded(type: WorkerMessageType): void {
    const stats = this.messageStats(type);
    stats.currentInFlight = Math.max(0, stats.currentInFlight - 1);
  }

  private recordCompletion(
    type: WorkerMessageType,
    dispatchedAt: number,
    outcome: "completed" | "failed" | "timedOut",
  ): void {
    const stats = this.messageStats(type);
    this.recordInFlightEnded(type);
    stats[outcome]++;
    const runMs = Math.max(0, monotonicNow() - dispatchedAt);
    stats.totalWorkerRunMs += runMs;
    stats.maxWorkerRunMs = Math.max(stats.maxWorkerRunMs, runMs);
  }

  private recordTerminated(type: WorkerMessageType): void {
    this.messageStats(type).terminated++;
  }

  private recordCancelled(type: WorkerMessageType): void {
    this.messageStats(type).cancelled++;
  }

  private hasQueuedOcrReadyDemand(): boolean {
    return this.dispatchQueue.some((request) => this.messageNeedsOcrReady(request.message));
  }

  private cleanupAbortHandler(request: QueuedWorkerRequest): void {
    if (request.abortSignal && request.abortHandler) {
      request.abortSignal.removeEventListener("abort", request.abortHandler);
      request.abortHandler = undefined;
    }
  }

  private cleanupPendingAbortHandler(request: {
    abortSignal?: AbortSignal | undefined;
    abortHandler?: (() => void) | undefined;
  }): void {
    if (request.abortSignal && request.abortHandler) {
      request.abortSignal.removeEventListener("abort", request.abortHandler);
      request.abortHandler = undefined;
    }
  }

  private removeQueuedRequest(id: string): QueuedWorkerRequest | null {
    const index = this.dispatchQueue.findIndex((request) => request.id === id);
    if (index === -1) return null;
    const [request] = this.dispatchQueue.splice(index, 1);
    return request ?? null;
  }

  private attachAbortHandler(request: QueuedWorkerRequest): boolean {
    const signal = request.abortSignal;
    if (!signal) return true;
    if (signal.aborted) {
      this.recordCancelled(request.message.type);
      request.reject(abortError());
      return false;
    }

    request.abortHandler = () => {
      const queued = this.removeQueuedRequest(request.id);
      if (!queued) return;
      this.cleanupAbortHandler(queued);
      this.recordCancelled(queued.message.type);
      queued.reject(abortError());
    };
    signal.addEventListener("abort", request.abortHandler, { once: true });
    return true;
  }

  private replaceSlot(slot: WorkerSlot, reason: string): void {
    const index = this.workers.indexOf(slot);
    try {
      slot.worker.terminate();
    } catch {
      /* worker already dead */
    }
    if (index === -1) return;

    if (this.dispatchQueue.length === 0) {
      this.workers.splice(index, 1);
      return;
    }

    const replacement = this.createSlot();
    this.workers[index] = replacement;
    if (this.initialized && this.hasQueuedOcrReadyDemand()) {
      replacement.ready = false;
      void this.enqueueSlotInitialization(replacement).catch((err: unknown) => {
        const failedIndex = this.workers.indexOf(replacement);
        if (failedIndex !== -1) this.workers.splice(failedIndex, 1);
        replacement.worker.terminate();
        this.initialized = this.hasOcrRuntime();
        const error = err instanceof Error ? err : new Error(String(err));
        for (const request of [...this.dispatchQueue]) {
          if (this.workers.length === 0 || request.targetSlot === replacement || (
            !this.workers.some((worker) => worker.ocrReady || !worker.ready) &&
            this.messageNeedsOcrReady(request.message)
          )) {
            this.removeQueuedRequest(request.id);
            this.cleanupAbortHandler(request);
            request.reject(error);
          }
        }
        this.drainDispatchQueue();
        console.warn(
          `[WASMProcessingService] Replacement worker initialization failed after ${reason}:`,
          err,
        );
      });
    }
  }

  private abortPendingRequest(id: string): void {
    const pending = this.pendingRequests.get(id);
    if (!pending) return;
    this.cleanupPendingAbortHandler(pending);
    this.recordInFlightEnded(pending.messageType);
    this.recordCancelled(pending.messageType);
    this.recordTerminated(pending.messageType);
    pending.reject(abortError());
    pending.slot.inFlight = Math.max(0, pending.slot.inFlight - 1);
    this.pendingRequests.delete(id);
    this.replaceSlot(pending.slot, "request abort");
    this.drainDispatchQueue();
  }

  /**
   * Build one worker slot with its message/error handlers wired.
   * Rust+leptess pipeline (wasm32-unknown-emscripten) — each worker
   * dynamically imports IosScreenTimePipeline.wasm and mounts its own
   * eng.traineddata. Workers don't share LepTess state (Tesseract isn't
   * reentrant), which is exactly what we want.
   */
  private createSlot(): WorkerSlot {
    const worker = new Worker(
      new URL(
        "./processing/workers/imageProcessor.worker.emscripten.ts",
        import.meta.url,
      ),
      { type: "module" },
    );
    const slot: WorkerSlot = { worker, inFlight: 0, ocrReady: false, ready: true };
    worker.onmessage = (e: MessageEvent<WorkerResponse>) => this.onWorkerMessage(slot, e);
    worker.onerror = (error) => this.onWorkerError(slot, error);
    worker.onmessageerror = (error) => this.onWorkerMessageError(slot, error);
    return slot;
  }

  private ensurePoolSize(size: number): void {
    const targetSize = Math.max(1, size);
    for (let i = this.workers.length; i < targetSize; i++) {
      this.workers.push(this.createSlot());
    }
  }

  private readyOcrWorkerCount(): number {
    return this.workers.filter((slot) => slot.ocrReady).length;
  }

  private hasOcrRuntime(): boolean {
    return this.readyOcrWorkerCount() > 0;
  }

  private clampPoolTarget(size: number): number {
    return Math.min(poolSize(), Math.max(1, size));
  }

  private messageNeedsOcrReady(message: Omit<WorkerMessage, "id">): boolean {
    if (message.type === "INITIALIZE") return false;
    if (message.type === "EXTRACT_BARS") return false;
    if (message.type === "MEASURE_COLUMN_FILLS") return false;
    if (message.type === "DETECT_GRID") {
      return (message.payload as DetectGridPayload).method !== "line_based";
    }
    if (message.type === "PROCESS_IMAGE") {
      return (message.payload as ProcessImagePayload).gridDetectionMethod !== "line_based";
    }
    return true;
  }

  private countQueuedMessages(type: WorkerMessageType): number {
    return this.dispatchQueue.reduce(
      (count, request) => count + (request.message.type === type ? 1 : 0),
      0,
    );
  }

  private countPendingMessages(type: WorkerMessageType): number {
    let count = 0;
    for (const request of this.pendingRequests.values()) {
      if (request.messageType === type) count++;
    }
    return count;
  }

  private hasTargetedQueuedRequest(slot: WorkerSlot): boolean {
    return this.dispatchQueue.some((request) => request.targetSlot === slot);
  }

  private trimIdleWorkersToBudget(): void {
    const budgetedSize = poolSize();
    this.initializationTarget = Math.min(this.initializationTarget, budgetedSize);
    if (this.workers.length <= budgetedSize) return;

    while (this.workers.length > budgetedSize) {
      let index = -1;
      for (let i = this.workers.length - 1; i >= 0; i--) {
        const slot = this.workers[i]!;
        if (slot.inFlight === 0 && !this.hasTargetedQueuedRequest(slot)) {
          index = i;
          break;
        }
      }
      if (index < 0) break;
      const [slot] = this.workers.splice(index, 1);
      if (!slot) break;
      try {
        slot.worker.terminate();
      } catch {
        /* worker already dead */
      }
    }

    this.initialized = this.hasOcrRuntime();
  }

  private demandSizedPoolTarget(type: WorkerMessageType, requestedMinimum: number): number {
    if (type !== "PROCESS_IMAGE") {
      return this.clampPoolTarget(requestedMinimum);
    }
    const activeDemand =
      this.countPendingMessages("PROCESS_IMAGE") +
      this.countQueuedMessages("PROCESS_IMAGE") +
      1;
    return this.clampPoolTarget(Math.max(requestedMinimum, activeDemand));
  }

  /** PERF-1/PERF-11: fetch eng.traineddata once. On a cold cache this is the
   *  single 4 MB download for the whole pool — without it, every worker
   *  fetches its own copy in parallel before the HTTP cache populates. */
  private fetchTessdata(): Promise<Blob> {
    if (this.tessdataPromise) return this.tessdataPromise;
    const promise = fetch(getTessdataUrl()).then((r) => {
      if (!r.ok) {
        throw new Error(`Failed to fetch eng.traineddata: ${r.status}`);
      }
      return r.blob();
    });
    // On failure clear the cache so the next initialize() retries; workers
    // each fall back to their own fetch if no buffer is supplied.
    this.tessdataPromise = promise.catch((err) => {
      this.tessdataPromise = null;
      throw err;
    });
    return this.tessdataPromise;
  }

  /** PERF-1: `compileStreaming`-compile IosScreenTimePipeline.wasm exactly
   *  once. Streaming compilation is preserved — the module compiles as it
   *  downloads — it just happens once on the main thread instead of N times
   *  across the pool. The resulting `WebAssembly.Module` is shared to every
   *  worker via INITIALIZE; without it each worker fetches+compiles its own
   *  ~5.9 MB copy. Requires nginx to serve `application/wasm`; if the response
   *  isn't that type `compileStreaming` rejects and each worker falls back to
   *  the glue's own streaming path. */
  private compileWasmModule(): Promise<WebAssembly.Module> {
    if (this.wasmModulePromise) return this.wasmModulePromise;
    const promise = WebAssembly.compileStreaming(fetch(getWasmUrl()));
    // On failure clear the cache so the next initialize() retries; workers
    // each fall back to their own streaming compile if no module is supplied.
    this.wasmModulePromise = promise.catch((err) => {
      this.wasmModulePromise = null;
      throw err;
    });
    return this.wasmModulePromise;
  }

  private onWorkerMessage(slot: WorkerSlot, e: MessageEvent<WorkerResponse>): void {
    const data = e.data;

    if (data.type === "PROGRESS") {
      const request = this.pendingRequests.get(data.id);
      if (request?.onProgress) {
        request.onProgress(data.payload);
      }
      return;
    }

    const request = this.pendingRequests.get(data.id);
    if (!request) {
      console.warn(
        "[WASMProcessingService] No pending request for id:", data.id,
      );
      return;
    }

    // Defensive: the slot we matched the message to should be the same
    // one we dispatched to. Log if it isn't — that points at a routing
    // bug.
    if (request.slot !== slot) {
      console.warn(
        "[WASMProcessingService] Response from unexpected worker; routing the result anyway.",
      );
    }

    if (data.type === "ERROR") {
      const message = workerResponseErrorMessage(data);
      console.error("[WASMProcessingService] Worker returned error:", {
        message,
        error: data.error,
        errorName: data.errorName,
        errorDetails: data.errorDetails,
        errorStack: data.errorStack,
      });
      this.recordCompletion(request.messageType, request.dispatchedAt, "failed");
      const error = Object.assign(new Error(message), { abiMismatch: data.abiMismatch === true });
      if (data.abiMismatch) void recoverFromWasmAbiSkew();
      request.reject(error);
    } else {
      if (
        data.type === "PROCESS_IMAGE_COMPLETE" &&
        data.payload.ocrInitialized === true
      ) {
        slot.ocrReady = true;
        this.initialized = true;
        persistMeasuredOcrWorkerMemoryMb(data.payload.wasmHeapBytes);
        this.trimIdleWorkersToBudget();
      }
      this.recordCompletion(request.messageType, request.dispatchedAt, "completed");
      request.resolve(data.payload);
    }

    this.cleanupPendingAbortHandler(request);
    request.slot.inFlight = Math.max(0, request.slot.inFlight - 1);
    this.pendingRequests.delete(data.id);
    this.drainDispatchQueue();
  }

  private rejectPendingForSlot(slot: WorkerSlot, error: Error): void {
    // Reject every request that was routed to this slot. Other slots
    // are unaffected.
    for (const [id, request] of this.pendingRequests.entries()) {
      if (request.slot === slot) {
        this.cleanupPendingAbortHandler(request);
        this.recordCompletion(request.messageType, request.dispatchedAt, "failed");
        request.reject(error);
        this.pendingRequests.delete(id);
      }
    }
  }

  private onWorkerError(slot: WorkerSlot, error: Event | ErrorEvent): void {
    const message = workerCrashErrorMessage(error);
    console.error("[WASMProcessingService] Worker error:", { message, event: error });
    this.rejectPendingForSlot(slot, new Error(message));
    // Replace the dead worker in-place. A corpse left in the pool has
    // inFlight=0, so pickSlot() would PREFER it and every subsequent
    // message would silently 60s-timeout. Terminate it and spawn a
    // fresh slot so the pool keeps its width.
    const wasInitialized = this.initialized;
    this.replaceSlot(slot, "worker error");
    if (!wasInitialized) {
      // If the pool failed during initial fan-out, force the next initialize()
      // to restart instead of handing back the stale rejected promise.
      this.initialized = false;
      this.initializationPromise = null;
    }
    this.drainDispatchQueue();
  }

  private onWorkerMessageError(slot: WorkerSlot, error: MessageEvent): void {
    const message = workerCrashErrorMessage(error);
    console.error("[WASMProcessingService] Worker messageerror:", { message, event: error });
    this.rejectPendingForSlot(slot, new Error(message));
    this.replaceSlot(slot, "worker messageerror");
    this.drainDispatchQueue();
  }

  private generateMessageId(): string {
    return `msg_${++this.messageIdCounter}_${Date.now()}`;
  }

  private collectTransferables(message: WorkerMessage): Transferable[] {
    // Collect transferables for zero-copy transfer:
    //  - ImageData payloads: transfer the backing ArrayBuffer.
    //  - Blob payloads (PERF-2): a Blob is structured-cloned by reference,
    //    NOT copied — nothing to add to the transfer list.
    const transferables: Transferable[] = [];
    const payload = message.payload as Record<string, unknown> | undefined;
    const img = payload?.imageData;
    if (
      typeof ImageData !== "undefined" &&
      img instanceof ImageData &&
      img.data?.buffer
    ) {
      transferables.push(img.data.buffer);
    }
    return transferables;
  }

  private dispatchToSlot<T>(
    slot: WorkerSlot,
    request: QueuedWorkerRequest<T>,
  ): void {
    this.cleanupAbortHandler(request as QueuedWorkerRequest);
    if (!this.workers.includes(slot)) {
      this.recordTerminated(request.message.type);
      request.reject(new Error("Worker slot is no longer active"));
      return;
    }
    if (request.abortSignal?.aborted) {
      this.recordCancelled(request.message.type);
      request.reject(abortError());
      return;
    }
    const timeoutMs = request.message.type === "INITIALIZE" ? 120000 : 60000;
    const dispatchedAt = monotonicNow();
    this.recordDispatch(
      request.message.type,
      Math.max(0, dispatchedAt - request.createdAt),
    );
    const timeout = setTimeout(() => {
      const pending = this.pendingRequests.get(request.id);
      if (pending) {
        this.cleanupPendingAbortHandler(pending);
        this.recordCompletion(pending.messageType, pending.dispatchedAt, "timedOut");
        pending.slot.inFlight = Math.max(0, pending.slot.inFlight - 1);
        this.pendingRequests.delete(request.id);
        this.replaceSlot(pending.slot, "request timeout");
        this.drainDispatchQueue();
      }
      request.reject(
        new Error(
          `Worker message ${request.message.type} timed out after ${timeoutMs / 1000} seconds`,
        ),
      );
    }, timeoutMs);

    const pendingRequest: {
      slot: WorkerSlot;
      messageType: WorkerMessageType;
      dispatchedAt: number;
      resolve: (value: unknown) => void;
      reject: (error: Error) => void;
      onProgress?: ProcessingProgressCallback | undefined;
      abortSignal?: AbortSignal | undefined;
      abortHandler?: (() => void) | undefined;
    } = {
      slot,
      messageType: request.message.type,
      dispatchedAt,
      resolve: (value: unknown) => {
        clearTimeout(timeout);
        request.resolve(value as T);
      },
      reject: (error: Error) => {
        clearTimeout(timeout);
        request.reject(error);
      },
      onProgress: request.onProgress,
      abortSignal: request.abortSignal,
    };
    if (request.abortSignal) {
      pendingRequest.abortHandler = () => this.abortPendingRequest(request.id);
      request.abortSignal.addEventListener("abort", pendingRequest.abortHandler, { once: true });
    }
    this.pendingRequests.set(request.id, pendingRequest);
    slot.inFlight++;
    if (request.abortSignal?.aborted) {
      this.abortPendingRequest(request.id);
      return;
    }

    const fullMessage = { ...request.message, id: request.id } as WorkerMessage;
    slot.worker.postMessage(fullMessage, this.collectTransferables(fullMessage));
  }

  private drainDispatchQueue(): void {
    while (this.dispatchQueue.length > 0) {
      this.rejectStaleTargetRequests();
      const next = this.findDispatchableRequest();
      if (!next) return;
      const [request] = this.dispatchQueue.splice(next.index, 1);
      if (!request) return;
      const slot = next.slot;
      this.dispatchToSlot(slot, request);
    }
  }

  private rejectStaleTargetRequests(): void {
    for (let index = this.dispatchQueue.length - 1; index >= 0; index--) {
      const request = this.dispatchQueue[index]!;
      if (!request.targetSlot || this.workers.includes(request.targetSlot)) continue;
      this.dispatchQueue.splice(index, 1);
      this.cleanupAbortHandler(request);
      this.recordTerminated(request.message.type);
      request.reject(new Error("Worker slot is no longer active"));
    }
  }

  private findDispatchableRequest(): { index: number; slot: WorkerSlot } | null {
    for (let index = 0; index < this.dispatchQueue.length; index++) {
      const request = this.dispatchQueue[index]!;
      if (request.targetSlot) {
        if (
          this.workers.includes(request.targetSlot) &&
          (request.message.type === "INITIALIZE"
            ? request.targetSlot.inFlight === 0
            : this.slotCanRun(request.targetSlot, request.message))
        ) {
          return { index, slot: request.targetSlot };
        }
        continue;
      }
      const slot = this.workers.find((candidate) =>
        this.slotCanRun(candidate, request.message),
      );
      if (slot) return { index, slot };
    }
    return null;
  }

  private slotCanRun(slot: WorkerSlot, message: Omit<WorkerMessage, "id">): boolean {
    if (!slot.ready || slot.inFlight !== 0) return false;
    return !this.messageNeedsOcrReady(message) || slot.ocrReady;
  }

  /** Send a message to a SPECIFIC slot. Used by initialize() to fan
   *  out an INITIALIZE to every worker so they all load tessdata
   *  before the first PROCESS_IMAGE arrives. */
  private async sendMessageTo<T>(
    slot: WorkerSlot,
    message: Omit<WorkerMessage, "id">,
    onProgress?: ProcessingProgressCallback,
  ): Promise<T> {
    const id = this.generateMessageId();

    return new Promise<T>((resolve, reject) => {
      this.recordAccepted(message.type);
      const request: QueuedWorkerRequest<T> = {
        id,
        message,
        createdAt: monotonicNow(),
        targetSlot: slot,
        resolve,
        reject,
        onProgress,
      };
      if (slot.inFlight === 0 && this.workers.includes(slot)) {
        this.dispatchToSlot<T>(slot, request);
      } else {
        this.dispatchQueue.push(request as QueuedWorkerRequest);
        this.recordQueuedDepth();
      }
    });
  }

  /** Send a message to whichever worker is least busy. Used for the
   *  ordinary processImage / detectGrid / extract* calls. */
  private async sendMessage<T>(
    message: Omit<WorkerMessage, "id">,
    onProgress?: ProcessingProgressCallback,
    abortSignal?: AbortSignal,
    minimumPoolSize = 1,
  ): Promise<T> {
    const targetPoolSize = this.demandSizedPoolTarget(message.type, minimumPoolSize);
    this.ensurePoolSize(targetPoolSize);
    if (this.messageNeedsOcrReady(message) && this.readyOcrWorkerCount() < targetPoolSize) {
      void this.initialize(targetPoolSize).catch((err: unknown) => {
        console.warn("[WASMProcessingService] Demand-driven OCR worker initialization failed:", err);
      });
    }
    const id = this.generateMessageId();
    return new Promise<T>((resolve, reject) => {
      this.recordAccepted(message.type);
      const request: QueuedWorkerRequest<T> = {
        id,
        message,
        createdAt: monotonicNow(),
        resolve,
        reject,
        onProgress,
        abortSignal,
      };
      if (!this.attachAbortHandler(request as QueuedWorkerRequest)) return;
      const idleSlot = this.workers.find((slot) => this.slotCanRun(slot, request.message));
      if (idleSlot) {
        this.dispatchToSlot(idleSlot, request);
      } else {
        this.dispatchQueue.push(request as QueuedWorkerRequest);
        this.recordQueuedDepth();
      }
    });
  }

  async initialize(targetPoolSize = poolSize()): Promise<void> {
    const target = this.clampPoolTarget(targetPoolSize);
    const currentTargetBase = this.initializationPromise
      ? this.initializationTarget
      : this.readyOcrWorkerCount();
    this.initializationTarget = Math.max(currentTargetBase, target);
    if (this.readyOcrWorkerCount() >= target) {
      this.initialized = this.hasOcrRuntime();
      return;
    }

    if (!this.initializationPromise) {
      const promiseRef: { current?: Promise<void> } = {};
      const initializationPromise = (async () => {
        try {
          const payload = await this.getInitializationPayload();
          while (this.readyOcrWorkerCount() < this.initializationTarget) {
            // Create only the next slot needed for the sequential OCR warmup.
            // The first initialized worker reports its real WASM heap size; if
            // that tightens the memory budget, trimIdleWorkersToBudget can
            // lower initializationTarget before unused workers are ever made.
            if (
              !this.workers.some((candidate) => !candidate.ocrReady && candidate.inFlight === 0) &&
              this.workers.length < this.initializationTarget
            ) {
              this.ensurePoolSize(this.workers.length + 1);
            }
            const slot = [...this.workers]
              .filter((candidate) => !candidate.ocrReady)
              .sort((a, b) => a.inFlight - b.inFlight)[0];
            if (!slot) break;
            // eslint-disable-next-line no-await-in-loop -- sequential OCR runtime startup prevents multi-heap init spikes
            await this.initializeSlot(slot, payload);
          }
          this.initialized = this.hasOcrRuntime();
          this.drainDispatchQueue();
        } catch (error) {
          if (this.initializationPromise === promiseRef.current) {
            this.initializationPromise = null;
          }
          throw error;
        } finally {
          if (this.initializationPromise === promiseRef.current) {
            this.initializationPromise = null;
          }
        }
      })();

      promiseRef.current = initializationPromise;
      this.initializationPromise = initializationPromise;
    }
    return this.initializationPromise;
  }

  private async getInitializationPayload(): Promise<InitializePayload> {
    // PERF-1/PERF-11: fetch eng.traineddata + compile the pipeline WASM
    // ONCE on the main thread and hand both to every worker. Without this,
    // a cold-cache pool fan-out triggers N parallel 4 MB tessdata
    // downloads and N independent ~5.9 MB WASM compilations. Each shared
    // resource is independently optional — if either fails, proceed with
    // `undefined` for that one and each worker falls back to fetching /
    // compiling its own copy (slower, but still correct). Run the two in
    // parallel since they are independent network/compile work.
    const [tessdata, wasmModule] = await Promise.all([
      this.fetchTessdata().catch((err: unknown) => {
        console.warn(
          "[WASMProcessingService] Shared tessdata fetch failed; workers will fetch individually:",
          err,
        );
        return undefined;
      }),
      this.compileWasmModule().catch((err: unknown) => {
        console.warn(
          "[WASMProcessingService] Shared WASM compile failed; workers will compile individually:",
          err,
        );
        return undefined;
      }),
    ]);

    return {
      ...(tessdata && { tessdata }),
      ...(wasmModule && { wasmModule }),
      // The enabled language packs are recorded in localStorage, which does not
      // exist in a worker — resolve the selection here or every downloaded pack
      // goes unmounted and OCR quietly runs English-only.
      languages: await resolveLanguages(),
    };
  }

  private markSlotReadyIfCurrent(slot: WorkerSlot): void {
    if (this.workers.includes(slot)) {
      slot.ready = true;
      this.drainDispatchQueue();
    }
  }

  private enqueueSlotInitialization(
    slot: WorkerSlot,
    payload?: InitializePayload,
  ): Promise<void> {
    const previous = this.slotInitializationTail.catch(() => {
      /* non-fatal: serialisation only. A slot that failed to initialize must not
         block the NEXT slot from trying; the failure is returned to the caller
         that awaited that initialization. */
      return undefined;
    });
    const next = previous.then(async () => {
      if (!this.workers.includes(slot)) return;
      await this.initializeSlot(slot, payload);
    });
    this.slotInitializationTail = next.catch(() => {
      /* non-fatal: keeps the tail resolvable so one failed slot cannot wedge
         every later initialization. `next` is returned below un-caught, so the
         caller still sees the error. */
      return undefined;
    });
    return next;
  }

  private async initializeSlot(
    slot: WorkerSlot,
    payload?: InitializePayload,
  ): Promise<void> {
    slot.ready = false;
    const initializationPayload = payload ?? await this.getInitializationPayload();
    if (!this.workers.includes(slot)) {
      throw abortError("Worker initialization was superseded");
    }
    // The shared buffer and WebAssembly.Module are structured-cloned (not
    // transferred), so they stay valid for every worker and later respawns.
    const initialized = await this.sendMessageTo<{ initialized: boolean; wasmHeapBytes?: number }>(slot, {
      type: "INITIALIZE",
      payload: initializationPayload,
    });
    if (!this.workers.includes(slot)) {
      throw abortError("Worker initialization was superseded");
    }
    persistMeasuredOcrWorkerMemoryMb(initialized.wasmHeapBytes);
    slot.ocrReady = true;
    this.initialized = true;
    this.trimIdleWorkersToBudget();
    this.markSlotReadyIfCurrent(slot);
  }

  isInitialized(): boolean {
    return this.initialized;
  }

  async processImage(
    imageData: ImageData | Blob,
    config: ProcessingConfig,
    onProgress?: ProcessingProgressCallback,
  ): Promise<{
    hourlyData: HourlyData;
    title: string | null;
    total: string | null;
    gridCoordinates?: GridCoordinates;
    gridDetectionFailed?: boolean;
    gridDetectionError?: string;
    alignmentScore?: number | null;
    gridRegistrationScore?: number | null;
    axisDirection?: "ltr" | "rtl";
    suspectedAllDevices?: boolean;
    axisMaxMinutes?: number | null;
    allDevicesReasons?: string[];
    ocrFailed?: boolean;
    ocrError?: string | null;
  }> {
    if (!this.hasOcrRuntime()) {
      await this.initialize(1);
    }
    return this.runProcessImageMessage(imageData, config, onProgress);
  }

  async processImageWithGridDetection(
    imageData: ImageData | Blob,
    config: ProcessingConfig & { gridDetectionMethod: "ocr_anchored" | "line_based" },
    onProgress?: ProcessingProgressCallback,
  ): Promise<{
    hourlyData: HourlyData;
    title: string | null;
    total: string | null;
    gridCoordinates?: GridCoordinates;
    gridDetectionFailed?: boolean;
    gridDetectionError?: string;
    alignmentScore?: number | null;
    gridRegistrationScore?: number | null;
    axisDirection?: "ltr" | "rtl";
    suspectedAllDevices?: boolean;
    axisMaxMinutes?: number | null;
    allDevicesReasons?: string[];
    ocrFailed?: boolean;
    ocrError?: string | null;
  }> {
    const lineBased = config.gridDetectionMethod === "line_based";
    if (!lineBased && !this.hasOcrRuntime()) {
      await this.initialize(1);
    }
    const result = await this.runProcessImageMessage(imageData, config, onProgress, {
      ...(lineBased && {
        includeWasmModule: true,
        includeTessdata: true,
        minimumPoolSize: 1,
      }),
    });
    return result;
  }

  private async runProcessImageMessage(
    imageData: ImageData | Blob,
    config: ProcessingConfig,
    onProgress?: ProcessingProgressCallback,
    options?: {
      includeWasmModule?: boolean;
      includeTessdata?: boolean;
      minimumPoolSize?: number;
    },
  ): Promise<{
    hourlyData: HourlyData;
    title: string | null;
    total: string | null;
    gridCoordinates?: GridCoordinates;
    gridDetectionFailed?: boolean;
    gridDetectionError?: string;
    alignmentScore?: number | null;
    gridRegistrationScore?: number | null;
    axisDirection?: "ltr" | "rtl";
    suspectedAllDevices?: boolean;
    axisMaxMinutes?: number | null;
    allDevicesReasons?: string[];
    ocrFailed?: boolean;
    ocrError?: string | null;
  }> {
    // The apportionment + grid-registration knobs are global processing
    // preferences, so read them from the settings store HERE — the single
    // main-thread chokepoint for the full pipeline — rather than threading them
    // through every caller's ProcessingConfig. Workers can't read localStorage,
    // so they must travel in the message payload.
    const s = useSettingsStore.getState();
    const wasmModule = options?.includeWasmModule
      ? await this.compileWasmModule().catch((err: unknown) => {
          console.warn(
            "[WASMProcessingService] Shared WASM compile failed for cold line-based processing; worker will compile individually:",
            err,
          );
          return undefined;
        })
      : undefined;
    const tessdata = options?.includeTessdata
      ? await this.fetchTessdata().catch((err: unknown) => {
          console.warn(
            "[WASMProcessingService] Shared tessdata fetch failed for cold line-based processing; worker will fetch individually if OCR is needed:",
            err,
          );
          return undefined;
        })
      : undefined;

    // PERF-2: pass the Blob straight through to the worker — it decodes via
    // OffscreenCanvas off the main thread. No main-thread decode here.
    const result = await this.sendMessage<ProcessImageResultPayload>(
      {
        type: "PROCESS_IMAGE",
        payload: {
          imageData,
          imageType: config.imageType,
          gridCoordinates: config.gridCoordinates,
          gridDetectionMethod: config.gridDetectionMethod,
          ...(wasmModule !== undefined && { wasmModule }),
          ...(tessdata !== undefined && { tessdata }),
          maxShift: config.maxShift,
          languages: selectedLanguages(),
          ...effectiveScoringKnobs(s),
        },
      },
      onProgress,
      config.abortSignal,
      options?.minimumPoolSize,
    );

    // ARC-12: the worker returns a discriminated union. Flatten it back to
    // the public IProcessingService shape — a failed result yields zeroed
    // hourly data plus the `gridDetectionFailed` flag so callers mark the
    // screenshot `failed` rather than `completed`.
    if (result.ok) {
      return {
        hourlyData: result.hourlyData,
        title: result.title,
        total: result.total,
        ...(result.gridCoordinates !== undefined && {
          gridCoordinates: result.gridCoordinates,
        }),
        gridDetectionFailed: false,
        alignmentScore: result.alignmentScore ?? null,
        gridRegistrationScore: result.gridRegistrationScore ?? null,
        axisDirection: result.axisDirection ?? "ltr",
        suspectedAllDevices: result.suspectedAllDevices ?? false,
        axisMaxMinutes: result.axisMaxMinutes ?? null,
        allDevicesReasons: result.allDevicesReasons ?? [],
        ocrFailed: result.ocrFailed ?? false,
        ocrError: result.ocrError ?? null,
      };
    }
    // A negative-length `pipeline_process` (surfaced as "Output buffer too
    // small") means a stale / mismatched cached pipeline bundle — a JS bundle +
    // wasm from different deploys after the C-ABI changed. Self-heal: drop the
    // bad caches + service worker and reload once onto a consistent bundle.
    // Fire-and-forget — the reload supersedes the returned (failed) result, and
    // the guard inside makes it a no-op when offline or already attempted.
    if (result.abiMismatch) {
      void recoverFromWasmAbiSkew();
    }
    return {
      hourlyData: {},
      title: result.title ?? null,
      total: result.total ?? null,
      ...(result.gridCoordinates !== undefined && {
        gridCoordinates: result.gridCoordinates,
      }),
      gridDetectionFailed: true,
      // On a skew, `recoverFromWasmAbiSkew()` reloads onto a consistent bundle —
      // but when it's suppressed (offline, or already spent this session) the
      // rest of the batch surfaces this. Show an actionable hint rather than the
      // raw "Output buffer too small", which describes the symptom, not the cure.
      gridDetectionError: result.abiMismatch
        ? "The app engine was updated — reload the page to finish processing (a stale cached version was detected)."
        : result.error,
      alignmentScore: null,
      gridRegistrationScore: null,
      suspectedAllDevices: result.suspectedAllDevices ?? false,
      axisMaxMinutes: result.axisMaxMinutes ?? null,
      allDevicesReasons: result.allDevicesReasons ?? [],
      ocrFailed: result.ocrFailed ?? false,
      ocrError: result.ocrError ?? (result.ocrFailed ? result.error : null),
    };
  }

  private async ensureInitialized(): Promise<void> {
    if (!this.hasOcrRuntime()) {
      await this.initialize(1);
    }
  }

  async extractTitle(imageData: ImageData | Blob): Promise<string | null> {
    await this.ensureInitialized();
    const result = await this.sendMessage<{ title: string | null }>({
      type: "EXTRACT_TITLE",
      payload: { imageData },
    });
    return result.title;
  }

  async extractTotal(imageData: ImageData | Blob): Promise<string | null> {
    await this.ensureInitialized();
    const result = await this.sendMessage<{ total: string | null }>({
      type: "EXTRACT_TOTAL",
      payload: { imageData },
    });
    return result.total;
  }

  async extractHourlyData(
    imageData: ImageData | Blob,
    gridCoordinates: GridCoordinates,
    imageType: ImageType,
  ): Promise<HourlyData> {
    // Hourly bars from a known grid are geometry/color extraction, not OCR.
    // Keep this legacy public method on the bars-only path so callers cannot
    // accidentally initialize Tesseract just to recompute bar heights.
    return (await this.extractBarsOnly(imageData, gridCoordinates, imageType)).hourlyData;
  }

  async extractBarsOnly(
    imageData: ImageData | Blob,
    gridCoordinates: GridCoordinates,
    imageType: ImageType,
    options?: {
      totalText?: string | null;
      axisDirection?: "ltr" | "rtl";
      axisMaxMinutes?: number | null;
    },
  ): Promise<{
    hourlyData: HourlyData;
    gridCoordinates?: GridCoordinates;
    alignmentScore?: number | null;
    gridRegistrationScore?: number | null;
  }> {
    const s = useSettingsStore.getState();
    return await this.sendMessage<{
      hourlyData: HourlyData;
      gridCoordinates?: GridCoordinates;
      alignmentScore?: number | null;
      gridRegistrationScore?: number | null;
    }>({
      type: "EXTRACT_BARS",
      payload: {
        imageData,
        gridCoordinates,
        imageType,
        totalText: options?.totalText ?? null,
        ...effectiveScoringKnobs(s),
        // Carried from the stored result: nothing on this path re-reads the hour
        // labels, so a mirrored chart needs its direction handed back in — and an
        // hour-scaled "All Devices" chart needs its axis ceiling, or every bar
        // comes back at half the value the first pass measured.
        axisDirection: options?.axisDirection ?? "ltr",
        axisMaxMinutes: options?.axisMaxMinutes ?? null,
      },
    }, undefined, undefined, 1);
  }

  async measureColumnFills(
    imageData: ImageData | Blob,
    gridCoordinates: GridCoordinates,
  ): Promise<(number | null)[]> {
    // Pixel geometry only: no OCR runtime needed, so an uninitialized pool gets
    // the shared compiled module the same way line-based grid detection does.
    const wasmModule = this.initialized
      ? undefined
      : await this.compileWasmModule().catch(() => {
          /* non-fatal: the worker compiles the module itself when none is handed over */
          return undefined;
        });
    const result = await this.sendMessage<{ fills: (number | null)[] }>({
      type: "MEASURE_COLUMN_FILLS",
      payload: {
        imageData,
        gridCoordinates,
        ...(wasmModule !== undefined && { wasmModule }),
      },
    });
    return result.fills;
  }

  async detectGrid(
    imageData: ImageData | Blob,
    imageType: ImageType,
    method?: "ocr_anchored" | "line_based",
  ): Promise<GridCoordinates | null> {
    return (await this.detectGridDetailed(imageData, imageType, method)).gridCoordinates;
  }

  /** Grid detection that also returns the Rust detector's failure reason and weekly
   * flag, so the preprocessing pipeline can surface an actionable rejection (weekly
   * view / landscape / unsupported) instead of a generic "grid detection failed". */
  async detectGridDetailed(
    imageData: ImageData | Blob,
    imageType: ImageType,
    method?: "ocr_anchored" | "line_based",
  ): Promise<GridDetectionDetail> {
    const lineBasedOnly = method === "line_based";
    if (!lineBasedOnly) {
      await this.ensureInitialized();
    }
    const wasmModule = lineBasedOnly && !this.initialized
      ? await this.compileWasmModule().catch((err: unknown) => {
          console.warn(
            "[WASMProcessingService] Shared WASM compile failed for line-based detection; worker will compile individually:",
            err,
          );
          return undefined;
        })
      : undefined;
    const result = await this.sendMessage<{
      gridCoordinates: GridCoordinates | null;
      error?: string;
      isWeekly?: boolean;
    }>({
      type: "DETECT_GRID",
      payload: {
        imageData,
        imageType,
        method,
        ...(wasmModule !== undefined && { wasmModule }),
      },
    }, undefined, undefined, lineBasedOnly && !this.initialized ? 1 : poolSize());
    return {
      gridCoordinates: result.gridCoordinates,
      ...(result.error !== undefined ? { error: result.error } : {}),
      ...(result.isWeekly !== undefined ? { isWeekly: result.isWeekly } : {}),
    };
  }

  terminate(): void {
    for (const slot of this.workers) {
      slot.worker.terminate();
    }
    this.workers = [];
    this.initialized = false;
    this.initializationPromise = null;
    this.initializationTarget = 0;
    for (const request of this.pendingRequests.values()) {
      this.cleanupPendingAbortHandler(request);
      this.recordInFlightEnded(request.messageType);
      this.recordTerminated(request.messageType);
      request.reject(new Error("Worker pool terminated"));
    }
    this.pendingRequests.clear();
    for (const request of this.dispatchQueue) {
      this.cleanupAbortHandler(request);
      this.recordTerminated(request.message.type);
      request.reject(new Error("Worker pool terminated"));
    }
    this.dispatchQueue = [];
  }
}
