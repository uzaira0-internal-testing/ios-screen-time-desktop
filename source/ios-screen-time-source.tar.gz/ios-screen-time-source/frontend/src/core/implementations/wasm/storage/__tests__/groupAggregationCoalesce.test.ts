/**
 * getGroupAggregation coalescing — boot-cost guard.
 *
 * On a home/preprocessing load, both WASMScreenshotService.getGroups and
 * WASMPreprocessingService.getGroups call getGroupAggregation at once. On a
 * large dataset that's two full cursor passes, each deserializing every row.
 * The service shares one in-flight scan so concurrent callers pay for one pass,
 * then clears the handle so the NEXT call re-scans fresh (no stale counts after
 * a write).
 */
import "fake-indexeddb/auto";
import { describe, it, expect, beforeEach } from "bun:test";
import { db } from "../database";
import { IndexedDBStorageService } from "../IndexedDBStorageService";
import type { Screenshot } from "@/types";

const deps = (db as unknown as { _deps: { indexedDB: unknown; IDBKeyRange: unknown } })._deps;
deps.indexedDB = globalThis.indexedDB;
deps.IDBKeyRange = globalThis.IDBKeyRange;

function make(id: number, overrides: Partial<Screenshot> = {}): Screenshot {
  return {
    id,
    group_id: "g1",
    processing_status: "completed",
    annotation_status: "pending",
    extracted_hourly_data: { 0: 30, 1: 30 },
    extracted_title: `Title ${id}`,
    extracted_total: "1h",
    content_hash: `h-${id}`,
    verified_by_user_ids: null,
    ...overrides,
  } as Screenshot;
}

async function reset() {
  await db.delete();
  await db.open();
}

/** Count cursor passes by spying on db.screenshots.each. */
function spyEach() {
  type EachFn = typeof db.screenshots.each;
  const original = db.screenshots.each.bind(db.screenshots);
  let calls = 0;
  const patched: EachFn = (...args: Parameters<EachFn>) => {
    calls++;
    return original(...args);
  };
  db.screenshots.each = patched;
  return {
    get calls() {
      return calls;
    },
    restore() {
      db.screenshots.each = original;
    },
  };
}

describe("getGroupAggregation — in-flight coalescing", () => {
  let storage: IndexedDBStorageService;

  beforeEach(async () => {
    await reset();
    storage = new IndexedDBStorageService();
    await db.screenshots.bulkPut([
      make(1, { group_id: "g1", processing_status: "completed" }),
      make(2, { group_id: "g1", processing_status: "pending" }),
      make(3, { group_id: "g2", processing_status: "failed" }),
    ]);
  });

  it("two concurrent calls share ONE cursor pass and return equal data", async () => {
    const spy = spyEach();
    try {
      const [a, b] = await Promise.all([
        storage.getGroupAggregation(),
        storage.getGroupAggregation(),
      ]);
      expect(spy.calls).toBe(1); // not 2 — the second call rode the first scan
      expect(a).toEqual(b);
      const g1 = a.find((r) => r.id === "g1");
      expect(g1?.count).toBe(2);
      expect(g1?.processing_completed).toBe(1);
      expect(g1?.processing_pending).toBe(1);
    } finally {
      spy.restore();
    }
  });

  it("a call after the previous one settles re-scans fresh (sees new writes)", async () => {
    const first = await storage.getGroupAggregation();
    expect(first.find((r) => r.id === "g1")?.count).toBe(2);

    // Write lands AFTER the in-flight scan cleared — the next call must see it.
    await db.screenshots.put(make(4, { group_id: "g1", processing_status: "completed" }));

    const spy = spyEach();
    try {
      const second = await storage.getGroupAggregation();
      expect(spy.calls).toBe(1); // fresh scan, not a stale shared promise
      expect(second.find((r) => r.id === "g1")?.count).toBe(3);
    } finally {
      spy.restore();
    }
  });
});
