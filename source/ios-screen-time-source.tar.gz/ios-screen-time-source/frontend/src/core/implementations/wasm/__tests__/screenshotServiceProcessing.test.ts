import { afterEach, beforeEach, describe, expect, test } from "bun:test";

import { WASMScreenshotService } from "../WASMScreenshotService";
import type { IProcessingService, IStorageService } from "@/core/interfaces";
import type { GridCoordinates, HourlyData, Screenshot } from "@/types";

const originalLocalStorage = Object.getOwnPropertyDescriptor(globalThis, "localStorage");
const originalNavigator = Object.getOwnPropertyDescriptor(globalThis, "navigator");

function restoreGlobalProperty<T extends keyof typeof globalThis>(
  key: T,
  descriptor: PropertyDescriptor | undefined,
): void {
  if (descriptor) {
    Object.defineProperty(globalThis, key, descriptor);
  } else {
    delete (globalThis as Partial<typeof globalThis>)[key];
  }
}

function makeScreenshot(overrides: Partial<Screenshot> = {}): Screenshot {
  return {
    id: 42,
    image_type: "screen_time",
    processing_status: "pending",
    annotation_status: "pending",
    extracted_hourly_data: null,
    extracted_title: null,
    extracted_total: null,
    verified_by_user_ids: null,
    ...overrides,
  } as Screenshot;
}

function makeResult(gridCoordinates?: GridCoordinates): {
  hourlyData: HourlyData;
  title: string | null;
  total: string | null;
  gridCoordinates?: GridCoordinates;
  gridDetectionFailed: false;
  alignmentScore: number;
  gridRegistrationScore: number;
} {
  return {
    hourlyData: { 0: 12 } as HourlyData,
    title: "Sandbox",
    total: "12m",
    ...(gridCoordinates ? { gridCoordinates } : {}),
    gridDetectionFailed: false,
    alignmentScore: 1,
    gridRegistrationScore: 1,
  };
}

function makeStorage(screenshot: Screenshot, blob = new Blob(["png"], { type: "image/png" })) {
  const updates: Array<Partial<Screenshot>> = [];
  const storage = {
    getScreenshot: async () => screenshot,
    getImageBlob: async () => blob,
    updateScreenshot: async (_id: number, data: Partial<Screenshot>) => {
      updates.push(data);
      Object.assign(screenshot, data);
    },
  } as Partial<IStorageService> as IStorageService;
  return { storage, updates };
}

function makeUploadStorage() {
  const calls = {
    saveScreenshot: 0,
    saveImageBlob: 0,
  };
  const storage = {
    findScreenshotByContentHash: async () => null,
    findNearDuplicate: async () => null,
    saveScreenshot: async () => {
      calls.saveScreenshot++;
      return 100;
    },
    saveImageBlob: async () => {
      calls.saveImageBlob++;
    },
  } as Partial<IStorageService> as IStorageService;
  return { storage, calls };
}

function makeProcessing() {
  const calls = {
    processImageWithGridDetection: 0,
    processImage: 0,
    detectGrid: 0,
    extractBarsOnly: 0,
  };
  const grid: GridCoordinates = {
    upper_left: { x: 1, y: 2 },
    lower_right: { x: 3, y: 4 },
  };
  const processing = {
    processImageWithGridDetection: async () => {
      calls.processImageWithGridDetection++;
      return makeResult(grid);
    },
    processImage: async () => {
      calls.processImage++;
      return makeResult(grid);
    },
    detectGrid: async () => {
      calls.detectGrid++;
      return grid;
    },
    extractBarsOnly: async () => {
      calls.extractBarsOnly++;
      return {
        hourlyData: { 0: 12 } as HourlyData,
        gridCoordinates: grid,
        alignmentScore: 1,
        gridRegistrationScore: 1,
      };
    },
    extractTitle: async () => null,
    extractTotal: async () => null,
    extractHourlyData: async () => ({}),
    initialize: async () => {},
    isInitialized: () => true,
    terminate: () => {},
  } as Partial<IProcessingService> as IProcessingService;
  return { processing, calls };
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

async function waitForHeldWrites(
  releaseBlobWrites: Array<() => void>,
  expected: number,
  attempts = 100,
): Promise<void> {
  if (releaseBlobWrites.length >= expected) return;
  if (attempts <= 0) {
    throw new Error(`Timed out waiting for ${expected} held blob writes`);
  }
  await delay(1);
  return waitForHeldWrites(releaseBlobWrites, expected, attempts - 1);
}

describe("WASMScreenshotService processing scheduling", () => {
  beforeEach(() => {
    const values = new Map<string, string>();
    Object.defineProperty(globalThis, "localStorage", {
      configurable: true,
      value: {
        getItem: (key: string) => values.get(key) ?? null,
        setItem: (key: string, value: string) => values.set(key, value),
        removeItem: (key: string) => values.delete(key),
      },
    });
  });

  afterEach(() => {
    restoreGlobalProperty("localStorage", originalLocalStorage);
    restoreGlobalProperty("navigator", originalNavigator);
  });

  test("default annotation queue includes failed OCR screenshots", async () => {
    const failed = makeScreenshot({ id: 9, processing_status: "failed" });
    const skipped = makeScreenshot({ id: 10, processing_status: "skipped" });
    const storage = {
      getAllScreenshots: async () => [skipped, failed],
    } as Partial<IStorageService> as IStorageService;
    const { processing } = makeProcessing();
    const service = new WASMScreenshotService(storage, processing);

    const next = await service.getNext();

    expect(next?.id).toBe(failed.id);
  });

  test("failed queue items remain available without an automatic OCR retry", async () => {
    const failed = makeScreenshot({ processing_status: "failed" });
    const { storage, updates } = makeStorage(failed);
    const { processing, calls } = makeProcessing();
    const service = new WASMScreenshotService(storage, processing);

    const result = await service.processIfNeeded(failed);

    expect(result).toBe(failed);
    expect(calls.processImageWithGridDetection).toBe(0);
    expect(calls.processImage).toBe(0);
    expect(calls.detectGrid).toBe(0);
    expect(updates).toHaveLength(0);
  });

  test("processing result normalizes a completed row with a current blocker", async () => {
    const screenshot = makeScreenshot({
      processing_status: "completed",
      has_blocking_issues: true,
      processing_issues: [{
        issue_type: "bar_extraction_failed",
        severity: "blocking",
        description: "No usable bars found",
        message: null,
      }],
    });
    const { storage } = makeStorage(screenshot);
    const { processing } = makeProcessing();
    const service = new WASMScreenshotService(storage, processing);

    const result = await service.getProcessingResult(screenshot.id);

    expect(result.processing_status).toBe("failed");
    expect(result.success).toBe(false);
    expect(result.has_blocking_issues).toBe(true);
  });

  test("processing result separates manual skips from Daily Total skips", async () => {
    const screenshot = makeScreenshot({
      processing_status: "skipped",
      extracted_title: "Instagram",
    });
    const { storage } = makeStorage(screenshot);
    const { processing } = makeProcessing();
    const service = new WASMScreenshotService(storage, processing);

    expect((await service.getProcessingResult(screenshot.id)).is_daily_total).toBe(false);
    screenshot.extracted_title = "Daily Total";
    expect((await service.getProcessingResult(screenshot.id)).is_daily_total).toBe(true);
  });

  test("processIfNeeded persists RTL axis direction", async () => {
    const screenshot = makeScreenshot();
    const { storage } = makeStorage(screenshot);
    const { processing } = makeProcessing();
    processing.processImageWithGridDetection = async () => ({ ...makeResult(), axisDirection: "rtl" });
    const updated = await new WASMScreenshotService(storage, processing).processIfNeeded(screenshot);
    expect(updated.processing_metadata?.axis_direction).toBe("rtl");
  });

  test("folder upload preserves original_filepath", async () => {
    const { storage } = makeUploadStorage();
    let saved: Screenshot | undefined;
    storage.saveScreenshot = async (s) => { saved = s; return 100; };
    const { processing } = makeProcessing();
    const file = new File(["png"], "capture.png", { type: "image/png" });
    await new WASMScreenshotService(storage, processing).addScreenshots(file, "screen_time", { originalFilepath: "folder/capture.png" });
    expect(saved?.original_filepath).toBe("folder/capture.png");
  });

  test("processIfNeeded uses the combined grid/OCR path when no grid is trusted", async () => {
    const screenshot = makeScreenshot();
    const { storage } = makeStorage(screenshot);
    const { processing, calls } = makeProcessing();
    const service = new WASMScreenshotService(storage, processing);

    const updated = await service.processIfNeeded(screenshot);

    expect(calls.processImageWithGridDetection).toBe(1);
    expect(calls.detectGrid).toBe(0);
    expect(calls.processImage).toBe(0);
    expect(updated.processing_status).toBe("completed");
    expect(updated.extracted_title).toBe("Sandbox");
  });

  test("reprocessWithMethod uses one combined worker message for auto grid plus OCR", async () => {
    const screenshot = makeScreenshot();
    const { storage } = makeStorage(screenshot);
    const { processing, calls } = makeProcessing();
    const service = new WASMScreenshotService(storage, processing);

    const result = await service.reprocessWithMethod(42, "line_based");

    expect(calls.processImageWithGridDetection).toBe(1);
    expect(calls.detectGrid).toBe(0);
    expect(calls.processImage).toBe(0);
    expect(result.success).toBe(true);
    expect(result.extracted_title).toBe("Sandbox");
  });

  test("manual grid reprocess uses bars-only extraction without title/total OCR", async () => {
    const screenshot = makeScreenshot({
      processing_status: "failed",
      has_blocking_issues: true,
      processing_issues: [{
        issue_type: "grid_detection_failed",
        description: "old failure",
        severity: "blocking",
      }],
      extracted_title: "Existing",
      extracted_total: "12m",
    });
    const { storage } = makeStorage(screenshot);
    const { processing, calls } = makeProcessing();
    const service = new WASMScreenshotService(storage, processing);
    const grid: GridCoordinates = {
      upper_left: { x: 5, y: 6 },
      lower_right: { x: 7, y: 8 },
    };

    const result = await service.reprocess(42, grid);

    expect(calls.extractBarsOnly).toBe(1);
    expect(calls.processImage).toBe(0);
    expect(calls.processImageWithGridDetection).toBe(0);
    expect(calls.detectGrid).toBe(0);
    expect(result.success).toBe(true);
    expect(result.extracted_title).toBe("Existing");
    expect(result.extracted_total).toBe("12m");
    expect(screenshot.processing_status).toBe("completed");
    expect(screenshot.has_blocking_issues).toBe(false);
    expect(screenshot.processing_issues).toEqual([]);
    expect(screenshot.processing_metadata).not.toHaveProperty("ocr_ever_failed");
  });

  test("upload abort during perceptual hashing releases the content hash guard", async () => {
    const controller = new AbortController();
    // The content hash reads the file first; the perceptual hash reads it next.
    let reads = 0;
    class AbortingFile extends File {
      override async arrayBuffer(): Promise<ArrayBuffer> {
        reads++;
        if (reads === 2) controller.abort();
        return super.arrayBuffer();
      }
    }
    const { storage, calls } = makeUploadStorage();
    const { processing } = makeProcessing();
    const service = new WASMScreenshotService(storage, processing);
    const file = new AbortingFile([new Uint8Array([1, 2, 3])], "screen.png", { type: "image/png" });

    await expect(
      service.addScreenshots(file, "screen_time", { abortSignal: controller.signal }),
    ).rejects.toThrow("Perceptual hash aborted");

    expect(calls.saveScreenshot).toBe(0);
    const retry = await service.addScreenshots(file, "screen_time");

    expect(retry.id).toBe(100);
    expect(calls.saveScreenshot).toBe(1);
    expect(calls.saveImageBlob).toBe(1);
  });

  test("upload stores files without bypassing preprocessing stage queues", async () => {
    const { storage, calls: storageCalls } = makeUploadStorage();
    const { processing, calls: processingCalls } = makeProcessing();
    const service = new WASMScreenshotService(storage, processing);

    const created = await service.addScreenshots(
      new File([new Uint8Array([1, 2, 3])], "screen.png", { type: "image/png" }),
      "screen_time",
    );

    expect(created.id).toBe(100);
    expect(storageCalls.saveScreenshot).toBe(1);
    expect(storageCalls.saveImageBlob).toBe(1);
    expect(processingCalls.processImageWithGridDetection).toBe(0);
    expect(processingCalls.processImage).toBe(0);
    expect(processingCalls.detectGrid).toBe(0);
    expect(processingCalls.extractBarsOnly).toBe(0);
  });

  test("concurrent uploads are bounded by the upload import budget", async () => {
    Object.defineProperty(globalThis, "navigator", {
      configurable: true,
      value: { hardwareConcurrency: 2, deviceMemory: 1 },
    });

    let nextId = 100;
    let activeBlobWrites = 0;
    let peakBlobWrites = 0;
    let holdBlobWrites = true;
    const releaseBlobWrites: Array<() => void> = [];
    const storage = {
      findScreenshotByContentHash: async () => null,
      findNearDuplicate: async () => null,
      saveScreenshot: async () => nextId++,
      saveImageBlob: async () => {
        activeBlobWrites++;
        peakBlobWrites = Math.max(peakBlobWrites, activeBlobWrites);
        if (!holdBlobWrites) {
          activeBlobWrites--;
          return;
        }
        await new Promise<void>((resolve) => {
          releaseBlobWrites.push(() => {
            activeBlobWrites--;
            resolve();
          });
        });
      },
    } as Partial<IStorageService> as IStorageService;
    const { processing } = makeProcessing();
    const service = new WASMScreenshotService(storage, processing);

    const uploads = Array.from({ length: 8 }, (_, i) =>
      service.addScreenshots(
        new File([new Uint8Array([i + 1])], `screen-${i}.png`, { type: "image/png" }),
        "screen_time",
      ),
    );

    await waitForHeldWrites(releaseBlobWrites, 4);
    await delay(5);
    expect(peakBlobWrites).toBe(4);
    expect(releaseBlobWrites).toHaveLength(4);
    const duringUpload = service.getUploadSchedulerSnapshot();
    expect(duringUpload.stages.import?.configuredConcurrency).toBe(4);
    expect(duringUpload.stages.import?.accepted).toBe(8);
    expect(duringUpload.stages.import?.dispatched).toBe(4);
    expect(duringUpload.stages.import?.currentInFlight).toBe(4);
    expect(duringUpload.stages.import?.currentQueued).toBe(4);
    expect(duringUpload.stages.import?.maxInFlight).toBe(4);
    // Queue depth excludes the four items already dispatched/in flight.
    expect(duringUpload.stages.import?.maxQueueDepth).toBe(4);

    holdBlobWrites = false;
    while (releaseBlobWrites.length) releaseBlobWrites.shift()?.();
    const results = await Promise.all(uploads);

    expect(results).toHaveLength(8);
    expect(peakBlobWrites).toBe(4);
    expect(activeBlobWrites).toBe(0);
    const afterUpload = service.getUploadSchedulerSnapshot();
    expect(afterUpload.stages.import?.completed).toBe(8);
    expect(afterUpload.stages.import?.currentInFlight).toBe(0);
    expect(afterUpload.stages.import?.currentQueued).toBe(0);
    expect(afterUpload.stages.content_hash?.completed).toBe(8);
    expect(afterUpload.stages.content_hash?.maxInFlight ?? 0).toBeLessThanOrEqual(
      afterUpload.stages.content_hash?.configuredConcurrency ?? 0,
    );
    expect(afterUpload.stages.perceptual_hash?.completed).toBe(8);
    expect(afterUpload.stages.perceptual_hash?.maxInFlight ?? 0).toBeLessThanOrEqual(
      afterUpload.stages.perceptual_hash?.configuredConcurrency ?? 0,
    );
  });
});
