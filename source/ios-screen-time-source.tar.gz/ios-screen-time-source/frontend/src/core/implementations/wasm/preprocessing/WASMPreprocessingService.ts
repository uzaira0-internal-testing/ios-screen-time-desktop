/**
 * WASM-mode preprocessing service.
 *
 * Orchestrates all 4 preprocessing stages client-side:
 *   1. Device detection — dimension-based iOS device identification
 *   2. Cropping — iPad sidebar removal via Canvas
 *   3. PHI detection — Tesseract.js OCR + NER + regex
 *   4. PHI redaction — Canvas-based redbox/blackbox/pixelate
 *
 * Data is stored in IndexedDB via the storage service.
 * Processing is synchronous (no backend) — runStage() returns after completion.
 */

import {
  withScreenshotLock, screenshotLockName, screenshotInputRevision, assertScreenshotInput, ScreenshotInputChangedError,
} from "../storage/screenshotLocks";
import type {
  CropWorkerPoolSchedulerSnapshot,
  IPreprocessingService,
  PreprocessingStage,
  PreprocessingStageSchedulerSnapshot,
  PreprocessingStageSchedulerStats,
  RunStageOptions,
  RunStageResult,
} from "@/core/interfaces/IPreprocessingService";
import type { IStorageService, StorageEstimate } from "@/core/interfaces/IStorageService";
import type {
  Screenshot,
  Group,
  PreprocessingSummary,
  PreprocessingEvent,
  PreprocessingEventLog,
  PreprocessingDetailsResponse,
  BrowserUploadResponse,
  PHIRegionsResponse,
  PHIRegionRect,
} from "@/types";
import { detectDevice } from "./deviceDetection";
import { autoCropRect } from "./cropping";
import { CropWorkerPool } from "./cropWorkerPool";
import {
  emptyHistory,
  seedHistory,
  pushCrop,
  undo as undoHistory,
  redo as redoHistory,
  canUndo,
  canRedo,
  currentEntry,
  type CropHistory,
  type CropHistoryEntry,
  type CropRect,
  type GridSnapshot,
} from "./cropHistory";
import { yieldToMain } from "@/lib/scheduler";
import type { PHIRegion, CropHistoryState } from "@/core/interfaces/IPreprocessingService";
import type { IProcessingService, GridDetectionDetail } from "@/core/interfaces/IProcessingService";
import {
  createObjectURL as cachedCreateObjectURL,
  createRevokingURLCache,
  readImageDimensions,
} from "../storage/opfsBlobStorage";
import {
  browserResourceNumber,
  computeStageImageUrlCacheSize,
} from "@/lib/resourceBudget";
import {
  FALLBACK_PREPROCESS_CORES,
  computeCropDecodeConcurrency,
  computeDeviceCropConcurrency,
  computeDeviceDetectionConcurrency,
  isAbortLike,
  mapBounded,
  metadataIoConcurrency,
  monotonicNow,
  throwIfAborted,
  type MutablePreprocessingStageStats,
  type StageRunAccounting,
} from "./preprocessingStageRuntime";

import { PREPROCESSING_STAGES, StageStatus as SS } from "@/core/generated/constants";
import { effectiveScoringKnobs } from "@/store/settingsStore";
import { enabledLanguageCodes } from "@/core/implementations/wasm/languagePacks/languagePackStore";
import { PHI_STAGES } from "@/core/di/tokens";
import { hasExportableHourlyValues } from "../exportRecord";
import {
  mergeDataQualityEvidence,
  withAxisDirection,
  withDataQualityFlags,
  withOcrFailureHistory,
  type DataQualityFlags,
} from "@/utils/dataQuality";
const STAGES: PreprocessingStage[] = [...PREPROCESSING_STAGES];
const STAGE_RESULT_CACHE_VERSION = 1;

declare const __COMMIT_SHA__: string;
declare const __PIPELINE_WASM_HASH__: string;

// PHI modules are dynamic-imported only when the feature is enabled, so the
// nerWorker chunk and phiDetection helpers stay tree-shakable in WASM-mode
// builds where AppFeatures.phiDetection is false.
type PhiModule = typeof import("./phiDetection");
type PhiRedactModule = typeof import("./phiRedaction");

interface StageProcessOutcome {
  cacheHit: boolean;
  failed?: boolean;
}

export interface WASMPreprocessingOptions {
  /** When false, runStage("phi_*") is a no-op and PHI helpers are never imported. */
  enablePhi: boolean;
}

export {
  computeCropDecodeConcurrency,
  computeDeviceCropConcurrency,
  computeDeviceDetectionConcurrency,
} from "./preprocessingStageRuntime";

// ---------------------------------------------------------------------------
// Helpers to read/write preprocessing metadata on a screenshot
// ---------------------------------------------------------------------------

interface PreprocessingMeta {
  stage_status: Record<string, string>;
  events: PreprocessingEvent[];
  current_events: Record<string, number>;
}

function getPreprocessing(screenshot: Screenshot): PreprocessingMeta {
  const pm = (screenshot.processing_metadata as Record<string, unknown>) ?? {};
  const pp = (pm.preprocessing as PreprocessingMeta) ?? {
    stage_status: {},
    events: [],
    current_events: {},
  };
  return pp;
}

function setPreprocessing(screenshot: Screenshot, pp: PreprocessingMeta): Record<string, unknown> {
  const pm = { ...((screenshot.processing_metadata as Record<string, unknown>) ?? {}) };
  // Write top-level stage result keys to match server shape (PreprocessingDetailsResponse).
  // This ensures components reading preprocessing.device_detection etc. work in both modes.
  const ppOut: Record<string, unknown> = { ...pp };
  for (const stage of STAGES) {
    delete ppOut[stage];
  }
  for (const [stage, eid] of Object.entries(pp.current_events)) {
    const event = pp.events.find((e) => e.event_id === eid);
    if (event) {
      ppOut[stage] = event.result;
    }
  }
  pm.preprocessing = ppOut;
  return pm;
}

/**
 * Read the crop undo/redo history. Stored as a sibling key of `preprocessing`
 * inside `processing_metadata` (NOT inside the PreprocessingMeta blob, so
 * `setPreprocessing`'s per-stage key expansion never touches it).
 */
function readCropHistory(screenshot: Screenshot): CropHistory {
  const pm = (screenshot.processing_metadata as Record<string, unknown>) ?? {};
  const h = pm.crop_history as CropHistory | undefined;
  if (h && Array.isArray(h.entries) && typeof h.index === "number") return h;
  return emptyHistory();
}

/** Merge a crop history into an already-built processing_metadata object. */
function withCropHistory(pm: Record<string, unknown>, h: CropHistory): Record<string, unknown> {
  return { ...pm, crop_history: h };
}

/** Build a grid snapshot from a (possibly partial) grid update, falling back to
 *  the screenshot's current grid coords for any field the update didn't set. */
function gridSnapshotFromUpdate(
  gridUpdate: Record<string, number | null>,
  screenshot: Screenshot,
): GridSnapshot {
  const pick = (key: string, cur: number | null | undefined): number | null =>
    key in gridUpdate ? (gridUpdate[key] ?? null) : (cur ?? null);
  return {
    ulx: pick("grid_upper_left_x", screenshot.grid_upper_left_x),
    uly: pick("grid_upper_left_y", screenshot.grid_upper_left_y),
    lrx: pick("grid_lower_right_x", screenshot.grid_lower_right_x),
    lry: pick("grid_lower_right_y", screenshot.grid_lower_right_y),
  };
}

function addEvent(
  pp: PreprocessingMeta,
  stage: string,
  status: string,
  result: Record<string, unknown>,
): PreprocessingMeta {
  // Derive next ID from existing events to avoid collisions across page reloads
  const maxExisting = pp.events.reduce((max, e) => Math.max(max, e.event_id), 0);
  const eid = maxExisting + 1;
  const previousEventId = pp.current_events[stage] ?? null;
  const event: PreprocessingEvent = {
    event_id: eid,
    stage,
    timestamp: new Date().toISOString(),
    source: "wasm",
    params: {},
    result,
    output_file: null,
    input_file: null,
    supersedes: previousEventId,
  };
  const currentEvents = { ...pp.current_events, [stage]: eid };
  const stageStatus = { ...pp.stage_status, [stage]: status };
  const stageIndex = STAGES.indexOf(stage as PreprocessingStage);
  if (stageIndex >= 0) {
    for (const downstream of STAGES.slice(stageIndex + 1)) {
      if (currentEvents[downstream] != null) {
        delete currentEvents[downstream];
        stageStatus[downstream] = SS.INVALIDATED;
      }
    }
  }
  return {
    ...pp,
    events: [...pp.events, event],
    current_events: currentEvents,
    stage_status: stageStatus,
  };
}

function contentHashFor(screenshot: Screenshot): string | null {
  const hash = (screenshot as { content_hash?: string | null }).content_hash;
  return typeof hash === "string" && hash.length > 0 ? hash : null;
}

function pipelineCacheIdentity(): string {
  const wasmHash =
    typeof __PIPELINE_WASM_HASH__ !== "undefined" && __PIPELINE_WASM_HASH__
      ? __PIPELINE_WASM_HASH__
      : "dev";
  const commitSha =
    typeof __COMMIT_SHA__ !== "undefined" && __COMMIT_SHA__
      ? __COMMIT_SHA__
      : "dev";
  return `wasm:${wasmHash}|commit:${commitSha}`;
}

function currentEventResult(pp: PreprocessingMeta, stage: string): Record<string, unknown> | null {
  const eventId = pp.current_events[stage];
  if (!eventId) return null;
  return pp.events.find((e) => e.event_id === eventId)?.result ?? null;
}

function deviceDetectionCacheKey(screenshot: Screenshot): string | null {
  const contentHash = contentHashFor(screenshot);
  if (!contentHash) return null;
  return JSON.stringify({
    v: STAGE_RESULT_CACHE_VERSION,
    stage: "device_detection",
    content_hash: contentHash,
  });
}

function croppingCacheKey(screenshot: Screenshot, pp: PreprocessingMeta): string | null {
  const contentHash = contentHashFor(screenshot);
  if (!contentHash) return null;
  const detection = currentEventResult(pp, "device_detection") ?? {};
  return JSON.stringify({
    v: STAGE_RESULT_CACHE_VERSION,
    stage: "cropping",
    content_hash: contentHash,
    detection: {
      dimensions: detection.dimensions ?? null,
      device_category: detection.device_category ?? null,
      device_model: detection.device_model ?? null,
      needs_cropping: detection.needs_cropping ?? null,
      orientation: detection.orientation ?? null,
    },
  });
}

function ocrInputCacheKey(
  screenshot: Screenshot,
  pp: PreprocessingMeta,
  opts: {
    imageType: string;
    ocrMethod: "ocr_anchored" | "line_based";
    maxShift: number;
    skipDailyTotals: boolean;
  },
): string | null {
  const contentHash = contentHashFor(screenshot);
  if (!contentHash) return null;
  const crop = currentEventResult(pp, "cropping") ?? {};
  const cropFingerprint = {
    crop_region: crop.crop_region ?? null,
    cropped_dimensions: crop.cropped_dimensions ?? null,
    manual: crop.manual === true,
    original_dimensions: crop.original_dimensions ?? null,
    was_cropped: crop.was_cropped === true,
  };
  return JSON.stringify({
    v: STAGE_RESULT_CACHE_VERSION,
    stage: "ocr",
    pipeline: pipelineCacheIdentity(),
    content_hash: contentHash,
    image_type: opts.imageType,
    method: opts.ocrMethod,
    max_shift: opts.maxShift,
    skip_daily_totals: opts.skipDailyTotals,
    crop: cropFingerprint,
    // The apportionment / grid-registration knobs change the 24 values this
    // stage produces, so they are cache INPUTS. Without them, a user who
    // adjusts the Apportionment Cap in Settings and re-runs OCR gets a cache
    // hit and their change appears to do nothing at all. Same for the enabled
    // OCR languages: they decide whether a localized title/total is readable.
    scoring: effectiveScoringKnobs(),
    languages: enabledLanguageCodes(),
  });
}

function cacheStamp(
  result: Record<string, unknown>,
  cacheKey: string | null,
  screenshot: Screenshot,
): Record<string, unknown> {
  if (!cacheKey) return result;
  return {
    ...result,
    cache_version: STAGE_RESULT_CACHE_VERSION,
    cache_key: cacheKey,
    content_hash: contentHashFor(screenshot),
  };
}

function findReusableCompletedEvent(
  pp: PreprocessingMeta,
  stage: string,
  cacheKey: string | null,
): PreprocessingEvent | null {
  if (!cacheKey) return null;
  for (let i = pp.events.length - 1; i >= 0; i--) {
    const event = pp.events[i]!;
    if (event.stage !== stage) continue;
    if (event.result?.cache_version !== STAGE_RESULT_CACHE_VERSION) continue;
    if (event.result?.cache_key !== cacheKey) continue;
    if (event.result?.processing_status === "failed") continue;
    if (event.result?.has_blocking_issues === true) continue;
    return event;
  }
  return null;
}

function replayCachedResult(event: PreprocessingEvent): Record<string, unknown> {
  return {
    ...event.result,
    cache_hit: true,
    cache_source_event_id: event.event_id,
  };
}

function invalidateReusableStageResults(
  pp: PreprocessingMeta,
  stages: readonly PreprocessingStage[],
  invalidatedAt: string,
): { pp: PreprocessingMeta; changed: boolean } {
  const resetStages = new Set<string>(stages);
  let changed = false;
  const events = pp.events.map((event) => {
    if (!resetStages.has(event.stage)) return event;
    if (!event.result || (!("cache_key" in event.result) && !("cache_version" in event.result))) {
      return event;
    }
    changed = true;
    const {
      cache_key: _cacheKey,
      cache_version: _cacheVersion,
      ...resultWithoutReusableCache
    } = event.result;
    return {
      ...event,
      result: {
        ...resultWithoutReusableCache,
        cache_invalidated_at: invalidatedAt,
        cache_invalidated_reason: "stage_reset",
      },
    };
  });
  return changed ? { pp: { ...pp, events }, changed } : { pp, changed };
}

/**
 * Normalize legacy events stored with `created_at` (pre-typed era) to the
 * current `PreprocessingEvent` shape.  Handles existing IndexedDB data without
 * requiring a Dexie schema migration since events are stored as an opaque JSON
 * blob inside `processing_metadata`.
 */
function normalizeEvents(events: PreprocessingEvent[]): PreprocessingEvent[] {
  return events.map((e) => {
    if (!e.timestamp && (e as Record<string, unknown>).created_at) {
      const { created_at, status: _status, ...rest } = e as Record<string, unknown>;
      return {
        ...rest,
        timestamp: created_at as string,
        source: (rest.source as string) ?? "wasm",
        params: (rest.params as Record<string, unknown>) ?? {},
        output_file: (rest.output_file as string | null) ?? null,
        input_file: (rest.input_file as string | null) ?? null,
        supersedes: (rest.supersedes as number | null) ?? null,
      } as PreprocessingEvent;
    }
    return e;
  });
}

/**
 * Strip PHI cleartext from the current phi_detection event. Called once
 * redaction completes — after a screenshot is redacted, the raw OCR text and
 * the verbatim PHI strings (SSNs, emails, MRNs) must not survive in IndexedDB
 * metadata. Region geometry is preserved so boxes can still be re-rendered;
 * only the sensitive `ocr_text` and per-region `text` are destroyed.
 */
function scrubPhiDetectionEvent(pp: PreprocessingMeta): PreprocessingMeta {
  const detectionId = pp.current_events.phi_detection;
  if (!detectionId) return pp;
  return {
    ...pp,
    events: pp.events.map((e) => {
      if (e.event_id !== detectionId) return e;
      const result: Record<string, unknown> = { ...e.result };
      delete result.ocr_text;
      if (Array.isArray(result.phi_entities)) {
        result.phi_entities = (result.phi_entities as Record<string, unknown>[]).map((r) =>
          "text" in r ? { ...r, text: "[redacted]" } : r,
        );
      }
      return { ...e, result };
    }),
  };
}

/** True once a completed phi_redaction event with `redacted: true` exists. */
function isRedacted(pp: PreprocessingMeta): boolean {
  const redactionId = pp.current_events.phi_redaction;
  if (!redactionId) return false;
  const event = pp.events.find((e) => e.event_id === redactionId);
  return event?.result?.redacted === true;
}

// ---------------------------------------------------------------------------
// Service implementation
// ---------------------------------------------------------------------------

export class WASMPreprocessingService implements IPreprocessingService {
  private storage: IStorageService;
  private processing: IProcessingService;
  private readonly enablePhi: boolean;
  /** The stage list this service treats as active — drives prereqs, resets, invalidation. */
  private readonly activeStages: readonly PreprocessingStage[];
  private phiModulePromise: Promise<PhiModule> | null = null;
  private phiRedactPromise: Promise<PhiRedactModule> | null = null;
  private stageSchedulerStats: Partial<Record<PreprocessingStage, MutablePreprocessingStageStats>> = {};
  private cropWorkerPool: CropWorkerPool | null = null;
  private lastCropWorkerPoolSnapshot: CropWorkerPoolSchedulerSnapshot | null = null;
  private ocrWarmupPromise: Promise<void> | null = null;

  private getCropWorkerPool(): CropWorkerPool {
    if (!this.cropWorkerPool) {
      this.lastCropWorkerPoolSnapshot = null;
      this.cropWorkerPool = new CropWorkerPool(
        computeCropDecodeConcurrency(
          browserResourceNumber("hardwareConcurrency") ?? FALLBACK_PREPROCESS_CORES,
          browserResourceNumber("deviceMemory"),
        ),
      );
    }
    return this.cropWorkerPool;
  }

  private warmOneOcrWorker(): Promise<void> {
    if (this.processing.isInitialized()) return Promise.resolve();
    if (!this.ocrWarmupPromise) {
      this.ocrWarmupPromise = this.processing.initialize(1)
        .catch((error: unknown) => {
          console.warn("[WASM] OCR warmup failed; OCR stage will retry on demand:", error);
        })
        .finally(() => {
          this.ocrWarmupPromise = null;
        });
    }
    return this.ocrWarmupPromise;
  }

  constructor(
    storage: IStorageService,
    processing: IProcessingService,
    options: WASMPreprocessingOptions = { enablePhi: true },
  ) {
    this.storage = storage;
    this.processing = processing;
    this.enablePhi = options.enablePhi;
    this.activeStages = options.enablePhi
      ? STAGES
      : STAGES.filter((s) => !PHI_STAGES.includes(s));
  }

  private loadPhiModule(): Promise<PhiModule> {
    if (!this.phiModulePromise) {
      this.phiModulePromise = import("./phiDetection");
    }
    return this.phiModulePromise;
  }

  private loadPhiRedactModule(): Promise<PhiRedactModule> {
    if (!this.phiRedactPromise) {
      this.phiRedactPromise = import("./phiRedaction");
    }
    return this.phiRedactPromise;
  }

  /** Prereq stages for a given target — the active stages that run before it. */
  private prereqsFor(stage: PreprocessingStage): readonly PreprocessingStage[] {
    const idx = this.activeStages.indexOf(stage);
    if (idx < 0) return [];
    return this.activeStages.slice(0, idx);
  }

  /** Downstream stages of a given target — the active stages from it onward. */
  private downstreamFrom(stage: PreprocessingStage): readonly PreprocessingStage[] {
    const idx = this.activeStages.indexOf(stage);
    if (idx < 0) return [];
    return this.activeStages.slice(idx);
  }

  /** Stages after a completed stage whose cached outputs depend on that stage's bytes/metadata. */
  private downstreamAfter(stage: PreprocessingStage): readonly PreprocessingStage[] {
    const idx = this.activeStages.indexOf(stage);
    if (idx < 0) return [];
    return this.activeStages.slice(idx + 1);
  }

  private invalidateStagesAfter(pp: PreprocessingMeta, stage: PreprocessingStage): PreprocessingMeta {
    const newStageStatus = { ...pp.stage_status };
    for (const ds of this.downstreamAfter(stage)) {
      const current = newStageStatus[ds] ?? SS.PENDING;
      if (current !== SS.PENDING) {
        newStageStatus[ds] = SS.INVALIDATED;
      }
    }
    return { ...pp, stage_status: newStageStatus };
  }

  async getStorageEstimate(): Promise<StorageEstimate | null> {
    return this.storage.getStorageEstimate();
  }

  getStageSchedulerSnapshot(): PreprocessingStageSchedulerSnapshot {
    const stages: Record<string, PreprocessingStageSchedulerStats> = {};
    for (const [stage, stats] of Object.entries(this.stageSchedulerStats)) {
      const measuredItems =
        stats.totalCompletedItems + stats.totalFailedItems + stats.totalAbortedItems;
      stages[stage] = {
        ...stats,
        averageRunMs: stats.runs > 0 ? stats.totalRunMs / stats.runs : 0,
        averageItemMs: measuredItems > 0 ? stats.totalItemMs / measuredItems : 0,
      };
    }
    return { stages, cropWorkerPool: this.getCropWorkerPoolSnapshot() };
  }

  private getCropWorkerPoolSnapshot(): CropWorkerPoolSchedulerSnapshot {
    if (this.cropWorkerPool) {
      return this.cropWorkerPool.getSnapshot();
    }
    if (this.lastCropWorkerPoolSnapshot) {
      return this.lastCropWorkerPoolSnapshot;
    }
    return {
      maxWorkers: computeCropDecodeConcurrency(
        browserResourceNumber("hardwareConcurrency") ?? FALLBACK_PREPROCESS_CORES,
        browserResourceNumber("deviceMemory"),
      ),
      poolSize: 0,
      busyWorkers: 0,
      queuedRequests: 0,
      accepted: 0,
      dispatched: 0,
      completed: 0,
      failed: 0,
      cancelled: 0,
      terminated: 0,
      fallbackRuns: 0,
      maxQueueDepth: 0,
      maxBusyWorkers: 0,
    };
  }

  private stageStats(stage: PreprocessingStage): MutablePreprocessingStageStats {
    const existing = this.stageSchedulerStats[stage];
    if (existing) return existing;
    const fresh: MutablePreprocessingStageStats = {
      runs: 0,
      totalQueuedItems: 0,
      totalCompletedItems: 0,
      totalFailedItems: 0,
      totalAbortedItems: 0,
      totalCacheHits: 0,
      totalRunMs: 0,
      maxRunMs: 0,
      totalItemMs: 0,
      maxItemMs: 0,
      maxInFlightItems: 0,
      lastQueuedItems: 0,
      lastCompletedItems: 0,
      lastFailedItems: 0,
      lastAbortedItems: 0,
      lastCacheHits: 0,
      lastRunMs: 0,
      lastConfiguredConcurrency: 0,
      lastMaxInFlightItems: 0,
    };
    this.stageSchedulerStats[stage] = fresh;
    return fresh;
  }

  private recordStageRun(
    stage: PreprocessingStage,
    run: StageRunAccounting,
    runMs: number,
  ): void {
    const stats = this.stageStats(stage);
    stats.runs++;
    stats.totalQueuedItems += run.queuedItems;
    stats.totalCompletedItems += run.completedItems;
    stats.totalFailedItems += run.failedItems;
    stats.totalAbortedItems += run.abortedItems;
    stats.totalCacheHits += run.cacheHits;
    stats.totalRunMs += runMs;
    stats.maxRunMs = Math.max(stats.maxRunMs, runMs);
    stats.totalItemMs += run.totalItemMs;
    stats.maxItemMs = Math.max(stats.maxItemMs, run.maxItemMs);
    stats.maxInFlightItems = Math.max(stats.maxInFlightItems, run.maxInFlightItems);
    stats.lastQueuedItems = run.queuedItems;
    stats.lastCompletedItems = run.completedItems;
    stats.lastFailedItems = run.failedItems;
    stats.lastAbortedItems = run.abortedItems;
    stats.lastCacheHits = run.cacheHits;
    stats.lastRunMs = runMs;
    stats.lastConfiguredConcurrency = run.configuredConcurrency;
    stats.lastMaxInFlightItems = run.maxInFlightItems;
  }

  async reconcileStuckStages(): Promise<number> {
    if (typeof navigator === "undefined" || !navigator.locks) return 0;
    const locks = navigator.locks;
    const screenshots = await this.storage.getAllScreenshots();
    // Each screenshot's stage_status reconciliation is independent, but keep
    // IDB request creation bounded so a large library does not queue thousands
    // of structured-clone writes at once.
    const changed = await mapBounded(screenshots, metadataIoConcurrency(), (candidate) =>
      locks.request(screenshotLockName(candidate.id), { ifAvailable: true }, async (lock) => {
      if (!lock) return false;
      const s = await this.storage.getScreenshot(candidate.id);
      if (!s) return false;
      const pp = getPreprocessing(s);
      let didChange = false;
      const newStageStatus = { ...pp.stage_status };
      for (const stage of STAGES) {
        if (newStageStatus[stage] === "running") {
          newStageStatus[stage] = SS.PENDING;
          didChange = true;
        }
      }
      if (!didChange) return false;
      const updatedPp: PreprocessingMeta = { ...pp, stage_status: newStageStatus };
      await this.storage.updateScreenshot(s.id, {
        processing_metadata: setPreprocessing(s, updatedPp),
      });
      return true;
    }));
    return changed.filter(Boolean).length;
  }

  forceStop(): void {
    // Terminate the processing worker (kills any in-flight OCR/grid detection).
    // It will be lazily recreated on the next processImage/detectGrid call.
    this.processing.terminate();
    if (this.cropWorkerPool) {
      this.cropWorkerPool.terminate();
      this.lastCropWorkerPoolSnapshot = this.cropWorkerPool.getSnapshot();
      this.cropWorkerPool = null;
    }
    // Also terminate the PHI NER worker — but only if it was ever loaded.
    // (OCR runs through the shared Emscripten pipeline, no separate worker.)
    if (this.phiModulePromise) {
      this.phiModulePromise
        .then((m) => {
          m.terminateNERWorker();
        })
        .catch(() => { /* module never finished loading; nothing to terminate */ });
    }
  }

  /**
   * Mark a stage `running` on the screenshot BEFORE its multi-step blob writes
   * begin. If the tab crashes mid-stage, `reconcileStuckStages` resets the
   * `running` row back to `pending` so the stage is re-run rather than left in
   * a half-written state (a redacted blob with metadata still claiming
   * `pending`). Returns the freshly-read screenshot so callers continue from
   * current on-disk state.
   */
  private async markStageRunning(
    screenshotId: number,
    stage: string,
  ): Promise<Screenshot | null> {
    const screenshot = await this.storage.getScreenshot(screenshotId);
    if (!screenshot) return null;
    const pp = getPreprocessing(screenshot);
    const runningPp: PreprocessingMeta = {
      ...pp,
      stage_status: { ...pp.stage_status, [stage]: "running" },
    };
    await this.storage.updateScreenshot(screenshotId, {
      processing_metadata: setPreprocessing(screenshot, runningPp),
    });
    // Return the screenshot with the running status applied so the caller's
    // subsequent re-read sees a consistent base.
    return { ...screenshot, processing_metadata: setPreprocessing(screenshot, runningPp) };
  }

  /**
   * Cancellation is different from a tab crash: the caller is still alive, so
   * clear the `running` sentinel immediately instead of waiting for the next
   * runStage() reconciliation pass.
   */
  private async resetAbortedRunningStage(
    screenshot: Screenshot,
    stage: PreprocessingStage,
  ): Promise<void> {
    const screenshotId = screenshot.id;
    const fresh = await this.storage.getScreenshot(screenshotId);
    if (!fresh) return;
    const pp = getPreprocessing(fresh);
    if (pp.stage_status[stage] !== SS.RUNNING) return;
    const updatedPp: PreprocessingMeta = {
      ...pp,
      stage_status: { ...pp.stage_status, [stage]: SS.PENDING },
    };
    await this.storage.updateScreenshot(screenshotId, {
      processing_metadata: setPreprocessing(fresh, updatedPp),
    });
  }

  private async handleStageAbort(
    screenshot: Screenshot,
    stage: PreprocessingStage,
  ): Promise<void> {
    try {
      await this.resetAbortedRunningStage(screenshot, stage);
    } catch (error) {
      console.warn(`[WASM] failed to reset aborted ${stage} stage for screenshot ${screenshot.id}:`, error);
    }
  }

  /** Record a failed event and return when the image blob is missing from storage. */
  private async recordMissingBlob(screenshot: Screenshot, stage: PreprocessingStage): Promise<void> {
    const pp = getPreprocessing(screenshot);
    const updated = addEvent(pp, stage, SS.FAILED, {
      processing_status: "failed",
      error: "Image file missing from storage. Re-upload this screenshot.",
      ...(stage === "ocr" ? { ocr_failed: false, ocr_error: null } : {}),
    });
    await this.storage.updateScreenshot(screenshot.id, {
      processing_metadata: setPreprocessing(screenshot, updated),
      processing_status: "failed",
      processing_issues: [{
        issue_type: "image_blob_missing",
        description: "Image file missing from storage. Re-upload this screenshot.",
        severity: "blocking",
      }],
      has_blocking_issues: true,
      processed_at: new Date().toISOString(),
    });
  }

  async getGroups(): Promise<Group[]> {
    // Single shared full-table aggregation pass — identical source of truth as
    // WASMScreenshotService.getGroups (see IStorageService.getGroupAggregation).
    const rows = await this.storage.getGroupAggregation();
    return rows.map((data) => ({
      id: data.id,
      name: data.id === "ungrouped" ? "Ungrouped" : data.id,
      image_type: data.image_type as "battery" | "screen_time",
      created_at: data.created_at,
      screenshot_count: data.count,
      processing_pending: data.processing_pending,
      processing_completed: data.processing_completed,
      processing_failed: data.processing_failed,
      processing_skipped: data.processing_skipped,
      processing_deleted: data.processing_deleted,
      totals_mismatch_count: data.totals_mismatch,
    })) as Group[];
  }

  async getScreenshots(params: {
    group_id: string;
    page_size?: number;
    sort_by?: string;
    sort_order?: string;
  }): Promise<{ items: Screenshot[]; total: number }> {
    const all = await this.storage.getAllScreenshots({ group_id: params.group_id });
    // Sort by id ascending by default
    const sorted = [...all].sort((a, b) => (a.id) - (b.id));
    return { items: sorted, total: sorted.length };
  }

  async getSummary(groupId: string): Promise<PreprocessingSummary> {
    const screenshots = await this.storage.getAllScreenshots({ group_id: groupId });
    const stageSummaries: Record<string, Record<string, number>> = {
      device_detection: { completed: 0, pending: 0, invalidated: 0, running: 0, failed: 0, exceptions: 0 },
      cropping: { completed: 0, pending: 0, invalidated: 0, running: 0, failed: 0, exceptions: 0 },
      phi_detection: { completed: 0, pending: 0, invalidated: 0, running: 0, failed: 0, exceptions: 0 },
      phi_redaction: { completed: 0, pending: 0, invalidated: 0, running: 0, failed: 0, exceptions: 0 },
      ocr: { completed: 0, pending: 0, invalidated: 0, running: 0, failed: 0, exceptions: 0 },
    };

    for (const s of screenshots) {
      const pp = getPreprocessing(s);
      for (const stage of STAGES) {
        const status = pp.stage_status[stage] ?? SS.PENDING;
        const stageSummary = stageSummaries[stage]!;
        if (status in stageSummary) {
          stageSummary[status] = (stageSummary[status] ?? 0) + 1;
        } else {
          stageSummary.pending = (stageSummary.pending ?? 0) + 1;
        }
      }
    }

    const summary = { total: screenshots.length, ...stageSummaries };
    return summary as PreprocessingSummary;
  }

  async runStage(stage: PreprocessingStage, options: RunStageOptions): Promise<RunStageResult> {
    // PHI stages are inert when the feature is disabled. The UI shouldn't
    // surface them, but if a deep-link or stale call hits us, no-op cleanly.
    if (!this.enablePhi && (PHI_STAGES).includes(stage)) {
      return {
        queued_count: 0,
        message: `${stage.replace(/_/g, " ")} is disabled in this mode`,
      };
    }

    // Always reconcile stuck 'running' rows before we start. The store
    // also calls reconcileStuckStages() on first loadSummary, but that's
    // only once-per-session — if a user starts a run, navigates away
    // mid-batch, comes back without a full reload, and clicks Run again,
    // any rows we never finished writing on the way out would still be
    // 'running' and therefore not eligible. Reconciling at runStage entry
    // makes a re-run idempotent.
    try {
      await this.reconcileStuckStages();
    } catch (e) {
      console.warn("[WASM] reconcileStuckStages on runStage entry failed:", e);
    }

    // Get eligible screenshots
    let screenshots: Screenshot[];
    if (options.screenshot_ids?.length) {
      const all = await mapBounded(
        options.screenshot_ids,
        metadataIoConcurrency(),
        (id) => this.storage.getScreenshot(id),
      );
      screenshots = all.filter((s): s is Screenshot => s !== null);
    } else if (options.group_id) {
      screenshots = await this.storage.getAllScreenshots({ group_id: options.group_id });
    } else {
      return { queued_count: 0, message: "No group or screenshot IDs specified" };
    }

    // Filter to eligible: status pending/invalidated/failed, prereqs met.
    // Prereqs come from the active stage list — PHI stages stay PENDING
    // forever when disabled and would otherwise wedge OCR.
    const prereqs = this.prereqsFor(stage);

    const eligible = screenshots.filter((s) => {
      const pp = getPreprocessing(s);
      const status = pp.stage_status[stage] ?? SS.PENDING;
      if (
        status !== SS.PENDING &&
        status !== SS.INVALIDATED &&
        status !== SS.FAILED &&
        status !== SS.CANCELLED
      ) return false;
      // Check prereqs
      return prereqs.every((p) => (
        pp.stage_status[p] === SS.COMPLETED || pp.stage_status[p] === SS.SKIPPED
      ));
    });

    if (eligible.length === 0) {
      return { queued_count: 0, message: `No eligible screenshots for ${stage.replace(/_/g, " ")}` };
    }

    let completed = 0;
    let failed = 0;
    options.onProgress?.(0, eligible.length);

    // Shared failure recorder. Both the unbounded and serial paths use
    // it. Wrapping the IDB write in its own try/catch is load-bearing:
    // if updateScreenshot itself rejects (quota, version error), the
    // unbounded path's post-allSettled walk would otherwise blow up
    // partway through and leave subsequent rows with no recorded
    // failure event.
    const recordFailure = async (screenshot: Screenshot, reason: unknown): Promise<void> => {
      failed++;
      console.error(`[WASM] ${stage} failed for screenshot ${screenshot.id}:`, reason);
      if (reason instanceof ScreenshotInputChangedError) return;
      try {
        const fresh = await this.storage.getScreenshot(screenshot.id);
        if (!fresh) return;
        const pp = getPreprocessing(fresh);
        const updated = addEvent(pp, stage, SS.FAILED, {
          error: reason instanceof Error ? reason.message : String(reason),
          ...(stage === "ocr" ? { ocr_failed: false, ocr_error: null } : {}),
        });
        await this.storage.updateScreenshot(screenshot.id, {
          processing_status: "failed",
          processing_metadata: setPreprocessing(fresh, updated),
          processing_issues: [{
            issue_type: `${stage}_failed`,
            description: reason instanceof Error ? reason.message : String(reason),
            severity: "blocking",
          }],
          has_blocking_issues: true,
          processed_at: new Date().toISOString(),
        });
      } catch (writeErr) {
        console.error(`[WASM] failed to record failure event for screenshot ${screenshot.id}:`, writeErr);
      }
    };

    // device_detection is the cheapest stage: header dimensions plus metadata /
    // original-blob writes. Cropping is also cheap for the iPhone no-crop
    // majority, but its iPad path may decode/canvas a region, so crop items use
    // a lower RAM-aware budget and the actual decode work is bounded again by
    // `cropDecodeGate`. OCR scales with the processing-worker pool size (one
    // PROCESS_IMAGE per LepTess worker); PHI stages serialize because they share
    // a single Tesseract/NER worker per tab.
    const cores = browserResourceNumber("hardwareConcurrency") ?? FALLBACK_PREPROCESS_CORES;
    const deviceMemoryGb = browserResourceNumber("deviceMemory");
    const stageItemConcurrency = stage === "device_detection"
      ? computeDeviceDetectionConcurrency(cores, deviceMemoryGb)
      : stage === "cropping"
        ? computeDeviceCropConcurrency(cores, deviceMemoryGb)
        : 1;
    const isBoundedConcurrency =
      stage === "device_detection" || stage === "cropping";
    const ocrConcurrency = stage === "ocr" ? this.processing.getPoolSize?.() ?? 1 : 0;
    const configuredConcurrency = isBoundedConcurrency
      ? Math.min(stageItemConcurrency, eligible.length)
      : ocrConcurrency > 1
        ? Math.min(ocrConcurrency, eligible.length)
        : 1;
    if (stage === "cropping" && eligible.length > 0) {
      void this.warmOneOcrWorker();
    }
    const ocrWasColdAtRunStart = stage === "ocr" && !this.processing.isInitialized();
    if (ocrWasColdAtRunStart) {
      await this.warmOneOcrWorker();
      throwIfAborted(options.abortSignal);
    }
    const runAccounting: StageRunAccounting = {
      queuedItems: eligible.length,
      configuredConcurrency,
      completedItems: 0,
      failedItems: 0,
      abortedItems: 0,
      cacheHits: 0,
      currentInFlightItems: 0,
      maxInFlightItems: 0,
      totalItemMs: 0,
      maxItemMs: 0,
    };
    const runStartedAt = monotonicNow();
    const runOne = async (screenshot: Screenshot): Promise<void> => {
      if (options.abortSignal?.aborted) return;
      const itemStartedAt = monotonicNow();
      runAccounting.currentInFlightItems++;
      runAccounting.maxInFlightItems = Math.max(
        runAccounting.maxInFlightItems,
        runAccounting.currentInFlightItems,
      );
      try {
        const wasRetryingFailedStage =
          getPreprocessing(screenshot).stage_status[stage] === SS.FAILED;
        const outcome = await this.processStage(screenshot, stage, options);
        if (wasRetryingFailedStage && stage !== "ocr") {
          const fresh = await this.storage.getScreenshot(screenshot.id);
          if (
            fresh?.processing_status === "failed" &&
            getPreprocessing(fresh).stage_status[stage] === SS.COMPLETED
          ) {
            const nonBlockingIssues = (fresh.processing_issues ?? []).filter(
              (issue) => ["non_blocking", "warning", "info"].includes(issue.severity),
            );
            await this.storage.updateScreenshot(screenshot.id, {
              processing_status: "pending",
              processing_issues: nonBlockingIssues,
              has_blocking_issues: false,
              processed_at: null,
            });
          }
        }
        if (outcome.cacheHit) runAccounting.cacheHits++;
        if (outcome.failed) {
          failed++;
          runAccounting.failedItems++;
        } else {
          completed++;
          runAccounting.completedItems++;
        }
      } catch (e) {
        if (isAbortLike(e, options.abortSignal)) {
          runAccounting.abortedItems++;
          await this.handleStageAbort(screenshot, stage);
          return;
        }
        runAccounting.failedItems++;
        await recordFailure(screenshot, e);
      } finally {
        const itemMs = Math.max(0, monotonicNow() - itemStartedAt);
        runAccounting.currentInFlightItems = Math.max(0, runAccounting.currentInFlightItems - 1);
        runAccounting.totalItemMs += itemMs;
        runAccounting.maxItemMs = Math.max(runAccounting.maxItemMs, itemMs);
      }
      options.onProgress?.(completed + failed, eligible.length);
    };

    try {
      if (isBoundedConcurrency) {
        let cursor = 0;
        // Tail-recursive worker: each iteration is a fresh microtask so the
        // call stack doesn't grow with eligible.length. The outer Promise.all
        // is the concurrency primitive — N runners share the cursor.
        const runner = async (): Promise<void> => {
          if (options.abortSignal?.aborted) return;
          const i = cursor++;
          if (i >= eligible.length) return;
          await runOne(eligible[i]!);
          return runner();
        };
        await Promise.all(
          Array.from({ length: configuredConcurrency }, () => runner()),
        );
      } else if (ocrConcurrency > 1) {
        // Pool-sized concurrency for OCR. Use a cursor + N workers
        // pattern so each worker pulls the next eligible screenshot the
        // moment it finishes its current one. This keeps the pool fully
        // saturated even when individual screenshots take wildly
        // different OCR times (Pro Max + many apps vs iPhone SE +
        // single-app).
        let cursor = 0;
        if (ocrWasColdAtRunStart && eligible.length > 1) {
          await runOne(eligible[cursor++]!);
          await yieldToMain();
        }
        const runner = async (): Promise<void> => {
          if (options.abortSignal?.aborted) return;
          const i = cursor++;
          if (i >= eligible.length) return;
          await runOne(eligible[i]!);
          return runner();
        };
        await Promise.all(
          Array.from({ length: configuredConcurrency }, () => runner()),
        );
      } else {
        // PHI: serialize because the Tesseract.js + NER workers are
        // singletons and not part of the LepTess pool. Use a recursive
        // step so the loop stays sequential without an `await`-in-loop
        // pattern, and preserves the inter-item setTimeout yield that
        // lets the progress bar repaint.
        const step = async (i: number): Promise<void> => {
          if (i >= eligible.length || options.abortSignal?.aborted) return;
          await runOne(eligible[i]!);
          // Yield so pending input/paint runs between items. scheduler.yield
          // (when available) resumes at higher priority than setTimeout(0), so a
          // user interaction during a PHI batch isn't starved behind the loop.
          await yieldToMain();
          return step(i + 1);
        };
        await step(0);
      }
    } finally {
      if (options.abortSignal?.aborted) {
        const accountedItems =
          runAccounting.completedItems + runAccounting.failedItems + runAccounting.abortedItems;
        runAccounting.abortedItems += Math.max(0, runAccounting.queuedItems - accountedItems);
      }
      this.recordStageRun(stage, runAccounting, Math.max(0, monotonicNow() - runStartedAt));
    }

    // Clean up the NER worker after a PHI detection batch
    if (stage === "phi_detection" && this.phiModulePromise) {
      const m = await this.phiModulePromise;
      m.terminateNERWorker();
    }

    const stageLabel = stage.replace(/_/g, " ");
    return {
      queued_count: completed,
      failed_count: failed,
      message:
        failed > 0
          ? `Completed ${stageLabel} for ${completed} screenshot(s), ${failed} failed`
          : `Completed ${stageLabel} for ${completed} screenshot(s)`,
      screenshot_ids: eligible.map((s) => s.id),
    };
  }

  private async processStage(
    screenshot: Screenshot, stage: PreprocessingStage, options: RunStageOptions,
  ): Promise<StageProcessOutcome> {
    return withScreenshotLock(screenshot.id, async () => {
      const fresh = await this.storage.getScreenshot(screenshot.id);
      if (!fresh) throw new ScreenshotInputChangedError();
      return this.processStageLocked(fresh, stage, options);
    });
  }

  private async processStageLocked(
    screenshot: Screenshot,
    stage: PreprocessingStage,
    options: RunStageOptions,
  ): Promise<StageProcessOutcome> {
    throwIfAborted(options.abortSignal);
    const id = screenshot.id;
    const inputRevision = screenshotInputRevision(screenshot);
    const commit = async (data: Partial<Screenshot>): Promise<void> => {
      await assertScreenshotInput(this.storage, id, inputRevision);
      await this.storage.updateScreenshot(id, data);
    };
    let cacheHit = false;
    let failedOutcome = false;
    let imageBlobPromise: Promise<Blob | null> | undefined;
    const getImageBlob = async (): Promise<Blob | null> => {
      if (!imageBlobPromise) {
        imageBlobPromise = this.storage.getImageBlob(id).then((blob) => {
          throwIfAborted(options.abortSignal);
          return blob;
        });
      }
      try {
        return await imageBlobPromise;
      } catch (error) {
        if (isAbortLike(error, options.abortSignal)) {
          imageBlobPromise = undefined;
        }
        throw error;
      } finally {
        throwIfAborted(options.abortSignal);
      }
    };

    switch (stage) {
      case "device_detection": {
        const ppAtStart = getPreprocessing(screenshot);
        const cacheKey = deviceDetectionCacheKey(screenshot);
        const cachedEvent = findReusableCompletedEvent(ppAtStart, stage, cacheKey);
        if (cachedEvent) {
          cacheHit = true;
          const updated = addEvent(ppAtStart, stage, SS.COMPLETED, replayCachedResult(cachedEvent));
          await commit({
            processing_metadata: setPreprocessing(screenshot, updated),
          });
          break;
        }

        // Device detection MUST run on the pristine PRE-CROP image. The
        // `cropping` stage overwrites the current image blob with the cropped
        // result (saveImageBlob), so on a re-run — or any second pipeline pass —
        // `getImageBlob(id)` returns an already-cropped image whose dimensions
        // match no device profile; the matcher then falls through to its loose
        // aspect-ratio branch and labels everything "iPhone 14 Pro" / unknown.
        // Snapshot the untouched source once here (the first stage) so both
        // detection and any re-run always read the true original, never the crop.
        const existingOriginal = await this.storage.getStageBlob(id, "original");
        const sourceBlob = existingOriginal ?? await (async () => {
          const blob = await getImageBlob();
          if (blob) {
            await this.storage.saveStageBlob(id, "original", blob);
          }
          return blob;
        })();

        let width = 0;
        let height = 0;
        if (sourceBlob) {
          // Dimensions only — read them from the image header (a few KB) instead
          // of decoding the full RGBA bitmap (tens of MB) just to read w/h. Fall
          // back to a real decode for any format the header parser can't read.
          const dims = await readImageDimensions(sourceBlob);
          if (dims) {
            width = dims.width;
            height = dims.height;
          } else {
            // Header parse failed (uncommon format / truncated header). Fall back to a
            // full decode through the crop worker pool so decode memory is bounded
            // and kept off the main thread when workers are available.
            const decodedDims = await this.getCropWorkerPool().readBlobDimensions(
              sourceBlob,
              options.abortSignal,
            );
            width = decodedDims.width;
            height = decodedDims.height;
          }
        } else {
          console.warn(`[WASM] device_detection: No blob for screenshot ${id}`);
        }

        const result = detectDevice(width, height);

        const pp = getPreprocessing(screenshot);

        // Portrait-only input contract: every iOS Screen Time chart is taller than
        // wide (iPads included), so a landscape frame is a rotated/invalid capture
        // the pipeline can't frame. Fail at the EARLIEST stage with an actionable
        // message so it never silently produces wrong numbers downstream — recording
        // device_detection as FAILED also halts cropping/ocr via the stage-prereq
        // gate. The Rust grid detector rejects landscape too (defense in depth).
        if (result.orientation === "landscape") {
          const landscapeMsg = "Landscape orientation — capture the Screen Time chart in portrait";
          const failed = addEvent(pp, stage, SS.FAILED, {
            device_model: result.model ?? "unknown",
            device_family: result.family ?? "unknown",
            device_category: result.category,
            confidence: result.confidence,
            orientation: result.orientation,
            dimensions: { width, height },
            needs_cropping: false,
            error: landscapeMsg,
            has_blocking_issues: true,
            issues: [landscapeMsg],
          });
          await commit({
            processing_metadata: setPreprocessing(screenshot, failed),
            processing_status: "failed",
            processing_issues: [{
              issue_type: "unsupported_orientation",
              description: `${landscapeMsg}.`,
              severity: "blocking",
            }],
            has_blocking_issues: true,
            processed_at: new Date().toISOString(),
          } as Partial<Screenshot>);
          failedOutcome = true;
          break;
        }

        const updated = addEvent(pp, stage, SS.COMPLETED, cacheStamp({
          device_model: result.model ?? "unknown",
          device_family: result.family ?? "unknown",
          device_category: result.category,
          confidence: result.confidence,
          orientation: result.orientation,
          dimensions: { width, height },
          needs_cropping: result.needsCropping ?? false,
        }, cacheKey, screenshot));

        await commit({
          processing_metadata: setPreprocessing(screenshot, updated),
        });
        break;
      }

      case "cropping": {
        const ppAtStart = getPreprocessing(screenshot);
        const cacheKey = croppingCacheKey(screenshot, ppAtStart);
        const cachedEvent = findReusableCompletedEvent(ppAtStart, stage, cacheKey);
        if (cachedEvent) {
          const cachedResult = replayCachedResult(cachedEvent);
          const cachedBlob = cachedResult.was_cropped === true
            ? await this.storage.getStageBlob(id, "cropping")
            : null;
          if (cachedResult.was_cropped !== true || cachedBlob) {
            cacheHit = true;
            if (cachedBlob) {
              await this.storage.saveImageBlob(id, cachedBlob);
            }
            const updated = addEvent(ppAtStart, stage, SS.COMPLETED, cachedResult);
            await commit({
              processing_metadata: setPreprocessing(screenshot, updated),
            });
            break;
          }
        }
        // Fast path — the no-crop majority (iPhones). device_detection already
        // decoded this image and recorded its dimensions + needs_cropping. When
        // it determined no crop is needed, the cropping output is byte-identical
        // to the source, so there is nothing to manufacture: skip the decode,
        // the canvas blit + JPEG encode, AND the redundant full-size snapshot
        // write, and just record the event. This collapses the common case to a
        // metadata-only write — as cheap as device_detection itself.
        // getStageImageUrl("cropping") falls back to the current image blob when
        // no cropping snapshot exists (identical bytes here), so the stage
        // preview still works. And post-redaction that fallback already serves
        // the redacted current blob (deletePreRedactionBlobs removes the
        // "cropping" snapshot), so skipping the write is behaviour-identical and
        // keeps redaction irreversible. Falls through to the full path below
        // whenever detection is missing or said a crop IS needed.
        const ppDet = getPreprocessing(screenshot);
        const detResult = ppDet.events.find(
          (e) => e.stage === "device_detection" && e.event_id === ppDet.current_events.device_detection,
        )?.result;
        const detDims = detResult?.dimensions as { width: number; height: number } | undefined;
        const originalBlob = await this.storage.getStageBlob(id, "original");
        if (detResult?.needs_cropping === false && detDims) {
          if (!originalBlob) {
            const blob = await getImageBlob();
            if (!blob) { await this.recordMissingBlob(screenshot, stage); return { cacheHit, failed: true }; }
          }
          const dims: [number, number] = [detDims.width, detDims.height];
          const updated = addEvent(ppDet, stage, SS.COMPLETED, cacheStamp({
            was_cropped: false,
            was_patched: false,
            original_dimensions: dims,
            cropped_dimensions: dims,
            device_model: detResult.device_model,
            is_ipad: detResult.device_category === "ipad",
          }, cacheKey, screenshot));
          await commit({
            processing_metadata: setPreprocessing(screenshot, updated),
          });
          break;
        }

        // Full path — no prior detection, or detection said a crop is needed.
        // Sentinel: mark `running` before the multi-step blob writes so a
        // mid-stage crash is reconciled back to `pending` (COR-9).
        await this.markStageRunning(id, stage);

        // Use the preserved original if available (handles re-runs after reset)
        const currentBlob = originalBlob ? null : await getImageBlob();
        const sourceBlob = originalBlob ?? currentBlob;
        if (!sourceBlob) { await this.recordMissingBlob(screenshot, stage); return { cacheHit, failed: true }; }

        // Medium-cost crop/encode work runs in a bounded persistent worker pool.
        // iPhones already returned via the metadata-only fast path above.
        const cropResult = await this.getCropWorkerPool().cropScreenshot(
          sourceBlob,
          options.abortSignal,
        );

        if (cropResult.wasCropped) {
          // Preserve original only once, before first overwrite
          if (!originalBlob) {
            await this.storage.saveStageBlob(id, "original", sourceBlob);
          }
          // Save cropped blob as current + stage snapshot
          await this.storage.saveStageBlob(id, "cropping", cropResult.croppedBlob);
          await this.storage.saveImageBlob(id, cropResult.croppedBlob);
        } else {
          // Even if not cropped, save a snapshot so getStageImageUrl("cropping") works
          await this.storage.saveStageBlob(id, "cropping", sourceBlob);
        }

        // Re-read AFTER the blob writes — the event_id derivation in addEvent
        // must be based on current on-disk metadata, not a stale snapshot
        // captured before a concurrent stage may have written events (COR-13).
        const fresh = await this.storage.getScreenshot(id);
        if (!fresh) return { cacheHit, failed: true };
        const pp = getPreprocessing(fresh);
        const detectionEvent = pp.events.find(
          (e) => e.stage === "device_detection" && e.event_id === pp.current_events.device_detection,
        );
        const updated = addEvent(pp, stage, SS.COMPLETED, cacheStamp({
          was_cropped: cropResult.wasCropped,
          was_patched: false,
          original_dimensions: [cropResult.originalDimensions.width, cropResult.originalDimensions.height],
          cropped_dimensions: [cropResult.croppedDimensions.width, cropResult.croppedDimensions.height],
          device_model: cropResult.deviceModel,
          is_ipad: detectionEvent?.result?.device_category === "ipad",
        }, cacheKey, screenshot));

        await commit({
          processing_metadata: setPreprocessing(fresh, updated),
        });
        break;
      }

      case "phi_detection": {
        const blob = await getImageBlob();
        if (!blob) { await this.recordMissingBlob(screenshot, stage); return { cacheHit, failed: true }; }

        const { detectPHI } = await this.loadPhiModule();
        const phiResult = await detectPHI(blob, {
          llmEndpoint: options.llm_endpoint,
          llmModel: options.llm_model,
          llmApiKey: options.llm_api_key,
          abortSignal: options.abortSignal,
        });

        const pp = getPreprocessing(screenshot);
        const updated = addEvent(pp, stage, SS.COMPLETED, {
          phi_detected: phiResult.regions.length > 0,
          regions_count: phiResult.regions.length,
          phi_entities: phiResult.regions,
          ocr_text: phiResult.ocrText,
          ocr_confidence: phiResult.ocrConfidence,
          ner_status: phiResult.nerStatus,
          reviewed: false,
        });

        await commit({
          processing_metadata: setPreprocessing(screenshot, updated),
        });
        break;
      }

      case "phi_redaction": {
        const blob = await getImageBlob();
        if (!blob) { await this.recordMissingBlob(screenshot, stage); return { cacheHit, failed: true }; }

        // Get PHI regions from the detection stage (read geometry BEFORE scrub)
        const ppPre = getPreprocessing(screenshot);
        const detectionEventId = ppPre.current_events.phi_detection;
        const detectionEvent = ppPre.events.find((e) => e.event_id === detectionEventId);
        const regions = (detectionEvent?.result?.phi_entities ?? []) as PHIRegion[];

        if (regions.length === 0) {
          // No PHI to redact — still scrub the detection event's OCR text,
          // since the redaction stage has run and the screenshot is sanitized.
          // No blob writes here, so no running sentinel needed.
          const pp = scrubPhiDetectionEvent(ppPre);
          const updated = addEvent(pp, stage, SS.COMPLETED, {
            phi_detected: false,
            redacted: false,
            redaction_method: options.phi_redaction_method ?? "redbox",
            regions_redacted: 0,
          });
          await commit({
            processing_metadata: setPreprocessing(screenshot, updated),
          });
          break;
        }

        // Sentinel before the irreversible blob writes (saveImageBlob +
        // deletePreRedactionBlobs). A crash between the redaction write and
        // the COMPLETED event would otherwise leave a redacted image with
        // metadata still claiming redaction is pending (COR-9).
        await this.markStageRunning(id, stage);

        const method = (options.phi_redaction_method ?? "redbox") as "redbox" | "blackbox" | "pixelate";
        const { redactImage } = await this.loadPhiRedactModule();
        const redactedBlob = await redactImage(blob, regions, method, 2, options.abortSignal);

        // Save redacted image as current + stage snapshot
        await this.storage.saveImageBlob(id, redactedBlob);
        await this.storage.saveStageBlob(id, "phi_redaction", redactedBlob);
        // Securely drop the un-redacted source imagery now a clean blob exists.
        await this.storage.deletePreRedactionBlobs(id);

        // Re-read after the blob writes so the COMPLETED event's id is derived
        // from current on-disk metadata, not a stale pre-write snapshot (COR-13).
        const fresh = await this.storage.getScreenshot(id);
        if (!fresh) return { cacheHit, failed: true };
        // Scrub the verbatim PHI text out of the detection event metadata.
        const pp = scrubPhiDetectionEvent(getPreprocessing(fresh));
        const updated = addEvent(pp, stage, SS.COMPLETED, {
          phi_detected: true,
          redacted: true,
          redaction_method: method,
          regions_redacted: regions.length,
        });

        await commit({
          processing_metadata: setPreprocessing(fresh, updated),
        });
        break;
      }

      case "ocr": {
        const ocrMethod = (options.ocr_method ?? "line_based") as "ocr_anchored" | "line_based";
        const maxShift = options.max_shift ?? 5;

        // Determine image type from screenshot metadata
        const metadata = screenshot as unknown as Record<string, unknown>;
        const imageType = (metadata.image_type as "battery" | "screen_time") ?? "screen_time";
        const ppAtStart = getPreprocessing(screenshot);
        const cacheKey = ocrInputCacheKey(screenshot, ppAtStart, {
          imageType,
          ocrMethod,
          maxShift,
          skipDailyTotals: options.skip_daily_totals === true,
        });
        const cachedEvent = findReusableCompletedEvent(ppAtStart, stage, cacheKey);
        if (cachedEvent) {
          cacheHit = true;
          const cachedResult = replayCachedResult(cachedEvent);
          const updated = addEvent(ppAtStart, stage, SS.COMPLETED, cachedResult);
          const gridCoords = cachedResult.grid_coordinates as
            | { upper_left?: { x?: number; y?: number }; lower_right?: { x?: number; y?: number } }
            | null
            | undefined;
          const processingStatus =
            cachedResult.processing_status === "skipped" ? "skipped" : "completed";
          const cachedHourly =
            (cachedResult.extracted_hourly_data as Record<string, number> | null | undefined) ?? null;
          const cachedQuality = mergeDataQualityEvidence(
            screenshot.processing_metadata as Record<string, unknown> | null,
            {
              suspected_all_devices: cachedResult.suspected_all_devices === true,
              axis_max_minutes:
                (cachedResult.axis_max_minutes as number | null | undefined) ?? null,
              all_devices_reasons:
                (cachedResult.all_devices_reasons as string[] | undefined) ?? [],
            },
            cachedHourly,
            screenshot.image_type,
          );
          await commit({
            processing_metadata: withDataQualityFlags(
              setPreprocessing(screenshot, updated),
              cachedQuality,
              cachedHourly,
              screenshot.image_type,
            ),
            extracted_title: (cachedResult.extracted_title as string | null | undefined) ?? null,
            extracted_total: (cachedResult.extracted_total as string | null | undefined) ?? null,
            extracted_hourly_data: cachedHourly,
            grid_upper_left_x: gridCoords?.upper_left?.x ?? null,
            grid_upper_left_y: gridCoords?.upper_left?.y ?? null,
            grid_lower_right_x: gridCoords?.lower_right?.x ?? null,
            grid_lower_right_y: gridCoords?.lower_right?.y ?? null,
            alignment_score: (cachedResult.alignment_score as number | null | undefined) ?? null,
            grid_registration_score: (cachedResult.grid_registration_score as number | null | undefined) ?? null,
            processing_status: processingStatus,
            processing_issues: cachedQuality.suspected_all_devices
              ? [{
                  issue_type: "suspected_all_devices",
                  description: cachedQuality.all_devices_reasons.join("; "),
                  severity: "non_blocking",
                }]
              : [],
            has_blocking_issues: false,
            processed_at: new Date().toISOString(),
          } as Partial<Screenshot>);
          break;
        }
        const blob = await getImageBlob();
        if (!blob) { await this.recordMissingBlob(screenshot, stage); return { cacheHit, failed: true }; }

        let ocrResult: {
          hourlyData: unknown;
          title: string | null;
          total: string | null;
          gridCoordinates?: unknown;
          gridDetectionFailed?: boolean;
          gridDetectionError?: string;
          alignmentScore?: number | null;
          gridRegistrationScore?: number | null;
          suspectedAllDevices?: boolean;
          axisMaxMinutes?: number | null;
          allDevicesReasons?: string[];
          ocrFailed?: boolean;
          ocrError?: string | null;
          // Which way the chart's hour axis runs. Without it declared here the
          // field the worker returns is dropped, and nothing on the WIZARD path
          // records the direction — so a later grid nudge re-extracts a mirrored
          // chart as left-to-right and overwrites correct hours with reversed
          // ones. `WASMScreenshotService` already persists this on its own path.
          axisDirection?: "ltr" | "rtl";
        };

        const recordHardGridFailure = async (
          issue: string,
          isWeekly: boolean,
          quality?: DataQualityFlags,
          ocrFailure?: { failed: boolean; error?: string | null },
        ): Promise<void> => {
          const ocrFailed = ocrFailure?.failed === true;
          const ocrError = ocrFailed
            ? ocrFailure?.error?.trim() || "OCR engine failed while processing the screenshot"
            : null;
          const ppOcr = getPreprocessing(screenshot);
          const updated = addEvent(ppOcr, stage, SS.FAILED, {
            processing_status: "failed",
            processing_method: ocrMethod,
            extracted_title: null,
            extracted_total: null,
            grid_detection_confidence: 0,
            has_blocking_issues: true,
            issues: [issue, ...(ocrError ? [ocrError] : [])],
            ocr_failed: ocrFailed,
            ocr_error: ocrError,
          });
          let metadata = setPreprocessing(screenshot, updated);
          if (quality) {
            metadata = withDataQualityFlags(
              metadata,
              quality,
              undefined,
              screenshot.image_type,
            );
          }
          metadata = withOcrFailureHistory(metadata, ocrFailed);
          await commit({
            processing_metadata: metadata,
            processing_status: "failed",
            processing_issues: [
              {
                issue_type: isWeekly ? "weekly_view_unsupported" : "grid_detection_failed",
                description: issue,
                severity: "blocking",
              },
              {
                issue_type: "no_hourly_data",
                description: "No hourly bar data could be extracted",
                severity: "blocking",
              },
              ...(ocrError
                ? [{
                    issue_type: "ocr_processing_failed",
                    description: ocrError,
                    severity: "blocking" as const,
                  }]
                : []),
              ...(quality?.suspected_all_devices
                ? [{
                    issue_type: "suspected_all_devices",
                    description: quality.all_devices_reasons.join("; "),
                    severity: "non_blocking" as const,
                  }]
                : []),
            ],
            has_blocking_issues: true,
            processed_at: new Date().toISOString(),
          } as Partial<Screenshot>);
        };

        const recordOcrStageFailure = async (message: string): Promise<void> => {
          const ppOcr = getPreprocessing(screenshot);
          const updated = addEvent(ppOcr, stage, SS.FAILED, {
            processing_status: "failed",
            processing_method: ocrMethod,
            extracted_title: null,
            extracted_total: null,
            grid_detection_confidence: 0,
            has_blocking_issues: true,
            issues: [message],
            ocr_failed: false,
            ocr_error: null,
          });
          await commit({
            processing_metadata: withOcrFailureHistory(setPreprocessing(screenshot, updated), false),
            processing_status: "failed",
            processing_issues: [
              { issue_type: "ocr_stage_failed", description: message, severity: "blocking" },
            ],
            has_blocking_issues: true,
            processed_at: new Date().toISOString(),
          } as Partial<Screenshot>);
        };

        try {
          if (this.processing.processImageWithGridDetection) {
            ocrResult = await this.processing.processImageWithGridDetection(blob, {
              imageType,
              gridDetectionMethod: ocrMethod,
              maxShift,
              ...(options.abortSignal !== undefined && { abortSignal: options.abortSignal }),
            });
          } else {
            // Detect grid using the user's chosen method first, then fall back to the other.
            // Line-based detection doesn't need Tesseract, so we skip initialize() here —
            // it will be called lazily before processImage() which needs OCR for title/total.
            const fallbackMethod = ocrMethod === "line_based" ? "ocr_anchored" : "line_based";
            // detectGridDetailed also returns the Rust detector's failure reason / weekly
            // flag (local mode only) so we can give an actionable rejection; fall back to
            // the coordinate-only detectGrid in any impl that doesn't provide it.
            const detectGrid = (m: "ocr_anchored" | "line_based"): Promise<GridDetectionDetail> =>
              this.processing.detectGridDetailed
                ? this.processing.detectGridDetailed(blob, imageType, m)
                : this.processing.detectGrid(blob, imageType, m).then((gridCoordinates) => ({ gridCoordinates }));

            const primary = await detectGrid(ocrMethod);
            throwIfAborted(options.abortSignal);
            let grid = primary.gridCoordinates;
            let gridDiag: GridDetectionDetail = primary;
            if (!grid && !primary.isWeekly) {
              const fb = await detectGrid(fallbackMethod);
              throwIfAborted(options.abortSignal);
              grid = fb.gridCoordinates;
              gridDiag = fb;
            }

            if (!grid) {
              const issue = gridDiag.isWeekly
                ? "Weekly view detected — capture the daily (24-hour) Screen Time chart (Day view, not Week)"
                : "Could not detect a daily Screen Time chart. Make sure the screenshot is the Day view (not Week), in portrait, at Standard display zoom.";
              await recordHardGridFailure(issue, gridDiag.isWeekly === true);
              failedOutcome = true;
              break;
            }

            // Initialize Tesseract now — processImage needs it for title/total OCR.
            if (!this.processing.isInitialized()) {
              await this.processing.initialize();
            }
            throwIfAborted(options.abortSignal);
            ocrResult = await this.processing.processImage(blob, {
              imageType,
              gridCoordinates: grid,
              maxShift,
              ...(options.abortSignal !== undefined && { abortSignal: options.abortSignal }),
            });
          }
        } catch (err) {
          if (isAbortLike(err, options.abortSignal)) throw err;
          const message = err instanceof Error ? err.message : String(err);
          await recordOcrStageFailure(message);
          failedOutcome = true;
          break;
        }

        if (ocrResult.gridDetectionFailed && !ocrResult.gridCoordinates) {
          const issue = ocrResult.gridDetectionError?.trim() ||
            "Could not detect a daily Screen Time chart. Make sure the screenshot is the Day view (not Week), in portrait, at Standard display zoom.";
          const failureQuality = mergeDataQualityEvidence(
            screenshot.processing_metadata as Record<string, unknown> | null,
            {
              suspected_all_devices: ocrResult.suspectedAllDevices === true,
              axis_max_minutes: ocrResult.axisMaxMinutes ?? null,
              all_devices_reasons: ocrResult.allDevicesReasons ?? [],
            },
            undefined,
            screenshot.image_type,
          );
          await recordHardGridFailure(
            issue,
            issue.startsWith("Weekly view detected"),
            failureQuality,
            {
              failed: ocrResult.ocrFailed === true,
              ...(ocrResult.ocrError !== undefined && { error: ocrResult.ocrError }),
            },
          );
          failedOutcome = true;
          break;
        }

        // Auto-skip daily total images if setting is enabled
        if (options.skip_daily_totals && ocrResult.title === "Daily Total") {
          const ppSkip = getPreprocessing(screenshot);
          const skippedEvent = addEvent(ppSkip, stage, SS.COMPLETED, cacheStamp({
            processing_status: "skipped",
            processing_method: ocrMethod,
            extracted_title: "Daily Total",
            extracted_total: null,
            is_daily_total: true,
          }, cacheKey, screenshot));
          await commit({
            processing_metadata: setPreprocessing(screenshot, skippedEvent),
            extracted_title: "Daily Total",
            processing_status: "skipped",
            processing_issues: [],
            has_blocking_issues: false,
            processed_at: new Date().toISOString(),
          } as Partial<Screenshot>);
          break;
        }

        const hasHourlyData = hasExportableHourlyValues(
          ocrResult.hourlyData as Record<string, unknown> | null | undefined,
        );
        const processingFailed =
          ocrResult.ocrFailed === true ||
          ocrResult.gridDetectionFailed === true ||
          !hasHourlyData;
        failedOutcome = processingFailed;
        const issues: NonNullable<Screenshot["processing_issues"]> = [
          ...(ocrResult.ocrFailed
            ? [{
                issue_type: "ocr_processing_failed",
                description: ocrResult.ocrError?.trim() || "OCR engine failed while extracting text",
                severity: "blocking" as const,
              }]
            : []),
          ...(ocrResult.gridDetectionFailed || ocrResult.gridDetectionError
            ? [{
                issue_type: "grid_detection_failed",
                description: ocrResult.gridDetectionError || "Grid detection failed",
                severity: "blocking" as const,
              }]
            : []),
          ...(!hasHourlyData
            ? [{
                issue_type: "no_hourly_data",
                description: "No hourly bar data extracted",
                severity: "blocking" as const,
              }]
            : []),
        ];
        const hourlyData = ocrResult.hourlyData as Record<string, number> | null;
        const quality = mergeDataQualityEvidence(
          screenshot.processing_metadata as Record<string, unknown> | null,
          {
            suspected_all_devices: ocrResult.suspectedAllDevices === true,
            axis_max_minutes: ocrResult.axisMaxMinutes ?? null,
            all_devices_reasons: ocrResult.allDevicesReasons ?? [],
          },
          hourlyData,
          screenshot.image_type,
        );

        const ppOcr = getPreprocessing(screenshot);
        const updated = addEvent(ppOcr, stage, processingFailed ? SS.FAILED : SS.COMPLETED, cacheStamp({
          processing_status: processingFailed ? "failed" : "completed",
          processing_method: ocrMethod,
          extracted_title: ocrResult.title,
          extracted_total: ocrResult.total,
          grid_coordinates: ocrResult.gridCoordinates ?? null,
          extracted_hourly_data: ocrResult.hourlyData ?? null,
          grid_detection_confidence: processingFailed ? 0 : 1,
          has_blocking_issues: processingFailed,
          issues: issues.map((issue) => issue.description),
          alignment_score: ocrResult.alignmentScore ?? null,
          grid_registration_score: ocrResult.gridRegistrationScore ?? null,
          suspected_all_devices: quality.suspected_all_devices,
          axis_max_minutes: quality.axis_max_minutes,
          all_devices_reasons: quality.all_devices_reasons,
          ocr_failed: ocrResult.ocrFailed === true,
          ocr_error: ocrResult.ocrError ?? null,
        }, processingFailed ? null : cacheKey, screenshot));

        // Save all extracted data to the screenshot record so the annotation
        // queue can read grid coordinates, hourly data, title, and total.
        const gridCoords = ocrResult.gridCoordinates as { upper_left: { x: number; y: number }; lower_right: { x: number; y: number } } | undefined;
        await commit({
          processing_metadata: withAxisDirection(
            withOcrFailureHistory(
              withDataQualityFlags(
                setPreprocessing(screenshot, updated),
                quality,
                hourlyData,
                screenshot.image_type,
              ),
              ocrResult.ocrFailed === true,
            ),
            ocrResult.axisDirection,
          ),
          extracted_title: ocrResult.title,
          extracted_total: ocrResult.total,
          extracted_hourly_data: hourlyData,
          grid_upper_left_x: gridCoords?.upper_left?.x ?? null,
          grid_upper_left_y: gridCoords?.upper_left?.y ?? null,
          grid_lower_right_x: gridCoords?.lower_right?.x ?? null,
          grid_lower_right_y: gridCoords?.lower_right?.y ?? null,
          alignment_score: ocrResult.alignmentScore ?? null,
          grid_registration_score: ocrResult.gridRegistrationScore ?? null,
          processing_status: processingFailed ? "failed" : "completed",
          processing_issues: issues.concat(
            quality.suspected_all_devices
              ? [{
                  issue_type: "suspected_all_devices",
                  description: quality.all_devices_reasons.join("; "),
                  severity: "non_blocking",
                }]
              : [],
          ),
          has_blocking_issues: processingFailed,
          processed_at: new Date().toISOString(),
        } as Partial<Screenshot>);
        break;
      }
    }
    return { cacheHit, failed: failedOutcome };
  }

  async resetStage(stage: PreprocessingStage, groupId: string): Promise<{ message: string; count?: number }> {
    const screenshots = await this.storage.getAllScreenshots({ group_id: groupId });
    const downstreamStages = this.downstreamFrom(stage);
    const clearsOcrOutputs = downstreamStages.includes("ocr");

    // Each downstream-stage reset is independent, but keep IDB writes bounded.
    const changed = await mapBounded(screenshots, metadataIoConcurrency(), async (s) => {
      const pp = getPreprocessing(s);
      let didChange = false;
      const newStageStatus = { ...pp.stage_status };
      const newCurrentEvents = { ...pp.current_events };
      for (const ds of downstreamStages) {
        if (newStageStatus[ds] !== undefined && newStageStatus[ds] !== SS.PENDING) {
          newStageStatus[ds] = SS.PENDING;
          didChange = true;
        }
        if (ds in newCurrentEvents) {
          delete newCurrentEvents[ds];
          didChange = true;
        }
      }
      const resetAt = new Date().toISOString();
      const stagedPp: PreprocessingMeta = {
        ...pp,
        stage_status: newStageStatus,
        current_events: newCurrentEvents,
      };
      const invalidated = invalidateReusableStageResults(stagedPp, downstreamStages, resetAt);
      didChange ||= invalidated.changed;

      const clearsExistingOcrOutputs = clearsOcrOutputs && (
        s.extracted_title != null ||
        s.extracted_total != null ||
        s.extracted_hourly_data != null ||
        s.grid_upper_left_x != null ||
        s.grid_upper_left_y != null ||
        s.grid_lower_right_x != null ||
        s.grid_lower_right_y != null ||
        s.alignment_score != null ||
        s.grid_registration_score != null ||
        s.processed_at != null ||
        s.processing_status !== "pending" ||
        s.has_blocking_issues === true ||
        ((s.processing_issues as unknown[] | null | undefined)?.length ?? 0) > 0
      );
      didChange ||= clearsExistingOcrOutputs;

      if (!didChange) return false;
      const update: Partial<Screenshot> = {
        processing_metadata: setPreprocessing(s, invalidated.pp),
      };
      if (clearsOcrOutputs) {
        Object.assign(update, {
          extracted_title: null,
          extracted_total: null,
          extracted_hourly_data: null,
          grid_upper_left_x: null,
          grid_upper_left_y: null,
          grid_lower_right_x: null,
          grid_lower_right_y: null,
          alignment_score: null,
          grid_registration_score: null,
          processing_status: "pending",
          processing_issues: [],
          has_blocking_issues: false,
          processed_at: null,
        } satisfies Partial<Screenshot>);
      }
      await this.storage.updateScreenshot(s.id, update);
      return true;
    });
    const count = changed.filter(Boolean).length;

    return { message: `Reset ${stage.replace(/_/g, " ")} for ${count} screenshot(s)`, count };
  }

  async skipStage(stage: PreprocessingStage, groupId: string, screenshotIds?: number[], unskip?: boolean): Promise<{ message: string; count?: number }> {
    const screenshots = await this.storage.getAllScreenshots({ group_id: groupId });
    const targets = screenshotIds ? screenshots.filter(s => screenshotIds.includes(s.id)) : screenshots;

    // Each skip/unskip write is independent, but keep IDB writes bounded.
    const changed = await mapBounded(targets, metadataIoConcurrency(), async (s) => {
      const pp = getPreprocessing(s);
      const current = pp.stage_status[stage] ?? SS.PENDING;
      const newStageStatus = { ...pp.stage_status };
      const newCurrentEvents = { ...pp.current_events };

      if (unskip) {
        if (current !== SS.SKIPPED) return false;
        newStageStatus[stage] = SS.PENDING;
      } else {
        if (!(current === SS.PENDING || current === SS.INVALIDATED || current === SS.FAILED || current === SS.CANCELLED)) return false;
        newStageStatus[stage] = SS.SKIPPED;
      }

      const resolvesCurrentFailure = current === SS.FAILED || current === SS.CANCELLED;
      if (resolvesCurrentFailure) {
        // Preserve the failed event in history, but stop treating it as the
        // current result after an operator explicitly skips the stage.
        delete newCurrentEvents[stage];
      }
      const updatedPp: PreprocessingMeta = {
        ...pp,
        stage_status: newStageStatus,
        current_events: newCurrentEvents,
      };
      const update: Partial<Screenshot> = {
        processing_metadata: setPreprocessing(s, updatedPp),
      };
      if (resolvesCurrentFailure && s.processing_status === "failed") {
        const nonBlockingIssues = (s.processing_issues ?? []).filter(
          (issue) => ["non_blocking", "warning", "info"].includes(issue.severity),
        );
        Object.assign(update, {
          processing_status: "pending",
          processing_issues: nonBlockingIssues,
          has_blocking_issues: false,
          processed_at: null,
        } satisfies Partial<Screenshot>);
      }
      await this.storage.updateScreenshot(s.id, update);
      return true;
    });
    const count = changed.filter(Boolean).length;

    const action = unskip ? "Unskipped" : "Skipped";
    return { message: `${action} ${stage.replace(/_/g, " ")} for ${count} screenshot(s)`, count };
  }

  async invalidateFromStage(screenshotId: number, stage: string): Promise<void> {
    const screenshot = await this.storage.getScreenshot(screenshotId);
    if (!screenshot) return;

    const downstream = this.downstreamFrom(stage as PreprocessingStage);
    if (downstream.length === 0) return;
    const pp = getPreprocessing(screenshot);
    const newStageStatus = { ...pp.stage_status };
    const newCurrentEvents = { ...pp.current_events };
    newStageStatus[stage] = SS.INVALIDATED;

    for (const ds of downstream) {
      if (newStageStatus[ds] && newStageStatus[ds] !== SS.PENDING) {
        newStageStatus[ds] = SS.INVALIDATED;
      }
      delete newCurrentEvents[ds];
    }

    await this.storage.updateScreenshot(screenshotId, {
      processing_metadata: setPreprocessing(screenshot, {
        ...pp,
        stage_status: newStageStatus,
        current_events: newCurrentEvents,
      }),
      extracted_title: null,
      extracted_total: null,
      extracted_hourly_data: null,
      grid_upper_left_x: null,
      grid_upper_left_y: null,
      grid_lower_right_x: null,
      grid_lower_right_y: null,
      alignment_score: null,
      grid_registration_score: null,
      grid_detection_confidence: null,
      processing_status: "pending",
      processing_issues: [],
      has_blocking_issues: false,
      processed_at: null,
    });
  }

  async getEventLog(screenshotId: number): Promise<PreprocessingEventLog> {
    const screenshot = await this.storage.getScreenshot(screenshotId);
    if (!screenshot) return { screenshot_id: screenshotId, base_file_path: "", events: [], stage_status: {}, current_events: {} };

    const pp = getPreprocessing(screenshot);
    return {
      screenshot_id: screenshotId,
      base_file_path: `wasm://screenshot/${screenshotId}`,
      events: normalizeEvents(pp.events),
      stage_status: pp.stage_status,
      current_events: pp.current_events,
    };
  }

  async getScreenshot(screenshotId: number): Promise<Screenshot | null> {
    return this.storage.getScreenshot(screenshotId);
  }

  async uploadBrowser(_formData: FormData): Promise<BrowserUploadResponse> {
    // In WASM mode, uploads go through the WASMScreenshotService
    // This is a compatibility shim — the preprocessing upload tab
    // calls this but in WASM mode we handle uploads differently
    throw new Error("Browser upload not supported in WASM mode — use drag-and-drop on the home page");
  }

  async getOriginalImageUrl(screenshotId: number): Promise<string> {
    // Once a screenshot is redacted the un-redacted original is destroyed
    // (deletePreRedactionBlobs) — refuse rather than silently serving the
    // redacted image under a name that implies it is the original.
    const screenshot = await this.storage.getScreenshot(screenshotId);
    if (screenshot && isRedacted(getPreprocessing(screenshot))) {
      throw new Error(
        `Screenshot ${screenshotId} has been redacted — the original image is no longer available`,
      );
    }
    // Prefer the preserved original (saved before cropping), fall back to current
    const originalBlob = await this.storage.getStageBlob(screenshotId, "original");
    const blob = originalBlob ?? await this.storage.getImageBlob(screenshotId);
    if (!blob) throw new Error(`No image blob for screenshot ${screenshotId}`);
    // Always mint a FRESH URL — never return a cached one. Both callers
    // (useScreenshotImageUrl + CropAdjustModal) revoke the returned URL on
    // cleanup per the documented "always uncached" contract. Returning a shared
    // cached URL let the first caller's cleanup revoke poison it, so reopening
    // the crop modal after applying a crop hit ERR_FILE_NOT_FOUND on the dead
    // blob URL. The revoking LRU still releases the prior URL on
    // overwrite/eviction as a leak backstop — mirrors getStageImageUrl, which
    // mints fresh for exactly this reason.
    const url = URL.createObjectURL(blob);
    this.stageBlobUrls.set(`${screenshotId}:original`, url);
    return url;
  }

  async applyManualCrop(
    screenshotId: number,
    crop: { left: number; top: number; right: number; bottom: number },
  ): Promise<void> {
    return withScreenshotLock(screenshotId, async () => {
      try {
        await this.applyManualCropLocked(screenshotId, crop);
      } catch (error) {
        await this.recordCropFailure(screenshotId, error);
        throw error;
      }
    });
  }

  private async applyManualCropLocked(
    screenshotId: number,
    crop: { left: number; top: number; right: number; bottom: number },
  ): Promise<void> {
    const before = await this.storage.getScreenshot(screenshotId);
    // For manual crop, use the original image (not a previously cropped one)
    const originalBlob = await this.storage.getStageBlob(screenshotId, "original");
    const blob = originalBlob ?? (await this.storage.getImageBlob(screenshotId));
    if (!blob) throw new Error("No image blob for manual crop");

    // Sentinel: mark `cropping` running before the multi-step blob writes so a
    // crash mid-crop is reconciled back to `pending` (COR-9).
    await this.markStageRunning(screenshotId, "cropping");

    // Preserve original if not already saved
    if (!originalBlob) {
      await this.storage.saveStageBlob(screenshotId, "original", blob);
    }

    // Seed the undo history from the pre-crop state the FIRST time a crop is
    // recorded for this screenshot (so the first undo returns to the
    // auto-crop / uncropped baseline, not to a missing entry).
    let history = before ? readCropHistory(before) : emptyHistory();
    if (history.entries.length === 0 && before) {
      history = seedHistory(await this.cropStateBefore(screenshotId, before));
    }

    // crop.{left,top,right,bottom} are absolute pixel coords in ORIGINAL-image
    // space (the crop modal always edits the preserved original).
    const cropWidth = crop.right - crop.left;
    const cropHeight = crop.bottom - crop.top;
    if (cropWidth <= 0 || cropHeight <= 0) {
      throw new Error(`Invalid crop dimensions: ${cropWidth}x${cropHeight}`);
    }
    const { originalDimensions } = await this.deriveCropFromOriginal(screenshotId, crop);
    const origWidth = originalDimensions.width;
    const origHeight = originalDimensions.height;

    // Update cropping event and migrate grid coordinates in a single write
    const screenshot = await this.storage.getScreenshot(screenshotId);
    if (screenshot) {
      // Migrate grid coords into the NEW crop's image space.
      //
      // The stored grid is NOT necessarily in original-image space — it lives in
      // the space of whatever crop was in effect when the grid was last detected:
      // the auto-crop for an un-manually-cropped iPad (origin x=640), or the
      // previously-applied manual crop. `crop.{left,top}` is in ORIGINAL space
      // (the modal always edits the preserved original). Subtracting an
      // original-space offset from a grid that's already in a cropped frame
      // drifts it by that frame's origin (and on iPads drove the grid off-image,
      // tripping the reset guard below). So first lift the grid back to original
      // space by adding its current frame's origin, then re-base into the new crop:
      //   grid_new = grid_stored + prevOrigin − crop.{left,top}
      // The current frame is the crop on the current history entry (null ⇒ origin
      // 0). `history` was just seeded above and isn't advanced until pushCrop()
      // below, so this entry always reflects the frame the stored grid is in.
      const prevCrop = currentEntry(history)?.crop ?? null;
      const prevLeft = prevCrop?.left ?? 0;
      const prevTop = prevCrop?.top ?? 0;

      const gridUpdate: Record<string, number | null> = {};
      if (screenshot.grid_upper_left_x != null && screenshot.grid_lower_right_x != null) {
        const newULX = (screenshot.grid_upper_left_x ?? 0) + prevLeft - crop.left;
        const newULY = (screenshot.grid_upper_left_y ?? 0) + prevTop - crop.top;
        const newLRX = (screenshot.grid_lower_right_x ?? 0) + prevLeft - crop.left;
        const newLRY = (screenshot.grid_lower_right_y ?? 0) + prevTop - crop.top;

        // Check if grid is still within the cropped region
        if (newLRX > 0 && newLRY > 0 && newULX < cropWidth && newULY < cropHeight) {
          gridUpdate.grid_upper_left_x = Math.max(0, newULX);
          gridUpdate.grid_upper_left_y = Math.max(0, newULY);
          gridUpdate.grid_lower_right_x = Math.min(cropWidth, newLRX);
          gridUpdate.grid_lower_right_y = Math.min(cropHeight, newLRY);
        } else {
          // Grid falls entirely outside cropped region — reset
          gridUpdate.grid_upper_left_x = null;
          gridUpdate.grid_upper_left_y = null;
          gridUpdate.grid_lower_right_x = null;
          gridUpdate.grid_lower_right_y = null;
        }
      }

      // Record this crop on the undo stack with its post-migration grid snapshot.
      history = pushCrop(history, {
        crop,
        grid: gridSnapshotFromUpdate(gridUpdate, screenshot),
        source: "manual",
      });

      const pp = getPreprocessing(screenshot);
      const updated = this.invalidateStagesAfter(addEvent(pp, "cropping", SS.COMPLETED, {
        was_cropped: true,
        was_patched: false,
        manual: true,
        crop_region: crop,
        original_dimensions: [origWidth, origHeight],
        cropped_dimensions: [cropWidth, cropHeight],
      }), "cropping");
      await this.storage.updateScreenshot(screenshotId, {
        processing_metadata: withCropHistory(setPreprocessing(screenshot, updated), history),
        ...gridUpdate,
        extracted_title: null,
        extracted_total: null,
        extracted_hourly_data: null,
        alignment_score: null,
        grid_registration_score: null,
        processing_status: "pending",
        processing_issues: [],
        has_blocking_issues: false,
        processed_at: null,
      });
    }
  }

  async getCropHistory(screenshotId: number): Promise<CropHistoryState> {
    const screenshot = await this.storage.getScreenshot(screenshotId);
    if (!screenshot) return { canUndo: false, canRedo: false, currentCrop: null };
    // Once redacted the un-redacted original is destroyed, so a crop can no
    // longer be reconstructed — report no history (hides the controls).
    if (isRedacted(getPreprocessing(screenshot))) {
      return { canUndo: false, canRedo: false, currentCrop: null };
    }
    const h = readCropHistory(screenshot);
    const cur = currentEntry(h);
    return { canUndo: canUndo(h), canRedo: canRedo(h), currentCrop: cur?.crop ?? null };
  }

  async undoManualCrop(screenshotId: number): Promise<void> {
    await this.moveCropHistory(screenshotId, "undo");
  }

  async redoManualCrop(screenshotId: number): Promise<void> {
    await this.moveCropHistory(screenshotId, "redo");
  }

  /**
   * Step the crop history one entry and re-materialize that state: re-crop the
   * preserved `original` by the entry's rectangle (or restore the full original
   * for an uncropped entry), restore its grid snapshot, and record a cropping
   * event so labels/tables stay truthful. No image bytes are stored by the
   * history itself — every state is reconstructed from `original`.
   */
  private async moveCropHistory(screenshotId: number, dir: "undo" | "redo"): Promise<void> {
    return withScreenshotLock(screenshotId, async () => {
      try {
        await this.moveCropHistoryLocked(screenshotId, dir);
      } catch (error) {
        await this.recordCropFailure(screenshotId, error);
        throw error;
      }
    });
  }

  private async recordCropFailure(screenshotId: number, error: unknown): Promise<void> {
    const fresh = await this.storage.getScreenshot(screenshotId);
    if (!fresh) return;
    const message = error instanceof Error ? error.message : String(error);
    const updated = this.invalidateStagesAfter(addEvent(getPreprocessing(fresh), "cropping", SS.FAILED, { error: message }), "cropping");
    await this.storage.updateScreenshot(screenshotId, {
      processing_metadata: setPreprocessing(fresh, updated),
      processing_status: "failed", has_blocking_issues: true,
      processing_issues: [{ issue_type: "cropping_failed", severity: "blocking", description: message }],
      extracted_title: null, extracted_total: null, extracted_hourly_data: null,
      alignment_score: null, grid_registration_score: null,
      grid_upper_left_x: null, grid_upper_left_y: null, grid_lower_right_x: null, grid_lower_right_y: null,
    });
  }

  private async moveCropHistoryLocked(screenshotId: number, dir: "undo" | "redo"): Promise<void> {
    const screenshot = await this.storage.getScreenshot(screenshotId);
    if (!screenshot) throw new Error(`Screenshot ${screenshotId} not found`);
    if (isRedacted(getPreprocessing(screenshot))) {
      throw new Error("Crop history is unavailable after redaction");
    }
    const h0 = readCropHistory(screenshot);
    const h1 = dir === "undo" ? undoHistory(h0) : redoHistory(h0);
    if (h1 === h0) return; // already at the bound — nothing to do
    const target = currentEntry(h1);
    if (!target) return;

    // Sentinel before the blob writes (COR-9), mirroring applyManualCrop.
    await this.markStageRunning(screenshotId, "cropping");
    const { dimensions, originalDimensions } = await this.deriveCropFromOriginal(
      screenshotId,
      target.crop,
    );

    // Re-read AFTER the blob writes so the event id is derived from current
    // on-disk metadata (COR-13).
    const fresh = await this.storage.getScreenshot(screenshotId);
    if (!fresh) return;
    const pp = getPreprocessing(fresh);
    const updated = this.invalidateStagesAfter(addEvent(pp, "cropping", SS.COMPLETED, {
      was_cropped: target.crop !== null,
      was_patched: false,
      manual: target.source === "manual",
      ...(target.crop ? { crop_region: target.crop } : {}),
      original_dimensions: [originalDimensions.width, originalDimensions.height],
      cropped_dimensions: [dimensions.width, dimensions.height],
      restored_from_history: true,
    }), "cropping");
    await this.storage.updateScreenshot(screenshotId, {
      processing_metadata: withCropHistory(setPreprocessing(fresh, updated), h1),
      grid_upper_left_x: target.grid.ulx,
      grid_upper_left_y: target.grid.uly,
      grid_lower_right_x: target.grid.lrx,
      grid_lower_right_y: target.grid.lry,
      extracted_title: null,
      extracted_total: null,
      extracted_hourly_data: null,
      alignment_score: null,
      grid_registration_score: null,
      processing_status: "pending",
      processing_issues: [],
      has_blocking_issues: false,
      processed_at: null,
    });
  }

  /**
   * Re-materialize a crop state by cropping the preserved `original` by `rect`
   * (null = full original) and writing it as the current image + `cropping`
   * stage blob. Returns the produced and original dimensions. Throws when no
   * original survives (e.g. post-redaction) — the state can't be reconstructed.
   */
  private async deriveCropFromOriginal(
    screenshotId: number,
    rect: CropRect | null,
  ): Promise<{
    dimensions: { width: number; height: number };
    originalDimensions: { width: number; height: number };
  }> {
    const originalBlob = await this.storage.getStageBlob(screenshotId, "original");
    const baseBlob = originalBlob ?? (await this.storage.getImageBlob(screenshotId));
    if (!baseBlob) throw new Error("No original image to reconstruct the crop from");
    const originalDimensions = await this.blobDimensions(baseBlob);

    if (!rect) {
      // Uncropped state — the current image is the original itself.
      await this.storage.saveStageBlob(screenshotId, "cropping", baseBlob);
      await this.storage.saveImageBlob(screenshotId, baseBlob);
      return { dimensions: originalDimensions, originalDimensions };
    }

    const cropResult = await this.getCropWorkerPool().cropBlobToRect(
      baseBlob,
      rect,
      originalDimensions,
    );
    const croppedBlob = cropResult.croppedBlob;
    await this.storage.saveStageBlob(screenshotId, "cropping", croppedBlob);
    await this.storage.saveImageBlob(screenshotId, croppedBlob);
    return { dimensions: cropResult.croppedDimensions, originalDimensions };
  }

  /** Header-read dimensions, falling back to a full decode if the header read fails. */
  private async blobDimensions(blob: Blob): Promise<{ width: number; height: number }> {
    const dims = await readImageDimensions(blob);
    if (dims) return { width: dims.width, height: dims.height };
    return this.getCropWorkerPool().readBlobDimensions(blob);
  }

  /** The crop state currently in effect, derived from the latest cropping event,
   *  used to seed the undo history's baseline entry. */
  private async cropStateBefore(
    screenshotId: number,
    screenshot: Screenshot,
  ): Promise<CropHistoryEntry> {
    const grid: GridSnapshot = {
      ulx: screenshot.grid_upper_left_x ?? null,
      uly: screenshot.grid_upper_left_y ?? null,
      lrx: screenshot.grid_lower_right_x ?? null,
      lry: screenshot.grid_lower_right_y ?? null,
    };
    const pp = getPreprocessing(screenshot);
    const evId = pp.current_events.cropping;
    const res = (evId ? pp.events.find((e) => e.event_id === evId)?.result : undefined) as
      | Record<string, unknown>
      | undefined;

    // A prior manual crop carries its exact rectangle.
    if (res?.manual === true && res.crop_region) {
      return { crop: res.crop_region as CropRect, grid, source: "manual" };
    }
    // An auto-crop is reconstructable from the original dimensions (deterministic).
    if (res?.was_cropped === true) {
      const dimsArr = res.original_dimensions as [number, number] | undefined;
      let dims = dimsArr ? { width: dimsArr[0], height: dimsArr[1] } : null;
      if (!dims) {
        const original = await this.storage.getStageBlob(screenshotId, "original");
        dims = original ? await this.blobDimensions(original) : null;
      }
      const rect = dims ? autoCropRect(dims.width, dims.height) : null;
      return { crop: rect, grid, source: rect ? "auto" : "none" };
    }
    // Never cropped — the baseline is the full original.
    return { crop: null, grid, source: "none" };
  }

  async getPHIRegions(screenshotId: number): Promise<PHIRegionsResponse> {
    if (!this.enablePhi) return { regions: [], source: null, event_id: null };
    const screenshot = await this.storage.getScreenshot(screenshotId);
    if (!screenshot) return { regions: [], source: null, event_id: null };

    const pp = getPreprocessing(screenshot);
    const detectionEventId = pp.current_events.phi_detection;
    const detectionEvent = pp.events.find((e) => e.event_id === detectionEventId);
    return {
      regions: (detectionEvent?.result?.phi_entities ?? []) as PHIRegionRect[],
      source: "wasm",
      event_id: detectionEventId ?? null,
    };
  }

  async savePHIRegions(screenshotId: number, body: { regions: PHIRegionRect[]; preset: string }): Promise<void> {
    if (!this.enablePhi) {
      throw new Error("PHI editing is disabled in this mode");
    }
    const screenshot = await this.storage.getScreenshot(screenshotId);
    if (!screenshot) throw new Error(`Screenshot ${screenshotId} not found`);

    const pp = getPreprocessing(screenshot);
    const updated = addEvent(pp, "phi_detection", SS.COMPLETED, {
      phi_detected: body.regions?.length > 0,
      regions_count: body.regions?.length ?? 0,
      phi_entities: body.regions ?? [],
      reviewed: true,
    });

    await this.storage.updateScreenshot(screenshotId, {
      processing_metadata: setPreprocessing(screenshot, updated),
    });
  }

  async applyRedaction(screenshotId: number, body: { regions: PHIRegionRect[]; redaction_method: string }): Promise<void> {
    return withScreenshotLock(screenshotId, () => this.applyRedactionLocked(screenshotId, body));
  }

  private async applyRedactionLocked(screenshotId: number, body: { regions: PHIRegionRect[]; redaction_method: string }): Promise<void> {
    if (!this.enablePhi) {
      throw new Error("PHI redaction is disabled in this mode");
    }
    const blob = await this.storage.getImageBlob(screenshotId);
    if (!blob) throw new Error("No image blob for redaction");

    const regions = (body.regions ?? []) as PHIRegion[];
    const method = (body.redaction_method ?? "redbox") as "redbox" | "blackbox" | "pixelate";

    // Sentinel: mark phi_redaction running before the irreversible blob writes
    // (saveImageBlob + deletePreRedactionBlobs destroy the un-redacted source) so
    // a crash mid-redaction is reconciled instead of leaving a half-redacted
    // record stuck with its pre-redaction status. The batch path already does
    // this; the interactive path (PHIRegionEditor Save/Redact) did not.
    await this.markStageRunning(screenshotId, "phi_redaction");

    const { redactImage } = await this.loadPhiRedactModule();
    const redactedBlob = await redactImage(blob, regions, method);
    await this.storage.saveImageBlob(screenshotId, redactedBlob);
    await this.storage.saveStageBlob(screenshotId, "phi_redaction", redactedBlob);
    // Securely drop the un-redacted source imagery now a clean blob exists.
    await this.storage.deletePreRedactionBlobs(screenshotId);

    const screenshot = await this.storage.getScreenshot(screenshotId);
    if (screenshot) {
      // Scrub the verbatim PHI text out of the detection event metadata.
      const pp = scrubPhiDetectionEvent(getPreprocessing(screenshot));
      const updated = addEvent(pp, "phi_redaction", SS.COMPLETED, {
        phi_detected: regions.length > 0,
        redacted: true,
        redaction_method: method,
        regions_redacted: regions.length,
      });
      await this.storage.updateScreenshot(screenshotId, {
        processing_metadata: setPreprocessing(screenshot, updated),
      });
    }
  }

  async getDetails(screenshotId: number): Promise<PreprocessingDetailsResponse | null> {
    const screenshot = await this.storage.getScreenshot(screenshotId);
    if (!screenshot) return null;
    const pp = getPreprocessing(screenshot);
    // Build a PreprocessingDetailsResponse from the stored metadata
    const devEvent = pp.events.find((e) => e.event_id === pp.current_events.device_detection);
    const cropEvent = pp.events.find((e) => e.event_id === pp.current_events.cropping);
    const phiDetEvent = pp.events.find((e) => e.event_id === pp.current_events.phi_detection);
    const phiRedEvent = pp.events.find((e) => e.event_id === pp.current_events.phi_redaction);
    return {
      has_preprocessing: Object.keys(pp.stage_status).length > 0,
      device_detection: devEvent?.result ?? null,
      cropping: cropEvent?.result ?? null,
      phi_detection: phiDetEvent?.result ?? null,
      phi_redaction: phiRedEvent?.result ?? null,
      stage_status: pp.stage_status,
      current_events: pp.current_events,
    } as PreprocessingDetailsResponse;
  }

  /**
   * Revoking LRU of stage-blob object URLs. Keyed by `${screenshotId}:${stage}`.
   * Evicted entries have their blob URL released via URL.revokeObjectURL — the
   * old unbounded Map dropped 50 entries at a time WITHOUT revoking, leaking a
   * blob URL (and its backing blob) on every drop.
   */
  // These are review-panel images (original / cropping / phi_redaction stage
  // blobs) — one or two on screen at a time, and the "original" pre-crop frames
  // are the largest in the system. Treat this as a RAM residency budget rather
  // than a fixed UI constant.
  private stageBlobUrls = createRevokingURLCache<string>(
    computeStageImageUrlCacheSize(browserResourceNumber("deviceMemory")),
  );

  async getStageImageUrl(screenshotId: number, stage: string): Promise<string> {
    // Map each stage to the blob that represents what it saw / produced.
    // device_detection has no image output of its own — it runs on the pristine
    // PRE-CROP source, preserved as the "original" stage blob. Serving that (not
    // the current, already-cropped blob) is why the device-detection review
    // thumbnail shows the uncropped screenshot detection actually measured.
    // cropping / phi_redaction each save their own output snapshot.
    const blobStage = stage === "device_detection" ? "original" : stage;
    let blob: Blob | null = null;
    if (blobStage === "original" || blobStage === "cropping" || blobStage === "phi_redaction") {
      blob = await this.storage.getStageBlob(screenshotId, blobStage);
    }
    // Fall back to the current image when the stage snapshot is absent (e.g.
    // redaction deletes "original"; the no-crop fast path skips the "cropping"
    // snapshot since it would equal the current blob; or legacy data predating
    // stage snapshots).
    // Read the blob and mint a FRESH URL below — must NOT return getImageUrl()'s
    // shared-cache URL here: useScreenshotImageUrl revokes every getStageImageUrl
    // result on cleanup, which would poison the shared imageURLCache entry and
    // break this screenshot's thumbnail in every getImageUrl-based view.
    if (!blob) {
      blob = await this.storage.getImageBlob(screenshotId);
    }
    if (!blob) throw new Error(`No image blob for screenshot ${screenshotId}`);
    // Key by the REQUESTED stage, never by blobStage — keying device_detection
    // under "original" would collide with getOriginalImageUrl's shared
    // `${id}:original` cache entry and revoke a URL it still hands out. The
    // revoking LRU releases evicted/overwritten URLs; the hook also revokes on
    // cleanup (a harmless double-revoke). getStageImageUrl always mints a fresh
    // URL and never returns a cached one, so a revoked entry is never served.
    const url = URL.createObjectURL(blob);
    this.stageBlobUrls.set(`${screenshotId}:${stage}`, url);
    return url;
  }

  async getImageUrl(screenshotId: number): Promise<string> {
    const url = await cachedCreateObjectURL(screenshotId);
    if (!url) throw new Error(`No image blob for screenshot ${screenshotId}`);
    return url;
  }
}
