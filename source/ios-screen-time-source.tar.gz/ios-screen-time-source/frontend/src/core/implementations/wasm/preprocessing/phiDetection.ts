/**
 * Client-side PHI detection using the Rust+leptess OCR (via Emscripten WASM)
 * + Transformers.js NER + regex patterns.
 *
 * Replicates the server's Presidio + regex pipeline:
 * 1. OCR with `pipeline_phi_words` (Rust + libtesseract) → words with bboxes
 * 2. NER with BERT (via Web Worker) → PERSON, ORG, LOC, MISC entities
 * 3. Regex patterns → email, phone, SSN, MRN, etc.
 * 4. Allow-list filtering → remove known false positives (app names, UI labels)
 * 5. Map matches back to image coordinates via OCR word bboxes
 */

import type { PHIRegion } from "@/core/interfaces/IPreprocessingService";
import { decodeImage, emPhiWords } from "@/core/implementations/wasm/processing/emscripten/pipelineLoader";
import { assertDecodedPixelBudget, readImageDimensions } from "@/core/implementations/wasm/utils/imageLimits";
import { displayText } from "@/lib/displayText";
import type { NerEntity, NerRequest, NerResponse } from "./nerWorkerProtocol";
export type { PHIRegion };

export interface PHIDetectionResult {
  regions: PHIRegion[];
  ocrText: string;
  ocrConfidence: number;
  /** Indicates whether the NER engine ran successfully. "skipped" means only regex ran. */
  nerStatus: "success" | "failed" | "timeout" | "skipped";
}

// Word with bounding box from Tesseract.js
interface OCRWord {
  text: string;
  bbox: { x0: number; y0: number; x1: number; y1: number };
  confidence: number;
  charStart: number; // offset into full text
  charEnd: number;
}

// NER entity from worker
/** Declared once, in the worker protocol both sides compile against. */
type NEREntity = NerEntity;

// ---------------------------------------------------------------------------
// Regex patterns (ported from Python phi-detector-remover/core/detectors/regex.py)
// ---------------------------------------------------------------------------

const REGEX_PATTERNS: Array<{ label: string; pattern: RegExp }> = [
  { label: "email", pattern: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g },
  { label: "phone", pattern: /(\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/g },
  // SSN with IRS validation: exclude 000/666/9xx area numbers, 00 group, 0000 serial
  { label: "ssn", pattern: /\b(?!000|666|9\d{2})\d{3}[-.]?(?!00)\d{2}[-.]?(?!0000)\d{4}\b/g },
  { label: "mrn", pattern: /(?:MRN|Medical Record|Record #)[:\s]*(\d{6,10})/gi },
  { label: "study_id", pattern: /(?:EXAMPLE_STUDY|STUDY)[_-]?\d{4}(?:[_-]\d+)?/gi },
  { label: "zip", pattern: /\b\d{5}(?:-\d{4})?\b/g },
  { label: "url", pattern: /https?:\/\/[^\s]+/g },
  { label: "ip_address", pattern: /\b(?:\d{1,3}\.){3}\d{1,3}\b/g },
  { label: "credit_card", pattern: /\b(?:\d{4}[-\s]?){3}\d{4}\b/g },
  // Apple device serial (12 alphanumeric chars)
  { label: "device_serial", pattern: /\b[A-Z0-9]{12}\b/g },
  // IMEI (15 digits)
  { label: "imei", pattern: /\b\d{15}\b/g },
  // UUID
  { label: "uuid", pattern: /\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/gi },
];

// ---------------------------------------------------------------------------
// Allow-list — matching server Presidio config
// Terms that should never be flagged as PHI in iOS Screen Time screenshots
// ---------------------------------------------------------------------------

const ALLOW_LIST = new Set([
  // Wi-Fi variations
  "Wi-Fi", "WiFi", "wi",
  // App names commonly flagged as PERSON/ORG
  "Disney", "Disney+", "Lingokids", "Photo Booth",
  "Screen Time", "App Store", "Control Center", "Bluetooth",
  "YT Kids", "YT", "YouTube", "YouTube Kids",
  "TikTok", "Instagram", "Safari", "Netflix",
  "Roblox", "Minecraft", "Fortnite",
  "PBS Kids", "Nick Jr",
  // UI labels
  "Daily Average", "Pickups", "Notifications",
  "Most Used", "Show More", "Show Less",
  "Settings", "General", "Privacy",
  // Time strings (common OCR noise)
  "12 AM", "12AM", "AM", "PM",
]);

// Case-insensitive version for comparison
const ALLOW_LIST_LOWER = new Set([...ALLOW_LIST].map((s) => s.toLowerCase()));

// Entity types to exclude (matching server Presidio config — too many false positives)
const EXCLUDED_ENTITY_TYPES = new Set(["DATE_TIME", "LOCATION", "LOC"]);

// Min bounding box area to consider a valid detection
const MIN_BBOX_AREA = 100;

// ---------------------------------------------------------------------------
// NER Worker management
// ---------------------------------------------------------------------------

let nerWorker: Worker | null = null;
let nerRequestId = 0;
const pendingNER = new Map<number, {
  resolve: (result: NERResult) => void;
  reject: (err: Error) => void;
}>();

/**
 * Sticky NER health status. When the NER model fails to load (CSP blocked the
 * HuggingFace CDN, offline, missing local copy), PHI detection silently
 * degrades to regex-only — a detection-completeness gap. This flag makes that
 * VISIBLE: a non-null value means NER is unavailable and the caller/UI should
 * warn the user that detection is regex-only.
 */
let nerLoadError: string | null = null;

/** Returns a human-readable NER failure reason, or null if NER is healthy. */
export function getNerHealthStatus(): string | null {
  return nerLoadError;
}

interface NERResult {
  entities: NEREntity[];
  status: "success" | "failed" | "timeout" | "skipped";
}

function abortError(message = "PHI detection aborted"): Error {
  try {
    return new DOMException(message, "AbortError");
  } catch {
    const error = new Error(message);
    error.name = "AbortError";
    return error;
  }
}

function throwIfAborted(signal?: AbortSignal): void {
  if (signal?.aborted) throw abortError();
}

let phiOcrQueueTail: Promise<void> = Promise.resolve();
let nerQueueTail: Promise<void> = Promise.resolve();

async function waitForExclusiveTurn(previous: Promise<void>, signal?: AbortSignal): Promise<void> {
  if (!signal) {
    await previous.catch(() => {
      /* non-fatal: we are only waiting for our turn in the queue. Whether the
         PREVIOUS job succeeded is that caller's business — its rejection is
         delivered to whoever awaited it, and must not deny us the lock. */
    });
    return;
  }
  if (signal.aborted) throw abortError();
  await new Promise<void>((resolve, reject) => {
    const onAbort = () => {
      cleanup();
      reject(abortError());
    };
    const cleanup = () => signal.removeEventListener("abort", onAbort);
    signal.addEventListener("abort", onAbort, { once: true });
    void previous
      .catch(() => {
        /* non-fatal: same as above — a failed predecessor still releases the
           queue, so we proceed to our turn rather than hanging forever. */
      })
      .then(() => {
        cleanup();
        resolve();
      });
  });
}

function enqueueExclusive<T>(
  queue: "phi_ocr" | "ner",
  signal: AbortSignal | undefined,
  job: () => Promise<T>,
): Promise<T> {
  const previous = queue === "phi_ocr" ? phiOcrQueueTail : nerQueueTail;
  let release!: () => void;
  const current = new Promise<void>((resolve) => {
    release = resolve;
  });
  const nextTail = previous
    .catch(() => {
      /* non-fatal: this is the QUEUE TAIL, not the job result. Letting one
         job's rejection through here would poison the chain and wedge every
         later PHI request; the rejection is still returned to its own caller. */
    })
    .then(() => current);
  if (queue === "phi_ocr") phiOcrQueueTail = nextTail;
  else nerQueueTail = nextTail;

  return (async () => {
    try {
      await waitForExclusiveTurn(previous, signal);
      throwIfAborted(signal);
      return await job();
    } finally {
      release();
    }
  })();
}

/**
 * Typed send to the NER worker.
 *
 * `Worker.postMessage` takes `any`, so the protocol was only enforced on the
 * receiving side: renaming a field here would still compile, and the worker
 * would call the model with `undefined` and fall through to its catch — every
 * PHI detection silently degrading to regex-only. This binds the sender to the
 * same declaration the worker reads.
 */
function postToNerWorker(worker: Worker, message: NerRequest): void {
  worker.postMessage(message);
}

function getNERWorker(): Worker {
  if (!nerWorker) {
    nerWorker = new Worker(
      new URL("./nerWorker.ts", import.meta.url),
      { type: "module" },
    );
    nerWorker.onmessage = (e: MessageEvent<NerResponse>) => {
      const message = e.data;
      if (message.type === "ready") {
        // Model loaded — clear any prior failure.
        nerLoadError = null;
        return;
      }
      if (message.type === "error") {
        // Model failed to load — record visibly so detection-quality
        // degradation to regex-only is surfaced, not silent.
        nerLoadError = message.error || "NER model failed to load";
        console.warn(
          `[phiDetection] NER unavailable — PHI detection is regex-only: ${nerLoadError}`,
        );
        return;
      }
      const { id, entities, error } = message;
      const pending = pendingNER.get(id);
      if (pending) {
        pendingNER.delete(id);
        if (error) {
          console.warn(`[phiDetection] NER failed for request ${id}: ${error} — falling back to regex-only`);
          pending.resolve({ entities: [], status: "failed" });
        } else {
          pending.resolve({ entities, status: "success" });
        }
      }
    };
    nerWorker.onerror = (e: ErrorEvent) => {
      console.error("[phiDetection] NER worker error:", e.message);
      nerLoadError = e.message || "NER worker crashed";
      // Reject all pending requests
      for (const [id, pending] of pendingNER) {
        pending.resolve({ entities: [], status: "failed" });
        pendingNER.delete(id);
      }
      // Worker is broken — reset so it gets recreated on next call
      nerWorker = null;
    };
    // Pre-initialize the pipeline
    postToNerWorker(nerWorker, { type: "init" });
  }
  return nerWorker;
}

async function runNER(text: string, signal?: AbortSignal): Promise<NERResult> {
  throwIfAborted(signal);
  if (!text.trim()) return { entities: [], status: "skipped" };

  return enqueueExclusive("ner", signal, () => runNERExclusive(text, signal));
}

async function runNERExclusive(text: string, signal?: AbortSignal): Promise<NERResult> {
  const worker = getNERWorker();
  const id = ++nerRequestId;

  return new Promise((resolve, reject) => {
    let timeoutId: ReturnType<typeof setTimeout> | null = null;
    const cleanup = () => {
      if (timeoutId !== null) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
      signal?.removeEventListener("abort", onAbort);
    };
    const onAbort = () => {
      pendingNER.delete(id);
      cleanup();
      reject(abortError());
    };
    if (signal?.aborted) {
      reject(abortError());
      return;
    }

    pendingNER.set(id, {
      resolve: (result) => {
        cleanup();
        resolve(result);
      },
      reject: (err) => {
        cleanup();
        reject(err);
      },
    });
    signal?.addEventListener("abort", onAbort, { once: true });
    postToNerWorker(worker, { text, id });

    // Timeout after 60s (model download on first run can exceed 30s)
    timeoutId = setTimeout(() => {
      if (pendingNER.has(id)) {
        pendingNER.delete(id);
        cleanup();
        console.warn(`[phiDetection] NER timed out after 60s for request ${id} — falling back to regex-only`);
        resolve({ entities: [], status: "timeout" });
      }
    }, 60_000);
  });
}

// ---------------------------------------------------------------------------
// OCR helper — full-page Rust OCR via the Emscripten pipeline.
//
// Replaces Tesseract.js. The Rust side returns word-level boxes with
// confidence and pre-computed char offsets into a joined `full_text`,
// matching the contract that NER/regex/allow-list code below already uses.
// ---------------------------------------------------------------------------

async function blobToImageData(imageBlob: Blob, signal?: AbortSignal): Promise<ImageData> {
  throwIfAborted(signal);
  const headerDims = await readImageDimensions(imageBlob);
  if (headerDims) assertDecodedPixelBudget(headerDims.width, headerDims.height);
  throwIfAborted(signal);
  const { width, height, data } = await decodeImage(new Uint8Array(await imageBlob.arrayBuffer()));
  throwIfAborted(signal);
  return {
    width,
    height,
    data: new Uint8ClampedArray(data.buffer as ArrayBuffer, data.byteOffset, data.byteLength),
    colorSpace: "srgb",
  };
}

async function ocrWithBboxes(imageBlob: Blob, signal?: AbortSignal): Promise<{
  words: OCRWord[];
  fullText: string;
  confidence: number;
}> {
  return enqueueExclusive("phi_ocr", signal, async () => {
    const imageData = await blobToImageData(imageBlob, signal);
    throwIfAborted(signal);
    const result = await emPhiWords(imageData);
    throwIfAborted(signal);

    if (!result.success || !result.words) {
      throw new Error(`PHI OCR failed: ${result.error ?? "unknown"}`);
    }

    const words: OCRWord[] = result.words.map((w) => ({
      text: w.text,
      bbox: { x0: w.x, y0: w.y, x1: w.x + w.w, y1: w.y + w.h },
      confidence: w.conf,
      charStart: w.char_start,
      charEnd: w.char_end,
    }));

    return {
      words,
      fullText: result.full_text ?? "",
      // Tesseract conf is 0–100; downstream consumers don't care about scale,
      // but keep it as a number.
      confidence: result.avg_confidence ?? 0,
    };
  });
}

// ---------------------------------------------------------------------------
// Map text offsets back to image bounding boxes
// ---------------------------------------------------------------------------

function offsetToRegion(
  start: number,
  end: number,
  words: OCRWord[],
): { x: number; y: number; w: number; h: number } | null {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  let found = false;

  for (const word of words) {
    // Check if word overlaps with the match range
    if (word.charEnd > start && word.charStart < end) {
      found = true;
      minX = Math.min(minX, word.bbox.x0);
      minY = Math.min(minY, word.bbox.y0);
      maxX = Math.max(maxX, word.bbox.x1);
      maxY = Math.max(maxY, word.bbox.y1);
    }
  }

  if (!found) return null;

  return {
    x: minX,
    y: minY,
    w: maxX - minX,
    h: maxY - minY,
  };
}

// ---------------------------------------------------------------------------
// Check if a detected text is in the allow list
// ---------------------------------------------------------------------------

function isAllowListed(text: string): boolean {
  const trimmed = text.trim();
  if (ALLOW_LIST.has(trimmed)) return true;
  const trimmedLower = trimmed.toLowerCase();
  if (ALLOW_LIST_LOWER.has(trimmedLower)) return true;

  // Check if the text is a substring of an allow-listed term
  if (trimmed.length >= 3) {
    for (const allowedLower of ALLOW_LIST_LOWER) {
      if (allowedLower.includes(trimmedLower)) return true;
    }
  }
  return false;
}

// ---------------------------------------------------------------------------
// Main detection function
// ---------------------------------------------------------------------------

export interface DetectPHIOptions {
  llmEndpoint?: string | undefined;
  llmModel?: string | undefined;
  llmApiKey?: string | undefined;
  /**
   * Explicit consent to send OCR'd screenshot text (which is PHI by
   * definition) to the configured LLM endpoint. The LLM path is the one part
   * of WASM mode that leaves the device — it is OFF unless the caller passes
   * `true` here, even when an endpoint is configured.
   */
  llmConsent?: boolean | undefined;
  abortSignal?: AbortSignal | undefined;
}

export async function detectPHI(imageBlob: Blob, options?: DetectPHIOptions): Promise<PHIDetectionResult> {
  throwIfAborted(options?.abortSignal);
  // Step 1: OCR with bounding boxes
  const { words, fullText, confidence } = await ocrWithBboxes(imageBlob, options?.abortSignal);
  throwIfAborted(options?.abortSignal);

  if (!fullText.trim()) {
    return { regions: [], ocrText: "", ocrConfidence: 0, nerStatus: "skipped" };
  }

  // Step 2 & 3: Run NER, regex, and optionally LLM in parallel.
  // The LLM path sends PHI off-device — gate it on explicit consent.
  const llmEndpoint = options?.llmEndpoint;
  const llmModel = options?.llmModel;
  const llmConfigured = Boolean(llmEndpoint && llmModel);
  if (llmConfigured && !options?.llmConsent) {
    console.warn(
      "[phiDetection] LLM endpoint is configured but consent was not given — " +
        "skipping off-device LLM detection (NER + regex only).",
    );
  }
  const tasks: [Promise<NERResult>, Promise<RegexMatch[]>, Promise<LLMEntity[]>] = [
    runNER(fullText, options?.abortSignal),
    Promise.resolve(findRegexMatches(fullText)),
    llmEndpoint && llmModel && options?.llmConsent
      ? runLLMDetection(fullText, llmEndpoint, llmModel, options.llmApiKey, options.abortSignal)
      : Promise.resolve([]),
  ];

  const [nerResult, regexMatches, llmEntities] = await Promise.all(tasks);
  throwIfAborted(options?.abortSignal);

  const nerEntities = nerResult.entities;

  const regions: PHIRegion[] = [];

  // Step 4: Process NER results
  for (const entity of nerEntities) {
    throwIfAborted(options?.abortSignal);
    if (EXCLUDED_ENTITY_TYPES.has(entity.entity_group)) continue;
    if (isAllowListed(entity.word)) continue;

    const bbox = offsetToRegion(entity.start, entity.end, words);
    if (!bbox) continue;
    if (bbox.w * bbox.h < MIN_BBOX_AREA) continue;

    regions.push({
      ...bbox,
      label: entity.entity_group,
      source: "ner",
      confidence: entity.score,
      text: entity.word,
    });
  }

  // Step 5: Process regex matches
  for (const match of regexMatches) {
    throwIfAborted(options?.abortSignal);
    if (isAllowListed(match.text)) continue;

    const bbox = offsetToRegion(match.start, match.end, words);
    if (!bbox) continue;
    if (bbox.w * bbox.h < MIN_BBOX_AREA) continue;

    if (isDuplicateRegion(regions, bbox)) continue;

    regions.push({
      ...bbox,
      label: match.label,
      source: "regex",
      confidence: 0.85,
      text: match.text,
    });
  }

  // Step 6: Process LLM results
  for (const entity of llmEntities) {
    throwIfAborted(options?.abortSignal);
    if (isAllowListed(entity.text)) continue;

    const bbox = offsetToRegion(entity.start, entity.end, words);
    if (!bbox) continue;
    if (bbox.w * bbox.h < MIN_BBOX_AREA) continue;

    if (isDuplicateRegion(regions, bbox)) continue;

    regions.push({
      ...bbox,
      label: entity.label,
      source: `llm:${options?.llmModel ?? "unknown"}`,
      confidence: entity.confidence,
      text: entity.text,
    });
  }

  return {
    regions,
    ocrText: fullText,
    ocrConfidence: confidence,
    nerStatus: nerResult.status,
  };
}

function isDuplicateRegion(
  existing: PHIRegion[],
  bbox: { x: number; y: number; w: number; h: number },
): boolean {
  return existing.some(
    (r) =>
      Math.abs(r.x - bbox.x) < 5 &&
      Math.abs(r.y - bbox.y) < 5 &&
      Math.abs(r.w - bbox.w) < 10 &&
      Math.abs(r.h - bbox.h) < 10,
  );
}

// ---------------------------------------------------------------------------
// LLM-assisted detection — calls an OpenAI-compatible chat/completions endpoint
// ---------------------------------------------------------------------------

interface LLMEntity {
  label: string;
  text: string;
  start: number;
  end: number;
  confidence: number;
}

const LLM_SYSTEM_PROMPT = `You are a PHI (Protected Health Information) detector for iOS Screen Time screenshots.
Given OCR-extracted text, identify ALL personally identifiable information.

Return ONLY a JSON array of objects with these fields:
- "label": entity type (PERSON, PHONE, EMAIL, SSN, MRN, ADDRESS, DATE_OF_BIRTH, MEDICAL_RECORD, DEVICE_ID)
- "text": the exact text matched (must appear verbatim in the input)
- "confidence": 0.0-1.0

Example: [{"label":"PERSON","text":"John Smith","confidence":0.95}]

If no PHI is found, return an empty array: []
Do NOT include app names, UI labels, or time strings. Only real PHI.`;

async function runLLMDetection(
  fullText: string,
  endpoint: string,
  model: string,
  apiKey?: string,
  signal?: AbortSignal,
): Promise<LLMEntity[]> {
  try {
    throwIfAborted(signal);
    // Validate the endpoint and refuse to send PHI over plaintext transport.
    let parsedUrl: URL;
    try {
      parsedUrl = new URL(`${endpoint.replace(/\/+$/, "")}/chat/completions`);
    } catch {
      console.error("[phiDetection] LLM endpoint is not a valid URL — skipping LLM detection");
      return [];
    }
    const isLocalHost =
      parsedUrl.hostname === "localhost" ||
      parsedUrl.hostname === "127.0.0.1" ||
      parsedUrl.hostname === "[::1]";
    if (parsedUrl.protocol !== "https:" && !isLocalHost) {
      console.error(
        `[phiDetection] refusing to send PHI to a non-HTTPS LLM endpoint (${parsedUrl.hostname}) — skipping`,
      );
      return [];
    }
    const url = parsedUrl.toString();
    console.warn(
      `[phiDetection] sending OCR text off-device to LLM endpoint ${parsedUrl.host} (model ${model})`,
    );

    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (apiKey) {
      headers["Authorization"] = `Bearer ${apiKey}`;
    }

    const requestInit: RequestInit = {
      method: "POST",
      headers,
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: LLM_SYSTEM_PROMPT },
          { role: "user", content: `Analyze this OCR text for PHI:\n\n${fullText}` },
        ],
        temperature: 0.1,
        max_tokens: 2048,
      }),
    };
    if (signal) requestInit.signal = signal;
    const response = await fetch(url, requestInit);
    throwIfAborted(signal);

    if (!response.ok) {
      console.error(`[phiDetection] LLM request failed: ${response.status} ${response.statusText}`);
      return [];
    }

    // OpenAI-compatible chat-completions envelope. Only the first choice's
    // message content is read; everything else in the response is ignored.
    const data = (await response.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    throwIfAborted(signal);
    const content = data.choices?.[0]?.message?.content ?? "";

    // Parse JSON from response (may be wrapped in ```json ... ```)
    const jsonMatch = /\[[\s\S]*\]/.exec(content);
    if (!jsonMatch) {
      // Do NOT log the response content — it echoes back the PHI just sent.
      console.warn(
        `[phiDetection] LLM response contained no JSON array (${content.length} chars) — skipping LLM detection`,
      );
      return [];
    }

    // Model-authored JSON: every field is checked in the loop below.
    const parsed: unknown = JSON.parse(jsonMatch[0]);
    if (!Array.isArray(parsed)) return [];
    const items = parsed as Array<{
      label?: unknown;
      text?: unknown;
      confidence?: unknown;
    }>;

    // Map LLM entities back to text offsets
    const entities: LLMEntity[] = [];
    const textLower = fullText.toLowerCase();
    for (const item of items) {
      throwIfAborted(signal);
      const { label, text, confidence } = item;
      if (typeof text !== "string" || !text) continue;
      // The label only names the span; the SPAN is what gets redacted. A model
      // that returns a non-string label must not cost us the redaction, so it
      // is coerced rather than treated as a reason to skip the entity.
      if (label === undefined || label === null || label === "") continue;
      const labelText =
        typeof label === "string" ? label : displayText(label) || "PHI";
      const idx = textLower.indexOf(text.toLowerCase());
      if (idx === -1) continue;
      entities.push({
        label: labelText,
        text,
        start: idx,
        end: idx + text.length,
        confidence: typeof confidence === "number" ? confidence : 0.8,
      });
    }

    return entities;
  } catch (err) {
    if (err instanceof Error && err.name === "AbortError") throw err;
    console.error("[phiDetection] LLM detection failed:", err);
    return [];
  }
}

// ---------------------------------------------------------------------------
// Regex matching helper
// ---------------------------------------------------------------------------

interface RegexMatch {
  label: string;
  text: string;
  start: number;
  end: number;
}

function findRegexMatches(text: string): RegexMatch[] {
  const matches: RegexMatch[] = [];

  for (const { label, pattern } of REGEX_PATTERNS) {
    // Reset regex state (lastIndex)
    const re = new RegExp(pattern.source, pattern.flags);
    let match: RegExpExecArray | null;

    while ((match = re.exec(text)) !== null) {
      matches.push({
        label,
        text: match[0],
        start: match.index,
        end: match.index + match[0].length,
      });
    }
  }

  return matches;
}

/**
 * Terminate the NER worker to free resources.
 * Call when preprocessing is complete or component unmounts.
 */
export function terminateNERWorker(): void {
  if (nerWorker) {
    nerWorker.terminate();
    nerWorker = null;
    pendingNER.clear();
  }
}
