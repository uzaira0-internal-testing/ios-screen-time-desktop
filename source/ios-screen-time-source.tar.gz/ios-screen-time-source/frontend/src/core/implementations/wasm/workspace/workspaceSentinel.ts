/**
 * Crash-recovery sentinel for workspace import (roadmap #22).
 *
 * Import is destructive (it clears the workspace, then restores). If the tab dies
 * mid-restore, the workspace is left partial. We record an "import in progress"
 * marker BEFORE clearing and remove it only on success, so the next boot can detect
 * an interrupted import and warn the user.
 *
 * The marker lives in localStorage — NOT the `settings` table — precisely because
 * import calls clearAll(), which wipes `settings`. A settings-row sentinel would be
 * erased by the very operation it is meant to survive.
 */
const SENTINEL_KEY = "wasm_workspace_import_in_progress";

export interface ImportSentinel {
  startedAt: string;
  source: string;
}

export function markImportStarted(source: string): void {
  try {
    localStorage.setItem(
      SENTINEL_KEY,
      JSON.stringify({ startedAt: new Date().toISOString(), source } satisfies ImportSentinel),
    );
  } catch {
    // localStorage unavailable (private mode / disabled) — the sentinel is
    // best-effort; the import still proceeds.
  }
}

export function clearImportSentinel(): void {
  try {
    localStorage.removeItem(SENTINEL_KEY);
  } catch {
    // ignore
  }
}

/** Returns the marker if a previous import did not finish, else null. */
export function getInterruptedImport(): ImportSentinel | null {
  try {
    const raw = localStorage.getItem(SENTINEL_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<ImportSentinel>;
    if (typeof parsed?.startedAt !== "string") return null;
    return { startedAt: parsed.startedAt, source: parsed.source ?? "unknown" };
  } catch {
    return null;
  }
}
