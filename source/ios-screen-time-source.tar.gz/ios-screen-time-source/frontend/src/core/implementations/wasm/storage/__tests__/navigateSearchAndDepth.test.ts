/**
 * Locks the unified-navigation contract:
 *
 *  1. Search threads into the SAME cursor the selector list uses, so Next/Prev
 *     walk only matching items and current_index/total reflect the searched set
 *     (previously search filtered the list but navigation ignored it).
 *
 *  2. Navigation has no page ceiling: advancing from an item deep in a long
 *     queue lands on the immediate next id — never snaps back toward the top.
 *     This is the primitive skipScreenshot now relies on instead of scanning a
 *     ≤100-item loaded page (which used to throw you back to ~item 100).
 */
import "fake-indexeddb/auto";
import { describe, it, expect, beforeEach } from "bun:test";
import { db } from "../database";
import { IndexedDBStorageService } from "../IndexedDBStorageService";
import type { Screenshot } from "@/types";

const deps = (db as unknown as { _deps: { indexedDB: unknown; IDBKeyRange: unknown } })._deps;
deps.indexedDB = globalThis.indexedDB;
deps.IDBKeyRange = globalThis.IDBKeyRange;

function make(id: number, overrides: Partial<Screenshot>): Screenshot {
  return {
    id,
    group_id: "g1",
    processing_status: "completed",
    annotation_status: "pending",
    extracted_hourly_data: { 0: 30, 1: 30 },
    extracted_title: `Title ${id}`,
    extracted_total: "1h",
    content_hash: `h-${id}`,
    verified_by_user_ids: null,
    ...overrides,
  } as Screenshot;
}

async function reset() {
  await db.delete();
  await db.open();
}

describe("navigateScreenshots — search-aware walk", () => {
  let storage: IndexedDBStorageService;

  beforeEach(async () => {
    await reset();
    storage = new IndexedDBStorageService();
    await db.screenshots.bulkPut([
      make(1, { extracted_title: "Instagram" }),
      make(2, { extracted_title: "YouTube" }),
      make(3, { extracted_title: "Instacart" }),
      make(4, { extracted_title: "TikTok" }),
    ]);
  });

  it("next skips non-matching items to the next match", async () => {
    const res = await storage.navigateScreenshots(1, {
      group_id: "g1",
      search: "insta",
      direction: "next",
    });
    expect(res.screenshot?.id).toBe(3); // skips id 2 (YouTube)
    expect(res.total_in_filter).toBe(2);
  });

  it("prev returns the previous match, not the adjacent id", async () => {
    const res = await storage.navigateScreenshots(3, {
      group_id: "g1",
      search: "insta",
      direction: "prev",
    });
    expect(res.screenshot?.id).toBe(1);
  });

  it("current ranks within the searched set", async () => {
    const res = await storage.navigateScreenshots(1, {
      group_id: "g1",
      search: "insta",
      direction: "current",
    });
    expect(res.current_index).toBe(1);
    expect(res.total_in_filter).toBe(2);
    expect(res.has_prev).toBe(false);
    expect(res.has_next).toBe(true);
  });

  it("next past the last match drains to empty (does not escape the search)", async () => {
    const res = await storage.navigateScreenshots(3, {
      group_id: "g1",
      search: "insta",
      direction: "next",
    });
    expect(res.screenshot).toBeNull();
    expect(res.total_in_filter).toBe(2);
  });
});

describe("navigateScreenshots — no page ceiling deep in a long queue", () => {
  let storage: IndexedDBStorageService;

  beforeEach(async () => {
    await reset();
    storage = new IndexedDBStorageService();
    await db.screenshots.bulkPut(
      Array.from({ length: 250 }, (_, i) => make(i + 1, {})),
    );
  });

  it("advances from a deep item to the immediate next id (was: snap back to ~100)", async () => {
    const res = await storage.navigateScreenshots(150, {
      group_id: "g1",
      direction: "next",
    });
    expect(res.screenshot?.id).toBe(151);
    expect(res.current_index).toBe(151);
    expect(res.total_in_filter).toBe(250);
    expect(res.has_next).toBe(true);
  });

  it("ranks a deep item correctly for the counter", async () => {
    const res = await storage.navigateScreenshots(150, {
      group_id: "g1",
      direction: "current",
    });
    expect(res.current_index).toBe(150);
    expect(res.total_in_filter).toBe(250);
  });
});
