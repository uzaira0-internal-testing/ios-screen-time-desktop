/** Hard cap on decoded pixels — guards against a "decode bomb" where a small
 * compressed file expands to a multi-GB RGBA buffer and crashes the tab. */
export const MAX_DECODED_PIXELS = 50_000_000;

/** Thrown when an image's decoded pixel count exceeds {@link MAX_DECODED_PIXELS}. */
export class ImageTooLargeError extends Error {
  constructor(width: number, height: number) {
    super(
      `Image too large to decode safely (${width}x${height} = ` +
        `${((width * height) / 1_000_000).toFixed(1)} MP, cap ` +
        `${(MAX_DECODED_PIXELS / 1_000_000).toFixed(0)} MP).`,
    );
    this.name = "ImageTooLargeError";
  }
}

export function assertDecodedPixelBudget(width: number, height: number): void {
  if (width * height > MAX_DECODED_PIXELS) {
    throw new ImageTooLargeError(width, height);
  }
}

export interface ImageDimensions {
  width: number;
  height: number;
}

/**
 * Read an image's pixel dimensions from its HEADER bytes without decoding the
 * pixels. This is intentionally storage-free so workers can use it before a
 * decode without pulling IndexedDB/OPFS code into the worker bundle.
 *
 * Supports PNG, JPEG and WebP (the iOS screenshot formats). Returns null for any
 * blob it cannot confidently parse so callers can fall back to a real decode.
 */
export async function readImageDimensions(blob: Blob): Promise<ImageDimensions | null> {
  try {
    // 64 KB is ample: PNG/WebP carry size in the first ~30 bytes; a JPEG's first
    // Start-Of-Frame marker sits before the entropy-coded scan, almost always
    // within the first few KB.
    const HEADER_BYTES = 64 * 1024;
    const buf = await blob.slice(0, Math.min(blob.size, HEADER_BYTES)).arrayBuffer();
    const view = new DataView(buf);
    const len = view.byteLength;
    if (len < 24) return null;

    // PNG: 89 50 4E 47 0D 0A 1A 0A, then IHDR (width @16, height @20, big-endian)
    if (view.getUint32(0) === 0x89504e47 && view.getUint32(4) === 0x0d0a1a0a) {
      const width = view.getUint32(16);
      const height = view.getUint32(20);
      return width > 0 && height > 0 ? { width, height } : null;
    }

    // JPEG: starts FF D8; walk marker segments to the first Start-Of-Frame (SOFn).
    if (view.getUint16(0) === 0xffd8) {
      let offset = 2;
      while (offset + 9 < len) {
        if (view.getUint8(offset) !== 0xff) {
          offset++;
          continue;
        }
        let marker = view.getUint8(offset + 1);
        // Collapse any run of 0xFF fill bytes preceding the marker code.
        while (marker === 0xff && offset + 2 < len) {
          offset++;
          marker = view.getUint8(offset + 1);
        }
        // SOF markers carry dimensions: C0-C3, C5-C7, C9-CB, CD-CF
        // (C4/C8/CC are DHT/JPG/DAC, not frame headers).
        const isSOF =
          (marker >= 0xc0 && marker <= 0xc3) ||
          (marker >= 0xc5 && marker <= 0xc7) ||
          (marker >= 0xc9 && marker <= 0xcb) ||
          (marker >= 0xcd && marker <= 0xcf);
        if (isSOF) {
          // segment: FF marker | length(2) | precision(1) | height(2) | width(2)
          const height = view.getUint16(offset + 5);
          const width = view.getUint16(offset + 7);
          return width > 0 && height > 0 ? { width, height } : null;
        }
        // Standalone markers with no length payload: SOI(D8), EOI(D9), RSTn(D0-D7).
        if (marker === 0xd8 || marker === 0xd9 || (marker >= 0xd0 && marker <= 0xd7)) {
          offset += 2;
          continue;
        }
        // Every other marker is followed by a 2-byte segment length.
        const segLen = view.getUint16(offset + 2);
        if (segLen < 2) return null; // malformed
        offset += 2 + segLen;
      }
      return null;
    }

    // WebP: "RIFF"...."WEBP" then a VP8 (lossy) / VP8L (lossless) / VP8X (ext) chunk.
    if (view.getUint32(0) === 0x52494646 && len >= 30 && view.getUint32(8) === 0x57454250) {
      const fourCC = view.getUint32(12);
      if (fourCC === 0x56503858) {
        // "VP8X": flags(1)+reserved(3), then 24-bit (canvasW-1) and (canvasH-1), LE.
        const w = 1 + (view.getUint8(24) | (view.getUint8(25) << 8) | (view.getUint8(26) << 16));
        const h = 1 + (view.getUint8(27) | (view.getUint8(28) << 8) | (view.getUint8(29) << 16));
        return { width: w, height: h };
      }
      if (fourCC === 0x56503820) {
        // "VP8 " (lossy): 14-bit width @26, height @28, little-endian.
        const w = view.getUint16(26, true) & 0x3fff;
        const h = view.getUint16(28, true) & 0x3fff;
        return w > 0 && h > 0 ? { width: w, height: h } : null;
      }
      if (fourCC === 0x5650384c) {
        // "VP8L" (lossless): 1 signature byte @20, then 14+14 bits packed LE @21.
        const bits =
          view.getUint8(21) |
          (view.getUint8(22) << 8) |
          (view.getUint8(23) << 16) |
          (view.getUint8(24) << 24);
        const w = (bits & 0x3fff) + 1;
        const h = ((bits >>> 14) & 0x3fff) + 1;
        return { width: w, height: h };
      }
      return null;
    }

    return null;
  } catch {
    // Any out-of-bounds read / corrupt header lets callers decode instead.
    return null;
  }
}
