/**
 * Optional OCR language packs — catalogue, download, storage, removal.
 *
 * The pipeline works with English alone: grid detection and bar extraction key
 * on Western digits and chart geometry, so the 24 hourly values extract in any
 * locale that renders Western numerals. A pack raises accuracy of the TEXT
 * reads — most importantly the app name, which IS the title on app-detail
 * pages, and the human-readable total string.
 *
 * Packs are NOT bundled. They are served from this app's own origin under
 * `/tessdata/` and downloaded only when the user asks for one, which is why the
 * default install stays small and the app keeps working with no network at all.
 * A download is the single user-initiated network request this otherwise
 * offline app makes.
 *
 * Bytes live in OPFS under a dedicated `language-packs` directory, kept apart
 * from the screenshot blob store so pack size never pollutes the screenshot
 * storage accounting. Where OPFS is unavailable (WebKit webviews, e.g. the
 * desktop app) they live in a dedicated IndexedDB database instead, the same
 * fallback the screenshot blob store uses.
 */

import { LANGUAGE_PACKS, type LanguagePack } from "@/core/generated/constants";
import { languagePackUrl } from "@/core/implementations/wasm/processing/emscripten/pipelineAssetBase";
import { writeOpfsFile } from "@/core/implementations/wasm/storage/opfsWrite";

/** OPFS directory holding downloaded `<code>.traineddata` files. */
const PACK_DIR = "language-packs";

/** The pack that always exists — bundled with the app, never downloadable. */
export const BUNDLED_LANGUAGE = "eng";

/** IndexedDB fallback for engines without OPFS: one store, pack code → bytes. */
const IDB_NAME = "language-packs";
const IDB_STORE = "packs";

/** localStorage key holding the user's enabled pack codes. */
const ENABLED_KEY = "ocr.languagePacks.enabled";

export interface LanguagePackStatus extends LanguagePack {
  /** Bytes are present in OPFS. */
  installed: boolean;
  /** User has this pack switched on for OCR. */
  enabled: boolean;
}

export class LanguagePackError extends Error {
  readonly code: string;
  readonly reason: unknown;

  constructor(message: string, code: string, reason?: unknown) {
    super(message);
    this.name = "LanguagePackError";
    this.code = code;
    this.reason = reason;
  }
}

async function packDir(create = false): Promise<FileSystemDirectoryHandle | null> {
  if (typeof navigator === "undefined" || !navigator.storage?.getDirectory) return null;
  try {
    const root = await navigator.storage.getDirectory();
    return await root.getDirectoryHandle(PACK_DIR, { create });
  } catch (err) {
    // NotFoundError simply means nothing has been downloaded yet.
    if ((err as DOMException)?.name === "NotFoundError") return null;
    console.warn("[languagePacks] OPFS access failed:", err);
    return null;
  }
}

function withIdbStore<T>(
  mode: IDBTransactionMode,
  run: (store: IDBObjectStore) => IDBRequest<T>,
): Promise<T> {
  return new Promise((resolve, reject) => {
    const open = indexedDB.open(IDB_NAME, 1);
    open.onupgradeneeded = () => open.result.createObjectStore(IDB_STORE);
    open.onerror = () => reject(open.error ?? new Error("IndexedDB open failed"));
    open.onsuccess = () => {
      const db = open.result;
      const tx = db.transaction(IDB_STORE, mode);
      const request = run(tx.objectStore(IDB_STORE));
      tx.oncomplete = () => {
        db.close();
        resolve(request.result);
      };
      tx.onerror = tx.onabort = () => {
        db.close();
        reject(tx.error ?? request.error ?? new Error("IndexedDB transaction failed"));
      };
    };
  });
}

async function idbCodes(): Promise<string[]> {
  if (typeof indexedDB === "undefined") return [];
  try {
    return (await withIdbStore("readonly", (store) => store.getAllKeys())).map(String);
  } catch (err) {
    console.warn("[languagePacks] IndexedDB access failed:", err);
    return [];
  }
}

function readEnabled(): Set<string> {
  try {
    const raw = localStorage.getItem(ENABLED_KEY);
    if (!raw) return new Set();
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? new Set(parsed.filter((c): c is string => typeof c === "string")) : new Set();
  } catch {
    return new Set();
  }
}

function writeEnabled(codes: Set<string>): void {
  try {
    localStorage.setItem(ENABLED_KEY, JSON.stringify([...codes]));
  } catch (err) {
    console.warn("[languagePacks] could not persist enabled packs:", err);
  }
}

/** Codes whose bytes are present in OPFS. */
export async function installedCodes(): Promise<string[]> {
  const found = new Set(await idbCodes());
  const dir = await packDir(false);
  if (dir) {
    for await (const [name] of dir as unknown as AsyncIterable<[string, FileSystemHandle]>) {
      if (name.endsWith(".traineddata")) found.add(name.slice(0, -".traineddata".length));
    }
  }
  return [...found].sort();
}

/** Full catalogue with install + enable state, for the Settings UI. */
export async function listLanguagePacks(): Promise<LanguagePackStatus[]> {
  const installed = new Set(await installedCodes());
  const enabled = readEnabled();
  return LANGUAGE_PACKS.map((p) => ({
    ...p,
    installed: installed.has(p.code),
    // A pack that was removed must not linger as "enabled" — it would produce a
    // language string Tesseract cannot satisfy.
    enabled: enabled.has(p.code) && installed.has(p.code),
  }));
}

/**
 * Tesseract language string for the enabled packs, e.g. `"eng+heb"`.
 *
 * English is always first and always present: it reads the Western digits every
 * locale's chart axis uses, and Latin app names stay readable through it even
 * on a non-Latin UI. Only INSTALLED packs are included, so a stale preference
 * can never produce a string that fails engine init.
 */
/**
 * The enabled pack codes, read synchronously from localStorage (main thread only).
 *
 * Unlike [`tesseractLanguageString`] this does not check that each pack is still
 * installed, so it is for cache keys and change detection — not for naming
 * languages to Tesseract, where a missing pack file makes engine init fail.
 */
export function enabledLanguageCodes(): string[] {
  return [...readEnabled()].sort();
}

export async function tesseractLanguageString(): Promise<string> {
  const installed = new Set(await installedCodes());
  const enabled = [...readEnabled()].filter((c) => installed.has(c)).sort();
  return [BUNDLED_LANGUAGE, ...enabled].join("+");
}

/** Turn a downloaded pack on or off for OCR. Enabling requires it installed. */
export async function setPackEnabled(code: string, enabled: boolean): Promise<void> {
  const codes = readEnabled();
  if (enabled) {
    const installed = await installedCodes();
    if (!installed.includes(code)) {
      throw new LanguagePackError(`Language pack "${code}" is not downloaded`, "not_installed");
    }
    codes.add(code);
  } else {
    codes.delete(code);
  }
  writeEnabled(codes);
}

/**
 * Download a pack and store it in OPFS.
 *
 * Verifies the byte length against `shared/language_packs.json`, which is
 * pinned to an immutable upstream tessdata_fast commit. A truncated or
 * substituted file is rejected rather than written, so a half-downloaded pack
 * can never wedge engine init.
 */
export async function installLanguagePack(
  code: string,
  onProgress?: (received: number, total: number) => void,
  signal?: AbortSignal,
): Promise<void> {
  const meta = LANGUAGE_PACKS.find((p) => p.code === code);
  if (!meta) throw new LanguagePackError(`Unknown language pack "${code}"`, "unknown_pack");

  let response: Response;
  try {
    response = await fetch(languagePackUrl(code), signal ? { signal } : {});
  } catch (err) {
    if (signal?.aborted) throw err;
    throw new LanguagePackError(`Could not download the ${meta.english_name} pack`, "network", err);
  }
  if (!response.ok) {
    throw new LanguagePackError(
      `Could not download the ${meta.english_name} pack (HTTP ${response.status})`,
      "http_error",
    );
  }

  // Stream so the UI can show progress on a multi-megabyte download.
  const chunks: Uint8Array[] = [];
  let received = 0;
  const reader = response.body?.getReader();
  if (reader) {
    for (;;) {
      // eslint-disable-next-line no-await-in-loop -- sequential by nature: a stream is consumed chunk-by-chunk, and each read must resolve before the next is issued
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      received += value.byteLength;
      onProgress?.(received, meta.bytes);
    }
  } else {
    const buf = new Uint8Array(await response.arrayBuffer());
    chunks.push(buf);
    received = buf.byteLength;
    onProgress?.(received, meta.bytes);
  }

  if (received !== meta.bytes) {
    throw new LanguagePackError(
      `The ${meta.english_name} pack downloaded incompletely (${received} of ${meta.bytes} bytes)`,
      "size_mismatch",
    );
  }

  const bytes = new Uint8Array(received);
  let offset = 0;
  for (const c of chunks) {
    bytes.set(c, offset);
    offset += c.byteLength;
  }

  const dir = await packDir(true);
  try {
    if (dir) {
      await writeOpfsFile(dir, [PACK_DIR], `${code}.traineddata`, bytes);
    } else {
      await withIdbStore("readwrite", (store) => store.put(bytes.buffer, code));
    }
  } catch (err) {
    throw new LanguagePackError(
      `Could not save the ${meta.english_name} pack — storage may be full`,
      "write_failed",
      err,
    );
  }
}

/** Delete a pack's bytes and clear its enabled flag. */
export async function removeLanguagePack(code: string): Promise<void> {
  const codes = readEnabled();
  codes.delete(code);
  writeEnabled(codes);

  if ((await idbCodes()).includes(code)) {
    try {
      await withIdbStore("readwrite", (store) => store.delete(code));
    } catch (err) {
      throw new LanguagePackError(`Could not remove the "${code}" pack`, "remove_failed", err);
    }
  }
  const dir = await packDir(false);
  if (!dir) return;
  try {
    await dir.removeEntry(`${code}.traineddata`);
  } catch (err) {
    if ((err as DOMException)?.name !== "NotFoundError") {
      throw new LanguagePackError(`Could not remove the "${code}" pack`, "remove_failed", err);
    }
  }
}

/** Raw bytes of an installed pack, for mounting into the Emscripten FS. */
export async function readLanguagePack(code: string): Promise<Uint8Array | null> {
  if ((await idbCodes()).includes(code)) {
    try {
      return new Uint8Array(await withIdbStore<ArrayBuffer>("readonly", (store) => store.get(code) as IDBRequest<ArrayBuffer>));
    } catch {
      return null;
    }
  }
  const dir = await packDir(false);
  if (!dir) return null;
  try {
    const handle = await dir.getFileHandle(`${code}.traineddata`);
    const file = await handle.getFile();
    return new Uint8Array(await file.arrayBuffer());
  } catch {
    return null;
  }
}

export function restoreEnabledLanguageCodes(codes: string[]): void {
  localStorage.setItem(ENABLED_KEY, JSON.stringify(codes));
}

/** Restore archive bytes without downloading or depending on OPFS writes. */
export async function restoreLanguagePack(code: string, bytes: Uint8Array): Promise<void> {
  const meta = LANGUAGE_PACKS.find((p) => p.code === code);
  if (!meta || meta.bytes !== bytes.byteLength) {
    throw new LanguagePackError(`Invalid language pack "${code}"`, "size_mismatch");
  }
  await withIdbStore("readwrite", (store) => store.put(bytes.slice().buffer, code));
}

/** Total bytes of all downloaded packs, for the storage summary. */
export async function totalLanguagePackBytes(): Promise<number> {
  // IndexedDB packs were length-checked against the catalogue on install.
  const inIdb = new Set(await idbCodes());
  let total = LANGUAGE_PACKS.filter((p) => inIdb.has(p.code)).reduce((sum, p) => sum + p.bytes, 0);
  const dir = await packDir(false);
  if (!dir) return total;
  for await (const [name, handle] of dir as unknown as AsyncIterable<[string, FileSystemHandle]>) {
    if (!name.endsWith(".traineddata")) continue;
    try {
      total += (await (handle as FileSystemFileHandle).getFile()).size;
    } catch {
      /* a file removed mid-scan simply does not count */
    }
  }
  return total;
}

/** Remove every downloaded pack — used by the "clear local data" lifeboat. */
export async function clearAllLanguagePacks(): Promise<void> {
  writeEnabled(new Set());
  if (typeof indexedDB !== "undefined") indexedDB.deleteDatabase(IDB_NAME);
  if (typeof navigator === "undefined" || !navigator.storage?.getDirectory) return;
  try {
    const root = await navigator.storage.getDirectory();
    await root.removeEntry(PACK_DIR, { recursive: true });
  } catch (err) {
    if ((err as DOMException)?.name !== "NotFoundError") {
      console.warn("[languagePacks] failed to clear packs:", err);
    }
  }
}
