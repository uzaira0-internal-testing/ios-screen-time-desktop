/**
 * Minimal async semaphore: bounds how many wrapped async operations run at once.
 *
 * Used to cap concurrent full-resolution image decodes — each holds a multi-MB
 * RGBA bitmap until `close()` — so a wide preprocessing batch can't OOM the tab,
 * while the cheap non-decoding work (header reads, metadata writes) still runs at
 * high item-level concurrency. The gate bounds the thing that actually costs
 * memory (held bitmaps), not the number of items in flight.
 */
export interface Semaphore {
  run<T>(fn: () => Promise<T>, signal?: AbortSignal): Promise<T>;
}

export function createSemaphore(max: number): Semaphore {
  const limit = Math.max(1, Math.floor(max));
  let active = 0;
  const waiters: Array<{
    resolve: () => void;
    reject: (error: Error) => void;
    signal?: AbortSignal | undefined;
    abortHandler?: (() => void) | undefined;
  }> = [];

  const abortError = (): Error => {
    try {
      return new DOMException("Semaphore wait aborted", "AbortError");
    } catch {
      const error = new Error("Semaphore wait aborted");
      error.name = "AbortError";
      return error;
    }
  };

  const acquire = (signal?: AbortSignal): Promise<void> =>
    new Promise((resolve, reject) => {
      if (signal?.aborted) {
        reject(abortError());
        return;
      }
      if (active < limit) {
        active++;
        resolve();
      } else {
        // No slot free — queue. The slot is handed over in release() without
        // decrementing `active`, so the count never dips below the holders.
        const waiter: {
          resolve: () => void;
          reject: (error: Error) => void;
          signal?: AbortSignal | undefined;
          abortHandler?: (() => void) | undefined;
        } = { resolve, reject, signal };
        waiter.abortHandler = () => {
          const index = waiters.indexOf(waiter);
          if (index >= 0) waiters.splice(index, 1);
          reject(abortError());
        };
        signal?.addEventListener("abort", waiter.abortHandler, { once: true });
        waiters.push(waiter);
      }
    });

  const release = (): void => {
    const next = waiters.shift();
    if (next) {
      if (next.signal && next.abortHandler) {
        next.signal.removeEventListener("abort", next.abortHandler);
      }
      next.resolve();
    } else {
      active--;
    }
  };

  return {
    async run<T>(fn: () => Promise<T>, signal?: AbortSignal): Promise<T> {
      await acquire(signal);
      try {
        if (signal?.aborted) throw abortError();
        return await fn();
      } finally {
        release();
      }
    },
  };
}
