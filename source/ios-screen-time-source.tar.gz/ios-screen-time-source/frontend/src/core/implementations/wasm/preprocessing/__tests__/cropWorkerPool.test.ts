import { afterEach, beforeEach, describe, expect, test } from "bun:test";
import { CropWorkerPool } from "../cropWorkerPool";

const originalWindow = (globalThis as { window?: unknown }).window;
const originalWorker = globalThis.Worker;

interface WorkerMessage {
  id: string;
  type: string;
}

class MockCropWorker {
  static instances: MockCropWorker[] = [];

  onmessage: ((event: MessageEvent) => void) | null = null;
  onerror: ((event: ErrorEvent) => void) | null = null;
  postedMessages: WorkerMessage[] = [];
  terminated = false;

  constructor() {
    MockCropWorker.instances.push(this);
  }

  postMessage(message: WorkerMessage): void {
    this.postedMessages.push(message);
  }

  terminate(): void {
    this.terminated = true;
  }

  completeNext(result: unknown): void {
    const message = this.postedMessages.shift();
    if (!message) throw new Error("No pending crop message");
    this.onmessage?.({
      data: {
        id: message.id,
        type: "result",
        result,
      },
    } as MessageEvent);
  }
}

function cropResult(label: string) {
  return {
    croppedBlob: new Blob([label], { type: "image/png" }),
    wasCropped: true,
    originalDimensions: { width: 100, height: 200 },
    croppedDimensions: { width: 80, height: 200 },
    deviceModel: "iPad",
  };
}

describe("CropWorkerPool", () => {
  beforeEach(() => {
    MockCropWorker.instances = [];
    Object.defineProperty(globalThis, "window", {
      configurable: true,
      value: {},
    });
    Object.defineProperty(globalThis, "Worker", {
      configurable: true,
      value: MockCropWorker as unknown as typeof Worker,
    });
  });

  afterEach(() => {
    Object.defineProperty(globalThis, "window", {
      configurable: true,
      value: originalWindow,
    });
    Object.defineProperty(globalThis, "Worker", {
      configurable: true,
      value: originalWorker,
    });
  });

  test("reuses a bounded worker and queues one crop per worker", async () => {
    const pool = new CropWorkerPool(1);
    const first = pool.cropScreenshot(new Blob(["first"], { type: "image/png" }));
    const second = pool.cropScreenshot(new Blob(["second"], { type: "image/png" }));

    expect(MockCropWorker.instances).toHaveLength(1);
    const worker = MockCropWorker.instances[0]!;
    expect(worker.postedMessages).toHaveLength(1);
    expect(worker.postedMessages[0]?.type).toBe("cropScreenshot");
    expect(pool.getSnapshot()).toMatchObject({
      maxWorkers: 1,
      poolSize: 1,
      busyWorkers: 1,
      queuedRequests: 1,
      accepted: 2,
      dispatched: 1,
      maxQueueDepth: 1,
      maxBusyWorkers: 1,
    });

    worker.completeNext(cropResult("first"));
    await expect(first).resolves.toMatchObject({ wasCropped: true });
    expect(MockCropWorker.instances).toHaveLength(1);
    expect(worker.postedMessages).toHaveLength(1);
    expect(pool.getSnapshot()).toMatchObject({
      poolSize: 1,
      busyWorkers: 1,
      queuedRequests: 0,
      completed: 1,
      dispatched: 2,
    });

    worker.completeNext(cropResult("second"));
    await expect(second).resolves.toMatchObject({ wasCropped: true });
    expect(pool.getSnapshot()).toMatchObject({
      poolSize: 1,
      busyWorkers: 0,
      queuedRequests: 0,
      completed: 2,
      failed: 0,
      cancelled: 0,
    });
    pool.terminate();
  });

  test("does not create a replacement when abort leaves no queued crop work", async () => {
    const pool = new CropWorkerPool(1);
    const abortController = new AbortController();
    const running = pool.cropScreenshot(
      new Blob(["running"], { type: "image/png" }),
      abortController.signal,
    );

    expect(MockCropWorker.instances).toHaveLength(1);
    const worker = MockCropWorker.instances[0]!;
    abortController.abort();

    await expect(running).rejects.toMatchObject({ name: "AbortError" });
    expect(worker.terminated).toBe(true);
    expect(MockCropWorker.instances).toHaveLength(1);
    expect(pool.getSnapshot()).toMatchObject({
      poolSize: 0,
      busyWorkers: 0,
      queuedRequests: 0,
      cancelled: 1,
      terminated: 1,
    });
    pool.terminate();
  });

  test("routes fallback dimension reads through the same bounded worker queue", async () => {
    const pool = new CropWorkerPool(1);
    const first = pool.readBlobDimensions(new Blob(["unknown-format"]));
    const second = pool.readBlobDimensions(new Blob(["unknown-format-2"]));

    expect(MockCropWorker.instances).toHaveLength(1);
    const worker = MockCropWorker.instances[0]!;
    expect(worker.postedMessages).toHaveLength(1);
    expect(worker.postedMessages[0]?.type).toBe("readBlobDimensions");
    expect(pool.getSnapshot()).toMatchObject({
      poolSize: 1,
      busyWorkers: 1,
      queuedRequests: 1,
      accepted: 2,
      dispatched: 1,
      maxQueueDepth: 1,
      maxBusyWorkers: 1,
    });

    worker.completeNext({ width: 1170, height: 2532 });
    await expect(first).resolves.toEqual({ width: 1170, height: 2532 });
    expect(worker.postedMessages).toHaveLength(1);
    expect(worker.postedMessages[0]?.type).toBe("readBlobDimensions");

    worker.completeNext({ width: 2048, height: 2732 });
    await expect(second).resolves.toEqual({ width: 2048, height: 2732 });
    expect(pool.getSnapshot()).toMatchObject({
      poolSize: 1,
      busyWorkers: 0,
      queuedRequests: 0,
      completed: 2,
      failed: 0,
      cancelled: 0,
    });
    pool.terminate();
  });

  test("creates a replacement only when queued crop demand remains after abort", async () => {
    const pool = new CropWorkerPool(1);
    const abortController = new AbortController();
    const first = pool.cropScreenshot(
      new Blob(["first"], { type: "image/png" }),
      abortController.signal,
    );
    const second = pool.cropScreenshot(new Blob(["second"], { type: "image/png" }));

    const firstWorker = MockCropWorker.instances[0]!;
    expect(firstWorker.postedMessages).toHaveLength(1);
    abortController.abort();

    await expect(first).rejects.toMatchObject({ name: "AbortError" });
    expect(firstWorker.terminated).toBe(true);
    expect(MockCropWorker.instances).toHaveLength(2);

    const replacement = MockCropWorker.instances[1]!;
    expect(replacement.postedMessages).toHaveLength(1);
    expect(pool.getSnapshot()).toMatchObject({
      poolSize: 1,
      busyWorkers: 1,
      queuedRequests: 0,
      cancelled: 1,
      terminated: 1,
      dispatched: 2,
    });
    replacement.completeNext(cropResult("second"));
    await expect(second).resolves.toMatchObject({ wasCropped: true });
    pool.terminate();
  });
});
