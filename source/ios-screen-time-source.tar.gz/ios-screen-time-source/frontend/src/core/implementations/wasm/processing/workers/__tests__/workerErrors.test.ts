import { expect, test } from "bun:test";

test("worker error serialization carries abiMismatch across postMessage", async () => {
  const originalSelf = Object.getOwnPropertyDescriptor(globalThis, "self");
  Object.defineProperty(globalThis, "self", { configurable: true, value: {} });
  try {
    const { serializeUnknownError } = await import("../imageProcessor.worker.emscripten");
    const error = Object.assign(new Error("stale WASM"), { abiMismatch: true });
    expect(structuredClone(serializeUnknownError(error))).toMatchObject({ error: "stale WASM", abiMismatch: true });
  } finally {
    if (originalSelf) Object.defineProperty(globalThis, "self", originalSelf);
    else Reflect.deleteProperty(globalThis, "self");
  }
});
