import { afterEach, beforeAll, beforeEach, expect, test } from "bun:test";
import {
  setOpfsWriteWorkerFactoryForTests,
  writeOpfsFile,
  type OpfsWriteRequest,
  type OpfsWriteResponse,
  type OpfsWriteWorker,
} from "../opfsWrite";
import { isQuotaExceeded } from "../opfsBlobStorage";

/**
 * An in-memory OPFS. Directory handles have no `createWritable` on their file
 * handles unless `withWritable` is set, which is what Safari before 26 looks
 * like. File handles always offer `createSyncAccessHandle`, which only the
 * worker calls.
 */
const files = new Map<string, Uint8Array>();
const openHandles = new Set<string>();
let withWritable = false;
let failWriteAfter: number | null = null;
const calls: string[] = [];

function fileHandle(key: string) {
  return {
    kind: "file" as const,
    createWritable: withWritable
      ? async () => {
          calls.push(`createWritable:${key}`);
          let pending = new Uint8Array();
          return {
            write: async (data: Blob | Uint8Array | string | ArrayBuffer) => {
              if (failWriteAfter !== null) throw new DOMException("disk full", "QuotaExceededError");
              pending = data instanceof Blob
                ? new Uint8Array(await data.arrayBuffer())
                : typeof data === "string"
                  ? new TextEncoder().encode(data)
                  : new Uint8Array(data instanceof ArrayBuffer ? data : data.slice());
            },
            close: async () => { files.set(key, pending); },
            abort: async () => { calls.push(`abort:${key}`); },
          };
        }
      : undefined,
    createSyncAccessHandle: async () => {
      if (openHandles.has(key)) throw new DOMException("already open", "NoModificationAllowedError");
      openHandles.add(key);
      calls.push(`sync:${key}`);
      let bytes = files.get(key) ?? new Uint8Array();
      let total = 0;
      return {
        truncate(size: number) { bytes = bytes.slice(0, size); files.set(key, bytes); },
        write(buffer: Uint8Array, options?: { at?: number }) {
          const at = options?.at ?? 0;
          let length = buffer.byteLength;
          if (failWriteAfter !== null) {
            if (total >= failWriteAfter) throw new DOMException("disk full", "QuotaExceededError");
            length = Math.min(length, failWriteAfter - total);
          }
          const next = new Uint8Array(Math.max(bytes.byteLength, at + length));
          next.set(bytes);
          next.set(buffer.subarray(0, length), at);
          bytes = next;
          files.set(key, bytes);
          total += length;
          return length;
        },
        flush() {},
        close() { openHandles.delete(key); },
      };
    },
  };
}

function dirHandle(prefix: string) {
  const handle = {
    kind: "directory" as const,
    getDirectoryHandle: async (name: string) => {
      if (name.includes("/")) throw new TypeError(`Name is not allowed: ${name}`);
      return dirHandle(`${prefix}${name}/`);
    },
    getFileHandle: async (name: string, options?: { create?: boolean }) => {
      const key = `${prefix}${name}`;
      if (!files.has(key)) {
        if (!options?.create) throw new DOMException("missing", "NotFoundError");
        files.set(key, new Uint8Array());
      }
      return fileHandle(key);
    },
    removeEntry: async (name: string) => {
      const key = `${prefix}${name}`;
      if (!files.delete(key)) throw new DOMException("missing", "NotFoundError");
      calls.push(`remove:${key}`);
    },
  };
  return handle as unknown as FileSystemDirectoryHandle;
}

const root = dirHandle("/");
const text = (key: string) => new TextDecoder().decode(files.get(key));

/**
 * Runs the real `opfsWrite.worker.ts` on this thread: the worker module sets
 * `self.onmessage`, and its `self.postMessage` is routed back to the page side.
 */
let workerHandler: ((event: MessageEvent<OpfsWriteRequest>) => void) | null = null;
let workersCreated = 0;
let workerLoadFails = false;

function fakeWorker(): OpfsWriteWorker {
  workersCreated++;
  const worker: OpfsWriteWorker = {
    onmessage: null,
    onerror: null,
    onmessageerror: null,
    terminate() {},
    postMessage(message) {
      if (workerLoadFails) {
        queueMicrotask(() => worker.onerror?.({ message: "404 opfsWrite.worker.js" } as ErrorEvent));
        return;
      }
      (globalThis as unknown as { postMessage: (response: OpfsWriteResponse) => void }).postMessage =
        (response) => worker.onmessage?.({ data: response } as MessageEvent<OpfsWriteResponse>);
      workerHandler?.({ data: structuredClone(message) } as MessageEvent<OpfsWriteRequest>);
    },
  };
  return worker;
}

const originalNavigator = Object.getOwnPropertyDescriptor(globalThis, "navigator");

beforeAll(async () => {
  const previous = (globalThis as { onmessage?: unknown }).onmessage;
  await import("../opfsWrite.worker");
  workerHandler = (globalThis as unknown as { onmessage: typeof workerHandler }).onmessage;
  (globalThis as { onmessage?: unknown }).onmessage = previous;
});

beforeEach(() => {
  files.clear();
  openHandles.clear();
  calls.length = 0;
  withWritable = false;
  failWriteAfter = null;
  workersCreated = 0;
  workerLoadFails = false;
  setOpfsWriteWorkerFactoryForTests(fakeWorker);
  Object.defineProperty(globalThis, "navigator", {
    configurable: true,
    value: { storage: { getDirectory: async () => root } },
  });
});

afterEach(() => {
  setOpfsWriteWorkerFactoryForTests(null);
  if (originalNavigator) Object.defineProperty(globalThis, "navigator", originalNavigator);
  else Reflect.deleteProperty(globalThis, "navigator");
});

test("uses createWritable when the engine has it and never starts the worker", async () => {
  withWritable = true;
  const dir = await root.getDirectoryHandle("screenshots");
  await writeOpfsFile(dir, ["screenshots"], "1.img", new Blob(["main thread"]));
  expect(text("/screenshots/1.img")).toBe("main thread");
  expect(workersCreated).toBe(0);
  expect(calls).toEqual(["createWritable:/screenshots/1.img"]);
});

test("without createWritable, writes every data type through the worker's sync access handle", async () => {
  const dir = await root.getDirectoryHandle("screenshots");
  await writeOpfsFile(dir, ["screenshots"], "blob.img", new Blob(["from a blob"]));
  await writeOpfsFile(dir, ["screenshots"], "bytes.bin", new TextEncoder().encode("from bytes"));
  await writeOpfsFile(dir, ["screenshots"], "buffer.bin", new TextEncoder().encode("from a buffer").buffer);
  await writeOpfsFile(dir, ["screenshots"], "text.json", '{"from":"a string"}');

  expect(text("/screenshots/blob.img")).toBe("from a blob");
  expect(text("/screenshots/bytes.bin")).toBe("from bytes");
  expect(text("/screenshots/buffer.bin")).toBe("from a buffer");
  expect(text("/screenshots/text.json")).toBe('{"from":"a string"}');
  expect(workersCreated).toBe(1);
  expect(calls.every((call) => call.startsWith("sync:"))).toBe(true);
  expect(openHandles.size).toBe(0);
});

test("the worker replaces longer existing contents instead of leaving a tail", async () => {
  const dir = await root.getDirectoryHandle("language-packs");
  await writeOpfsFile(dir, ["language-packs"], "deu.traineddata", "a much longer first version");
  await writeOpfsFile(dir, ["language-packs"], "deu.traineddata", "short");
  expect(text("/language-packs/deu.traineddata")).toBe("short");
});

test("the worker walks a nested directory path from the OPFS root", async () => {
  const dir = await (await root.getDirectoryHandle("a")).getDirectoryHandle("b");
  await writeOpfsFile(dir, ["a", "b"], "nested.txt", "deep");
  expect(text("/a/b/nested.txt")).toBe("deep");
});

test("concurrent writes to one file run one at a time in the worker", async () => {
  const dir = await root.getDirectoryHandle("screenshots");
  await Promise.all(
    ["first", "second", "third"].map((value) =>
      writeOpfsFile(dir, ["screenshots"], "same.img", value),
    ),
  );
  expect(text("/screenshots/same.img")).toBe("third");
});

test("a quota failure in the worker reaches the caller as QuotaExceededError and leaves no file", async () => {
  const dir = await root.getDirectoryHandle("screenshots");
  failWriteAfter = 4;
  const error = await writeOpfsFile(dir, ["screenshots"], "big.img", "more than four bytes").catch(
    (err: unknown) => err,
  );
  expect(error).toBeInstanceOf(DOMException);
  expect((error as DOMException).name).toBe("QuotaExceededError");
  expect(isQuotaExceeded(error)).toBe(true);
  expect(files.has("/screenshots/big.img")).toBe(false);
  expect(openHandles.size).toBe(0);

  // The worker is still usable after a failed write.
  failWriteAfter = null;
  await writeOpfsFile(dir, ["screenshots"], "small.img", "ok");
  expect(text("/screenshots/small.img")).toBe("ok");
  expect(workersCreated).toBe(1);
});

test("other worker errors keep their name and message", async () => {
  const dir = await root.getDirectoryHandle("screenshots");
  const error = await writeOpfsFile(dir, ["bad/name"], "x.img", "data").catch((err: unknown) => err);
  expect((error as DOMException).name).toBe("TypeError");
  expect((error as DOMException).message).toContain("bad/name");
  expect(files.has("/screenshots/x.img")).toBe(false);
});

test("a worker that fails to load rejects the write, removes the empty file and fails later writes fast", async () => {
  workerLoadFails = true;
  const dir = await root.getDirectoryHandle("db-backups");
  await expect(writeOpfsFile(dir, ["db-backups"], "backup.json", "{}")).rejects.toThrow(
    "OPFS write worker failed",
  );
  expect(files.has("/db-backups/backup.json")).toBe(false);

  await expect(writeOpfsFile(dir, ["db-backups"], "backup2.json", "{}")).rejects.toThrow(
    "OPFS write worker failed",
  );
  expect(workersCreated).toBe(1);
  expect(files.has("/db-backups/backup2.json")).toBe(false);
});

test("a failed createWritable write is aborted and rethrown", async () => {
  withWritable = true;
  failWriteAfter = 0;
  const dir = await root.getDirectoryHandle("screenshots");
  const error = await writeOpfsFile(dir, ["screenshots"], "1.img", "data").catch((err: unknown) => err);
  expect(isQuotaExceeded(error)).toBe(true);
  expect(calls).toContain("abort:/screenshots/1.img");
  expect(workersCreated).toBe(0);
});
