/**
 * Invariants of the language-pack catalogue and the downscale flag.
 *
 * These guard the two claims the rest of the feature relies on: that every
 * catalogue entry is fetchable and correctly sized (the install path verifies
 * byte length before writing, so a wrong number here bricks that language), and
 * that a resized screenshot is distinguishable from a cropped one.
 */

import { describe, expect, it } from "bun:test";

import { LANGUAGE_PACKS, LANGUAGE_PACKS_ALWAYS_BUNDLED } from "@/core/generated/constants";
import { detectDevice } from "@/core/implementations/wasm/preprocessing/deviceDetection";
import { BUNDLED_LANGUAGE } from "@/core/implementations/wasm/languagePacks/languagePackStore";

describe("language pack catalogue", () => {
  it("has unique codes", () => {
    const codes = LANGUAGE_PACKS.map((p) => p.code);
    expect(new Set(codes).size).toBe(codes.length);
  });

  it("never offers the bundled language as a download", () => {
    expect(LANGUAGE_PACKS_ALWAYS_BUNDLED).toContain(BUNDLED_LANGUAGE);
    expect(LANGUAGE_PACKS.some((p) => p.code === BUNDLED_LANGUAGE)).toBe(false);
  });

  it("gives every pack a positive byte size", () => {
    // The installer rejects a download whose length differs, so a zero or
    // placeholder size here would make that language permanently uninstallable.
    for (const p of LANGUAGE_PACKS) {
      expect(p.bytes).toBeGreaterThan(0);
    }
  });

  it("declares a valid direction for every pack", () => {
    for (const p of LANGUAGE_PACKS) {
      expect(["ltr", "rtl"]).toContain(p.direction);
    }
  });

  it("marks Hebrew and Arabic as right-to-left", () => {
    const rtl = LANGUAGE_PACKS.filter((p) => p.direction === "rtl").map((p) => p.code).sort();
    expect(rtl).toEqual(["ara", "heb"]);
  });

  it("gives every pack a display name in English and its own script", () => {
    for (const p of LANGUAGE_PACKS) {
      expect(p.english_name.length).toBeGreaterThan(0);
      expect(p.native_name.length).toBeGreaterThan(0);
    }
  });
});

describe("downscaled-screenshot detection", () => {
  it("flags a long-edge-capped copy and reports its scale", () => {
    // The reference Hebrew screenshot: a 1206x2622 iPhone 16 Pro capture resized
    // to long-edge 2048 and re-encoded as JPEG by a messaging app.
    const r = detectDevice(942, 2048);
    expect(r.model).toBe("iPhone 16 Pro");
    expect(r.scaled).toBe(true);
    expect(r.scaleFactor).toBeCloseTo(0.7811, 3);
  });

  it("does not flag a native capture", () => {
    const r = detectDevice(1206, 2622);
    expect(r.confidence).toBe(1);
    expect(r.scaled).toBe(false);
    expect(r.scaleFactor).toBe(1);
  });

  it("does not mistake a height crop for a resize", () => {
    // Width matches the profile but height is short — that is a crop, and
    // reporting it as scaled would send the user hunting for an "original"
    // that does not exist.
    const r = detectDevice(1179, 1800);
    expect(r.scaled).toBe(false);
  });
});
