import type { Screenshot } from "@/types";

/**
 * Uncertainty-ordered annotation queue (roadmap #20).
 *
 * Surfaces the screenshots the automated pipeline is LEAST confident about
 * first, so human attention lands where it's most needed. This mirrors the
 * server-side ordering in `queue_repository.py::get_next_screenshot`:
 *   1. lowest grid-alignment score      (most misaligned bar graph first)
 *   2. lowest grid-detection confidence (tiebreak)
 *   3. oldest upload first              (stable, deterministic final tiebreak)
 *
 * A missing signal (`null`/`undefined`) is treated as fully confident (1.0) so
 * un-scored screenshots sort AFTER the known-uncertain ones — "no signal" must
 * never jump the queue ahead of "known-bad". This matches the server's
 * `coalesce(alignment_score, 1.0)`.
 */
const ABSENT_SIGNAL = 1;

const uncertaintyKey = (s: Screenshot): number =>
  typeof s.alignment_score === "number" ? s.alignment_score : ABSENT_SIGNAL;

const confidenceKey = (s: Screenshot): number =>
  typeof s.grid_detection_confidence === "number"
    ? s.grid_detection_confidence
    : ABSENT_SIGNAL;

/**
 * Comparator placing the most-uncertain screenshot first. Negative when `a`
 * should be served before `b`.
 */
export function compareByUncertainty(a: Screenshot, b: Screenshot): number {
  const byAlignment = uncertaintyKey(a) - uncertaintyKey(b);
  if (byAlignment !== 0) return byAlignment;

  const byConfidence = confidenceKey(a) - confidenceKey(b);
  if (byConfidence !== 0) return byConfidence;

  // ISO-8601 timestamps sort lexicographically; oldest first.
  return (a.uploaded_at ?? "").localeCompare(b.uploaded_at ?? "");
}

/**
 * Returns the single most-uncertain screenshot (the head of the queue) in O(n),
 * without allocating a sorted copy. Returns `null` for an empty input.
 */
export function mostUncertain(
  screenshots: readonly Screenshot[],
): Screenshot | null {
  if (screenshots.length === 0) return null;
  return screenshots.reduce((best, s) =>
    compareByUncertainty(s, best) < 0 ? s : best,
  );
}

/** Returns a new array ordered most-uncertain-first. Does not mutate the input. */
export function orderByUncertainty(
  screenshots: readonly Screenshot[],
): Screenshot[] {
  return [...screenshots].sort(compareByUncertainty);
}
