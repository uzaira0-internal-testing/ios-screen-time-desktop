import { describe, expect, test } from "bun:test";

import type { IStorageService } from "@/core/interfaces/IStorageService";
import type { IProcessingService } from "@/core/interfaces/IProcessingService";
import type { Screenshot } from "@/types";
import { WASMPreprocessingService } from "../WASMPreprocessingService";
import { useSettingsStore } from "@/store/settingsStore";

const originalWindow = (globalThis as { window?: unknown }).window;
const originalWorker = globalThis.Worker;

async function flushMicrotasks(times = 5): Promise<void> {
  if (times <= 0) return;
  await Promise.resolve();
  return flushMicrotasks(times - 1);
}

interface WorkerMessage {
  id: string;
  type: string;
}

class MockCropWorker {
  static instances: MockCropWorker[] = [];

  onmessage: ((event: MessageEvent) => void) | null = null;
  onerror: ((event: ErrorEvent) => void) | null = null;
  postedMessages: WorkerMessage[] = [];
  terminated = false;

  constructor() {
    MockCropWorker.instances.push(this);
  }

  postMessage(message: WorkerMessage): void {
    this.postedMessages.push(message);
  }

  terminate(): void {
    this.terminated = true;
  }

  completeNext(result: unknown): void {
    const message = this.postedMessages.shift();
    if (!message) throw new Error("No pending crop worker message");
    this.onmessage?.({
      data: {
        id: message.id,
        type: "result",
        result,
      },
    } as MessageEvent);
  }
}

function event(event_id: number, stage: string, result: Record<string, unknown>) {
  return {
    event_id,
    stage,
    timestamp: "2026-01-01T00:00:00.000Z",
    source: "wasm",
    params: {},
    result,
    output_file: null,
    input_file: null,
    supersedes: null,
  };
}

/**
 * Build a deliberately partial `Screenshot` fixture.
 *
 * The stage-cache code under test reads only `id` and `processing_metadata`,
 * so filling in the other ~40 columns would be noise. Casting the literal
 * straight to `Screenshot` no longer compiles (too few overlapping members),
 * and `as unknown as Screenshot` would silence field-name and field-type
 * checking entirely. Going through `Partial<Screenshot>` keeps both: a typo in
 * a key, or a wrong type in a value, is still a compile error here.
 */
function asScreenshot(partial: Partial<Screenshot>): Screenshot {
  return partial as Screenshot;
}

function makeScreenshot(): Screenshot {
  return asScreenshot({
    id: 1,
    group_id: "g",
    image_type: "screen_time",
    content_hash: "sha256:fixture",
    processing_status: "pending",
    processing_metadata: {
      preprocessing: {
        events: [
          event(1, "device_detection", {
            dimensions: { width: 1170, height: 2532 },
            needs_cropping: false,
          }),
          event(2, "cropping", {
            was_cropped: false,
            original_dimensions: [1170, 2532],
            cropped_dimensions: [1170, 2532],
          }),
        ],
        current_events: { device_detection: 1, cropping: 2 },
        stage_status: {
          device_detection: "completed",
          cropping: "completed",
          ocr: "pending",
        },
      },
    },
  });
}

function deviceCacheKey(contentHash = "sha256:fixture"): string {
  return JSON.stringify({
    v: 1,
    stage: "device_detection",
    content_hash: contentHash,
  });
}

function croppingCacheKey(contentHash = "sha256:fixture"): string {
  return JSON.stringify({
    v: 1,
    stage: "cropping",
    content_hash: contentHash,
    detection: {
      dimensions: { width: 1170, height: 2532 },
      device_category: "iphone",
      device_model: "iPhone 12",
      needs_cropping: false,
      orientation: "portrait",
    },
  });
}

function makeDeviceReplayScreenshot(): Screenshot {
  return asScreenshot({
    id: 1,
    group_id: "g",
    image_type: "screen_time",
    content_hash: "sha256:fixture",
    processing_status: "pending",
    processing_metadata: {
      preprocessing: {
        events: [
          event(1, "device_detection", {
            cache_version: 1,
            cache_key: deviceCacheKey(),
            content_hash: "sha256:fixture",
            device_model: "iPhone 12",
            device_family: "iphone_standard",
            device_category: "iphone",
            confidence: 1,
            orientation: "portrait",
            dimensions: { width: 1170, height: 2532 },
            needs_cropping: false,
          }),
        ],
        current_events: {},
        stage_status: {
          device_detection: "pending",
        },
      },
    },
  });
}

function makeCroppingReplayScreenshot(): Screenshot {
  return asScreenshot({
    id: 1,
    group_id: "g",
    image_type: "screen_time",
    content_hash: "sha256:fixture",
    processing_status: "pending",
    processing_metadata: {
      preprocessing: {
        events: [
          event(1, "device_detection", {
            cache_version: 1,
            cache_key: deviceCacheKey(),
            content_hash: "sha256:fixture",
            device_model: "iPhone 12",
            device_family: "iphone_standard",
            device_category: "iphone",
            confidence: 1,
            orientation: "portrait",
            dimensions: { width: 1170, height: 2532 },
            needs_cropping: false,
          }),
          event(2, "cropping", {
            cache_version: 1,
            cache_key: croppingCacheKey(),
            content_hash: "sha256:fixture",
            was_cropped: false,
            was_patched: false,
            original_dimensions: [1170, 2532],
            cropped_dimensions: [1170, 2532],
            device_model: "iPhone 12",
            is_ipad: false,
          }),
        ],
        current_events: { device_detection: 1 },
        stage_status: {
          device_detection: "completed",
          cropping: "pending",
        },
      },
    },
  });
}

function makeCropRequiredScreenshot(): Screenshot {
  return asScreenshot({
    id: 1,
    group_id: "g",
    image_type: "screen_time",
    content_hash: "sha256:fixture",
    processing_status: "pending",
    processing_metadata: {
      preprocessing: {
        events: [
          event(1, "device_detection", {
            device_model: "iPad Pro 12.9",
            device_family: "ipad_pro",
            device_category: "ipad",
            confidence: 1,
            orientation: "portrait",
            dimensions: { width: 2048, height: 2732 },
            needs_cropping: true,
          }),
        ],
        current_events: { device_detection: 1 },
        stage_status: {
          device_detection: "completed",
          cropping: "pending",
        },
      },
    },
  });
}

function makeDeviceFromOriginalScreenshot(): Screenshot {
  return asScreenshot({
    id: 1,
    group_id: "g",
    image_type: "screen_time",
    content_hash: "sha256:original-rerun",
    processing_status: "pending",
    processing_metadata: {
      preprocessing: {
        events: [],
        current_events: {},
        stage_status: {
          device_detection: "pending",
        },
      },
    },
  });
}

function makeCroppingFromOriginalScreenshot(): Screenshot {
  return asScreenshot({
    id: 1,
    group_id: "g",
    image_type: "screen_time",
    content_hash: "sha256:original-rerun",
    processing_status: "pending",
    processing_metadata: {
      preprocessing: {
        events: [
          event(1, "device_detection", {
            device_model: "iPhone 12",
            device_family: "iphone_standard",
            device_category: "iphone",
            confidence: 1,
            orientation: "portrait",
            dimensions: { width: 1170, height: 2532 },
            needs_cropping: false,
          }),
        ],
        current_events: { device_detection: 1 },
        stage_status: {
          device_detection: "completed",
          cropping: "pending",
        },
      },
    },
  });
}

function makeOcrCompletedManualCropScreenshot(): Screenshot {
  return asScreenshot({
    id: 1,
    group_id: "g",
    image_type: "screen_time",
    content_hash: "sha256:manual-crop",
    processing_status: "completed",
    extracted_title: "Old Title",
    extracted_total: "1h",
    extracted_hourly_data: { "0": 60 },
    alignment_score: 0.9,
    grid_registration_score: 0.8,
    has_blocking_issues: false,
    processing_issues: [],
    processed_at: "2026-01-01T00:00:00.000Z",
    grid_upper_left_x: 10,
    grid_upper_left_y: 20,
    grid_lower_right_x: 110,
    grid_lower_right_y: 220,
    processing_metadata: {
      crop_history: {
        entries: [
          {
            crop: null,
            grid: { ulx: 10, uly: 20, lrx: 110, lry: 220 },
            source: "none",
          },
          {
            crop: { left: 5, top: 6, right: 200, bottom: 300 },
            grid: { ulx: 5, uly: 14, lrx: 105, lry: 214 },
            source: "manual",
          },
        ],
        index: 1,
      },
      preprocessing: {
        events: [
          event(1, "device_detection", {
            dimensions: { width: 1170, height: 2532 },
            needs_cropping: false,
          }),
          event(2, "cropping", {
            was_cropped: true,
            manual: true,
            crop_region: { left: 5, top: 6, right: 200, bottom: 300 },
            original_dimensions: [1170, 2532],
            cropped_dimensions: [195, 294],
          }),
          event(3, "ocr", {
            processing_status: "completed",
            extracted_title: "Old Title",
            extracted_total: "1h",
            extracted_hourly_data: { "0": 60 },
            grid_coordinates: {
              upper_left: { x: 5, y: 14 },
              lower_right: { x: 105, y: 214 },
            },
          }),
        ],
        current_events: { device_detection: 1, cropping: 2, ocr: 3 },
        stage_status: {
          device_detection: "completed",
          cropping: "completed",
          ocr: "completed",
        },
      },
    },
  });
}

function pngBlob(width: number, height: number): Blob {
  return new Blob([
    new Uint8Array([
      0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
      0x00, 0x00, 0x00, 0x0d,
      0x49, 0x48, 0x44, 0x52,
      (width >>> 24) & 0xff, (width >>> 16) & 0xff, (width >>> 8) & 0xff, width & 0xff,
      (height >>> 24) & 0xff, (height >>> 16) & 0xff, (height >>> 8) & 0xff, height & 0xff,
      0x08, 0x02, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00,
    ]),
  ], { type: "image/png" });
}

function makeOriginalStageStorage(initial: Screenshot): IStorageService {
  let screenshot = structuredClone(initial);
  const originalBlob = pngBlob(1170, 2532);
  return {
    getAllScreenshots: (filter?: { group_id?: string }) =>
      Promise.resolve(!filter?.group_id || filter.group_id === screenshot.group_id ? [structuredClone(screenshot)] : []),
    getScreenshot: (id: number) =>
      Promise.resolve(id === screenshot.id ? (structuredClone(screenshot)) : null),
    updateScreenshot: (id: number, data: Partial<Screenshot>) => {
      if (id !== screenshot.id) return Promise.resolve();
      screenshot = { ...screenshot, ...structuredClone(data) } as Screenshot;
      return Promise.resolve();
    },
    getImageBlob: () => {
      throw new Error("crop history restore should read the preserved original first");
    },
    getStageBlob: (id: number, stage: string) =>
      Promise.resolve(id === screenshot.id && stage === "original" ? originalBlob : null),
    saveImageBlob: () => Promise.resolve(),
    saveStageBlob: () => Promise.resolve(),
  } as unknown as IStorageService;
}

function makeStorage(initial: Screenshot): IStorageService {
  let screenshot = structuredClone(initial);
  const imageBlob = new Blob(["fixture"], { type: "image/png" });

  return {
    getAllScreenshots: (filter?: { group_id?: string }) =>
      Promise.resolve(!filter?.group_id || filter.group_id === screenshot.group_id ? [structuredClone(screenshot)] : []),
    getScreenshot: (id: number) =>
      Promise.resolve(id === screenshot.id ? (structuredClone(screenshot)) : null),
    updateScreenshot: (id: number, data: Partial<Screenshot>) => {
      if (id !== screenshot.id) return Promise.resolve();
      screenshot = { ...screenshot, ...structuredClone(data) } as Screenshot;
      return Promise.resolve();
    },
    getImageBlob: (id: number) => Promise.resolve(id === screenshot.id ? imageBlob : null),
    getStageBlob: () => Promise.resolve(null),
    saveImageBlob: () => Promise.resolve(),
    saveStageBlob: () => Promise.resolve(),
  } as unknown as IStorageService;
}

function makeMultiStorage(initial: Screenshot[]): IStorageService {
  let screenshots = structuredClone(initial);
  const imageBlob = new Blob(["fixture"], { type: "image/png" });

  return {
    getAllScreenshots: (filter?: { group_id?: string }) =>
      Promise.resolve(screenshots
        .filter((s) => !filter?.group_id || filter.group_id === s.group_id)
        .map((s) => structuredClone(s))),
    getScreenshot: (id: number) => {
      const screenshot = screenshots.find((s) => s.id === id);
      return Promise.resolve(screenshot ? (structuredClone(screenshot)) : null);
    },
    updateScreenshot: (id: number, data: Partial<Screenshot>) => {
      screenshots = screenshots.map((s) =>
        s.id === id ? ({ ...s, ...structuredClone(data) } as Screenshot) : s,
      );
      return Promise.resolve();
    },
    getImageBlob: (id: number) =>
      Promise.resolve(screenshots.some((s) => s.id === id) ? imageBlob : null),
    getStageBlob: () => Promise.resolve(null),
    saveImageBlob: () => Promise.resolve(),
    saveStageBlob: () => Promise.resolve(),
  } as unknown as IStorageService;
}

function makeOriginalOnlyStorage(initial: Screenshot): {
  storage: IStorageService;
  getImageBlobCalls: () => number;
} {
  let screenshot = structuredClone(initial);
  let imageBlobCalls = 0;
  const originalBlob = pngBlob(1170, 2532);

  return {
    getImageBlobCalls: () => imageBlobCalls,
    storage: {
      getAllScreenshots: (filter?: { group_id?: string }) =>
        Promise.resolve(!filter?.group_id || filter.group_id === screenshot.group_id ? [structuredClone(screenshot)] : []),
      getScreenshot: (id: number) =>
        Promise.resolve(id === screenshot.id ? (structuredClone(screenshot)) : null),
      updateScreenshot: (id: number, data: Partial<Screenshot>) => {
        if (id !== screenshot.id) return Promise.resolve();
        screenshot = { ...screenshot, ...structuredClone(data) } as Screenshot;
        return Promise.resolve();
      },
      getImageBlob: () => {
        imageBlobCalls++;
        throw new Error("stage rerun should read the preserved original before current image blob");
      },
      getStageBlob: (id: number, stage: string) =>
        Promise.resolve(id === screenshot.id && stage === "original" ? originalBlob : null),
      saveStageBlob: () => Promise.resolve(),
    } as unknown as IStorageService,
  };
}

function makeAbortDuringCropStorage(initial: Screenshot, controller: AbortController): IStorageService {
  let screenshot = structuredClone(initial);
  const imageBlob = new Blob(["fixture"], { type: "image/png" });

  return {
    getAllScreenshots: (filter?: { group_id?: string }) =>
      Promise.resolve(!filter?.group_id || filter.group_id === screenshot.group_id ? [structuredClone(screenshot)] : []),
    getScreenshot: (id: number) =>
      Promise.resolve(id === screenshot.id ? (structuredClone(screenshot)) : null),
    updateScreenshot: (id: number, data: Partial<Screenshot>) => {
      if (id !== screenshot.id) return Promise.resolve();
      screenshot = { ...screenshot, ...structuredClone(data) } as Screenshot;
      return Promise.resolve();
    },
    getImageBlob: (id: number) => Promise.resolve(id === screenshot.id ? imageBlob : null),
    getStageBlob: () => {
      controller.abort();
      throw abortError();
    },
  } as unknown as IStorageService;
}

function makeReplayStorage(initial: Screenshot): {
  storage: IStorageService;
  getBlobCalls: () => number;
} {
  let screenshot = structuredClone(initial);
  let blobCalls = 0;

  return {
    getBlobCalls: () => blobCalls,
    storage: {
      getAllScreenshots: (filter?: { group_id?: string }) =>
        Promise.resolve(!filter?.group_id || filter.group_id === screenshot.group_id ? [structuredClone(screenshot)] : []),
      getScreenshot: (id: number) =>
        Promise.resolve(id === screenshot.id ? (structuredClone(screenshot)) : null),
      updateScreenshot: (id: number, data: Partial<Screenshot>) => {
        if (id !== screenshot.id) return Promise.resolve();
        screenshot = { ...screenshot, ...structuredClone(data) } as Screenshot;
        return Promise.resolve();
      },
      getImageBlob: () => {
        blobCalls++;
        throw new Error("cached replay should not read image blobs");
      },
    } as unknown as IStorageService,
  };
}

function makeProcessing() {
  let calls = 0;
  const service = {
    processImageWithGridDetection: () => {
      calls++;
      return Promise.resolve({
        hourlyData: { "0": 12, total: 12 },
        title: "Instagram",
        total: "12m",
        gridCoordinates: {
          upper_left: { x: 10, y: 20 },
          lower_right: { x: 110, y: 220 },
        },
        alignmentScore: 0.92,
        gridRegistrationScore: 0.87,
      });
    },
    getPoolSize: () => 1,
    processImage: () => {
      throw new Error("unexpected processImage fallback");
    },
    extractTitle: () => Promise.resolve(null),
    extractTotal: () => Promise.resolve(null),
    extractHourlyData: () => Promise.resolve({}),
    detectGrid: () => Promise.resolve(null),
    initialize: () => Promise.resolve(),
    isInitialized: () => true,
    terminate: () => {},
  } as unknown as IProcessingService;

  return { service, getCalls: () => calls };
}

function abortError(): Error {
  try {
    return new DOMException("Navigation changed", "AbortError");
  } catch {
    const error = new Error("Navigation changed");
    error.name = "AbortError";
    return error;
  }
}

function makeAbortingProcessing(controller: AbortController) {
  let calls = 0;
  const service = {
    processImageWithGridDetection: async () => {
      calls++;
      controller.abort();
      throw abortError();
    },
    getPoolSize: () => 1,
    processImage: async () => {
      throw new Error("unexpected processImage fallback");
    },
    extractTitle: async () => null,
    extractTotal: async () => null,
    extractHourlyData: async () => ({}),
    detectGrid: async () => null,
    initialize: async () => {},
    isInitialized: () => true,
    terminate: () => {},
  } as unknown as IProcessingService;

  return { service, getCalls: () => calls };
}

function withId(screenshot: Screenshot, id: number): Screenshot {
  return asScreenshot({
    ...structuredClone(screenshot),
    id,
  });
}

describe("WASM preprocessing stage result cache", () => {
  test("replays cached device detection without reading the image blob", async () => {
    const { storage, getBlobCalls } = makeReplayStorage(makeDeviceReplayScreenshot());
    const processing = makeProcessing();
    const service = new WASMPreprocessingService(storage, processing.service, { enablePhi: false });

    await service.runStage("device_detection", { group_id: "g" });

    expect(getBlobCalls()).toBe(0);
    const screenshot = await storage.getScreenshot(1);
    const preprocessing = (screenshot?.processing_metadata as Record<string, unknown>)
      .preprocessing as {
      events: Array<{ event_id: number; stage: string; result: Record<string, unknown> }>;
      current_events: Record<string, number>;
      stage_status: Record<string, string>;
    };
    expect(preprocessing.stage_status.device_detection).toBe("completed");
    const replayEvent = preprocessing.events.find((e) => e.event_id === preprocessing.current_events.device_detection);
    expect(replayEvent?.result.cache_hit).toBe(true);
    expect(replayEvent?.result.cache_source_event_id).toBe(1);
    expect(replayEvent?.result.device_model).toBe("iPhone 12");

    const metrics = service.getStageSchedulerSnapshot().stages.device_detection!;
    expect(metrics.runs).toBe(1);
    expect(metrics.lastQueuedItems).toBe(1);
    expect(metrics.lastCompletedItems).toBe(1);
    expect(metrics.lastCacheHits).toBe(1);
    expect(metrics.lastFailedItems).toBe(0);
    expect(metrics.lastConfiguredConcurrency).toBeGreaterThanOrEqual(1);
  });

  test("replays cached no-crop metadata without reading the image blob", async () => {
    const { storage, getBlobCalls } = makeReplayStorage(makeCroppingReplayScreenshot());
    const processing = makeProcessing();
    const service = new WASMPreprocessingService(storage, processing.service, { enablePhi: false });

    await service.runStage("cropping", { group_id: "g" });

    expect(getBlobCalls()).toBe(0);
    const screenshot = await storage.getScreenshot(1);
    const preprocessing = (screenshot?.processing_metadata as Record<string, unknown>)
      .preprocessing as {
      events: Array<{ event_id: number; stage: string; result: Record<string, unknown> }>;
      current_events: Record<string, number>;
      stage_status: Record<string, string>;
    };
    expect(preprocessing.stage_status.cropping).toBe("completed");
    const replayEvent = preprocessing.events.find((e) => e.event_id === preprocessing.current_events.cropping);
    expect(replayEvent?.result.cache_hit).toBe(true);
    expect(replayEvent?.result.cache_source_event_id).toBe(2);
    expect(replayEvent?.result.was_cropped).toBe(false);
  });

  test("reruns device detection from preserved original without reading the current image blob", async () => {
    const { storage, getImageBlobCalls } = makeOriginalOnlyStorage(makeDeviceFromOriginalScreenshot());
    const processing = makeProcessing();
    const service = new WASMPreprocessingService(storage, processing.service, { enablePhi: false });

    await service.runStage("device_detection", { group_id: "g" });

    expect(getImageBlobCalls()).toBe(0);
    const screenshot = await storage.getScreenshot(1);
    const preprocessing = (screenshot?.processing_metadata as Record<string, unknown>)
      .preprocessing as {
      events: Array<{ event_id: number; stage: string; result: Record<string, unknown> }>;
      current_events: Record<string, number>;
      stage_status: Record<string, string>;
    };
    expect(preprocessing.stage_status.device_detection).toBe("completed");
    const detection = preprocessing.events.find((e) => e.event_id === preprocessing.current_events.device_detection);
    expect(detection?.result.dimensions).toEqual({ width: 1170, height: 2532 });
  });

  test("routes device detection fallback dimension decode through the crop worker pool", async () => {
    MockCropWorker.instances = [];
    Object.defineProperty(globalThis, "window", {
      configurable: true,
      value: {},
    });
    Object.defineProperty(globalThis, "Worker", {
      configurable: true,
      value: MockCropWorker as unknown as typeof Worker,
    });

    try {
      const storage = makeStorage(makeDeviceFromOriginalScreenshot());
      const processing = makeProcessing();
      const service = new WASMPreprocessingService(storage, processing.service, { enablePhi: false });

      const running = service.runStage("device_detection", { group_id: "g" });
      await flushMicrotasks(10);

      expect(MockCropWorker.instances).toHaveLength(1);
      const worker = MockCropWorker.instances[0]!;
      expect(worker.postedMessages).toHaveLength(1);
      expect(worker.postedMessages[0]?.type).toBe("readBlobDimensions");

      worker.completeNext({ width: 1170, height: 2532 });
      const result = await running;

      expect(result.failed_count).toBe(0);
      const cropPool = service.getStageSchedulerSnapshot().cropWorkerPool!;
      expect(cropPool.accepted).toBe(1);
      expect(cropPool.dispatched).toBe(1);
      expect(cropPool.completed).toBe(1);
      expect(cropPool.maxBusyWorkers).toBe(1);

      const screenshot = await storage.getScreenshot(1);
      const preprocessing = (screenshot?.processing_metadata as Record<string, unknown>)
        .preprocessing as {
        events: Array<{ event_id: number; stage: string; result: Record<string, unknown> }>;
        current_events: Record<string, number>;
        stage_status: Record<string, string>;
      };
      expect(preprocessing.stage_status.device_detection).toBe("completed");
      const detection = preprocessing.events.find((e) => e.event_id === preprocessing.current_events.device_detection);
      expect(detection?.result.dimensions).toEqual({ width: 1170, height: 2532 });
    } finally {
      Object.defineProperty(globalThis, "window", {
        configurable: true,
        value: originalWindow,
      });
      Object.defineProperty(globalThis, "Worker", {
        configurable: true,
        value: originalWorker,
      });
    }
  });

  test("reruns no-crop cropping from preserved original without reading the current image blob", async () => {
    const { storage, getImageBlobCalls } = makeOriginalOnlyStorage(makeCroppingFromOriginalScreenshot());
    const processing = makeProcessing();
    const service = new WASMPreprocessingService(storage, processing.service, { enablePhi: false });

    await service.runStage("cropping", { group_id: "g" });

    expect(getImageBlobCalls()).toBe(0);
    const screenshot = await storage.getScreenshot(1);
    const preprocessing = (screenshot?.processing_metadata as Record<string, unknown>)
      .preprocessing as {
      events: Array<{ event_id: number; stage: string; result: Record<string, unknown> }>;
      current_events: Record<string, number>;
      stage_status: Record<string, string>;
    };
    expect(preprocessing.stage_status.cropping).toBe("completed");
    const crop = preprocessing.events.find((e) => e.event_id === preprocessing.current_events.cropping);
    expect(crop?.result.was_cropped).toBe(false);
    expect(crop?.result.cropped_dimensions).toEqual([1170, 2532]);
  });

  test("crop undo invalidates OCR and clears stale extracted fields", async () => {
    const storage = makeOriginalStageStorage(makeOcrCompletedManualCropScreenshot());
    const processing = makeProcessing();
    const service = new WASMPreprocessingService(storage, processing.service, { enablePhi: false });

    await service.undoManualCrop(1);

    const screenshot = await storage.getScreenshot(1);
    expect(screenshot?.processing_status).toBe("pending");
    expect(screenshot?.extracted_title).toBeNull();
    expect(screenshot?.extracted_total).toBeNull();
    expect(screenshot?.extracted_hourly_data).toBeNull();
    expect(screenshot?.alignment_score).toBeNull();
    expect(screenshot?.grid_registration_score).toBeNull();
    expect(screenshot?.has_blocking_issues).toBe(false);
    expect(screenshot?.processing_issues).toEqual([]);
    expect(screenshot?.processed_at).toBeNull();

    const preprocessing = (screenshot?.processing_metadata as Record<string, unknown>)
      .preprocessing as {
      events: Array<{ event_id: number; stage: string; result: Record<string, unknown> }>;
      current_events: Record<string, number>;
      stage_status: Record<string, string>;
    };
    expect(preprocessing.stage_status.cropping).toBe("completed");
    expect(preprocessing.stage_status.ocr).toBe("invalidated");
    expect(preprocessing.current_events.ocr).toBeUndefined();
    expect((preprocessing as unknown as Record<string, unknown>).ocr).toBeUndefined();
    const crop = preprocessing.events.find((e) => e.event_id === preprocessing.current_events.cropping);
    expect(crop?.result.restored_from_history).toBe(true);
    expect(crop?.result.was_cropped).toBe(false);
  });

  test("reruns OCR after an OCR reset instead of replaying stale output", async () => {
    const storage = makeStorage(makeScreenshot());
    const processing = makeProcessing();
    const service = new WASMPreprocessingService(storage, processing.service, { enablePhi: false });

    await service.runStage("ocr", { group_id: "g" });
    expect(processing.getCalls()).toBe(1);

    await service.resetStage("ocr", "g");
    const resetScreenshot = await storage.getScreenshot(1);
    expect(resetScreenshot?.processing_status).toBe("pending");
    expect(resetScreenshot?.extracted_title).toBeNull();
    expect(resetScreenshot?.extracted_total).toBeNull();
    expect(resetScreenshot?.extracted_hourly_data).toBeNull();
    const resetPreprocessing = (resetScreenshot?.processing_metadata as Record<string, unknown>)
      .preprocessing as Record<string, unknown>;
    expect(resetPreprocessing.ocr).toBeUndefined();

    await service.runStage("ocr", { group_id: "g" });

    expect(processing.getCalls()).toBe(2);
    const screenshot = await storage.getScreenshot(1);
    expect(screenshot?.extracted_title).toBe("Instagram");
    expect(screenshot?.extracted_total).toBe("12m");
    expect(screenshot?.grid_upper_left_x).toBe(10);

    const preprocessing = (screenshot?.processing_metadata as Record<string, unknown>)
      .preprocessing as {
      events: Array<{ event_id: number; stage: string; result: Record<string, unknown> }>;
      current_events: Record<string, number>;
      stage_status: Record<string, string>;
    };
    expect(preprocessing.stage_status.ocr).toBe("completed");
    const previousOcrEvent = preprocessing.events.find((e) => e.event_id === 3);
    expect(previousOcrEvent?.result.cache_key).toBeUndefined();
    expect(previousOcrEvent?.result.cache_version).toBeUndefined();
    expect(previousOcrEvent?.result.cache_invalidated_reason).toBe("stage_reset");
    const rerunEvent = preprocessing.events.find((e) => e.event_id === preprocessing.current_events.ocr);
    expect(rerunEvent?.event_id).toBe(4);
    expect(rerunEvent?.result.cache_hit).toBeUndefined();
  });

  test("changing the apportionment cap re-runs OCR instead of replaying the cached values", async () => {
    // The apportionment knobs change the 24 hourly values, so they are inputs to
    // the OCR stage and belong in its cache key.
    //
    // The path that made this bite: `invalidateFromStage` (an upstream re-run,
    // e.g. re-cropping) marks OCR INVALIDATED — eligible again — but unlike
    // `resetStage` it deliberately leaves the old event's cache_key intact so an
    // unchanged input can still replay. With the knobs missing from that key, a
    // user who changed the Apportionment Cap and then re-ran OCR replayed the
    // OLD values, and the setting silently did nothing.
    const initial = useSettingsStore.getState();
    const storage = makeStorage(makeScreenshot());
    const processing = makeProcessing();
    const service = new WASMPreprocessingService(storage, processing.service, { enablePhi: false });

    // Mark OCR eligible again exactly the way an upstream re-run does: status
    // INVALIDATED, prerequisites still completed, and the previous event's
    // cache_key left in place (only resetStage strips it).
    const invalidateOcr = async () => {
      const shot = (await storage.getScreenshot(1))!;
      const meta = shot.processing_metadata as Record<string, unknown>;
      const pp = meta.preprocessing as {
        current_events: Record<string, number>;
        stage_status: Record<string, string>;
      };
      const { ocr: _dropped, ...remainingCurrent } = pp.current_events;
      await storage.updateScreenshot(1, {
        processing_metadata: {
          ...meta,
          preprocessing: {
            ...pp,
            current_events: remainingCurrent,
            stage_status: { ...pp.stage_status, ocr: "invalidated" },
          },
        },
      });
    };

    try {
      useSettingsStore.getState().set("apportionMaxMinutes", 2);
      useSettingsStore.getState().set("apportionMaxPercent", 2);
      await service.runStage("ocr", { group_id: "g" });
      expect(processing.getCalls()).toBe(1);

      // Unchanged settings: invalidation alone must still replay from cache —
      // that reuse is the whole point of keeping the key across invalidation.
      await invalidateOcr();
      await service.runStage("ocr", { group_id: "g" });
      expect(processing.getCalls(), "unchanged settings still replay the cache").toBe(1);

      useSettingsStore.getState().set("apportionMaxPercent", 8);
      await invalidateOcr();
      await service.runStage("ocr", { group_id: "g" });
      expect(processing.getCalls(), "a changed cap must re-run the pipeline").toBe(2);

      // Both caps now reach the pipeline (it applies the larger), so the minutes
      // knob is part of the effective key too — it is no longer zeroed out by a
      // mode, which is what used to hide short-day apportionment entirely.
      useSettingsStore.getState().set("apportionMaxMinutes", 7);
      await invalidateOcr();
      await service.runStage("ocr", { group_id: "g" });
      expect(processing.getCalls(), "a changed minutes cap must re-run the pipeline").toBe(3);
    } finally {
      useSettingsStore.setState(initial);
    }
  });

  test("skipping a failed stage resolves the current failure but preserves event history", async () => {
    const failed = makeScreenshot();
    failed.processing_status = "failed";
    failed.has_blocking_issues = true;
    failed.processed_at = "2026-01-01T00:00:00.000Z";
    failed.processing_issues = [
      { issue_type: "ocr_stage_failed", severity: "blocking", description: "worker disconnected" },
      { issue_type: "suspected_all_devices", severity: "warning", description: "Axis exceeds one hour" },
    ] as unknown as NonNullable<Screenshot["processing_issues"]>;
    const preprocessing = (failed.processing_metadata as Record<string, unknown>)
      .preprocessing as {
      events: Array<ReturnType<typeof event>>;
      current_events: Record<string, number>;
      stage_status: Record<string, string>;
    };
    preprocessing.events.push(event(3, "ocr", { error: "worker disconnected", ocr_failed: false }));
    preprocessing.current_events.ocr = 3;
    preprocessing.stage_status.ocr = "failed";

    const storage = makeStorage(failed);
    const service = new WASMPreprocessingService(storage, makeProcessing().service, { enablePhi: false });

    const result = await service.skipStage("ocr", "g", [1]);

    expect(result.count).toBe(1);
    const screenshot = await storage.getScreenshot(1);
    expect(screenshot?.processing_status).toBe("pending");
    expect(screenshot?.has_blocking_issues).toBe(false);
    expect(screenshot?.processed_at).toBeNull();
    expect(screenshot?.processing_issues?.map((issue) => issue.issue_type)).toEqual([
      "suspected_all_devices",
    ]);
    const updated = (screenshot?.processing_metadata as Record<string, unknown>)
      .preprocessing as {
      events: Array<{ event_id: number }>;
      current_events: Record<string, number>;
      stage_status: Record<string, string>;
    };
    expect(updated.stage_status.ocr).toBe("skipped");
    expect(updated.current_events.ocr).toBeUndefined();
    expect(updated.events.map((item) => item.event_id)).toEqual([1, 2, 3]);
  });

  test("a skipped prerequisite allows the next stage to run", async () => {
    const screenshot = makeScreenshot();
    const preprocessing = (screenshot.processing_metadata as Record<string, unknown>)
      .preprocessing as { stage_status: Record<string, string> };
    preprocessing.stage_status.cropping = "skipped";
    const storage = makeStorage(screenshot);
    const processing = makeProcessing();
    const service = new WASMPreprocessingService(storage, processing.service, { enablePhi: false });

    const result = await service.runStage("ocr", { group_id: "g" });

    expect(result.failed_count).toBe(0);
    expect(processing.getCalls()).toBe(1);
    expect((await storage.getScreenshot(1))?.processing_status).toBe("completed");
  });

  test("a successful daily-total retry clears the current failed label", async () => {
    const screenshot = makeScreenshot();
    screenshot.processing_status = "failed";
    screenshot.processing_issues = [
      { issue_type: "ocr_stage_failed", severity: "blocking", description: "old worker failure" },
    ];
    screenshot.has_blocking_issues = true;
    const preprocessing = (screenshot.processing_metadata as Record<string, unknown>)
      .preprocessing as { stage_status: Record<string, string> };
    preprocessing.stage_status.ocr = "failed";
    const storage = makeStorage(screenshot);
    const processing = {
      ...makeProcessing().service,
      processImageWithGridDetection: async () => ({
        hourlyData: {},
        title: "Daily Total",
        total: null,
        gridDetectionFailed: false,
      }),
    } as IProcessingService;
    const service = new WASMPreprocessingService(storage, processing, { enablePhi: false });

    const result = await service.runStage("ocr", { group_id: "g", skip_daily_totals: true });

    expect(result.failed_count).toBe(0);
    const updated = await storage.getScreenshot(1);
    expect(updated?.processing_status).toBe("skipped");
    expect(updated?.processing_issues).toEqual([]);
    expect(updated?.has_blocking_issues).toBe(false);
  });

  test("retains All Devices evidence returned with a hard grid failure", async () => {
    const storage = makeStorage(makeScreenshot());
    const processing = {
      ...makeProcessing().service,
      processImageWithGridDetection: async () => ({
        hourlyData: {},
        title: null,
        total: null,
        gridDetectionFailed: true,
        gridDetectionError: "Grid detection failed",
        suspectedAllDevices: true,
        axisMaxMinutes: 120,
        allDevicesReasons: ["Chart axis exceeds 1 hour (120 min)"],
      }),
    } as IProcessingService;
    const service = new WASMPreprocessingService(storage, processing, { enablePhi: false });

    await service.runStage("ocr", { group_id: "g" });

    const result = await storage.getScreenshot(1);
    const metadata = result?.processing_metadata as Record<string, unknown>;
    const quality = metadata.quality_flags as Record<string, unknown>;
    expect(result?.processing_status).toBe("failed");
    expect(metadata.ocr_ever_failed).toBeUndefined();
    expect(quality.suspected_all_devices).toBe(true);
    expect(quality.axis_max_minutes).toBe(120);
    expect(result?.processing_issues?.map((issue) => issue.issue_type)).toEqual([
      "grid_detection_failed",
      "no_hourly_data",
      "suspected_all_devices",
    ]);
    expect(result?.has_blocking_issues).toBe(true);
  });

  test("records grid and OCR failures independently when both occur", async () => {
    const storage = makeStorage(makeScreenshot());
    const processing = {
      ...makeProcessing().service,
      processImageWithGridDetection: async () => ({
        hourlyData: {},
        title: null,
        total: null,
        gridDetectionFailed: true,
        gridDetectionError: "Grid detection failed",
        ocrFailed: true,
        ocrError: "Tesseract recognition failed",
      }),
    } as IProcessingService;
    const service = new WASMPreprocessingService(storage, processing, { enablePhi: false });

    await service.runStage("ocr", { group_id: "g" });

    const result = await storage.getScreenshot(1);
    const metadata = result?.processing_metadata as Record<string, unknown>;
    expect(result?.processing_status).toBe("failed");
    expect(metadata.ocr_ever_failed).toBe(true);
    expect(result?.processing_issues?.map((issue) => issue.issue_type)).toEqual([
      "grid_detection_failed",
      "no_hourly_data",
      "ocr_processing_failed",
    ]);
    const preprocessing = metadata.preprocessing as {
      events: Array<{ result: Record<string, unknown> }>;
    };
    expect(preprocessing.events.at(-1)?.result.ocr_failed).toBe(true);
    expect(preprocessing.events.at(-1)?.result.ocr_error).toBe("Tesseract recognition failed");
  });

  test("counts a missing image as failed instead of completed", async () => {
    const storage = makeStorage(makeScreenshot());
    storage.getImageBlob = async () => null;
    const processing = makeProcessing();
    const service = new WASMPreprocessingService(storage, processing.service, { enablePhi: false });

    const run = await service.runStage("ocr", { group_id: "g" });

    expect(run.queued_count).toBe(0);
    expect(run.failed_count).toBe(1);
    const result = await storage.getScreenshot(1);
    expect(result?.processing_status).toBe("failed");
    expect(result?.processing_issues?.[0]?.issue_type).toBe("image_blob_missing");
    expect(result?.has_blocking_issues).toBe(true);
  });

  test("labels an OCR-stage exception without claiming the OCR engine failed", async () => {
    const storage = makeStorage(makeScreenshot());
    const processing = {
      ...makeProcessing().service,
      processImageWithGridDetection: async () => {
        throw new Error("worker transport disconnected");
      },
    } as IProcessingService;
    const service = new WASMPreprocessingService(storage, processing, { enablePhi: false });

    const run = await service.runStage("ocr", { group_id: "g" });

    expect(run.queued_count).toBe(0);
    expect(run.failed_count).toBe(1);
    const result = await storage.getScreenshot(1);
    expect(result?.processing_status).toBe("failed");
    expect(result?.processing_issues?.[0]?.issue_type).toBe("ocr_stage_failed");
    expect((result?.processing_metadata as Record<string, unknown>).ocr_ever_failed).toBeUndefined();
    const preprocessing = (result?.processing_metadata as Record<string, unknown>)
      .preprocessing as { events: Array<{ result: Record<string, unknown> }> };
    const eventResult = preprocessing.events.at(-1)?.result;
    expect(eventResult?.ocr_failed).toBe(false);
    expect(eventResult?.ocr_error).toBeNull();
  });

  test("retains usable bars while labeling an actual OCR failure specifically", async () => {
    const storage = makeStorage(makeScreenshot());
    const processing = {
      ...makeProcessing().service,
      processImageWithGridDetection: async () => ({
        hourlyData: { "8": 30 },
        title: null,
        total: null,
        gridCoordinates: {
          upper_left: { x: 10, y: 20 },
          lower_right: { x: 210, y: 120 },
        },
        gridDetectionFailed: false,
        ocrFailed: true,
        ocrError: "OCR engine unavailable",
      }),
    } as IProcessingService;
    const service = new WASMPreprocessingService(storage, processing, { enablePhi: false });

    await service.runStage("ocr", { group_id: "g" });

    const result = await storage.getScreenshot(1);
    const metadata = result?.processing_metadata as Record<string, unknown>;
    expect(result?.processing_status).toBe("failed");
    expect(result?.extracted_hourly_data).toEqual({ "8": 30 });
    expect(metadata.ocr_ever_failed).toBe(true);
    expect(result?.processing_issues?.map((issue) => issue.issue_type)).toEqual([
      "ocr_processing_failed",
    ]);
    expect(result?.has_blocking_issues).toBe(true);
  });

  test("OCR rejects a commit after the crop input changes", async () => {
    const storage = makeStorage(makeScreenshot());
    const processing = makeProcessing();
    const originalProcess = processing.service.processImageWithGridDetection!.bind(processing.service);
    processing.service.processImageWithGridDetection = async (...args) => {
      await storage.updateScreenshot(1, { processing_metadata: { crop_history: { entries: [{ crop: "new" }], index: 0 } } });
      return originalProcess(...args);
    };
    await new WASMPreprocessingService(storage, processing.service, { enablePhi: false }).runStage("ocr", { group_id: "g" });
    const fresh = await storage.getScreenshot(1);
    expect(fresh?.processing_metadata?.crop_history).toEqual({ entries: [{ crop: "new" }], index: 0 });
    expect(fresh?.processing_status).toBe("pending");
    expect(fresh?.extracted_hourly_data).toBeUndefined();
  });

  test("reconciliation preserves stages owned by a live screenshot lock", async () => {
    const originalNavigator = Object.getOwnPropertyDescriptor(globalThis, "navigator");
    const screenshot = makeScreenshot();
    const pp = screenshot.processing_metadata!.preprocessing as { stage_status: Record<string, string> };
    pp.stage_status.ocr = "running";
    const storage = makeStorage(screenshot);
    Object.defineProperty(globalThis, "navigator", { configurable: true, value: {
      locks: { request: async (_name: string, _options: unknown, callback: (lock: null) => unknown) => callback(null) },
    } });
    try {
      const service = new WASMPreprocessingService(storage, makeProcessing().service, { enablePhi: false });
      expect(await service.reconcileStuckStages()).toBe(0);
      const fresh = await storage.getScreenshot(1);
      expect((fresh?.processing_metadata?.preprocessing as typeof pp).stage_status.ocr).toBe("running");
    } finally {
      if (originalNavigator) Object.defineProperty(globalThis, "navigator", originalNavigator);
      else Reflect.deleteProperty(globalThis, "navigator");
    }
  });

  test("failed cropping snapshot write leaves the main image unchanged and records failure", async () => {
    const screenshot = makeScreenshot();
    const storage = makeStorage(screenshot);
    const original = pngBlob(1170, 2532);
    let current = original;
    storage.getImageBlob = async () => current;
    storage.getStageBlob = async (_id, stage) => stage === "original" ? original : null;
    storage.saveImageBlob = async (_id, blob) => { current = blob; };
    storage.saveStageBlob = async (_id, stage) => {
      if (stage === "cropping") throw new DOMException("full", "QuotaExceededError");
    };
    const service = new WASMPreprocessingService(storage, makeProcessing().service, { enablePhi: false });
    const pool = { cropBlobToRect: async () => ({ croppedBlob: new Blob(["crop"]), croppedDimensions: { width: 10, height: 10 } }) };
    Object.assign(service, { getCropWorkerPool: () => pool });
    await expect(service.applyManualCrop(1, { left: 0, top: 0, right: 10, bottom: 10 })).rejects.toThrow("full");
    expect(current).toBe(original);
    const fresh = await storage.getScreenshot(1);
    expect((fresh?.processing_metadata?.preprocessing as { stage_status: Record<string, string> }).stage_status.cropping).toBe("failed");
  });

  test("does not persist an OCR failure when in-flight worker processing is aborted", async () => {
    const storage = makeStorage(makeScreenshot());
    const abortController = new AbortController();
    const processing = makeAbortingProcessing(abortController);
    const service = new WASMPreprocessingService(storage, processing.service, { enablePhi: false });

    const result = await service.runStage("ocr", {
      group_id: "g",
      abortSignal: abortController.signal,
    });

    expect(processing.getCalls()).toBe(1);
    expect(result.queued_count).toBe(0);
    expect(result.failed_count).toBe(0);

    const metrics = service.getStageSchedulerSnapshot().stages.ocr!;
    expect(metrics.lastQueuedItems).toBe(1);
    expect(metrics.lastCompletedItems).toBe(0);
    expect(metrics.lastFailedItems).toBe(0);
    expect(metrics.lastAbortedItems).toBe(1);

    const screenshot = await storage.getScreenshot(1);
    expect(screenshot?.processing_status).toBe("pending");
    expect(screenshot?.has_blocking_issues).toBeUndefined();
    expect(screenshot?.processing_issues).toBeUndefined();

    const preprocessing = (screenshot?.processing_metadata as Record<string, unknown>)
      .preprocessing as {
      events: Array<{ stage: string; result: Record<string, unknown> }>;
      stage_status: Record<string, string>;
    };
    expect(preprocessing.stage_status.ocr).toBe("pending");
    expect(preprocessing.events.filter((e) => e.stage === "ocr")).toHaveLength(0);
  });

  test("counts queued OCR items that never start after cancellation as aborted", async () => {
    const abortController = new AbortController();
    const storage = makeMultiStorage([
      withId(makeScreenshot(), 1),
      withId(makeScreenshot(), 2),
      withId(makeScreenshot(), 3),
    ]);
    const processing = makeAbortingProcessing(abortController);
    const service = new WASMPreprocessingService(storage, processing.service, { enablePhi: false });

    const result = await service.runStage("ocr", {
      group_id: "g",
      abortSignal: abortController.signal,
    });

    expect(processing.getCalls()).toBe(1);
    expect(result.queued_count).toBe(0);
    expect(result.failed_count).toBe(0);

    const metrics = service.getStageSchedulerSnapshot().stages.ocr!;
    expect(metrics.lastQueuedItems).toBe(3);
    expect(metrics.lastCompletedItems).toBe(0);
    expect(metrics.lastFailedItems).toBe(0);
    expect(metrics.lastAbortedItems).toBe(3);
    expect(
      metrics.lastCompletedItems + metrics.lastFailedItems + metrics.lastAbortedItems,
    ).toBe(metrics.lastQueuedItems);

    const first = await storage.getScreenshot(1);
    const second = await storage.getScreenshot(2);
    const third = await storage.getScreenshot(3);
    for (const screenshot of [first, second, third]) {
      expect(screenshot?.processing_status).toBe("pending");
      const preprocessing = (screenshot?.processing_metadata as Record<string, unknown>)
        .preprocessing as {
        events: Array<{ stage: string; result: Record<string, unknown> }>;
        stage_status: Record<string, string>;
      };
      expect(preprocessing.stage_status.ocr).toBe("pending");
      expect(preprocessing.events.filter((e) => e.stage === "ocr")).toHaveLength(0);
    }
  });

  test("resets a crop stage to pending when cancellation happens after it is marked running", async () => {
    const abortController = new AbortController();
    const storage = makeAbortDuringCropStorage(makeCropRequiredScreenshot(), abortController);
    const processing = makeProcessing();
    const service = new WASMPreprocessingService(storage, processing.service, { enablePhi: false });

    const result = await service.runStage("cropping", {
      group_id: "g",
      abortSignal: abortController.signal,
    });

    expect(result.queued_count).toBe(0);
    expect(result.failed_count).toBe(0);

    const screenshot = await storage.getScreenshot(1);
    expect(screenshot?.processing_status).toBe("pending");
    const preprocessing = (screenshot?.processing_metadata as Record<string, unknown>)
      .preprocessing as {
      events: Array<{ stage: string; result: Record<string, unknown> }>;
      stage_status: Record<string, string>;
    };
    expect(preprocessing.stage_status.cropping).toBe("pending");
    expect(preprocessing.events.filter((e) => e.stage === "cropping")).toHaveLength(0);
  });

  test("forceStop aborts in-flight crop worker work without recording a failed crop", async () => {
    MockCropWorker.instances = [];
    Object.defineProperty(globalThis, "window", {
      configurable: true,
      value: {},
    });
    Object.defineProperty(globalThis, "Worker", {
      configurable: true,
      value: MockCropWorker as unknown as typeof Worker,
    });

    try {
      const storage = makeStorage(makeCropRequiredScreenshot());
      const processing = makeProcessing();
      const service = new WASMPreprocessingService(storage, processing.service, { enablePhi: false });
      const abortController = new AbortController();

      const running = service.runStage("cropping", {
        group_id: "g",
        abortSignal: abortController.signal,
      });
      await flushMicrotasks(10);

      expect(MockCropWorker.instances).toHaveLength(1);
      expect(MockCropWorker.instances[0]?.postedMessages).toHaveLength(1);

      abortController.abort();
      service.forceStop();
      const result = await running;

      expect(result.queued_count).toBe(0);
      expect(result.failed_count).toBe(0);

      const stageMetrics = service.getStageSchedulerSnapshot().stages.cropping!;
      expect(stageMetrics.lastQueuedItems).toBe(1);
      expect(stageMetrics.lastCompletedItems).toBe(0);
      expect(stageMetrics.lastFailedItems).toBe(0);
      expect(stageMetrics.lastAbortedItems).toBe(1);

      const cropPool = service.getStageSchedulerSnapshot().cropWorkerPool!;
      expect(cropPool.poolSize).toBe(0);
      expect(cropPool.busyWorkers).toBe(0);
      expect(cropPool.queuedRequests).toBe(0);
      expect(cropPool.cancelled).toBe(1);
      expect(cropPool.terminated).toBe(1);

      const screenshot = await storage.getScreenshot(1);
      expect(screenshot?.processing_status).toBe("pending");
      const preprocessing = (screenshot?.processing_metadata as Record<string, unknown>)
        .preprocessing as {
        events: Array<{ stage: string; result: Record<string, unknown> }>;
        stage_status: Record<string, string>;
      };
      expect(preprocessing.stage_status.cropping).toBe("pending");
      expect(preprocessing.events.filter((e) => e.stage === "cropping")).toHaveLength(0);
    } finally {
      Object.defineProperty(globalThis, "window", {
        configurable: true,
        value: originalWindow,
      });
      Object.defineProperty(globalThis, "Worker", {
        configurable: true,
        value: originalWorker,
      });
    }
  });
});
