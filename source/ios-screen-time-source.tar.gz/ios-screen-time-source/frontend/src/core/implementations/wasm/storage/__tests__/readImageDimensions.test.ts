/**
 * Unit tests for header-only image dimension parsing (PNG + JPEG). This is what
 * device_detection uses instead of a full pixel decode, so it must read w/h
 * correctly from the header bytes — and return null (→ decode fallback) for
 * anything it can't parse.
 */
import { describe, it, expect } from "bun:test";
import { readImageDimensions } from "../opfsBlobStorage";

function u32be(n: number): number[] {
  return [(n >>> 24) & 0xff, (n >>> 16) & 0xff, (n >>> 8) & 0xff, n & 0xff];
}
function u16be(n: number): number[] {
  return [(n >>> 8) & 0xff, n & 0xff];
}
function blob(bytes: number[]): Blob {
  return new Blob([new Uint8Array(bytes)]);
}

function pngBytes(width: number, height: number): number[] {
  return [
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, // signature
    ...u32be(13), // IHDR length
    0x49, 0x48, 0x44, 0x52, // "IHDR"
    ...u32be(width),
    ...u32be(height),
    0x08, 0x06, 0x00, 0x00, 0x00, // bit depth / colour type / etc.
  ];
}

// JPEG: SOI, then an APP0 segment (to exercise the segment walk), then SOF0.
function jpegBytes(width: number, height: number): number[] {
  const app0Payload = Array.from({ length: 14 }, () => 0x00); // 14 bytes → length 16
  return [
    0xff, 0xd8, // SOI
    0xff, 0xe0, ...u16be(16), ...app0Payload, // APP0
    0xff, 0xc0, ...u16be(17), 0x08, ...u16be(height), ...u16be(width), // SOF0
    0x03, 0x01, 0x22, 0x00, // partial component data (ignored)
  ];
}

describe("readImageDimensions", () => {
  it("reads PNG width/height from IHDR", async () => {
    expect(await readImageDimensions(blob(pngBytes(1170, 2532)))).toEqual({ width: 1170, height: 2532 });
  });

  it("reads JPEG width/height from the first SOF marker (after APP0)", async () => {
    expect(await readImageDimensions(blob(jpegBytes(2048, 2732)))).toEqual({ width: 2048, height: 2732 });
  });

  it("returns null for an unrecognised format", async () => {
    expect(await readImageDimensions(blob([0x00, 0x01, 0x02, 0x03, 0x04, 0x05, ...Array<number>(30).fill(0)]))).toBeNull();
  });

  it("returns null for a too-short blob", async () => {
    expect(await readImageDimensions(blob([0x89, 0x50, 0x4e, 0x47]))).toBeNull();
  });

});
