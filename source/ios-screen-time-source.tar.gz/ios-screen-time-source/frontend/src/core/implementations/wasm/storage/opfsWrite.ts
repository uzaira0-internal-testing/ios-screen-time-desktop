/**
 * The one way this app writes a whole file to OPFS.
 *
 * `FileSystemFileHandle.createWritable()` only exists in Safari from 26, so
 * older Safari and the macOS 13.3–15 WKWebView desktop shell cannot write OPFS
 * files from the page. They do have `createSyncAccessHandle()` (Safari 15.2+),
 * which works only in a dedicated worker; `opfsWrite.worker.ts` does the write
 * there when `createWritable` is missing.
 *
 * `createWritable` writes to a swap file and replaces the target on close, so
 * a failed write leaves the old contents. The worker writes in place and
 * deletes the file if the write fails, so a failure leaves no file rather than
 * a partial one. Errors reach the caller with their DOMException name intact,
 * so quota checks (`isQuotaExceeded`) see `QuotaExceededError` either way.
 */

export type OpfsWriteData = Blob | ArrayBuffer | Uint8Array | string;

export interface OpfsWriteRequest {
  id: number;
  /** Directory names below the OPFS root, e.g. `["screenshots"]`. */
  path: readonly string[];
  name: string;
  data: OpfsWriteData;
}

export interface OpfsWriteErrorPayload {
  name: string;
  message: string;
  stack?: string;
}

export type OpfsWriteResponse =
  | { id: number; type: "result" }
  | { id: number; type: "error"; error: OpfsWriteErrorPayload };

/** The part of `Worker` this module uses; tests substitute a fake. */
export interface OpfsWriteWorker {
  postMessage(message: OpfsWriteRequest): void;
  terminate(): void;
  onmessage: ((event: MessageEvent<OpfsWriteResponse>) => void) | null;
  onerror: ((event: ErrorEvent) => void) | null;
  onmessageerror: ((event: MessageEvent) => void) | null;
}

function createWorker(): OpfsWriteWorker {
  return new Worker(new URL("./opfsWrite.worker.ts", import.meta.url), {
    type: "module",
  }) as unknown as OpfsWriteWorker;
}

let workerFactory: () => OpfsWriteWorker = createWorker;
let worker: OpfsWriteWorker | null = null;
/** Set once the worker itself fails to load or run; later writes fail fast. */
let workerFailure: Error | null = null;
let nextId = 1;
const pending = new Map<number, { resolve: () => void; reject: (error: Error) => void }>();

function toError(payload: OpfsWriteErrorPayload): Error {
  // DOMException keeps `name` (and the legacy `code`, e.g. 22 for quota).
  const error = new DOMException(payload.message, payload.name);
  if (payload.stack) {
    try {
      Object.defineProperty(error, "stack", { value: payload.stack, configurable: true });
    } catch {
      /* stack is read-only on some engines */
    }
  }
  return error;
}

function failWorker(error: Error): void {
  workerFailure = error;
  const current = worker;
  worker = null;
  current?.terminate();
  for (const entry of pending.values()) entry.reject(error);
  pending.clear();
}

function getWorker(): OpfsWriteWorker {
  if (worker) return worker;
  const created = workerFactory();
  created.onmessage = (event) => {
    const response = event.data;
    const entry = pending.get(response.id);
    if (!entry) return;
    pending.delete(response.id);
    if (response.type === "result") entry.resolve();
    else entry.reject(toError(response.error));
  };
  created.onerror = (event) => {
    event.preventDefault?.();
    failWorker(new Error(`OPFS write worker failed: ${event.message || "could not load"}`));
  };
  created.onmessageerror = () => {
    failWorker(new Error("OPFS write worker could not read a message"));
  };
  worker = created;
  return created;
}

function writeInWorker(path: readonly string[], name: string, data: OpfsWriteData): Promise<void> {
  if (workerFailure) return Promise.reject(workerFailure);
  return new Promise<void>((resolve, reject) => {
    const id = nextId++;
    pending.set(id, { resolve, reject });
    try {
      getWorker().postMessage({ id, path: [...path], name, data });
    } catch (error) {
      pending.delete(id);
      reject(error instanceof Error ? error : new Error(String(error)));
    }
  });
}

/**
 * Replace `name` in `dir` with `data`. `path` is the directory names from the
 * OPFS root down to `dir`; the worker fallback needs it because it opens the
 * file from its own `navigator.storage.getDirectory()`.
 */
export async function writeOpfsFile(
  dir: FileSystemDirectoryHandle,
  path: readonly string[],
  name: string,
  data: OpfsWriteData,
): Promise<void> {
  const handle = await dir.getFileHandle(name, { create: true });
  if (typeof handle.createWritable !== "function") {
    try {
      await writeInWorker(path, name, data);
    } catch (error) {
      // The worker removes a file it failed to write, but if it never ran,
      // the empty file `getFileHandle` just created would be left behind.
      await dir.removeEntry(name).catch(() => { /* non-fatal: already gone, or the write error below says why */ });
      throw error;
    }
    return;
  }
  let writable: FileSystemWritableFileStream | null = null;
  try {
    writable = await handle.createWritable();
    await writable.write(data as FileSystemWriteChunkType);
    await writable.close();
  } catch (error) {
    try { await writable?.abort(); } catch { /* release a partial OPFS stream */ }
    throw error;
  }
}

/** Test seam: replace the worker constructor and forget any worker state. */
export function setOpfsWriteWorkerFactoryForTests(factory: (() => OpfsWriteWorker) | null): void {
  worker?.terminate();
  worker = null;
  workerFailure = null;
  pending.clear();
  workerFactory = factory ?? createWorker;
}
