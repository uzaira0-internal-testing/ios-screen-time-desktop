/**
 * Loader for the Emscripten-compiled pipeline (Path B).
 *
 * The emscripten build produces IosScreenTimePipeline.js + .wasm which are
 * placed in /pipeline-em/ at build time (see scripts/build-wasm-emscripten.sh).
 *
 * This module handles:
 *  1. Dynamically importing the Emscripten JS glue
 *  2. Fetching + mounting eng.traineddata into the Emscripten virtual FS
 *  3. Providing typed wrappers around the raw C-ABI exports
 */

import {
  BUNDLED_LANGUAGE,
  readLanguagePack,
  tesseractLanguageString,
} from "@/core/implementations/wasm/languagePacks/languagePackStore";
import { PIPELINE_ASSET_BASE } from "./pipelineAssetBase";
import { decodeToRgba, pngFromRust } from "./rgbaCodec";

export interface EmPipelineResult {
  pipeline_schema_version?: number;
  success: boolean;
  hourly_values?: number[];
  /** Reading direction of the hour axis. `"rtl"` means iOS mirrored the chart
   *  (Hebrew, Arabic); `hourly_values` is already in clock order either way, but
   *  the flag must be stored so a later manual grid adjustment can re-apply it. */
  axis_direction?: "ltr" | "rtl";
  total?: number;
  alignment_score?: number;
  grid_registration_score?: number;
  title?: string | null;
  total_text?: string | null;
  is_daily_total?: boolean;
  grid_bounds?: {
    upper_left_x: number;
    upper_left_y: number;
    lower_right_x: number;
    lower_right_y: number;
  };
  grid_confidence?: number;
  suspected_all_devices?: boolean;
  axis_max_minutes?: number | null;
  all_devices_reasons?: string[];
  error?: string;
  ocr_error?: string | null;
  /** Set when `pipeline_process` returned a negative length. For this result
   *  shape the 64 KB output buffer is never genuinely too small, so a negative
   *  length means the wasm was called with the wrong ABI — a stale / mismatched
   *  cached pipeline bundle. The main thread self-heals on this flag
   *  (see lib/wasmRecovery.ts). */
  abiMismatch?: boolean;
}

export const REQUIRED_PIPELINE_SCHEMA_VERSION = 4;

/** Reject an old compiled pipeline explicitly. Newly-added result fields must
 * never degrade to false/null merely because a stale ignored WASM artifact was
 * copied into a fresh frontend bundle. */
export function validatePipelineResultContract(
  result: EmPipelineResult,
): EmPipelineResult {
  if (result.pipeline_schema_version === REQUIRED_PIPELINE_SCHEMA_VERSION) {
    return result;
  }
  const actual = result.pipeline_schema_version ?? "missing";
  return {
    ...(result.pipeline_schema_version !== undefined && {
      pipeline_schema_version: result.pipeline_schema_version,
    }),
    success: false,
    abiMismatch: true,
    error:
      `Incompatible OCR pipeline schema (${actual}); ` +
      `expected ${REQUIRED_PIPELINE_SCHEMA_VERSION}. Rebuild the Emscripten pipeline.`,
  };
}

export interface EmGridResult {
  success: boolean;
  bounds?: {
    upper_left_x: number;
    upper_left_y: number;
    lower_right_x: number;
    lower_right_y: number;
  } | null;
  confidence: number;
  method: string;
  error?: string;
  /** OCR engine failure encountered while the OCR-anchored detector ran. */
  ocr_error?: string | null;
  /** True when the chart was positively identified as the WEEKLY (7-column) view
   * rather than the daily (24-hour) chart. Lets callers reject it with a clear
   * "capture the daily view" message. Mirrors the Rust GridDetectionResult field. */
  is_weekly?: boolean;
  /** Reading direction the detector established from the hour labels. Detectors
   *  that read no labels (LineBased) always report `"ltr"`. */
  axis_direction?: "ltr" | "rtl";
}

export interface EmOcrResult {
  title?: string | null;
  total_text?: string | null;
  is_daily_total?: boolean;
  ocr_error?: string | null;
  error?: string;
}

/** Per-word OCR result for PHI detection. `char_start`/`char_end` are
 *  offsets into the joined `full_text` (space-separated), so JS can map
 *  regex/NER matches back to image bboxes without re-tokenizing. */
export interface EmPhiWord {
  text: string;
  x: number;
  y: number;
  w: number;
  h: number;
  conf: number;
  char_start: number;
  char_end: number;
}

export interface EmPhiWordsResult {
  success: boolean;
  words?: EmPhiWord[];
  full_text?: string;
  avg_confidence?: number;
  error?: string;
}

/** The slice of Emscripten's virtual filesystem API this loader uses. */
interface EmscriptenFS {
  mkdir(path: string): void;
  writeFile(path: string, data: Uint8Array): void;
  symlink(oldPath: string, newPath: string): void;
}

/**
 * Typed surface of the generated Emscripten glue module.
 *
 * The glue itself is untyped generated JS; this interface is the contract the
 * loader relies on — the C-ABI exports listed in EXPORTED_FUNCTIONS of
 * `scripts/build-wasm-emscripten.sh` plus the FS/heap plumbing. Argument
 * counts here MUST match the Rust `pipeline_em.rs` signatures: the 17-arg
 * `_pipeline_process` / 19-arg `_pipeline_extract_bars` layouts are the ABI
 * that `abiMismatch` recovery exists to police, so a drift between this type
 * and the wasm is exactly the bug the schema-version check catches at runtime.
 */
interface EmscriptenModule {
  FS: EmscriptenFS;
  /** View over wasm linear memory. Emscripten replaces it on memory growth, so
   *  it is always re-read from the module, never cached. */
  HEAPU8: Uint8Array;
  _pipeline_alloc(len: number): number;
  _pipeline_free(ptr: number, len: number): void;
  _pipeline_decode(bytesPtr: number, bytesLen: number, outDimsPtr: number): number;
  _pipeline_crop_png(bytesPtr: number, bytesLen: number, x: number, y: number, w: number, h: number, outLenPtr: number): number;
  _pipeline_redact_png(
    bytesPtr: number,
    bytesLen: number,
    regionsPtr: number,
    methodPtr: number,
    padding: number,
    outLenPtr: number,
  ): number;
  _pipeline_dhash(bytesPtr: number, bytesLen: number, outPtr: number): number;
  _pipeline_column_fills(
    rgbaPtr: number,
    rgbaLen: number,
    width: number,
    height: number,
    x: number,
    y: number,
    w: number,
    h: number,
    outPtr: number,
  ): number;
  _pipeline_set_language(langPtr: number): void;
  _pipeline_process(
    rgbaPtr: number,
    rgbaLen: number,
    width: number,
    height: number,
    imgTypePtr: number,
    maxShift: number,
    gridUlX: number,
    gridUlY: number,
    gridLrX: number,
    gridLrY: number,
    apportionMaxMinutes: number,
    apportionMaxPercent: number,
    apportionMinRegistration: number,
    gridRegDeadband: number,
    gridRegTol: number,
    outPtr: number,
    outLen: number,
  ): number;
  _pipeline_extract_bars(
    rgbaPtr: number,
    rgbaLen: number,
    width: number,
    height: number,
    imgTypePtr: number,
    gridUlX: number,
    gridUlY: number,
    gridLrX: number,
    gridLrY: number,
    totalPtr: number,
    apportionMaxMinutes: number,
    apportionMaxPercent: number,
    apportionMinRegistration: number,
    gridRegDeadband: number,
    gridRegTol: number,
    axisPtr: number,
    axisMaxMinutes: number,
    outPtr: number,
    outLen: number,
  ): number;
  _pipeline_detect_grid(
    rgbaPtr: number,
    rgbaLen: number,
    width: number,
    height: number,
    method: number,
    outPtr: number,
    outLen: number,
  ): number;
  _pipeline_extract_ocr(
    rgbaPtr: number,
    rgbaLen: number,
    width: number,
    height: number,
    outPtr: number,
    outLen: number,
  ): number;
  _pipeline_phi_words(
    rgbaPtr: number,
    rgbaLen: number,
    width: number,
    height: number,
    outPtr: number,
    outLen: number,
  ): number;
}

let modulePromise: Promise<EmscriptenModule> | null = null;
const TEXT_ENCODER = new TextEncoder();
const TEXT_DECODER = new TextDecoder();

/**
 * PERF-1/PERF-11: `eng.traineddata` is ~4 MB. With a worker pool, each worker
 * fetching its own copy on a cold cache means N parallel downloads. The main
 * thread can fetch it once and hand a Blob handle to every worker via the
 * INITIALIZE message; `ensureTessdataMounted` consumes it through this slot
 * instead of issuing its own `fetch`. A worker that receives no preloaded
 * asset falls back to fetching its own copy.
 */
type TessdataSource = ArrayBuffer | Blob;

let preloadedTessdata: TessdataSource | null = null;

/** Hand the worker a preloaded `eng.traineddata` asset before `loadModule`
 *  fetches its own. Must be called before the first OCR call for the saving
 *  to take effect. */
export function setPreloadedTessdata(source: TessdataSource): void {
  preloadedTessdata = source;
}

/**
 * The user's enabled OCR languages, as Tesseract's `+`-joined string.
 *
 * The enabled set is persisted in localStorage, which does NOT exist in a Web
 * Worker — `tesseractLanguageString()` called in here silently returned "eng"
 * and every downloaded pack went unmounted, so a Hebrew total (say) read as
 * nothing while the grid and bars looked perfect. The pack BYTES live in OPFS
 * and are readable from a worker; only the selection has to travel, so the main
 * thread resolves it and posts it with the other preloaded assets.
 */
let preloadedLanguages: string | null = null;

export function setPreloadedLanguages(languages: string): void {
  if (preloadedLanguages === languages) return;
  preloadedLanguages = languages;
  // The mount is memoized, and Tesseract binds its packs at engine init. A user
  // who enables a pack after the worker pool has warmed up would otherwise keep
  // the old language set for the life of the worker, so drop the memo and let
  // the next OCR call remount and re-announce the languages.
  tessdataMountedPromise = null;
}

/**
 * PERF-1: the compiled `IosScreenTimePipeline.wasm` (~5.9 MB) is identical for
 * every worker — only the linear memory is per-instance. The main thread
 * compiles it ONCE with `WebAssembly.compileStreaming` and posts the resulting
 * `WebAssembly.Module` (structured-cloneable to dedicated workers, sharing the
 * compiled code) to every worker via INITIALIZE. `loadModule` then feeds it to
 * Emscripten through the `instantiateWasm` hook so the glue skips its own
 * fetch+compile entirely. A worker that receives no preloaded module (e.g. the
 * warm-up call before INITIALIZE) falls back to the glue's own streaming
 * `instantiateStreaming` path — the streaming-compile win is preserved either
 * way; it just happens once instead of N times.
 */
let preloadedWasmModule: WebAssembly.Module | null = null;

/** Hand the worker a preloaded, pre-compiled `WebAssembly.Module` for the
 *  pipeline before `loadModule` instantiates Emscripten. Must be called before
 *  the first pipeline call for the saving to take effect. Mirrors
 *  `setPreloadedTessdata`. */
export function setPreloadedWasmModule(module: WebAssembly.Module): void {
  preloadedWasmModule = module;
}

let tessdataMountedPromise: Promise<void> | null = null;

// Resolve relative to the bundled chunk URL. Under GitHub Pages this becomes
// `https://<host>/<repo>/assets/<chunk>.js`, so `../pipeline-em/` lands at
// `<repo>/pipeline-em/`. An absolute `/pipeline-em/` would break the subpath.
const BASE = PIPELINE_ASSET_BASE;
const OUTPUT_BUFFER_SIZE = 65536; // 64 KB — enough for any JSON result

// Build-time content hash of IosScreenTimePipeline.wasm (16-char SHA-256
// prefix), inlined by the bundler (server/build.ts `define`). Empty in dev,
// where there is no define — `typeof` keeps that from throwing.
declare const __PIPELINE_WASM_HASH__: string;
const PIPELINE_VERSION =
  typeof __PIPELINE_WASM_HASH__ !== "undefined" ? __PIPELINE_WASM_HASH__ : "";
/**
 * `?v=<wasm-hash>` stamped onto the ABI-coupled pipeline asset URLs — the glue,
 * the wasm, and the glue's integrity sidecar. A JS bundle built against wasm
 * hash X requests `…IosScreenTimePipeline.wasm?v=X`, so the service worker can
 * only satisfy it with the wasm it precached under that exact key — it can never
 * serve a wasm from a different deploy. This is the structural fix for the
 * JS↔wasm ABI skew (the 12→16-arg `pipeline_process` change) that
 * `lib/wasmRecovery.ts` recovers from at runtime: prevent the mismatch at the
 * source instead. The hash is stable while the wasm is unchanged, so it does not
 * force a needless 5.9 MB re-download each deploy. `eng.traineddata` is
 * ABI-independent and large, so it is intentionally left unstamped. Empty in dev
 * → bare URLs.
 */
const PIPELINE_VERSION_QUERY = PIPELINE_VERSION ? `?v=${PIPELINE_VERSION}` : "";

/** URL of `eng.traineddata`, resolved against the same `BASE` the loader
 *  fetches from. Exported so the main thread (WASMProcessingService) can
 *  fetch the buffer ONCE and share it with the pool (PERF-1/PERF-11) without
 *  duplicating — or drifting from — this module's URL-resolution logic. */
export function getTessdataUrl(): string {
  return `${BASE}eng.traineddata`;
}

/** URL of the compiled pipeline `.wasm`, resolved against the same `BASE` the
 *  loader's `locateFile` would resolve it to. Exported so the main thread
 *  (WASMProcessingService) can `compileStreaming` the module ONCE and share it
 *  with the pool (PERF-1) without duplicating this module's URL-resolution
 *  logic. */
export function getWasmUrl(): string {
  return `${BASE}IosScreenTimePipeline.wasm${PIPELINE_VERSION_QUERY}`;
}

/**
 * SEC-6: integrity check on the fetched Emscripten glue before it is executed
 * via `new Function`. The expected SHA-256 is published as a sidecar file
 * `IosScreenTimePipeline.js.sha256` (hex digest, optionally followed by a
 * filename à la `sha256sum`). If the sidecar is absent (404) we log a warning
 * and proceed — emitting the sidecar is a build-step concern that lives in
 * `scripts/build-wasm-emscripten.sh` (outside this module). If the sidecar IS
 * present and the digest mismatches, we refuse to execute the script.
 */
async function verifyScriptIntegrity(
  scriptUrl: string,
  src: string,
  sidecarUrl: string,
): Promise<void> {
  if (typeof crypto === "undefined" || !crypto.subtle) {
    console.warn("[pipelineLoader] SubtleCrypto unavailable — skipping glue integrity check");
    return;
  }

  let expected: string | null = null;
  try {
    const resp = await fetch(sidecarUrl);
    if (resp.ok) {
      // sha256sum format: "<hex>  <filename>" — take the leading hex token.
      expected = (await resp.text()).trim().split(/\s+/)[0]?.toLowerCase() ?? null;
    }
  } catch {
    /* network error fetching the sidecar — treated the same as a 404 below */
  }

  if (!expected) {
    console.warn(
      "[pipelineLoader] No IosScreenTimePipeline.js.sha256 sidecar found — " +
        "executing glue without integrity verification. Emit the sidecar in " +
        "the WASM build step to close SEC-6.",
    );
    return;
  }

  const digest = await crypto.subtle.digest("SHA-256", TEXT_ENCODER.encode(src));
  const actual = Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  if (actual !== expected) {
    throw new Error(
      `[pipelineLoader] Integrity check FAILED for ${scriptUrl}: ` +
        `expected ${expected}, got ${actual}. Refusing to execute.`,
    );
  }
}

async function loadModule(): Promise<EmscriptenModule> {
  if (modulePromise) return modulePromise;

  const promise = (async () => {
    const scriptUrl = `${BASE}IosScreenTimePipeline.js${PIPELINE_VERSION_QUERY}`;
    // The SEC-6 integrity sidecar carries the SAME version stamp, appended after
    // the `.sha256` suffix (not after the query) so the path resolves correctly.
    const sidecarUrl = `${BASE}IosScreenTimePipeline.js.sha256${PIPELINE_VERSION_QUERY}`;

    let factory: (opts: object) => Promise<EmscriptenModule>;

    // Workers don't have `document` — use fetch + new Function instead of a
    // script tag. The Emscripten glue is a UMD/IIFE bundle (`var
    // IosScreenTimePipeline = (() => {...})()`), NOT an ES module, so a
    // blob-URL `import()` would not expose the factory — `new Function` is
    // the available option. SEC-6: the fetched source is SHA-256 verified
    // against a build-emitted sidecar (when present) before execution.
    if (typeof document === "undefined") {
      const src = await fetch(scriptUrl).then((r) => {
        if (!r.ok) throw new Error(`Failed to fetch ${scriptUrl}: ${r.status}`);
        return r.text();
      });
      await verifyScriptIntegrity(scriptUrl, src, sidecarUrl);
      // SEC-6: `new Function` is required to load the UMD/IIFE Emscripten glue
      // in a module worker (no `document` for a <script> tag; the bundle is
      // not an ES module so a blob-URL import would not expose the factory).
      // The fetched source is SHA-256 verified against a build-emitted sidecar
      // (verifyScriptIntegrity, above) before it is executed here.
      // eslint-disable-next-line @typescript-eslint/no-implied-eval -- SEC-6: deliberate — the only way to evaluate the UMD glue in a module worker; the source was SHA-256 verified above
      factory = (new Function(`${src}; return IosScreenTimePipeline;`) as () => typeof factory)();
    } else {
      await new Promise<void>((resolve, reject) => {
        const script = document.createElement("script");
        script.src = scriptUrl;
        script.onload = () => resolve();
        script.onerror = () => reject(new Error(`Failed to load ${scriptUrl}`));
        document.head.appendChild(script);
      });
      // The UMD factory attaches itself to globalThis untyped; narrow it here.
      factory = (globalThis as { IosScreenTimePipeline?: typeof factory }).IosScreenTimePipeline as typeof factory;
    }

    if (typeof factory !== "function") {
      throw new Error("IosScreenTimePipeline factory not found");
    }

    // PERF-12: WASM streaming compilation is in effect. We pass no
    // `wasmBinary` to the factory, so the Emscripten glue uses
    // `WebAssembly.instantiateStreaming` against the `.wasm` URL resolved by
    // `locateFile` — the module compiles as it downloads. Keep it that way:
    // setting `wasmBinary` here would force a buffer-then-compile path and
    // lose the streaming win. (nginx must serve `application/wasm` for the
    // streaming path to be taken — verified at deploy time, not here.)
    //
    // PERF-1: when the main thread has already `compileStreaming`-compiled the
    // module once and shared it (setPreloadedWasmModule), supply Emscripten's
    // `instantiateWasm(imports, successCallback)` hook so the glue REUSES that
    // compiled `WebAssembly.Module` instead of fetching+compiling its own copy
    // per worker. The hook must return synchronously; it kicks off
    // `WebAssembly.instantiate(module, imports)` and calls `successCallback`
    // from the resolved promise. `successCallback` is the glue's
    // `receiveInstance(instance, module?)` — passing just the instance is the
    // documented contract. Returning `{}` tells Emscripten the exports will
    // arrive asynchronously via the callback. With no shared module, the hook
    // is omitted and the glue's own streaming path runs (the warm-up call
    // before INITIALIZE takes this branch).
    const factoryOpts: Record<string, unknown> = {
      // Stamp the pipeline wasm by its EXACT basename — matching the precache,
      // which stamps that same basename — so the loader's request URL and the
      // precached cache key stay byte-identical (an `.endsWith(".wasm")` would
      // silently diverge if a second wasm were ever added but not stamped in the
      // precache). Used on the warm-up path where the glue fetches the wasm
      // itself; when the main thread shares a pre-compiled module (PERF-1) this
      // branch isn't hit.
      locateFile: (name: string) =>
        `${BASE}${name}${name === "IosScreenTimePipeline.wasm" ? PIPELINE_VERSION_QUERY : ""}`,
      // Filter benign leptonica/tesseract stderr that Emscripten routes to the
      // console. The WASM leptonica is built WITHOUT TIFF, so tesseract's debug
      // bitmap-font generation (the font is stored internally as a TIFF blob)
      // fails harmlessly — pixReadMemTiff → pixReadMem → pixaGenerateFontFromString
      // → bmfCreate — and tesseract logs a DPI estimate when the image carries no
      // resolution metadata. None of these affect text/anchor extraction; drop
      // them so they don't read as errors, but surface anything else as a warning.
      printErr: (text: string) => {
        if (/pixReadMemTiff|pixReadMem|pixaGenerateFontFromString|bmfCreate|Estimating resolution as/.test(text)) {
          return;
        }
        console.warn("[pipeline]", text);
      },
    };
    const sharedModule = preloadedWasmModule;
    if (sharedModule) {
      factoryOpts.instantiateWasm = (
        imports: WebAssembly.Imports,
        successCallback: (instance: WebAssembly.Instance) => void,
      ): object => {
        WebAssembly.instantiate(sharedModule, imports)
          .then((instance) => successCallback(instance))
          .catch((err: unknown) => {
            console.error("[pipelineLoader] shared WASM module instantiation failed:", err);
          });
        return {};
      };
    }
    const mod: EmscriptenModule = await factory(factoryOpts);

    return mod;
  })();

  // Cache the in-flight promise so concurrent callers share it, but on
  // rejection clear the cache so the NEXT call retries. Without this
  // clear, a transient fetch failure (offline blip, stale cache) sticks
  // forever and every OCR call returns the same rejection.
  modulePromise = promise.catch((err) => {
    modulePromise = null;
    throw err;
  });
  return modulePromise;
}

// ── Desktop native pipeline ──────────────────────────────────────────────────
// The desktop shell serves the same pipeline built natively (crates/processing,
// bin pipeline_native) behind its `pipeline:` scheme. It returns byte-identical
// JSON (tests/wasm/native_parity.mjs) and runs faster than WebKit's wasm. Its OCR
// is English only, since language packs live in page storage, so an OCR call
// goes native only while this module's own OCR language is plain English. Any
// failure returns null and the caller runs the call in wasm.
const NATIVE_URL: string | null = (() => {
  const location = globalThis.location as Location | undefined;
  if (location?.protocol === "tauri:") return "pipeline://localhost/";
  if (location?.hostname === "tauri.localhost") return `${location.protocol}//pipeline.localhost/`;
  return null;
})();
let nativeAvailable = NATIVE_URL !== null;
const disableNative = (): void => {
  nativeAvailable = false;
};
/** The language string last handed to `_pipeline_set_language`. */
let mountedLanguage: string | null = null;

async function nativeCall(
  op: string,
  imageData: ImageData,
  fields: Record<string, unknown>,
  ocr: boolean,
): Promise<string | null> {
  if (!nativeAvailable || NATIVE_URL === null) return null;
  if (ocr && mountedLanguage !== BUNDLED_LANGUAGE) return null;
  // Two frames, each a u32 little-endian length then its bytes: the JSON header
  // and the RGBA, as the sidecar reads them.
  const header = TEXT_ENCODER.encode(
    JSON.stringify({ width: imageData.width, height: imageData.height, op, ...fields }),
  );
  const rgba = imageData.data;
  const body = new Uint8Array(8 + header.length + rgba.length);
  const view = new DataView(body.buffer);
  view.setUint32(0, header.length, true);
  body.set(header, 4);
  view.setUint32(4 + header.length, rgba.length, true);
  body.set(rgba, 8 + header.length);
  try {
    const response = await fetch(NATIVE_URL, { method: "POST", body });
    if (response.ok) return await response.text();
    // 503: this build ships no native pipeline.
    if (response.status === 503) disableNative();
  } catch {
    // The scheme is not served (an older shell): stay on wasm.
    disableNative();
  }
  return null;
}

function nativeKnobs(options?: {
  apportionMaxMinutes?: number;
  apportionMaxPercent?: number;
  apportionMinRegistration?: number;
  gridRegDeadband?: number;
  gridRegTol?: number;
}): Record<string, number> {
  return {
    apportion_max_minutes: options?.apportionMaxMinutes ?? -1,
    apportion_max_percent: options?.apportionMaxPercent ?? -1,
    apportion_min_registration: options?.apportionMinRegistration ?? -1,
    grid_reg_deadband: options?.gridRegDeadband ?? -1,
    grid_reg_tol: options?.gridRegTol ?? -1,
  };
}

async function ensureTessdataMounted(mod: EmscriptenModule): Promise<void> {
  if (tessdataMountedPromise) return tessdataMountedPromise;

  const promise = (async () => {
    // Mount eng.traineddata into the Emscripten virtual filesystem only when an
    // OCR-capable path actually needs it. LineBased grid detection can now load
    // the WASM module without pinning the ~22 MB tessdata buffer in every worker.
    // PERF-1/PERF-11: prefer tessdata preloaded by the main thread (one fetch
    // shared across the pool) over fetching our own copy. Blob payloads clone
    // to workers by reference, so materialize bytes only inside the worker that
    // is about to mount OCR.
    const tessdata = preloadedTessdata
      ? preloadedTessdata instanceof Blob
        ? await preloadedTessdata.arrayBuffer()
        : preloadedTessdata
      : await fetch(`${BASE}eng.traineddata`).then((r) => {
          if (!r.ok) throw new Error(`Failed to fetch eng.traineddata: ${r.status}`);
          return r.arrayBuffer();
        });

    // Tesseract's strict convention is to search at
    // ${TESSDATA_PREFIX}/tessdata/eng.traineddata. Some leptess/libtesseract
    // revisions also fall back to ${TESSDATA_PREFIX}/eng.traineddata, so we
    // expose both. Use FS.symlink for the second path so the ~22 MB buffer
    // is written exactly once instead of duplicated. mkdir() throws EEXIST
    // if the directory is already there (across HMR or repeated calls in
    // dev), so guard each one.
    const tryMkdir = (path: string) => {
      try { mod.FS.mkdir(path); } catch (e) {
        const err = e as { code?: string; errno?: number };
        if (err?.code !== "EEXIST" && err?.errno !== 20) throw e;
      }
    };
    tryMkdir("/tesseract");
    tryMkdir("/tesseract/tessdata");
    const buf = new Uint8Array(tessdata);
    mod.FS.writeFile("/tesseract/tessdata/eng.traineddata", buf);
    try {
      mod.FS.symlink("/tesseract/tessdata/eng.traineddata", "/tesseract/eng.traineddata");
    } catch (e) {
      const err = e as { code?: string; errno?: number };
      // EEXIST means a previous load already created it; safe to ignore.
      // Anything else: fall back to a second writeFile so OCR still works.
      if (err?.code !== "EEXIST" && err?.errno !== 20) {
        console.warn("[pipelineLoader] symlink failed, falling back to duplicate write:", e);
        mod.FS.writeFile("/tesseract/eng.traineddata", buf);
      }
    }
    // Mount any language packs the user downloaded, then tell the pipeline
    // which languages to recognise with. Each pack is optional: a pack that
    // fails to read is skipped and simply left out of the language string, so
    // OCR still runs in English rather than failing engine init outright.
    try {
      // In a worker the selection can only come from the main thread (see
      // setPreloadedLanguages); tesseractLanguageString() is the main-thread path.
      const enabled = preloadedLanguages ?? (await tesseractLanguageString());
      const extras = enabled.split("+").filter((c) => c && c !== BUNDLED_LANGUAGE);
      const mounted: string[] = [];
      for (const code of extras) {
        // eslint-disable-next-line no-await-in-loop -- packs mount sequentially on purpose: one pack's bytes in memory at a time bounds worker RSS, and pack count is tiny
        const packBytes = await readLanguagePack(code);
        if (!packBytes) {
          console.warn(`[pipelineLoader] language pack "${code}" enabled but not readable; skipping`);
          continue;
        }
        // Exactly where eng.traineddata goes: the canonical
        // ${TESSDATA_PREFIX}/tessdata/ path, plus a link at the flat path some
        // leptess/libtesseract revisions probe instead. A pack present at only
        // one of the two makes LepTess::new("eng+<code>") fail outright, and the
        // Rust side then degrades to English — the total silently goes missing
        // while grid and bars still look perfect.
        mod.FS.writeFile(`/tesseract/tessdata/${code}.traineddata`, packBytes);
        try {
          mod.FS.symlink(`/tesseract/tessdata/${code}.traineddata`, `/tesseract/${code}.traineddata`);
        } catch (e) {
          const err = e as { code?: string; errno?: number };
          if (err?.code !== "EEXIST" && err?.errno !== 20) {
            mod.FS.writeFile(`/tesseract/${code}.traineddata`, packBytes);
          }
        }
        mounted.push(code);
      }
      // Only claim languages actually mounted — naming a pack whose file is
      // absent makes Tesseract refuse to initialise at all.
      const lang = [BUNDLED_LANGUAGE, ...mounted].join("+");
      const langBytes = encodeNullTerminated(lang);
      const langPtr = allocatePipelineBuffer(mod, langBytes.length);
      try {
        mod.HEAPU8.set(langBytes, langPtr);
        mod._pipeline_set_language(langPtr);
      } finally {
        mod._pipeline_free(langPtr, langBytes.length);
      }
      mountedLanguage = lang;
      if (mounted.length) {
        // eslint-disable-next-line no-console -- deliberate info-level breadcrumb: which OCR languages actually mounted is the first question when a non-English total goes missing
        console.info(`[pipelineLoader] OCR languages: ${lang}`);
      }
    } catch (e) {
      if (e instanceof RangeError && e.message.startsWith("WASM pipeline allocation failed")) throw e;
      // Never let an optional accuracy upgrade break module load.
      mountedLanguage = null;
      console.warn("[pipelineLoader] language pack mount failed, continuing in English:", e);
    }

    // The virtual FS now owns a copy of the tessdata bytes. Drop the preloaded
    // Blob/ArrayBuffer reference so this worker does not keep the shared asset
    // alive in addition to the mounted OCR data.
    // eslint-disable-next-line require-atomic-updates -- tessdataMountedPromise serializes this mount path; clearing the consumed preload is intentional.
    preloadedTessdata = null;
  })();

  tessdataMountedPromise = promise.catch((err) => {
    tessdataMountedPromise = null;
    throw err;
  });
  return tessdataMountedPromise;
}

export async function warmOcrRuntime(): Promise<void> {
  const mod = await loadModule();
  await ensureTessdataMounted(mod);
}

export async function wasmLinearMemoryBytes(): Promise<number | undefined> {
  const mod = await loadModule();
  const bytes = mod.HEAPU8?.buffer?.byteLength;
  return typeof bytes === "number" && Number.isFinite(bytes) && bytes > 0 ? bytes : undefined;
}

/** Decode encoded image bytes to RGBA with the shared pipeline module. */
export async function decodeImage(bytes: Uint8Array): Promise<{ width: number; height: number; data: Uint8Array }> {
  return decodeToRgba(await loadModule(), bytes);
}

/** Crop encoded image bytes to a PNG of the `width` x `height` rect at `x,y`. */
export async function cropPng(
  bytes: Uint8Array,
  x: number,
  y: number,
  width: number,
  height: number,
): Promise<Uint8Array<ArrayBuffer>> {
  const mod = await loadModule();
  return pngFromRust(mod, bytes, (ptr, len, outLen) => mod._pipeline_crop_png(ptr, len, x, y, width, height, outLen));
}

/** 256-hex-char (1024-bit) perceptual hash of encoded image bytes. */
export async function perceptualHashHex(bytes: Uint8Array): Promise<string> {
  const mod = await loadModule();
  let bytesPtr = 0;
  let outPtr = 0;
  try {
    bytesPtr = allocatePipelineBuffer(mod, bytes.length);
    outPtr = allocatePipelineBuffer(mod, 256);
    mod.HEAPU8.set(bytes, bytesPtr);
    if (mod._pipeline_dhash(bytesPtr, bytes.length, outPtr) !== 0) throw new Error("Unable to hash image");
    return TEXT_DECODER.decode(mod.HEAPU8.subarray(outPtr, outPtr + 256));
  } finally {
    if (outPtr) mod._pipeline_free(outPtr, 256);
    if (bytesPtr) mod._pipeline_free(bytesPtr, bytes.length);
  }
}

const COLUMN_FILLS_BYTES = 24 * 8;

/**
 * Fill ratio (0..1) of each of the 24 hourly columns of the `w` x `h` graph at
 * `x,y`, measured by the Rust pipeline so every browser engine agrees. All
 * nulls when the crop cannot be measured.
 */
export async function emColumnFills(
  imageData: ImageData,
  crop: { x: number; y: number; w: number; h: number },
): Promise<(number | null)[]> {
  const mod = await loadModule();
  if (typeof mod._pipeline_column_fills !== "function") {
    // A cached module older than this JS: the same skew the schema check polices.
    throw Object.assign(new Error("Pipeline WASM has no column-fill export"), { abiMismatch: true });
  }
  const rgba = imageData.data as Uint8ClampedArray;
  let rgbaPtr = 0;
  let outPtr = 0;
  try {
    rgbaPtr = allocatePipelineBuffer(mod, rgba.length);
    outPtr = allocatePipelineBuffer(mod, COLUMN_FILLS_BYTES);
    mod.HEAPU8.set(rgba, rgbaPtr);
    const status = mod._pipeline_column_fills(
      rgbaPtr,
      rgba.length,
      imageData.width,
      imageData.height,
      Math.round(crop.x),
      Math.round(crop.y),
      Math.round(crop.w),
      Math.round(crop.h),
      outPtr,
    );
    if (status !== 0) return Array.from({ length: 24 }, () => null);
    const view = new DataView(mod.HEAPU8.slice(outPtr, outPtr + COLUMN_FILLS_BYTES).buffer);
    return Array.from({ length: 24 }, (_, i) => view.getFloat64(i * 8, true));
  } finally {
    if (outPtr) mod._pipeline_free(outPtr, COLUMN_FILLS_BYTES);
    if (rgbaPtr) mod._pipeline_free(rgbaPtr, rgba.length);
  }
}

/** Redact integer `{x,y,w,h}` regions in encoded image bytes; returns a PNG. */
export async function redactPng(
  bytes: Uint8Array,
  regions: { x: number; y: number; w: number; h: number }[],
  method: string,
  padding: number,
): Promise<Uint8Array<ArrayBuffer>> {
  const mod = await loadModule();
  const json = encodeNullTerminated(JSON.stringify(regions));
  const methodBytes = encodeNullTerminated(method);
  let jsonPtr = 0;
  let methodPtr = 0;
  try {
    jsonPtr = allocatePipelineBuffer(mod, json.length);
    methodPtr = allocatePipelineBuffer(mod, methodBytes.length);
    mod.HEAPU8.set(json, jsonPtr);
    mod.HEAPU8.set(methodBytes, methodPtr);
    return pngFromRust(mod, bytes, (ptr, len, outLen) =>
      mod._pipeline_redact_png(ptr, len, jsonPtr, methodPtr, padding, outLen),
    );
  } finally {
    if (methodPtr) mod._pipeline_free(methodPtr, methodBytes.length);
    if (jsonPtr) mod._pipeline_free(jsonPtr, json.length);
  }
}

function allocatePipelineBuffer(mod: EmscriptenModule, length: number): number {
  const ptr = mod._pipeline_alloc(length);
  if (!ptr) throw new RangeError(`WASM pipeline allocation failed (${length} bytes)`);
  return ptr;
}

function encodeNullTerminated(str: string): Uint8Array {
  const bytes = TEXT_ENCODER.encode(str);
  const buf = new Uint8Array(bytes.length + 1);
  buf.set(bytes);
  buf[bytes.length] = 0;
  return buf;
}

const IMAGE_TYPE_BYTES: Record<"screen_time" | "battery", Uint8Array> = {
  screen_time: encodeNullTerminated("screen_time"),
  battery: encodeNullTerminated("battery"),
};

/**
 * Run the full pipeline (OCR + grid + bars) on raw RGBA image data.
 */
export async function emPipelineProcess(
  imageData: ImageData,
  imageType: "screen_time" | "battery",
  options?: {
    maxShift?: number;
    gridCoordinates?: {
      upper_left: { x: number; y: number };
      lower_right: { x: number; y: number };
    };
    /** Apportionment + grid-registration knobs from the Settings UI. A value of
     *  -1 (or omitted) tells the Rust pipeline to use its compiled SSoT default. */
    apportionMaxMinutes?: number;
    /** Apportionment cap as percent of OCR total; > 0 selects percentage mode and
     *  overrides apportionMaxMinutes. -1/omitted → compiled SSoT default (absolute). */
    apportionMaxPercent?: number;
    apportionMinRegistration?: number;
    gridRegDeadband?: number;
    gridRegTol?: number;
  },
): Promise<EmPipelineResult> {
  const mod = await loadModule();
  await ensureTessdataMounted(mod);

  const rgba = imageData.data as Uint8ClampedArray;
  const width = imageData.width;
  const height = imageData.height;

  const maxShift = options?.maxShift ?? 0;
  const gc = options?.gridCoordinates;
  const gridUlX = gc ? gc.upper_left.x : -1;
  const gridUlY = gc ? gc.upper_left.y : -1;
  const gridLrX = gc ? gc.lower_right.x : -1;
  const gridLrY = gc ? gc.lower_right.y : -1;
  // -1 = "use the compiled SSoT default" (see ScoringConfig::from_overrides in Rust).
  const apportionMaxMinutes = options?.apportionMaxMinutes ?? -1;
  const apportionMaxPercent = options?.apportionMaxPercent ?? -1;
  const apportionMinRegistration = options?.apportionMinRegistration ?? -1;
  const gridRegDeadband = options?.gridRegDeadband ?? -1;
  const gridRegTol = options?.gridRegTol ?? -1;

  const native = await nativeCall("process", imageData, {
    image_type: imageType,
    max_shift: maxShift,
    grid: [gridUlX, gridUlY, gridLrX, gridLrY],
    knobs: nativeKnobs(options),
  }, true);
  if (native !== null) return validatePipelineResultContract(JSON.parse(native) as EmPipelineResult);

  let rgbaPtr = 0;
  let outPtr = 0;
  const imageTypeBytes = IMAGE_TYPE_BYTES[imageType];
  let imgTypePtr = 0;

  try {
    rgbaPtr = allocatePipelineBuffer(mod, rgba.length);
    outPtr = allocatePipelineBuffer(mod, OUTPUT_BUFFER_SIZE);
    imgTypePtr = allocatePipelineBuffer(mod, imageTypeBytes.length);
    mod.HEAPU8.set(rgba, rgbaPtr);
    mod.HEAPU8.set(imageTypeBytes, imgTypePtr);

    const written: number = mod._pipeline_process(
      rgbaPtr,
      rgba.length,
      width,
      height,
      imgTypePtr,
      maxShift,
      gridUlX,
      gridUlY,
      gridLrX,
      gridLrY,
      apportionMaxMinutes,
      apportionMaxPercent,
      apportionMinRegistration,
      gridRegDeadband,
      gridRegTol,
      outPtr,
      OUTPUT_BUFFER_SIZE,
    );

    if (written < 0) {
      // The Rust entry (`pipeline_em.rs::write_json`) returns a negative length
      // ONLY when the JSON doesn't fit in `out_len`. Every success/error result
      // for this shape (24 hourly ints + short scalar/error strings) is a few
      // hundred bytes — orders of magnitude under the 64 KB buffer — so on a
      // correctly-called wasm this branch is unreachable. A negative length
      // therefore means `out_len` itself was read from the wrong stack slot: the
      // wasm was invoked with the wrong argument layout (a stale / mismatched
      // cached pipeline bundle, JS and wasm from different deploys after the
      // C-ABI changed). Flag it so the main thread can drop the bad caches and
      // reload onto a self-consistent bundle.
      return { success: false, error: "Output buffer too small", abiMismatch: true };
    }

    const json = TEXT_DECODER.decode(mod.HEAPU8.subarray(outPtr, outPtr + written));
    return validatePipelineResultContract(JSON.parse(json) as EmPipelineResult);
  } finally {
    if (rgbaPtr) mod._pipeline_free(rgbaPtr, rgba.length);
    if (outPtr) mod._pipeline_free(outPtr, OUTPUT_BUFFER_SIZE);
    if (imgTypePtr) mod._pipeline_free(imgTypePtr, imageTypeBytes.length);
  }
}

/**
 * Extract hourly bars and framing scores for a known grid without running OCR.
 *
 * Used for manual grid adjustment where title/total are preserved from the
 * previous OCR pass. The optional `totalText` is only used for apportionment.
 */
export async function emExtractBars(
  imageData: ImageData,
  imageType: "screen_time" | "battery",
  options: {
    gridCoordinates: {
      upper_left: { x: number; y: number };
      lower_right: { x: number; y: number };
    };
    totalText?: string | null;
    apportionMaxMinutes?: number;
    apportionMaxPercent?: number;
    apportionMinRegistration?: number;
    gridRegDeadband?: number;
    gridRegTol?: number;
    /**
     * Reading direction recorded when the screenshot was first processed. No
     * detector runs on this path — the user dragged the grid — so without it a
     * mirrored (Hebrew/Arabic) chart would come back with its 24 hours in image
     * order, silently reversed. Defaults to `"ltr"`.
     */
    axisDirection?: "ltr" | "rtl";
    /**
     * The chart's top-gridline value in minutes, recorded when the screenshot
     * was first processed. An "All Devices" chart is scaled in hours (`2h / 1h /
     * 0`), so its plot is 120 minutes tall rather than 60. This path runs no OCR
     * and cannot re-read that label, so without it dragging the grid on such a
     * screenshot halves every bar the first pass got right. Anything at or below
     * 60 means the ordinary chart.
     */
    axisMaxMinutes?: number | null;
  },
): Promise<EmPipelineResult> {
  const mod = await loadModule();

  const rgba = imageData.data as Uint8ClampedArray;
  const width = imageData.width;
  const height = imageData.height;
  const gc = options.gridCoordinates;
  const gridUlX = gc.upper_left.x;
  const gridUlY = gc.upper_left.y;
  const gridLrX = gc.lower_right.x;
  const gridLrY = gc.lower_right.y;
  const apportionMaxMinutes = options.apportionMaxMinutes ?? -1;
  const apportionMaxPercent = options.apportionMaxPercent ?? -1;
  const apportionMinRegistration = options.apportionMinRegistration ?? -1;
  const gridRegDeadband = options.gridRegDeadband ?? -1;
  const gridRegTol = options.gridRegTol ?? -1;

  const native = await nativeCall("extract_bars", imageData, {
    image_type: imageType,
    grid: [gridUlX, gridUlY, gridLrX, gridLrY],
    total_text: options.totalText ?? "",
    knobs: nativeKnobs(options),
    axis_direction: options.axisDirection ?? "ltr",
    axis_max_minutes: options.axisMaxMinutes ?? -1,
  }, false);
  if (native !== null) return validatePipelineResultContract(JSON.parse(native) as EmPipelineResult);

  let rgbaPtr = 0;
  let outPtr = 0;
  const imageTypeBytes = IMAGE_TYPE_BYTES[imageType];
  let imgTypePtr = 0;
  const totalBytes = encodeNullTerminated(options.totalText ?? "");
  let totalPtr = 0;
  const axisBytes = encodeNullTerminated(options.axisDirection ?? "ltr");
  let axisPtr = 0;

  try {
    rgbaPtr = allocatePipelineBuffer(mod, rgba.length);
    outPtr = allocatePipelineBuffer(mod, OUTPUT_BUFFER_SIZE);
    imgTypePtr = allocatePipelineBuffer(mod, imageTypeBytes.length);
    totalPtr = allocatePipelineBuffer(mod, totalBytes.length);
    axisPtr = allocatePipelineBuffer(mod, axisBytes.length);
    mod.HEAPU8.set(rgba, rgbaPtr);
    mod.HEAPU8.set(imageTypeBytes, imgTypePtr);
    mod.HEAPU8.set(totalBytes, totalPtr);
    mod.HEAPU8.set(axisBytes, axisPtr);

    const written: number = mod._pipeline_extract_bars(
      rgbaPtr,
      rgba.length,
      width,
      height,
      imgTypePtr,
      gridUlX,
      gridUlY,
      gridLrX,
      gridLrY,
      totalPtr,
      apportionMaxMinutes,
      apportionMaxPercent,
      apportionMinRegistration,
      gridRegDeadband,
      gridRegTol,
      axisPtr,
      options.axisMaxMinutes ?? -1,
      outPtr,
      OUTPUT_BUFFER_SIZE,
    );

    if (written < 0) {
      return { success: false, error: "Output buffer too small", abiMismatch: true };
    }

    const json = TEXT_DECODER.decode(mod.HEAPU8.subarray(outPtr, outPtr + written));
    return validatePipelineResultContract(JSON.parse(json) as EmPipelineResult);
  } finally {
    if (rgbaPtr) mod._pipeline_free(rgbaPtr, rgba.length);
    if (outPtr) mod._pipeline_free(outPtr, OUTPUT_BUFFER_SIZE);
    if (imgTypePtr) mod._pipeline_free(imgTypePtr, imageTypeBytes.length);
    if (totalPtr) mod._pipeline_free(totalPtr, totalBytes.length);
    if (axisPtr) mod._pipeline_free(axisPtr, axisBytes.length);
  }
}

/**
 * Grid detection only.
 *
 * `options.method`: 0 = OcrAnchored with LineBased fallback (default, matches canvas),
 *                   1 = LineBased only (fast, no OCR).
 */
export async function emDetectGrid(
  imageData: ImageData,
  options?: { method?: 0 | 1 },
): Promise<EmGridResult> {
  const mod = await loadModule();

  const rgba = imageData.data as Uint8ClampedArray;
  const width = imageData.width;
  const height = imageData.height;
  const method = options?.method ?? 0;
  if (method === 0) {
    await ensureTessdataMounted(mod);
  }

  const native = await nativeCall("detect_grid", imageData, { method }, method === 0);
  if (native !== null) return JSON.parse(native) as EmGridResult;

  let rgbaPtr = 0;
  let outPtr = 0;

  try {
    rgbaPtr = allocatePipelineBuffer(mod, rgba.length);
    outPtr = allocatePipelineBuffer(mod, OUTPUT_BUFFER_SIZE);
    mod.HEAPU8.set(rgba, rgbaPtr);

    const written: number = mod._pipeline_detect_grid(
      rgbaPtr,
      rgba.length,
      width,
      height,
      method,
      outPtr,
      OUTPUT_BUFFER_SIZE,
    );

    if (written < 0) {
      return { success: false, confidence: 0, method: "line_based", error: "Buffer too small" };
    }

    const json = TEXT_DECODER.decode(mod.HEAPU8.subarray(outPtr, outPtr + written));
    return JSON.parse(json) as EmGridResult;
  } finally {
    if (rgbaPtr) mod._pipeline_free(rgbaPtr, rgba.length);
    if (outPtr) mod._pipeline_free(outPtr, OUTPUT_BUFFER_SIZE);
  }
}

/**
 * OCR-only extraction — no grid detection, no bar extraction.
 *
 * Crops to the top 45% of the image and runs Tesseract to extract title and
 * total usage text. Use for EXTRACT_TITLE / EXTRACT_TOTAL to avoid the cost
 * of full OcrAnchored grid detection.
 */
export async function emExtractOcr(imageData: ImageData): Promise<EmOcrResult> {
  const mod = await loadModule();
  await ensureTessdataMounted(mod);

  const native = await nativeCall("extract_ocr", imageData, {}, true);
  if (native !== null) return JSON.parse(native) as EmOcrResult;

  const rgba = imageData.data as Uint8ClampedArray;
  const width = imageData.width;
  const height = imageData.height;

  let rgbaPtr = 0;
  let outPtr = 0;

  try {
    rgbaPtr = allocatePipelineBuffer(mod, rgba.length);
    outPtr = allocatePipelineBuffer(mod, OUTPUT_BUFFER_SIZE);
    mod.HEAPU8.set(rgba, rgbaPtr);

    const written: number = mod._pipeline_extract_ocr(
      rgbaPtr,
      rgba.length,
      width,
      height,
      outPtr,
      OUTPUT_BUFFER_SIZE,
    );

    if (written < 0) {
      return { error: "Output buffer too small" };
    }

    const json = TEXT_DECODER.decode(mod.HEAPU8.subarray(outPtr, outPtr + written));
    return JSON.parse(json) as EmOcrResult;
  } finally {
    if (rgbaPtr) mod._pipeline_free(rgbaPtr, rgba.length);
    if (outPtr) mod._pipeline_free(outPtr, OUTPUT_BUFFER_SIZE);
  }
}

/**
 * Full-page OCR for PHI detection. Returns every word with bbox + confidence
 * + character offsets into the joined `full_text`. Replaces Tesseract.js for
 * the PHI redaction pipeline.
 *
 * The output buffer is 1 MB rather than 64 KB because a long screenshot
 * (multi-app summary view) can have hundreds of words and the JSON balloons.
 */
const PHI_OUTPUT_BUFFER_SIZE = 1024 * 1024; // 1 MB

export async function emPhiWords(imageData: ImageData): Promise<EmPhiWordsResult> {
  const mod = await loadModule();
  await ensureTessdataMounted(mod);

  const native = await nativeCall("phi_words", imageData, {}, true);
  if (native !== null) return JSON.parse(native) as EmPhiWordsResult;

  const rgba = imageData.data as Uint8ClampedArray;
  const width = imageData.width;
  const height = imageData.height;

  let rgbaPtr = 0;
  let outPtr = 0;

  try {
    rgbaPtr = allocatePipelineBuffer(mod, rgba.length);
    outPtr = allocatePipelineBuffer(mod, PHI_OUTPUT_BUFFER_SIZE);
    mod.HEAPU8.set(rgba, rgbaPtr);

    const written: number = mod._pipeline_phi_words(
      rgbaPtr,
      rgba.length,
      width,
      height,
      outPtr,
      PHI_OUTPUT_BUFFER_SIZE,
    );

    if (written < 0) {
      return { success: false, error: "Output buffer too small" };
    }

    const json = TEXT_DECODER.decode(mod.HEAPU8.subarray(outPtr, outPtr + written));
    return JSON.parse(json) as EmPhiWordsResult;
  } finally {
    if (rgbaPtr) mod._pipeline_free(rgbaPtr, rgba.length);
    if (outPtr) mod._pipeline_free(outPtr, PHI_OUTPUT_BUFFER_SIZE);
  }
}
