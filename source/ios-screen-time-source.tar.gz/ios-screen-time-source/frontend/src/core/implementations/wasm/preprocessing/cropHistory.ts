/**
 * Pure crop undo/redo history for the offline pipeline.
 *
 * Why a rect stack and not image snapshots: BOTH crop paths — the pipeline's
 * auto-crop (`cropScreenshot`) and the user's manual crop (`applyManualCrop`) —
 * are pure rectangle crops of the preserved `"original"` stage blob, expressed
 * in original-image coordinates. So every crop state is fully described by ONE
 * rectangle (or `null` = uncropped/full original), and any state is rebuilt by
 * re-cropping `original`. That means:
 *   - zero extra image bytes at rest (no new PHI surface; pre-crop imagery never
 *     survives a later redaction, which destroys `original`), and
 *   - the whole history is JSON inside `processing_metadata`, so it rides the
 *     workspace-export ZIP for free.
 *
 * This module is the pure reducer only — no storage, no canvas. The service
 * persists the returned `CropHistory` and re-derives blobs from `original`.
 */

export interface CropRect {
  left: number;
  top: number;
  right: number;
  bottom: number;
}

/** Grid coordinates in the image space of a particular crop state (any field
 *  may be null when the grid fell outside the crop or was never detected). */
export interface GridSnapshot {
  ulx: number | null;
  uly: number | null;
  lrx: number | null;
  lry: number | null;
}

export type CropSource = "none" | "auto" | "manual";

export interface CropHistoryEntry {
  /** Rectangle applied to `original` to produce this state; null = full original. */
  crop: CropRect | null;
  /** Grid coords to restore alongside the image when this state is re-entered. */
  grid: GridSnapshot;
  /** Provenance, so restored cropping events/labels stay truthful. */
  source: CropSource;
}

export interface CropHistory {
  entries: CropHistoryEntry[];
  /** Index of the currently-applied entry; -1 only for an empty history. */
  index: number;
}

/** Hard cap on retained undo steps — crop is a deliberate, infrequent action,
 *  and the history is tiny JSON, but bound it so a pathological loop can't grow
 *  `processing_metadata` without limit. Oldest entries are evicted. */
export const MAX_CROP_HISTORY = 20;

export function emptyHistory(): CropHistory {
  return { entries: [], index: -1 };
}

export function currentEntry(h: CropHistory): CropHistoryEntry | null {
  return h.index >= 0 && h.index < h.entries.length ? h.entries[h.index]! : null;
}

export function canUndo(h: CropHistory): boolean {
  return h.index > 0;
}

export function canRedo(h: CropHistory): boolean {
  return h.index >= 0 && h.index < h.entries.length - 1;
}

/** Seed a fresh history whose single entry is the crop state in effect now. */
export function seedHistory(base: CropHistoryEntry): CropHistory {
  return { entries: [base], index: 0 };
}

/**
 * Apply a new crop on top of the current entry: drop any redo tail (a new
 * action invalidates undone-then-superseded states), append, and advance.
 * Evicts the oldest entry past MAX_CROP_HISTORY, keeping `index` on the newest.
 */
export function pushCrop(h: CropHistory, entry: CropHistoryEntry): CropHistory {
  const kept = h.entries.slice(0, h.index + 1);
  let entries = [...kept, entry];
  let index = entries.length - 1;
  if (entries.length > MAX_CROP_HISTORY) {
    const overflow = entries.length - MAX_CROP_HISTORY;
    entries = entries.slice(overflow);
    index = entries.length - 1;
  }
  return { entries, index };
}

/** Move one step back (no-op at the start). */
export function undo(h: CropHistory): CropHistory {
  if (!canUndo(h)) return h;
  return { ...h, index: h.index - 1 };
}

/** Move one step forward (no-op at the end). */
export function redo(h: CropHistory): CropHistory {
  if (!canRedo(h)) return h;
  return { ...h, index: h.index + 1 };
}

/** Width/height of a crop rect, or null for an uncropped state. */
export function rectDimensions(rect: CropRect | null): { width: number; height: number } | null {
  if (!rect) return null;
  return { width: rect.right - rect.left, height: rect.bottom - rect.top };
}
