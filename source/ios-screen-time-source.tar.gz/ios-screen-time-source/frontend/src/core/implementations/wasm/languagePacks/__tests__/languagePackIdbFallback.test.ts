/**
 * Without OPFS (WebKit webviews, the desktop app) a pack must still install,
 * read back byte-for-byte for the OCR worker, count toward storage, and remove.
 */

import "fake-indexeddb/auto";

import { afterEach, expect, it } from "bun:test";

import { LANGUAGE_PACKS } from "@/core/generated/constants";
import {
  installedCodes,
  installLanguagePack,
  readLanguagePack,
  removeLanguagePack,
  totalLanguagePackBytes,
} from "@/core/implementations/wasm/languagePacks/languagePackStore";

const realFetch = globalThis.fetch;
afterEach(() => {
  globalThis.fetch = realFetch;
});

it("installs, reads, counts and removes a pack through IndexedDB when OPFS is missing", async () => {
  expect(typeof navigator.storage?.getDirectory).toBe("undefined");
  const pack = LANGUAGE_PACKS.reduce((a, b) => (a.bytes <= b.bytes ? a : b));
  const bytes = new Uint8Array(pack.bytes).map((_, i) => i % 251);
  globalThis.fetch = (async () => new Response(bytes)) as unknown as typeof fetch;

  await installLanguagePack(pack.code);

  expect(await installedCodes()).toEqual([pack.code]);
  expect(await readLanguagePack(pack.code)).toEqual(bytes);
  expect(await totalLanguagePackBytes()).toBe(pack.bytes);

  await removeLanguagePack(pack.code);
  expect(await installedCodes()).toEqual([]);
  expect(await readLanguagePack(pack.code)).toBeNull();
});
