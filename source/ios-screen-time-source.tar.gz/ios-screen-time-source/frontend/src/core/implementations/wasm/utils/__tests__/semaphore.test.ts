/**
 * Unit tests for the async semaphore that bounds concurrent full-res decodes.
 */
import { describe, it, expect } from "bun:test";
import { createSemaphore } from "../semaphore";

const tick = () => new Promise<void>((r) => {
  setTimeout(r, 1);
});

describe("createSemaphore", () => {
  it("never lets more than `max` operations run concurrently", async () => {
    const sem = createSemaphore(3);
    let active = 0;
    let peak = 0;
    const job = async () => {
      await sem.run(async () => {
        active++;
        peak = Math.max(peak, active);
        await tick();
        active--;
      });
    };
    await Promise.all(Array.from({ length: 20 }, job));
    expect(peak).toBeLessThanOrEqual(3);
    expect(active).toBe(0);
  });

  it("runs everything (no work dropped) and returns each result", async () => {
    const sem = createSemaphore(2);
    const results = await Promise.all(
      Array.from({ length: 10 }, (_, i) => sem.run(async () => i * 2)),
    );
    expect(results).toEqual([0, 2, 4, 6, 8, 10, 12, 14, 16, 18]);
  });

  it("releases the slot even when the wrapped op throws", async () => {
    const sem = createSemaphore(1);
    await expect(sem.run(async () => { throw new Error("boom"); })).rejects.toThrow("boom");
    // If the slot leaked, this second run would hang forever.
    expect(await sem.run(async () => "ok")).toBe("ok");
  });

  it("treats max < 1 as 1", async () => {
    const sem = createSemaphore(0);
    let active = 0;
    let peak = 0;
    await Promise.all(
      Array.from({ length: 5 }, () =>
        sem.run(async () => {
          active++;
          peak = Math.max(peak, active);
          await tick();
          active--;
        }),
      ),
    );
    expect(peak).toBe(1);
  });

  it("rejects immediately when the signal is already aborted", async () => {
    const sem = createSemaphore(1);
    const controller = new AbortController();
    controller.abort();
    let ran = false;

    await expect(
      sem.run(async () => {
        ran = true;
      }, controller.signal),
    ).rejects.toThrow("Semaphore wait aborted");
    expect(ran).toBe(false);
  });

  it("removes an aborted queued waiter before it acquires a slot", async () => {
    const sem = createSemaphore(1);
    const controller = new AbortController();
    let releaseFirst: (() => void) | undefined;
    let secondRan = false;

    const first = sem.run(
      () =>
        new Promise<void>((resolve) => {
          releaseFirst = resolve;
        }),
    );
    const second = sem.run(async () => {
      secondRan = true;
    }, controller.signal);

    await tick();
    controller.abort();
    await expect(second).rejects.toThrow("Semaphore wait aborted");

    releaseFirst?.();
    await first;
    expect(secondRan).toBe(false);
    expect(await sem.run(async () => "ok")).toBe("ok");
  });
});
