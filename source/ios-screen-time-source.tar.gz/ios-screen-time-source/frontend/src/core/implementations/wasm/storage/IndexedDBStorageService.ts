import type {
  Screenshot,
  Annotation,
  ScreenshotListResponse,
  NavigationResponse,
} from "@/types";
import type {
  IStorageService,
  PaginationParams,
  NavigationQueryParams,
  StorageStats,
  StatusCounts,
  GroupAggregateRow,
  StorageEstimate,
} from "@/core/interfaces/IStorageService";
import { db } from "./database";
import { withScreenshotLock } from "./screenshotLocks";
import {
  storeImageBlob,
  retrieveImageBlob,
  deleteAllBlobsForScreenshot,
  clearAllOpfsBlobs,
  getTotalBlobSize,
  storeStageBlob,
  retrieveStageBlob,
  deleteStageBlob,
} from "./opfsBlobStorage";

import type { Collection, IndexableType } from "dexie";
import { useAuthStore } from "@/store/authStore";
import { parseOcrTotalMinutes } from "@/utils/formatters";
import { finiteHourlyNumber, hasExportableHourlyValues } from "../exportRecord";
import { canonicalHourIndex } from "@/utils/dataQuality";
import { hammingDistance } from "../utils/perceptualHash";
import {
  browserResourceNumber,
  computeMetadataIoConcurrency,
} from "@/lib/resourceBudget";

/** Get the current user's ID from the auth store, defaulting to 1 for WASM mode. */
function getCurrentUserId(): number {
  return useAuthStore.getState().userId ?? 1;
}

function metadataIoConcurrency(): number {
  return computeMetadataIoConcurrency(
    browserResourceNumber("hardwareConcurrency"),
    browserResourceNumber("deviceMemory"),
  );
}

async function forEachBoundedSettled<T>(
  items: readonly T[],
  concurrency: number,
  mapper: (item: T, index: number) => Promise<void>,
): Promise<void> {
  let cursor = 0;
  let failure: Error | undefined;
  const runner = async (): Promise<void> => {
    const index = cursor++;
    if (index >= items.length) return;
    try {
      await mapper(items[index]!, index);
    } catch (error) {
      failure ??= error instanceof Error ? error : new Error("Blob cleanup failed");
    }
    return runner();
  };
  await Promise.all(
    Array.from({ length: Math.min(Math.max(1, concurrency), items.length) }, () => runner()),
  );
  if (failure) throw failure;
}

/**
 * "Needs attention" predicate — the WASM (offline) port of the server's
 * `needs_attention_conditions()` (screenshot_repository.py). A COMPLETED
 * screenshot needs attention when ANY of:
 *  - it has no exportable hourly bars (legacy bad completed row);
 *  - bar/OCR total mismatch: it has hourly data and an OCR total that carries
 *    an h/m component (seconds-only like "9s" is excluded — parseOcrTotalMinutes
 *    returns null there), and |sum(hourly values) - OCR minutes| >= 1; OR
 *  - missing title: hourly data exists but the app name was never extracted.
 * Sums are raw (no rounding) over numeric hour keys, matching the server's
 * `SUM(value::numeric)`.
 */
export function needsAttention(s: Screenshot): boolean {
  if (s.processing_status !== "completed") return false;
  const hourly = s.extracted_hourly_data;
  if (!hasExportableHourlyValues(hourly)) return true;
  const storedHourly = hourly as Record<string, unknown>;
  if (Object.entries(storedHourly).some(([key, value]) => (
    canonicalHourIndex(key) === null || finiteHourlyNumber(value) === null
  ))) return true;

  // Missing title — app name not detected, needs manual entry.
  if (!s.extracted_title) return true;

  // Bar/OCR total mismatch.
  const ocrMinutes = parseOcrTotalMinutes(s.extracted_total);
  if (ocrMinutes === null) return false;
  let barTotal = 0;
  for (const [key, value] of Object.entries(storedHourly)) {
    if (canonicalHourIndex(key) !== null) barTotal += finiteHourlyNumber(value) ?? 0;
  }
  return Math.abs(barTotal - ocrMinutes) >= 1;
}

/** Apply verified_by_me / verified_by_others / totals_mismatch filters to a Dexie collection. */
function applyVerificationFilter<TKey extends IndexableType>(
  collection: Collection<Screenshot, TKey>,
  params: { verified_by_me?: boolean; verified_by_others?: boolean; totals_mismatch?: boolean },
): Collection<Screenshot, TKey> {
  const userId = getCurrentUserId();
  if (params.totals_mismatch === true) {
    return collection.filter(needsAttention);
  }
  if (params.verified_by_others === true) {
    return collection.filter(
      (s): boolean =>
        !!(
          s.verified_by_user_ids &&
          s.verified_by_user_ids.length > 0 &&
          !s.verified_by_user_ids.includes(userId)
        ),
    );
  }
  if (params.verified_by_me === true) {
    return collection.filter(
      (s): boolean =>
        !!(s.verified_by_user_ids && s.verified_by_user_ids.includes(userId)),
    );
  }
  if (params.verified_by_me === false) {
    return collection.filter(
      (s): boolean =>
        !s.verified_by_user_ids || !s.verified_by_user_ids.includes(userId),
    );
  }
  return collection;
}

/**
 * Apply the free-text search filter (id / participant_id / extracted_title).
 *
 * This is the SINGLE matcher used by BOTH the paginated list and the navigation
 * cursor, so "what the selector shows" and "what Next/Prev walks" can never
 * disagree. An empty/undefined term is a no-op.
 */
function applySearchFilter<TKey extends IndexableType>(
  collection: Collection<Screenshot, TKey>,
  search?: string,
): Collection<Screenshot, TKey> {
  if (!search) return collection;
  const q = search.toLowerCase();
  return collection.filter(
    (s): boolean =>
      s.id.toString().includes(q) ||
      !!(s.participant_id && s.participant_id.toLowerCase().includes(q)) ||
      !!(s.extracted_title && s.extracted_title.toLowerCase().includes(q)),
  );
}

export class IndexedDBStorageService implements IStorageService {
  private persistenceRequested = false;
  private dbReady: Promise<void>;
  private dbOpenFailed = false;
  // Coalesces concurrent full-table aggregation scans. On a home/preprocessing
  // load BOTH WASMScreenshotService.getGroups and WASMPreprocessingService.
  // getGroups can fire at once; on a large dataset that's two full cursor passes
  // (each deserializing every row). Sharing one in-flight scan halves that
  // boot cost. Cleared the moment it settles, so the next call re-scans fresh —
  // no stale counts after a write.
  private groupAggInFlight: Promise<GroupAggregateRow[]> | null = null;

  constructor() {
    this.dbReady = this.initializeDb();
    void this.requestPersistentStorage();
  }

  private async initializeDb(): Promise<void> {
    try {
      await this.maybeBackupBeforeMigration();
      await db.open();
    } catch (error) {
      this.dbOpenFailed = true;
      console.error("Failed to open IndexedDB:", error);
      throw new Error(
        `IndexedDB unavailable: ${error instanceof Error ? error.message : String(error)}. ` +
          "Local storage mode requires IndexedDB. Check that you are not in private browsing mode.",
      );
    }
  }

  private async maybeBackupBeforeMigration(): Promise<void> {
    let currentVersion: number;
    try {
      currentVersion = await new Promise<number>((resolve, reject) => {
        let resolved = false;
        const req = indexedDB.open("ScreenshotProcessorDB");
        req.onupgradeneeded = () => {
          // DB doesn't exist yet — abort to avoid creating it, resolve as 0
          req.transaction?.abort();
          resolved = true;
          resolve(0);
        };
        req.onsuccess = () => {
          if (!resolved) {
            resolve(req.result.version);
            req.result.close();
          }
        };
        req.onerror = () => {
          // onerror fires after onupgradeneeded abort — ignore if already resolved
          if (!resolved) reject(req.error ?? new Error("IndexedDB request failed"));
        };
      });
    } catch (err) {
      console.error("[Migration] Failed to probe DB version:", err);
      return;
    }

    const targetVersion = Math.round(db.verno * 10);
    if (currentVersion > 0 && currentVersion < targetVersion) {
      try {
        const { createPreMigrationBackup } = await import(
          "./database/preMigrationBackup"
        );
        await createPreMigrationBackup("ScreenshotProcessorDB");
      } catch (err) {
        console.warn("[Migration] Pre-migration backup failed (continuing):", err);
      }
    }
  }

  /** Ensure the database is open before performing operations. */
  private async ensureDB(): Promise<void> {
    if (this.dbOpenFailed) {
      throw new Error(
        "IndexedDB is not available. Local storage mode cannot function without it.",
      );
    }
    await this.dbReady;
  }

  /**
   * Request persistent storage to prevent browser from automatically
   * evicting IndexedDB data under storage pressure.
   */
  private async requestPersistentStorage(): Promise<void> {
    if (this.persistenceRequested) return;
    this.persistenceRequested = true;

    try {
      if (navigator.storage && navigator.storage.persist) {
        const isPersisted = await navigator.storage.persisted();
        if (isPersisted) {
          // eslint-disable-next-line no-console -- storage-persistence diagnostic; paired with console.warn on denial
          console.log(
            "[IndexedDBStorageService] Storage is already persistent",
          );
          return;
        }

        const granted = await navigator.storage.persist();
        if (granted) {
          // eslint-disable-next-line no-console -- storage-persistence diagnostic; paired with console.warn on denial
          console.log("[IndexedDBStorageService] Persistent storage granted");
        } else {
          console.warn(
            "[IndexedDBStorageService] Persistent storage denied - data may be evicted under storage pressure",
          );
        }
      } else {
        console.warn(
          "[IndexedDBStorageService] Storage persistence API not available",
        );
      }
    } catch (error) {
      console.error(
        "[IndexedDBStorageService] Failed to request persistent storage:",
        error,
      );
    }
  }

  async saveScreenshot(screenshot: Screenshot): Promise<number> {
    await this.ensureDB();
    try {
      const id = await db.screenshots.add(screenshot);
      this.invalidateFilterCounts();
      return id;
    } catch (error) {
      console.error("Failed to save screenshot:", error);
      throw error;
    }
  }

  async getScreenshot(id: number): Promise<Screenshot | null> {
    await this.ensureDB();
    try {
      const screenshot = await db.screenshots.get(id);
      return screenshot || null;
    } catch (error) {
      console.error("Failed to get screenshot:", error);
      throw error;
    }
  }

  async getAllScreenshots(filter?: {
    annotation_status?: string;
    group_id?: string;
    processing_status?: string;
  }): Promise<Screenshot[]> {
    await this.ensureDB();
    try {
      // Start with the most selective indexed filter, then apply remaining as .filter()
      let collection;

      if (filter?.annotation_status && filter?.group_id) {
        collection = db.screenshots
          .where("[group_id+annotation_status]")
          .equals([filter.group_id, filter.annotation_status]);
      } else if (filter?.group_id) {
        collection = db.screenshots
          .where("group_id")
          .equals(filter.group_id);
      } else if (filter?.annotation_status) {
        collection = db.screenshots
          .where("annotation_status")
          .equals(filter.annotation_status);
      } else if (filter?.processing_status) {
        // Only use processing_status index when no other filters
        return await db.screenshots
          .where("processing_status")
          .equals(filter.processing_status)
          .toArray();
      } else {
        return await db.screenshots.toArray();
      }

      // Apply processing_status as a post-filter if it wasn't used as the primary index
      if (filter?.processing_status) {
        collection = collection.filter(
          (s) => s.processing_status === filter.processing_status,
        );
      }

      return await collection.toArray();
    } catch (error) {
      console.error("Failed to get all screenshots:", error);
      throw error;
    }
  }

  async updateScreenshot(id: number, data: Partial<Screenshot>): Promise<void> {
    await this.ensureDB();
    try {
      const updated = await db.screenshots.update(id, data);
      if (updated === 0) {
        throw new Error(`Screenshot with ID ${id} not found`);
      }
      this.invalidateFilterCounts();
    } catch (error) {
      console.error("Failed to update screenshot:", error);
      throw error;
    }
  }

  async deleteScreenshot(id: number): Promise<void> {
    return withScreenshotLock(id, () => this.deleteScreenshotLocked(id));
  }

  private async deleteScreenshotLocked(id: number): Promise<void> {
    await this.ensureDB();
    try {
      // Retain the record for retry until every blob is removed.
      await deleteAllBlobsForScreenshot(id);
      await db.transaction(
        "rw",
        db.screenshots,
        db.annotations,
        db.imageBlobs,
        async () => {
          await db.screenshots.delete(id);
          await db.annotations.where("screenshot_id").equals(id).delete();
          await db.imageBlobs.delete(id);
        },
      );
      this.invalidateFilterCounts();
    } catch (error) {
      console.error("Failed to delete screenshot:", error);
      throw error;
    }
  }

  async saveAnnotation(annotation: Annotation): Promise<number> {
    await this.ensureDB();
    try {
      const id = await db.transaction(
        "rw",
        db.annotations,
        db.screenshots,
        async () => {
          // Check for existing annotation for this screenshot by this user
          // In WASM mode, we use a simple approach: one annotation per screenshot
          const existing = await db.annotations
            .where("screenshot_id")
            .equals(annotation.screenshot_id)
            .first();

          let annotationId: number;

          if (existing) {
            // UPDATE existing annotation (upsert)
            await db.annotations.update(existing.id, {
              ...annotation,
              id: existing.id,
              updated_at: new Date().toISOString(),
            });
            annotationId = existing.id!;
          } else {
            // CREATE new annotation
            annotationId = await db.annotations.add({
              ...annotation,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            });

            // Only increment count for NEW annotations
            const screenshot = await db.screenshots.get(
              annotation.screenshot_id,
            );

            if (screenshot) {
              const currentCount = screenshot.current_annotation_count || 0;

              await db.screenshots.update(annotation.screenshot_id, {
                current_annotation_count: currentCount + 1,
              });
            }
          }

          return annotationId;
        },
      );

      return id;
    } catch (error) {
      console.error("Failed to save annotation:", error);
      throw error;
    }
  }

  async getAnnotation(id: number): Promise<Annotation | null> {
    await this.ensureDB();
    try {
      const annotation = await db.annotations.get(id);
      return annotation || null;
    } catch (error) {
      console.error("Failed to get annotation:", error);
      throw error;
    }
  }

  async getAnnotationsByScreenshot(
    screenshotId: number,
  ): Promise<Annotation[]> {
    await this.ensureDB();
    try {
      return await db.annotations
        .where("screenshot_id")
        .equals(screenshotId)
        .toArray();
    } catch (error) {
      console.error("Failed to get annotations by screenshot:", error);
      throw error;
    }
  }

  async getAnnotationsByScreenshotIds(
    screenshotIds: number[],
  ): Promise<Annotation[]> {
    await this.ensureDB();
    if (screenshotIds.length === 0) return [];
    try {
      return await db.annotations
        .where("screenshot_id")
        .anyOf(screenshotIds)
        .toArray();
    } catch (error) {
      console.error("Failed to get annotations by screenshot IDs:", error);
      throw error;
    }
  }

  async getAllAnnotations(): Promise<Annotation[]> {
    await this.ensureDB();
    try {
      return await db.annotations.toArray();
    } catch (error) {
      console.error("Failed to get all annotations:", error);
      throw error;
    }
  }

  async updateAnnotation(
    id: number,
    data: Partial<Annotation>,
  ): Promise<Annotation> {
    await this.ensureDB();
    const updated = await db.annotations.update(id, {
      ...data,
      updated_at: new Date().toISOString(),
    });
    if (updated === 0) {
      throw new Error(`Annotation with ID ${id} not found`);
    }
    const annotation = await db.annotations.get(id);
    if (!annotation) {
      throw new Error(`Annotation with ID ${id} disappeared after update`);
    }
    return annotation;
  }

  async getAnnotationHistory(skip: number, limit: number): Promise<Annotation[]> {
    await this.ensureDB();
    try {
      return await db.annotations
        .orderBy("created_at")
        .reverse()
        .offset(skip)
        .limit(limit)
        .toArray();
    } catch (error) {
      console.error("Failed to get annotation history:", error);
      throw error;
    }
  }

  async deleteAnnotation(id: number): Promise<void> {
    await this.ensureDB();
    try {
      await db.transaction("rw", db.annotations, db.screenshots, async () => {
        const annotation = await db.annotations.get(id);

        if (annotation) {
          const screenshot = await db.screenshots.get(annotation.screenshot_id);

          if (screenshot) {
            const currentCount = screenshot.current_annotation_count || 0;

            await db.screenshots.update(annotation.screenshot_id, {
              current_annotation_count: Math.max(0, currentCount - 1),
            });
          }
        }

        await db.annotations.delete(id);
      });
    } catch (error) {
      console.error("Failed to delete annotation:", error);
      throw error;
    }
  }

  async saveImageBlob(screenshotId: number, blob: Blob): Promise<void> {
    await this.ensureDB();
    try {
      await storeImageBlob(screenshotId, blob);
    } catch (error) {
      console.error("Failed to save image blob:", error);
      throw error;
    }
  }

  async getImageBlob(screenshotId: number): Promise<Blob | null> {
    await this.ensureDB();
    try {
      return await retrieveImageBlob(screenshotId);
    } catch (error) {
      console.error("Failed to get image blob:", error);
      throw error;
    }
  }

  async saveStageBlob(screenshotId: number, stage: string, blob: Blob): Promise<void> {
    await this.ensureDB();
    try {
      await storeStageBlob(screenshotId, stage, blob);
    } catch (error) {
      console.error(`Failed to save stage blob for ${stage}:`, error);
      throw error;
    }
  }

  async getStageBlob(screenshotId: number, stage: string): Promise<Blob | null> {
    await this.ensureDB();
    try {
      return await retrieveStageBlob(screenshotId, stage);
    } catch (error) {
      console.error(`Failed to get stage blob for ${stage}:`, error);
      throw error;
    }
  }

  /**
   * Delete the pre-redaction stage snapshots (`original`, `device_detection`,
   * `cropping`, `phi_detection`) once a screenshot has been redacted. The
   * `phi_redaction` snapshot and the current redacted image are kept. This is
   * what makes redaction irreversible — otherwise the un-redacted PHI imagery
   * survives in OPFS. Best-effort.
   */
  async deletePreRedactionBlobs(screenshotId: number): Promise<void> {
    await this.ensureDB();
    await Promise.all(
      ["original", "device_detection", "cropping", "phi_detection"].map((stage) =>
        deleteStageBlob(screenshotId, stage),
      ),
    );
  }

  async deleteScreenshotsByGroup(groupId: string): Promise<{ screenshots_deleted: number; annotations_deleted: number }> {
    await this.ensureDB();
    try {
      const screenshots = await db.screenshots
        .where("group_id")
        .equals(groupId)
        .toArray();

      const screenshotIds = screenshots.map((s) => s.id);
      if (screenshotIds.length === 0) {
        return { screenshots_deleted: 0, annotations_deleted: 0 };
      }

      // Failed cleanup leaves records available for retry.
      await forEachBoundedSettled(
        screenshotIds,
        metadataIoConcurrency(),
        (id) => withScreenshotLock(id, () => deleteAllBlobsForScreenshot(id)),
      );

      // Delete records atomically, capturing annotation count from delete() return values
      let annotationsDeleted = 0;
      await db.transaction(
        "rw",
        db.screenshots,
        db.annotations,
        db.imageBlobs,
        async () => {
          await db.screenshots.bulkDelete(screenshotIds);
          for (const id of screenshotIds) {
            // eslint-disable-next-line require-atomic-updates, no-await-in-loop -- sequential deletes inside one Dexie rw transaction; count accumulation is intentional and single-threaded
            annotationsDeleted += await db.annotations.where("screenshot_id").equals(id).delete();
            // eslint-disable-next-line no-await-in-loop -- same Dexie transaction; sequential by design
            await db.imageBlobs.delete(id);
          }
        },
      );

      this.invalidateFilterCounts();

      return { screenshots_deleted: screenshotIds.length, annotations_deleted: annotationsDeleted };
    } catch (error) {
      console.error("Failed to delete screenshots by group:", error);
      throw error;
    }
  }

  async clearAll(): Promise<void> {
    try {
      // Clear OPFS blobs first (outside transaction since OPFS is not part of IndexedDB)
      await clearAllOpfsBlobs();

      await db.transaction(
        "rw",
        [db.screenshots, db.annotations, db.imageBlobs, db.processingQueue, db.syncRecords, db.settings, db.groups],
        async () => {
          await Promise.all([
            db.screenshots.clear(),
            db.annotations.clear(),
            db.imageBlobs.clear(),
            db.processingQueue.clear(),
            db.syncRecords.clear(),
            db.settings.clear(),
            db.groups.clear(),
          ]);
        },
      );
      this.invalidateFilterCounts();
    } catch (error) {
      console.error("Failed to clear all data:", error);
      throw error;
    }
  }

  async getStats(): Promise<StorageStats> {
    try {
      // Use screenshot count as blob count proxy (each screenshot has one blob).
      // getTotalBlobSize() reads a cached running counter; it throws if it has
      // to recompute and the OPFS walk fails partway — degrade to totalSize: -1
      // (sentinel for "unavailable") rather than crashing the whole stats call.
      const [screenshotCount, annotationCount] = await Promise.all([
        db.screenshots.count(),
        db.annotations.count(),
      ]);
      let totalSize = 0;
      try {
        totalSize = await getTotalBlobSize();
      } catch (sizeErr) {
        console.warn("[IndexedDBStorageService] Blob-size total unavailable:", sizeErr);
        totalSize = -1;
      }

      return {
        screenshotCount,
        annotationCount,
        blobCount: screenshotCount,
        totalSize,
      };
    } catch (error) {
      console.error("Failed to get stats:", error);
      throw error;
    }
  }

  async getStatusCounts(): Promise<StatusCounts> {
    const [
      totalScreenshots,
      annotationPending,
      annotationAnnotated,
      annotationVerified,
      processingCompleted,
      processingPending,
      processingProcessing,
      processingFailed,
      processingSkipped,
      processingDeleted,
      totalAnnotations,
    ] = await Promise.all([
      db.screenshots.count(),
      db.screenshots.where("annotation_status").equals("pending").count(),
      db.screenshots.where("annotation_status").equals("annotated").count(),
      db.screenshots.where("annotation_status").equals("verified").count(),
      db.screenshots.where("processing_status").equals("completed").count(),
      db.screenshots.where("processing_status").equals("pending").count(),
      db.screenshots.where("processing_status").equals("processing").count(),
      db.screenshots.where("processing_status").equals("failed").count(),
      db.screenshots.where("processing_status").equals("skipped").count(),
      db.screenshots.where("processing_status").equals("deleted").count(),
      db.annotations.count(),
    ]);

    return {
      annotation: {
        pending: annotationPending,
        annotated: annotationAnnotated,
        verified: annotationVerified,
      },
      processing: {
        completed: processingCompleted,
        pending: processingPending,
        processing: processingProcessing,
        failed: processingFailed,
        skipped: processingSkipped,
        deleted: processingDeleted,
      },
      totalScreenshots,
      totalAnnotations,
    };
  }

  async findScreenshotByContentHash(hash: string): Promise<Screenshot | null> {
    await this.ensureDB();
    const found = await db.screenshots.where("content_hash").equals(hash).first();
    return found ?? null;
  }

  async findNearDuplicate(
    perceptualHash: string,
    groupId: string | null,
    maxDistance: number,
  ): Promise<{ id: number; distance: number } | null> {
    await this.ensureDB();
    // Scope the scan to the same group — duplicates only matter within a batch —
    // and cap it to the most-recent rows so a 1000-image import stays linear
    // overall instead of O(N²). Re-encoded dupes are virtually always near their
    // original or from a recently-overlapping import, so the cap rarely misses.
    const SCAN_CAP = 500;
    const collection = (
      groupId ? db.screenshots.where("group_id").equals(groupId) : db.screenshots.toCollection()
    )
      .reverse()
      .limit(SCAN_CAP);
    let best: { id: number; distance: number } | null = null;
    await collection.each((s) => {
      const other = (s as { perceptual_hash?: string | null }).perceptual_hash;
      const id = s.id;
      if (!other || id == null) return;
      const distance = hammingDistance(perceptualHash, other);
      if (distance <= maxDistance && (best === null || distance < best.distance)) {
        best = { id, distance };
      }
    });
    return best;
  }

  async streamScreenshots(
    callback: (screenshot: Screenshot) => void | Promise<void>,
  ): Promise<void> {
    await this.ensureDB();
    // Dexie's each() streams via an IndexedDB cursor — the table is never
    // fully materialized in memory. each()'s callback is sync-only, so async
    // work is chained through a serial promise to preserve ordering and
    // back-pressure.
    let chain: Promise<void> = Promise.resolve();
    await db.screenshots.each((s) => {
      chain = chain.then(() => callback(s));
    });
    await chain;
  }

  async getGroupAggregation(): Promise<GroupAggregateRow[]> {
    // Share a scan already in progress; otherwise start one and clear the
    // handle when it settles (success or failure) so the next call is fresh.
    if (this.groupAggInFlight) return this.groupAggInFlight;
    const scan = this.scanGroupAggregation().finally(() => {
      this.groupAggInFlight = null;
    });
    this.groupAggInFlight = scan;
    return scan;
  }

  private async scanGroupAggregation(): Promise<GroupAggregateRow[]> {
    await this.ensureDB();
    const groupMap = new Map<string, GroupAggregateRow>();

    await db.screenshots.each((s) => {
      const gid = s.group_id || "ungrouped";
      let row = groupMap.get(gid);
      if (!row) {
        row = {
          id: gid,
          count: 0,
          image_type: s.image_type || "screen_time",
          created_at: s.uploaded_at || new Date().toISOString(),
          processing_pending: 0,
          processing_completed: 0,
          processing_failed: 0,
          processing_skipped: 0,
          processing_deleted: 0,
          totals_mismatch: 0,
        };
        groupMap.set(gid, row);
      }

      row.count++;
      const ps = s.processing_status || "pending";
      if (ps === "pending" || ps === "processing") row.processing_pending++;
      else if (ps === "completed") row.processing_completed++;
      else if (ps === "failed") row.processing_failed++;
      else if (ps === "skipped") row.processing_skipped++;
      else if (ps === "deleted") row.processing_deleted++;

      // "Needs attention" count powers the homepage group-card badge and must
      // agree with the totals_mismatch queue (same predicate as the filter).
      if (needsAttention(s)) row.totals_mismatch++;

      if (s.uploaded_at && s.uploaded_at < row.created_at) {
        row.created_at = s.uploaded_at;
      }
    });

    return [...groupMap.values()];
  }

  async getNextPendingScreenshot(): Promise<Screenshot | null> {
    try {
      return (
        (await db.screenshots
          .where("annotation_status")
          .equals("pending")
          .and(
            (s) =>
              s.processing_status === "failed" ||
              (s.processing_status !== "skipped" &&
                s.processing_status !== "deleted" &&
                !s.has_blocking_issues),
          )
          .first()) || null
      );
    } catch (error) {
      console.error("Failed to get next pending screenshot:", error);
      throw error;
    }
  }

  async bulkSaveScreenshots(screenshots: Screenshot[]): Promise<number[]> {
    await this.ensureDB();
    // Save each screenshot in its own transaction. A single wrapping
    // transaction has all-or-nothing semantics, but a tab crash MID-import
    // still leaves whatever Dexie had flushed — and the caller has no way to
    // know which. Per-item commits give a deterministic outcome: every id in
    // the returned array is a fully-written record; an interrupted import
    // simply stops, leaving earlier records intact and consistent.
    const ids: number[] = [];
    for (const screenshot of screenshots) {
      try {
        // eslint-disable-next-line no-await-in-loop -- per-item commit is intentional for crash-recovery determinism (see block comment above)
        const id = await db.screenshots.add(screenshot);
        ids.push(id);
      } catch (error) {
        console.error(
          `Failed to bulk-save screenshot (saved ${ids.length}/${screenshots.length}):`,
          error,
        );
        this.invalidateFilterCounts();
        throw error;
      }
    }
    this.invalidateFilterCounts();
    return ids;
  }

  async bulkSaveAnnotations(annotations: Annotation[]): Promise<number[]> {
    try {
      const ids: number[] = [];

      await db.transaction("rw", db.annotations, db.screenshots, async () => {
        for (const annotation of annotations) {
          // Upsert: check for existing annotation for this screenshot (same as saveAnnotation).
          // The whole loop body is intentionally sequential: each iteration
          // reads-then-writes and may increment a shared per-screenshot count,
          // so parallelizing would lose updates when two annotations target the
          // same screenshot.
          // eslint-disable-next-line no-await-in-loop -- sequential read-then-write upsert (see comment)
          const existing = await db.annotations
            .where("screenshot_id")
            .equals(annotation.screenshot_id)
            .first();

          if (existing) {
            // eslint-disable-next-line no-await-in-loop -- sequential read-then-write upsert (see comment)
            await db.annotations.update(existing.id, {
              ...annotation,
              id: existing.id,
              updated_at: new Date().toISOString(),
            });
            ids.push(existing.id);
          } else {
            // eslint-disable-next-line no-await-in-loop -- sequential read-then-write upsert (see comment)
            const id = await db.annotations.add(annotation);
            ids.push(id);

            // eslint-disable-next-line no-await-in-loop -- sequential read-then-write upsert (see comment)
            const screenshot = await db.screenshots.get(annotation.screenshot_id);
            if (screenshot) {
              const currentCount = screenshot.current_annotation_count || 0;
              // eslint-disable-next-line no-await-in-loop -- sequential count increment; parallel would lose updates
              await db.screenshots.update(annotation.screenshot_id, {
                current_annotation_count: currentCount + 1,
              });
            }
          }
        }
      });

      return ids;
    } catch (error) {
      console.error("Failed to bulk save annotations:", error);
      throw error;
    }
  }

  /**
   * Efficient paginated query using IndexedDB indexes.
   * Only loads the requested page instead of all screenshots.
   */
  async getScreenshotsPaginated(
    params: PaginationParams,
  ): Promise<ScreenshotListResponse> {
    try {
      const page = params.page || 1;
      const pageSize = params.page_size || 50;
      const offset = (page - 1) * pageSize;

      // Build query based on available indexes
      let collection = db.screenshots.toCollection();

      // Use compound index if both group_id and processing_status provided
      if (params.group_id && params.processing_status) {
        collection = db.screenshots
          .where("[group_id+processing_status]")
          .equals([params.group_id, params.processing_status]);
      } else if (params.group_id) {
        collection = db.screenshots.where("group_id").equals(params.group_id);
      } else if (params.processing_status) {
        collection = db.screenshots
          .where("processing_status")
          .equals(params.processing_status);
      }

      // Apply verification filters
      collection = applyVerificationFilter(collection, params);

      collection = applySearchFilter(collection, params.search);

      // Get total count first (this still needs full scan for complex filters)
      const total = await collection.count();

      // Apply sorting
      const sortBy = params.sort_by || "id";
      const sortOrder = params.sort_order || "asc";

      // For simple ID sorting, use indexed access
      if (sortBy === "id") {
        if (sortOrder === "desc") {
          collection = collection.reverse();
        }
      } else {
        // For other fields, we need to sort in memory (less efficient)
        // But we still only load what we need
        const allForSort = await collection.toArray();
        allForSort.sort((a, b) => {
          let aVal: unknown = a[sortBy as keyof Screenshot];
          let bVal: unknown = b[sortBy as keyof Screenshot];
          if (typeof aVal === "string") aVal = aVal.toLowerCase();
          if (typeof bVal === "string") bVal = bVal.toLowerCase();
          if (aVal === null || aVal === undefined) return 1;
          if (bVal === null || bVal === undefined) return -1;
          if (aVal < bVal) return sortOrder === "asc" ? -1 : 1;
          if (aVal > bVal) return sortOrder === "asc" ? 1 : -1;
          return 0;
        });

        const items = allForSort.slice(offset, offset + pageSize);
        return {
          items,
          total,
          page,
          page_size: pageSize,
          pages: Math.ceil(total / pageSize),
          has_next: offset + items.length < total,
          has_prev: page > 1,
        };
      }

      // Use offset and limit for efficient pagination
      const items = await collection.offset(offset).limit(pageSize).toArray();

      return {
        items,
        total,
        page,
        page_size: pageSize,
        pages: Math.ceil(total / pageSize),
        has_next: offset + items.length < total,
        has_prev: page > 1,
      };
    } catch (error) {
      console.error("Failed to get paginated screenshots:", error);
      throw error;
    }
  }

  /**
   * Cached filter-total counts. Keyed by a serialized filter tuple so the
   * O(N) count for a given filter is paid once per filter, not once per arrow
   * click. Invalidated on any screenshot mutation.
   */
  private filterCountCache = new Map<string, number>();

  /** Drop all cached filter totals — call on any screenshot insert/update/delete. */
  private invalidateFilterCounts(): void {
    this.filterCountCache.clear();
  }

  /** Build the indexed Dexie collection for a navigation filter (no JS filter). */
  private buildNavCollection(params: NavigationQueryParams) {
    if (params.group_id && params.processing_status) {
      return db.screenshots
        .where("[group_id+processing_status]")
        .equals([params.group_id, params.processing_status]);
    }
    if (params.group_id) {
      return db.screenshots.where("group_id").equals(params.group_id);
    }
    if (params.processing_status) {
      return db.screenshots
        .where("processing_status")
        .equals(params.processing_status);
    }
    return db.screenshots.toCollection();
  }

  /**
   * Efficient cursor-based navigation.
   *
   * When no JS-side verification filter is active, this uses an indexed
   * keyset cursor (`where('id').above/below(...).limit(1)`) — O(log N), not
   * O(N) — so it never loads or sorts the full primary-key list. When a
   * verification filter IS active (it can only be evaluated in JS), it walks
   * the filtered collection with an early-exiting cursor and caches the total.
   */
  async navigateScreenshots(
    currentId: number,
    params: NavigationQueryParams,
  ): Promise<NavigationResponse> {
    try {
      await this.ensureDB();
      const hasSearch = !!params.search;
      const hasJsFilter =
        params.verified_by_me !== undefined ||
        params.verified_by_others !== undefined ||
        params.totals_mismatch !== undefined ||
        hasSearch;
      const direction = params.direction ?? "current";

      const empty: NavigationResponse = {
        screenshot: null,
        current_index: 0,
        total_in_filter: 0,
        has_next: false,
        has_prev: false,
      };

      // -- Cursor keyset path: no JS filter, navigate via early-exit cursor --
      // For the unfiltered case Dexie uses the primary-key index directly.
      // For group/processing-filtered cases the cursor walk early-exits at the
      // first match — O(rank), and rank is ~1 for click-by-click navigation.
      if (!hasJsFilter) {
        const total = await this.buildNavCollection(params).count();
        if (total === 0) return empty;

        let targetId: number | null = null;
        if (direction === "next") {
          const next = await this.buildNavCollection(params)
            .filter((s) => s.id > currentId)
            .first();
          targetId = next?.id ?? null;
        } else if (direction === "prev") {
          const prev = await this.buildNavCollection(params)
            .reverse()
            .filter((s) => s.id < currentId)
            .first();
          targetId = prev?.id ?? null;
        } else {
          const current = await this.buildNavCollection(params)
            .filter((s) => s.id === currentId)
            .first();
          // If currentId fell out of the filter, anchor to the first item.
          targetId =
            current?.id ??
            (await this.buildNavCollection(params).first())?.id ??
            null;
        }

        if (targetId === null) {
          // No screenshot in the requested direction.
          return { ...empty, total_in_filter: total };
        }

        const targetScreenshot = (await db.screenshots.get(targetId)) ?? null;
        // current_index / has_next / has_prev need the target's rank.
        const idsBefore = await this.buildNavCollection(params)
          .filter((s) => s.id < targetId)
          .count();
        return {
          screenshot: targetScreenshot,
          current_index: targetScreenshot ? idsBefore + 1 : 0,
          total_in_filter: total,
          has_next: idsBefore < total - 1,
          has_prev: idsBefore > 0,
        };
      }

      // -- JS-filter path: cursor walk with early exit + cached total -------
      const cacheKey = JSON.stringify([
        params.group_id ?? "",
        params.processing_status ?? "",
        params.verified_by_me ?? null,
        params.verified_by_others ?? null,
        params.totals_mismatch ?? null,
        params.search ?? "",
      ]);

      const filtered = () =>
        applySearchFilter(
          applyVerificationFilter(this.buildNavCollection(params), params),
          params.search,
        );

      let total = this.filterCountCache.get(cacheKey);
      if (total === undefined) {
        total = await filtered().count();
        this.filterCountCache.set(cacheKey, total);
      }
      if (total === 0) return empty;

      // Walk the filtered set in id order, early-exiting once we have what we
      // need. We never collect the whole id list.
      let prevId: number | null = null;
      let curId: number | null = null;
      let nextId: number | null = null;
      let rank = -1; // 0-based rank of curId
      let seen = 0;
      let foundCurrent = false;
      let firstId: number | null = null;
      let firstGreaterId: number | null = null;
      let firstGreaterRank = -1;
      let lastLessId: number | null = null;
      let lastLessRank = -1;

      await filtered()
        .until(() => foundCurrent && nextId !== null)
        .each((s) => {
          if (firstId === null) firstId = s.id;
          if (!foundCurrent && s.id < currentId) {
            lastLessId = s.id;
            lastLessRank = seen;
          }
          if (!foundCurrent && firstGreaterId === null && s.id > currentId) {
            firstGreaterId = s.id;
            firstGreaterRank = seen;
          }
          if (foundCurrent) {
            if (nextId === null) nextId = s.id;
            return;
          }
          if (s.id === currentId) {
            foundCurrent = true;
            curId = s.id;
            rank = seen;
          } else {
            prevId = s.id;
            seen++;
          }
        });

      let targetId: number | null;
      let targetRank: number;
      if (!foundCurrent && direction === "next") {
        // currentId left the filter (e.g. it was just corrected + verified, so
        // it no longer "needs attention"). Prefer the next remaining item by id;
        // if nothing greater is left, fall back to the nearest lower remaining
        // item so the queue keeps draining instead of jumping to the empty-queue
        // page while earlier-id items are still flagged.
        if (firstGreaterId !== null) {
          targetId = firstGreaterId;
          targetRank = firstGreaterRank;
        } else {
          targetId = lastLessId;
          targetRank = lastLessRank;
        }
      } else if (!foundCurrent && direction === "prev") {
        targetId = lastLessId;
        targetRank = lastLessRank;
      } else if (!foundCurrent) {
        // currentId fell out of the filter: anchor "current" to the first item.
        targetId = firstId;
        targetRank = firstId === null ? -1 : 0;
      } else if (direction === "next") {
        targetId = nextId;
        targetRank = rank + 1;
      } else if (direction === "prev") {
        targetId = prevId;
        targetRank = rank - 1;
      } else {
        targetId = curId;
        targetRank = rank;
      }

      if (targetId === null || targetRank < 0 || targetRank >= total) {
        return { ...empty, total_in_filter: total };
      }

      const targetScreenshot = (await db.screenshots.get(targetId)) ?? null;
      return {
        screenshot: targetScreenshot,
        current_index: targetScreenshot ? targetRank + 1 : 0,
        total_in_filter: total,
        has_next: targetRank < total - 1,
        has_prev: targetRank > 0,
      };
    } catch (error) {
      console.error("Failed to navigate screenshots:", error);
      throw error;
    }
  }

  async getStorageEstimate(): Promise<StorageEstimate | null> {
    if (!navigator.storage?.estimate) return null;
    const { usage, quota } = await navigator.storage.estimate();
    return {
      usage: usage ?? 0,
      quota: quota ?? 0,
      percentUsed: quota ? ((usage ?? 0) / quota) * 100 : 0,
    };
  }
}
