import { afterEach, describe, expect, test } from "bun:test";

import { computeContentHash } from "../contentHash";

const originalCrypto = Object.getOwnPropertyDescriptor(globalThis, "crypto");

function restoreCrypto(): void {
  if (originalCrypto) {
    Object.defineProperty(globalThis, "crypto", originalCrypto);
  } else {
    delete (globalThis as { crypto?: Crypto }).crypto;
  }
}

describe("computeContentHash", () => {
  afterEach(() => {
    restoreCrypto();
  });

  test("uses bounded chunk reads when SubtleCrypto is unavailable", async () => {
    Object.defineProperty(globalThis, "crypto", {
      configurable: true,
      value: {},
    });
    const blob = new Blob([new Uint8Array([0x61, 0x62, 0x63])]);
    let fullRead = false;
    Object.defineProperty(blob, "arrayBuffer", {
      configurable: true,
      value: () => {
        fullRead = true;
        throw new Error("full blob read should not be used");
      },
    });

    const hash = await computeContentHash(blob);

    expect(hash).toBe("fnv1a:3:e71fa2190541574b");
    expect(fullRead).toBe(false);
  });

  test("does not materialize large files in one ArrayBuffer for content hashing", async () => {
    const digestCalls: ArrayBuffer[] = [];
    Object.defineProperty(globalThis, "crypto", {
      configurable: true,
      value: {
        subtle: {
          digest: async (_algorithm: string, bytes: ArrayBuffer) => {
            digestCalls.push(bytes);
            return new ArrayBuffer(32);
          },
        },
      },
    });
    const bytes = new Uint8Array(17 * 1024 * 1024 + 7);
    bytes[0] = 1;
    bytes[bytes.length - 1] = 2;
    const blob = new Blob([bytes]);
    let fullRead = false;
    let sliceCalls = 0;
    const originalSlice = blob.slice.bind(blob);
    Object.defineProperty(blob, "arrayBuffer", {
      configurable: true,
      value: () => {
        fullRead = true;
        throw new Error("full blob read should not be used for large files");
      },
    });
    Object.defineProperty(blob, "slice", {
      configurable: true,
      value: (...args: Parameters<Blob["slice"]>) => {
        sliceCalls++;
        return originalSlice(...args);
      },
    });

    const hash = await computeContentHash(blob);

    expect(hash.startsWith("fnv1a:")).toBe(true);
    expect(fullRead).toBe(false);
    expect(sliceCalls).toBeGreaterThan(1);
    expect(digestCalls).toHaveLength(0);
  });

  test("stops chunked hashing when the upload aborts", async () => {
    Object.defineProperty(globalThis, "crypto", {
      configurable: true,
      value: {},
    });
    const controller = new AbortController();
    const bytes = new Uint8Array(3 * 1024 * 1024);
    const blob = new Blob([bytes]);
    let readChunks = 0;
    const originalSlice = blob.slice.bind(blob);
    Object.defineProperty(blob, "slice", {
      configurable: true,
      value: (...args: Parameters<Blob["slice"]>) => {
        const chunk = originalSlice(...args);
        const originalArrayBuffer = chunk.arrayBuffer.bind(chunk);
        Object.defineProperty(chunk, "arrayBuffer", {
          configurable: true,
          value: async () => {
            readChunks++;
            const out = await originalArrayBuffer();
            if (readChunks === 1) controller.abort();
            return out;
          },
        });
        return chunk;
      },
    });

    await expect(computeContentHash(blob, controller.signal)).rejects.toThrow("Content hash aborted");

    expect(readChunks).toBe(1);
  });
});
