/**
 * Uncertainty-ordered queue (roadmap #20) — pure ordering policy.
 *
 * Mirrors the server-side ORDER BY in queue_repository.py: lowest grid-alignment
 * score first, then lowest grid-detection confidence, then oldest upload. A
 * missing signal is treated as fully confident (1.0) so un-scored screenshots
 * sort last.
 */
import { describe, it, expect } from "bun:test";
import type { Screenshot } from "@/types";
import {
  compareByUncertainty,
  mostUncertain,
  orderByUncertainty,
} from "./queueOrdering";

// Minimal Screenshot factory — only the fields the ordering reads.
const mk = (over: Partial<Screenshot>): Screenshot =>
  ({
    id: 0,
    uploaded_at: "2026-01-01T00:00:00Z",
    alignment_score: null,
    grid_detection_confidence: null,
    ...over,
  }) as Screenshot;

describe("uncertainty-ordered queue (#20)", () => {
  it("serves the lowest grid-alignment score first", () => {
    const list = [
      mk({ id: 1, alignment_score: 0.9 }),
      mk({ id: 2, alignment_score: 0.3 }),
      mk({ id: 3, alignment_score: 0.6 }),
    ];
    expect(mostUncertain(list)?.id).toBe(2);
    expect(orderByUncertainty(list).map((s) => s.id)).toEqual([2, 3, 1]);
  });

  it("breaks alignment ties with the lowest grid-detection confidence", () => {
    const list = [
      mk({ id: 1, alignment_score: 0.5, grid_detection_confidence: 0.8 }),
      mk({ id: 2, alignment_score: 0.5, grid_detection_confidence: 0.2 }),
    ];
    expect(mostUncertain(list)?.id).toBe(2);
  });

  it("breaks remaining ties with the oldest upload", () => {
    const list = [
      mk({ id: 1, alignment_score: 0.5, uploaded_at: "2026-03-01T00:00:00Z" }),
      mk({ id: 2, alignment_score: 0.5, uploaded_at: "2026-01-01T00:00:00Z" }),
    ];
    expect(mostUncertain(list)?.id).toBe(2);
  });

  it("treats a missing alignment score as fully confident (sorts last)", () => {
    const list = [
      mk({ id: 1, alignment_score: null }),
      mk({ id: 2, alignment_score: 0.7 }),
      mk({ id: 3, alignment_score: 0.99 }),
    ];
    // The un-scored screenshot (id 1, → 1.0) must never jump ahead of known-bad.
    expect(orderByUncertainty(list).map((s) => s.id)).toEqual([2, 3, 1]);
    expect(mostUncertain(list)?.id).toBe(2);
  });

  it("treats a missing confidence as fully confident when alignment ties", () => {
    const list = [
      mk({ id: 1, alignment_score: 0.5, grid_detection_confidence: null }),
      mk({ id: 2, alignment_score: 0.5, grid_detection_confidence: 0.4 }),
    ];
    expect(mostUncertain(list)?.id).toBe(2);
  });

  it("is a pure, stable comparator and does not mutate its input", () => {
    const list = [
      mk({ id: 1, alignment_score: 0.9 }),
      mk({ id: 2, alignment_score: 0.1 }),
    ];
    const snapshot = list.map((s) => s.id);
    orderByUncertainty(list);
    expect(list.map((s) => s.id)).toEqual(snapshot); // input untouched
    expect(compareByUncertainty(list[0]!, list[1]!)).toBeGreaterThan(0);
  });

  it("returns null for an empty queue", () => {
    expect(mostUncertain([])).toBeNull();
  });
});
