import { cropBlobToRect, cropScreenshot, readBlobDimensions } from "./cropping";
import type { CropRect } from "./cropHistory";

interface CropWorkerRequest {
  id: string;
  type: "cropScreenshot" | "cropBlobToRect" | "readBlobDimensions";
  blob: Blob;
  rect?: CropRect;
  knownDimensions?: { width: number; height: number };
}

interface CropWorkerErrorPayload {
  name: string;
  message: string;
  stack?: string;
}

type CropWorkerResponse =
  | {
      id: string;
      type: "result";
      result: unknown;
    }
  | {
      id: string;
      type: "error";
      error: CropWorkerErrorPayload;
    };

function serializeError(error: unknown): CropWorkerErrorPayload {
  if (error instanceof Error) {
    return {
      name: error.name,
      message: error.message,
      ...(error.stack ? { stack: error.stack } : {}),
    };
  }
  return {
    name: "Error",
    message: String(error),
  };
}

self.onmessage = async (event: MessageEvent<CropWorkerRequest>) => {
  const message = event.data;
  try {
    if (message.type === "cropScreenshot") {
      const result = await cropScreenshot(message.blob);
      self.postMessage({ id: message.id, type: "result", result } satisfies CropWorkerResponse);
      return;
    }

    if (message.type === "readBlobDimensions") {
      const result = await readBlobDimensions(message.blob);
      self.postMessage({ id: message.id, type: "result", result } satisfies CropWorkerResponse);
      return;
    }

    if (!message.rect) {
      throw new Error("cropBlobToRect requires a crop rectangle");
    }
    const result = await cropBlobToRect(message.blob, message.rect, message.knownDimensions);
    self.postMessage({ id: message.id, type: "result", result } satisfies CropWorkerResponse);
  } catch (error) {
    self.postMessage({
      id: message.id,
      type: "error",
      error: serializeError(error),
    } satisfies CropWorkerResponse);
  }
};
