const WORKGROUP_SIZE = 256;
const MAX_BENCHMARK_PIXELS = 4096 * 4096;

export interface ThresholdExecution {
  mask: Uint32Array;
  backend: "webgpu" | "cpu";
  parityMismatches: number;
  fallbackReason?: string;
}

export interface ThresholdBenchmarkResult {
  backend: "webgpu" | "cpu";
  width: number;
  height: number;
  pixels: number;
  iterations: number;
  cpuMedianMs: number;
  acceleratorMedianMs: number | null;
  speedup: number | null;
  parityMismatches: number;
  fallbackReason?: string;
}

function checkedPixelCount(rgba: Uint8Array, width: number, height: number): number {
  if (!Number.isSafeInteger(width) || !Number.isSafeInteger(height) || width < 0 || height < 0) {
    throw new RangeError("width and height must be non-negative safe integers");
  }
  const pixels = width * height;
  if (!Number.isSafeInteger(pixels) || pixels * 4 !== rgba.byteLength) {
    throw new RangeError("RGBA buffer size does not match width×height×4");
  }
  return pixels;
}

function thresholdByte(value: number): number {
  if (!Number.isFinite(value)) throw new RangeError("threshold must be finite");
  return Math.max(0, Math.min(255, Math.round(value)));
}

export function thresholdRgbaCpu(
  rgba: Uint8Array,
  width: number,
  height: number,
  threshold = 128,
): Uint32Array {
  const pixels = checkedPixelCount(rgba, width, height);
  const cutoff = thresholdByte(threshold);
  const mask = new Uint32Array(pixels);
  for (let pixel = 0, offset = 0; pixel < pixels; pixel++, offset += 4) {
    const red = rgba[offset] ?? 0;
    const green = rgba[offset + 1] ?? 0;
    const blue = rgba[offset + 2] ?? 0;
    const luma = (77 * red + 150 * green + 29 * blue) >>> 8;
    mask[pixel] = luma >= cutoff ? 1 : 0;
  }
  return mask;
}

function packedRgba(rgba: Uint8Array, pixels: number): Uint32Array {
  const packed = new Uint32Array(pixels);
  for (let pixel = 0, offset = 0; pixel < pixels; pixel++, offset += 4) {
    packed[pixel] =
      (rgba[offset] ?? 0) |
      ((rgba[offset + 1] ?? 0) << 8) |
      ((rgba[offset + 2] ?? 0) << 16) |
      ((rgba[offset + 3] ?? 0) << 24);
  }
  return packed;
}

async function thresholdRgbaWebGpu(
  rgba: Uint8Array,
  width: number,
  height: number,
  threshold: number,
): Promise<Uint32Array> {
  const pixels = checkedPixelCount(rgba, width, height);
  if (pixels === 0) return new Uint32Array();
  if (!navigator.gpu) throw new Error("WebGPU is unavailable");
  const adapter = await navigator.gpu.requestAdapter({ powerPreference: "high-performance" });
  if (!adapter) throw new Error("WebGPU returned no adapter");
  const device = await adapter.requestDevice();
  const bytes = pixels * Uint32Array.BYTES_PER_ELEMENT;
  const input = device.createBuffer({
    label: "threshold-rgba-input",
    size: bytes,
    usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
  });
  const output = device.createBuffer({
    label: "threshold-mask-output",
    size: bytes,
    usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC,
  });
  const readback = device.createBuffer({
    label: "threshold-mask-readback",
    size: bytes,
    usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
  });
  const params = device.createBuffer({
    label: "threshold-params",
    size: 8,
    usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
  });

  try {
    const module = device.createShaderModule({
      label: "threshold-rgba-compute",
      code: `
        struct Params { pixel_count: u32, threshold: u32 }
        @group(0) @binding(0) var<storage, read> rgba: array<u32>;
        @group(0) @binding(1) var<storage, read_write> mask: array<u32>;
        @group(0) @binding(2) var<uniform> params: Params;

        @compute @workgroup_size(${WORKGROUP_SIZE})
        fn main(@builtin(global_invocation_id) id: vec3<u32>) {
          let index = id.x;
          if (index >= params.pixel_count) { return; }
          let pixel = rgba[index];
          let red = pixel & 255u;
          let green = (pixel >> 8u) & 255u;
          let blue = (pixel >> 16u) & 255u;
          let luma = (77u * red + 150u * green + 29u * blue) >> 8u;
          mask[index] = select(0u, 1u, luma >= params.threshold);
        }
      `,
    });
    const pipeline = device.createComputePipeline({
      label: "threshold-rgba-pipeline",
      layout: "auto",
      compute: { module, entryPoint: "main" },
    });
    const bindGroup = device.createBindGroup({
      label: "threshold-rgba-bindings",
      layout: pipeline.getBindGroupLayout(0),
      entries: [
        { binding: 0, resource: { buffer: input } },
        { binding: 1, resource: { buffer: output } },
        { binding: 2, resource: { buffer: params } },
      ],
    });
    const packed = packedRgba(rgba, pixels);
    const parameterValues = new Uint32Array([pixels, thresholdByte(threshold)]);
    device.queue.writeBuffer(input, 0, packed.buffer as ArrayBuffer);
    device.queue.writeBuffer(params, 0, parameterValues.buffer);

    const encoder = device.createCommandEncoder({ label: "threshold-rgba-commands" });
    const pass = encoder.beginComputePass({ label: "threshold-rgba-pass" });
    pass.setPipeline(pipeline);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(pixels / WORKGROUP_SIZE));
    pass.end();
    encoder.copyBufferToBuffer(output, 0, readback, 0, bytes);
    device.queue.submit([encoder.finish()]);

    const outcome = await Promise.race([
      readback.mapAsync(GPUMapMode.READ).then(() => ({ kind: "mapped" as const })),
      device.lost.then((info) => ({ kind: "lost" as const, info })),
    ]);
    if (outcome.kind === "lost") {
      throw new Error(`WebGPU device lost (${outcome.info.reason}): ${outcome.info.message}`);
    }
    return new Uint32Array(readback.getMappedRange().slice(0));
  } finally {
    if (readback.mapState === "mapped") readback.unmap();
    input.destroy();
    output.destroy();
    readback.destroy();
    params.destroy();
    device.destroy();
  }
}

function mismatchCount(left: Uint32Array, right: Uint32Array): number {
  if (left.length !== right.length) return Math.max(left.length, right.length);
  let mismatches = 0;
  for (let index = 0; index < left.length; index++) {
    if (left[index] !== right[index]) mismatches++;
  }
  return mismatches;
}

export async function thresholdRgbaWithWebGpuFallback(
  rgba: Uint8Array,
  width: number,
  height: number,
  threshold = 128,
): Promise<ThresholdExecution> {
  const cpu = thresholdRgbaCpu(rgba, width, height, threshold);
  try {
    const gpu = await thresholdRgbaWebGpu(rgba, width, height, threshold);
    const parityMismatches = mismatchCount(cpu, gpu);
    if (parityMismatches > 0) {
      return {
        mask: cpu,
        backend: "cpu",
        parityMismatches,
        fallbackReason: `WebGPU parity mismatch in ${parityMismatches} pixels`,
      };
    }
    return { mask: gpu, backend: "webgpu", parityMismatches: 0 };
  } catch (error) {
    return {
      mask: cpu,
      backend: "cpu",
      parityMismatches: 0,
      fallbackReason: error instanceof Error ? error.message : String(error),
    };
  }
}

function median(values: number[]): number {
  const sorted = [...values].sort((left, right) => left - right);
  return sorted[Math.floor(sorted.length / 2)] ?? 0;
}

export async function benchmarkRgbaThreshold(
  width = 1024,
  height = 1024,
  iterations = 3,
): Promise<ThresholdBenchmarkResult> {
  if (!Number.isInteger(iterations) || iterations < 1 || iterations > 20) {
    throw new RangeError("iterations must be an integer from 1 through 20");
  }
  if (!Number.isSafeInteger(width) || !Number.isSafeInteger(height) || width < 1 || height < 1) {
    throw new RangeError("benchmark width and height must be positive safe integers");
  }
  const pixels = width * height;
  if (!Number.isSafeInteger(pixels) || pixels > MAX_BENCHMARK_PIXELS) {
    throw new RangeError(`benchmark image must contain at most ${MAX_BENCHMARK_PIXELS} pixels`);
  }
  const rgba = new Uint8Array(pixels * 4);
  for (let index = 0; index < pixels; index++) {
    const offset = index * 4;
    rgba[offset] = (index * 17) & 255;
    rgba[offset + 1] = (index * 31) & 255;
    rgba[offset + 2] = (index * 47) & 255;
    rgba[offset + 3] = 255;
  }

  const cpuTimes: number[] = [];
  for (let run = 0; run < iterations; run++) {
    const started = performance.now();
    thresholdRgbaCpu(rgba, width, height);
    cpuTimes.push(performance.now() - started);
  }

  const acceleratorTimes: number[] = [];
  let execution: ThresholdExecution | undefined;
  for (let run = 0; run < iterations; run++) {
    const started = performance.now();
    // eslint-disable-next-line no-await-in-loop -- benchmark samples must be serialized: concurrent GPU runs would contend and each sample would time the contention rather than the kernel
    execution = await thresholdRgbaWithWebGpuFallback(rgba, width, height);
    acceleratorTimes.push(performance.now() - started);
    if (execution.backend === "cpu") break;
  }
  if (!execution) throw new Error("benchmark produced no execution");

  const cpuMedianMs = median(cpuTimes);
  const acceleratorMedianMs = execution.backend === "webgpu" ? median(acceleratorTimes) : null;
  return {
    backend: execution.backend,
    width,
    height,
    pixels,
    iterations,
    cpuMedianMs,
    acceleratorMedianMs,
    speedup:
      acceleratorMedianMs && acceleratorMedianMs > 0 ? cpuMedianMs / acceleratorMedianMs : null,
    parityMismatches: execution.parityMismatches,
    ...(execution.fallbackReason ? { fallbackReason: execution.fallbackReason } : {}),
  };
}
