import { createContext } from "react";
import type { ServiceContainer } from "../di";
import type { AppConfig } from "../config";

export const ServiceContext = createContext<ServiceContainer | null>(null);

// Module-level singletons to survive React StrictMode unmount/remount cycles.
// Exposed via helper functions below so that ServiceProvider.tsx exports only
// the Provider component (Fast Refresh requirement).
interface GlobalState {
  container: ServiceContainer | null;
  config: AppConfig | null;
  bootstrapPromise: Promise<ServiceContainer> | null;
}

const state: GlobalState = {
  container: null,
  config: null,
  bootstrapPromise: null,
};

export function getGlobalContainer(): ServiceContainer | null {
  return state.container;
}

export function getGlobalConfig(): AppConfig | null {
  return state.config;
}

export function setGlobalContainer(c: ServiceContainer | null, cfg: AppConfig | null): void {
  state.container = c;
  state.config = cfg;
}

export function getBootstrapPromise(): Promise<ServiceContainer> | null {
  return state.bootstrapPromise;
}

export function setBootstrapPromise(p: Promise<ServiceContainer> | null): void {
  state.bootstrapPromise = p;
}

/**
 * Pre-populate the global container from outside this module.
 *
 * `main.tsx` calls this BEFORE rendering React in server mode, which
 * eliminates a race where a rapidly-mounted route component (e.g.
 * AnnotationWorkspace) called useScreenshotService before ServiceProvider's
 * async useEffect had set state. ErrorBoundary caught the throw and the
 * next render succeeded, but the console error broke tests and confused
 * users in devtools.
 */
export function presetGlobalContainer(c: ServiceContainer, cfg: AppConfig): void {
  setGlobalContainer(c, cfg);
}

// Clean up worker threads when the tab/window is closed.
//
// `terminate()`, not `destroy()`: destroy() also clears the registration map,
// and beforeunload fires while the React tree is still mounted and still
// rendering. Any component that resolved a service in that window threw
// "Service not registered: IScreenshotService", which ErrorBoundary caught and
// logged — a console error and a fallback flash on every navigation away.
// Nothing is leaked by leaving the map intact: the document is being discarded.
// The global reference is left in place for the same reason — nulling it made
// ServiceProvider start a fresh bootstrap during unload.
if (typeof window !== "undefined") {
  window.addEventListener("beforeunload", () => {
    state.container?.terminate();
  });
}
