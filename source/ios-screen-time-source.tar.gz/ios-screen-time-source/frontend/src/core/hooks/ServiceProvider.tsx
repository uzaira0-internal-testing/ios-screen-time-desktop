import React, {
  useEffect,
  type ReactNode,
  useState,
} from "react";
import { bootstrapServices, type ServiceContainer } from "../di";
import { createConfig, AppConfig } from "../config";
import {
  ServiceContext,
  getGlobalContainer,
  getGlobalConfig,
  setGlobalContainer,
  getBootstrapPromise,
  setBootstrapPromise,
} from "./ServiceContext";
import { Spinner } from "@/components/ui/Spinner";
import { wipeAllLocalData } from "@/lib/resetLocalData";
import { voidHandler } from "@/lib/asyncHandler";

function getOrCreateContainer(config: AppConfig): Promise<ServiceContainer> {
  // If we have a container and the config matches, reuse it
  const existing = getGlobalContainer();
  const existingCfg = getGlobalConfig();
  if (
    existing &&
    existingCfg &&
    existingCfg.mode === config.mode &&
    existingCfg.apiBaseUrl === config.apiBaseUrl
  ) {
    return Promise.resolve(existing);
  }

  // If bootstrap is already in progress for this config, reuse the promise
  const inflight = getBootstrapPromise();
  if (inflight) return inflight;

  // Otherwise create a new one
  const promise = bootstrapServices(config)
    .then((container) => {
      setGlobalContainer(container, config);
      setBootstrapPromise(null);
      return container;
    })
    .catch((err) => {
      setBootstrapPromise(null); // Allow retry on next mount
      throw err;
    });
  setBootstrapPromise(promise);
  return promise;
}

interface ServiceProviderProps {
  children: ReactNode;
  config?: AppConfig;
}

export const ServiceProvider: React.FC<ServiceProviderProps> = ({
  children,
  config,
}) => {
  // Create config once
  const [effectiveConfig] = useState(() => config || createConfig());
  const [container, setContainer] = useState<ServiceContainer | null>(
    getGlobalContainer(),
  );
  const [error, setError] = useState<string | null>(null);
  // Boot-error "lifeboat" reset state. When bootstrap fails because local data
  // is wedged (corrupt migration / quota-exhausted write / a dataset too large
  // to load on a weak machine), Reload alone loops — a destructive wipe is the
  // only recovery, so gate it behind an explicit confirm.
  const [confirmingReset, setConfirmingReset] = useState(false);
  const [resetting, setResetting] = useState(false);

  async function recoverByWipe() {
    setResetting(true);
    try {
      await wipeAllLocalData();
    } finally {
      // Reload regardless — the wipe is best-effort and a fresh boot is the goal.
      window.location.reload();
    }
  }

  useEffect(() => {
    // Bootstrap services (async for WASM/Tauri code-splitting)
    if (container) return;
    let cancelled = false;
    getOrCreateContainer(effectiveConfig)
      .then((c) => {
        if (!cancelled) setContainer(c);
      })
      .catch((err) => {
        if (cancelled) return;
        console.error("[ServiceProvider] Bootstrap failed:", err);
        setError(
          err instanceof Error
            ? err.message
            : "Failed to initialize application services",
        );
      });
    return () => {
      cancelled = true;
    };
  }, [container, effectiveConfig]);

  if (error) {
    return (
      <div role="alert" className="flex items-center justify-center min-h-screen p-8">
        <div className="max-w-md text-center space-y-4">
          <h1 className="text-xl font-semibold text-eq-danger">Application failed to start</h1>
          <p className="text-sm text-eq-muted">{error}</p>
          <button
            type="button"
            className="px-4 py-2 text-sm bg-eq-surface-muted rounded-eq-md hover:bg-eq-surface-muted"
            onClick={() => window.location.reload()}
          >
            Reload
          </button>

          {/* Recovery path when a reload won't help (wedged local data). Two
              steps because this erases every screenshot/annotation on this
              device — there is no undo and no backend copy. */}
          {!confirmingReset ? (
            <p className="pt-2 text-xs text-eq-muted">
              Still stuck after reloading?{" "}
              <button
                type="button"
                className="underline hover:text-eq-ink"
                onClick={() => setConfirmingReset(true)}
              >
                Clear local data &amp; restart
              </button>
            </p>
          ) : (
            <div className="space-y-3 rounded-eq-md border border-eq-danger bg-eq-danger-bg p-3 text-left">
              <p className="text-xs text-eq-danger">
                This erases all screenshots, annotations, and caches on this
                device, then restarts the app. There is no undo and no online
                copy. Only do this if reloading hasn&apos;t recovered the app.
              </p>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  disabled={resetting}
                  className="px-3 py-1.5 text-xs rounded-eq-md border border-eq-border text-eq-muted disabled:opacity-50"
                  onClick={() => setConfirmingReset(false)}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={resetting}
                  className="px-3 py-1.5 text-xs rounded-eq-md bg-eq-danger text-white hover:bg-eq-danger disabled:opacity-50"
                  onClick={voidHandler(recoverByWipe)}
                >
                  {resetting ? "Clearing…" : "Erase & restart"}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Show a spinner (not a blank white screen) until services are ready. Server
  // mode is typically <1ms, but WASM mode dynamically imports the pipeline, so
  // a centered indicator avoids a "is it broken?" blank on first offline load.
  if (!container) {
    return (
      <div className="flex h-screen items-center justify-center bg-eq-bg">
        <Spinner size="lg" label="Loading…" />
      </div>
    );
  }

  return (
    <ServiceContext.Provider value={container}>
      {children}
    </ServiceContext.Provider>
  );
};
