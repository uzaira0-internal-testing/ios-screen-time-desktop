import type {
  Group,
  Screenshot,
  PreprocessingSummary,
  PreprocessingEventLog,
  PreprocessingDetailsResponse,
  BrowserUploadResponse,
  PHIRegionsResponse,
  PHIRegionRect,
} from "@/types";
import type { PreprocessingStages } from "@/core/generated/constants";
import type { StorageEstimate } from "./IStorageService";

export type PreprocessingStage = PreprocessingStages;

/** A crop rectangle in original-image coordinates (matches the server contract). */
export interface CropRectangle {
  left: number;
  top: number;
  right: number;
  bottom: number;
}

/** Undo/redo availability for a screenshot's crop, plus the currently-applied
 *  crop rectangle (null = uncropped). Drives the crop Undo/Redo controls. */
export interface CropHistoryState {
  canUndo: boolean;
  canRedo: boolean;
  currentCrop: CropRectangle | null;
}

/** A PHI region detected in an image, with bounding box and metadata. */
export interface PHIRegion {
  x: number;
  y: number;
  w: number;
  h: number;
  label: string;
  source: string;
  confidence: number;
  text: string;
}

export interface RunStageOptions {
  group_id?: string;
  screenshot_ids?: number[];
  phi_pipeline_preset?: string;
  phi_redaction_method?: string;
  phi_ocr_engine?: string;
  phi_ner_detector?: string;
  llm_endpoint?: string;
  llm_model?: string;
  llm_api_key?: string;
  ocr_method?: string;
  max_shift?: number;
  skip_daily_totals?: boolean;
  /** Called after each screenshot completes (WASM mode only). */
  onProgress?: (completed: number, total: number) => void;
  /** Signal to abort processing (WASM mode only). */
  abortSignal?: AbortSignal;
}

export interface RunStageResult {
  queued_count: number;
  message: string;
  screenshot_ids?: number[];
  task_ids?: string[];
  /** Number of screenshots that FAILED this stage (WASM batch path). Lets the
   *  caller warn on partial failure instead of showing a successes-only toast. */
  failed_count?: number;
}

export interface PreprocessingStageSchedulerStats {
  runs: number;
  totalQueuedItems: number;
  totalCompletedItems: number;
  totalFailedItems: number;
  totalAbortedItems: number;
  totalCacheHits: number;
  totalRunMs: number;
  maxRunMs: number;
  averageRunMs: number;
  totalItemMs: number;
  maxItemMs: number;
  averageItemMs: number;
  maxInFlightItems: number;
  lastQueuedItems: number;
  lastCompletedItems: number;
  lastFailedItems: number;
  lastAbortedItems: number;
  lastCacheHits: number;
  lastRunMs: number;
  lastConfiguredConcurrency: number;
  lastMaxInFlightItems: number;
}

export interface CropWorkerPoolSchedulerSnapshot {
  maxWorkers: number;
  poolSize: number;
  busyWorkers: number;
  queuedRequests: number;
  accepted: number;
  dispatched: number;
  completed: number;
  failed: number;
  cancelled: number;
  terminated: number;
  fallbackRuns: number;
  maxQueueDepth: number;
  maxBusyWorkers: number;
}

export interface PreprocessingStageSchedulerSnapshot {
  stages: Record<string, PreprocessingStageSchedulerStats>;
  cropWorkerPool?: CropWorkerPoolSchedulerSnapshot;
}

export interface IPreprocessingService {
  getGroups(): Promise<Group[]>;
  getScreenshots(params: {
    group_id: string;
    page_size?: number;
    sort_by?: string;
    sort_order?: string;
  }): Promise<{ items: Screenshot[]; total: number }>;
  getSummary(groupId: string): Promise<PreprocessingSummary>;
  runStage(stage: PreprocessingStage, options: RunStageOptions): Promise<RunStageResult>;
  resetStage(stage: PreprocessingStage, groupId: string): Promise<{ message: string; count?: number }>;
  skipStage(stage: PreprocessingStage, groupId: string, screenshotIds?: number[], unskip?: boolean): Promise<{ message: string; count?: number }>;
  invalidateFromStage(screenshotId: number, stage: string): Promise<void>;
  getEventLog(screenshotId: number): Promise<PreprocessingEventLog>;
  getScreenshot(screenshotId: number): Promise<Screenshot | null>;
  uploadBrowser(formData: FormData): Promise<BrowserUploadResponse>;
  getOriginalImageUrl(screenshotId: number): Promise<string>;
  applyManualCrop(screenshotId: number, crop: { left: number; top: number; right: number; bottom: number }): Promise<void>;
  /** Crop undo/redo (WASM-offline only — rect-replay from the preserved original).
   *  In server mode these report no history and the controls stay hidden. */
  getCropHistory(screenshotId: number): Promise<CropHistoryState>;
  undoManualCrop(screenshotId: number): Promise<void>;
  redoManualCrop(screenshotId: number): Promise<void>;
  getPHIRegions(screenshotId: number): Promise<PHIRegionsResponse>;
  savePHIRegions(screenshotId: number, body: { regions: PHIRegionRect[]; preset: string }): Promise<void>;
  applyRedaction(screenshotId: number, body: { regions: PHIRegionRect[]; redaction_method: string }): Promise<void>;
  getDetails(screenshotId: number): Promise<PreprocessingDetailsResponse | null>;
  getStageImageUrl(screenshotId: number, stage: string): Promise<string>;
  /** Get the current image URL for a screenshot (latest processed version). */
  getImageUrl(screenshotId: number): Promise<string>;
  /** Force-stop any in-progress processing (terminates workers). No-op in server mode. */
  forceStop?(): void;
  /** Reset any stages stuck in "running" status after a tab crash (WASM mode only). */
  reconcileStuckStages?(): Promise<number>;
  /** Estimate storage usage (WASM mode only). */
  getStorageEstimate?(): Promise<StorageEstimate | null>;
  /** Optional local-mode stage telemetry for throughput and backpressure diagnostics. */
  getStageSchedulerSnapshot?(): PreprocessingStageSchedulerSnapshot;
}

/**
 * The WASM/local-mode preprocessing surface.
 *
 * The base `IPreprocessingService` marks `forceStop`, `reconcileStuckStages`
 * and `getStorageEstimate` optional because the server implementation does
 * not provide them. Local-mode callers that need these (crash recovery,
 * quota UI, worker teardown) should accept this narrower type so the methods
 * are guaranteed rather than guarded with `if (service.x)` at every site.
 *
 * This is an additive sub-interface: the WASM implementation already
 * satisfies it. It does not change the base contract.
 */
export interface ILocalPreprocessingService extends IPreprocessingService {
  /** Always present in local mode — terminates the in-progress workers. */
  forceStop(): void;
  /** Always present in local mode — resets stages stuck "running". */
  reconcileStuckStages(): Promise<number>;
  /** Always present in local mode — current storage usage estimate. */
  getStorageEstimate(): Promise<StorageEstimate | null>;
  /** Always present in local mode — preprocessing-stage timing and queue counters. */
  getStageSchedulerSnapshot(): PreprocessingStageSchedulerSnapshot;
}
