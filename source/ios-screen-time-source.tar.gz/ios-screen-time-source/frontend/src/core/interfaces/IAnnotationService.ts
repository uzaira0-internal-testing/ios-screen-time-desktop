import type { Annotation, AnnotationCreate } from '@/types';

/**
 * Annotation service contract.
 *
 * NOTE on capability divergence (ARC-17): the server implementation does not
 * support `update` (it throws) and `getByScreenshot` returns `[]` — the
 * server treats annotations as append-only and exposes per-screenshot reads
 * only through the consensus endpoint. Callers that genuinely need editing or
 * per-screenshot reads should accept {@link ILocalAnnotationService}, which
 * the WASM implementation satisfies and which documents those methods as
 * fully functional.
 */
export interface IAnnotationService {
  create(data: AnnotationCreate): Promise<Annotation>;

  /** Server mode: throws (annotations are append-only). Local mode: edits in place. */
  update(id: number, data: Partial<AnnotationCreate>): Promise<Annotation>;

  /** Server mode: returns `[]` (use the consensus endpoint). Local mode: real query. */
  getByScreenshot(screenshotId: number): Promise<Annotation[]>;

  getHistory(skip?: number, limit?: number): Promise<Annotation[]>;

  delete(id: number): Promise<void>;
}

/**
 * The WASM/local-mode annotation surface.
 *
 * Identical shape to `IAnnotationService`, but `update` and `getByScreenshot`
 * are contractually functional here (they are not in server mode). Additive —
 * the WASM implementation already satisfies it; the base contract is unchanged.
 */
export type ILocalAnnotationService = IAnnotationService;
