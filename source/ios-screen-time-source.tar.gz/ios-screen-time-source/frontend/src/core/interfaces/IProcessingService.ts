import type { HourlyData, GridCoordinates, ImageType } from '@/types';

export interface ProcessingConfig {
  imageType: ImageType;
  gridCoordinates?: GridCoordinates;
  /** Optional grid method for one-worker decode → grid → OCR processing. */
  gridDetectionMethod?: "ocr_anchored" | "line_based";
  /** Max pixels to shift grid for optimization (0 = disabled) */
  maxShift?: number;
  /** Optional cancellation signal for queued local/WASM processing work. */
  abortSignal?: AbortSignal;
}

/**
 * Processing progress with specific stage types for the processing pipeline.
 * This extends the general ProcessingProgress with more specific stage values.
 */
export interface ProcessingProgress {
  stage:
    | 'loading'
    | 'preprocessing'
    | 'ocr_title'
    | 'ocr_total'
    | 'ocr_hourly'
    | 'complete'
    | (string & {});
  progress: number;
  message?: string;
}

export type ProcessingProgressCallback = (progress: ProcessingProgress) => void;

export interface ProcessingSchedulerMessageStats {
  accepted: number;
  dispatched: number;
  currentInFlight: number;
  maxInFlight: number;
  completed: number;
  failed: number;
  timedOut: number;
  cancelled: number;
  terminated: number;
  totalQueueWaitMs: number;
  maxQueueWaitMs: number;
  averageQueueWaitMs: number;
  totalWorkerRunMs: number;
  maxWorkerRunMs: number;
  averageWorkerRunMs: number;
}

export interface ProcessingSchedulerSnapshot {
  poolSize: number;
  readyWorkers: number;
  busyWorkers: number;
  queuedRequests: number;
  pendingRequests: number;
  maxQueueDepth: number;
  /** OCR worker memory cost used for pool sizing, after applying the
   * conservative floor to the worker-reported WASM heap measurement. */
  measuredOcrWorkerCostMb: number | null;
  messages: Record<string, ProcessingSchedulerMessageStats>;
}

/** Grid detection result with the failure diagnostics the coordinate-only
 * {@link IProcessingService.detectGrid} discards. Lets callers surface an
 * actionable rejection (weekly view, landscape, unsupported resolution) instead
 * of a generic "grid detection failed" message. */
export interface GridDetectionDetail {
  gridCoordinates: GridCoordinates | null;
  /** Detector failure reason, when detection did not succeed. */
  error?: string;
  /** True when positively identified as the WEEKLY (7-column) view. */
  isWeekly?: boolean;
}

export interface IProcessingService {
  processImage(
    imageData: ImageData | Blob,
    config: ProcessingConfig,
    onProgress?: ProcessingProgressCallback
  ): Promise<{
    hourlyData: HourlyData;
    title: string | null;
    total: string | null;
    gridCoordinates?: GridCoordinates;
    gridDetectionFailed?: boolean;
    gridDetectionError?: string;
    alignmentScore?: number | null;
    gridRegistrationScore?: number | null;
    /** Reading direction of the hour axis, `"rtl"` when iOS mirrored the chart
     *  (Hebrew, Arabic). `hourlyData` is already in clock order; the flag is
     *  stored so a later manual grid adjustment can re-apply the orientation. */
    axisDirection?: "ltr" | "rtl";
    suspectedAllDevices?: boolean;
    axisMaxMinutes?: number | null;
    allDevicesReasons?: string[];
    /** The OCR engine failed even if grid/bar extraction produced partial data. */
    ocrFailed?: boolean;
    /** Human-readable OCR engine failure retained for audit and review. */
    ocrError?: string | null;
  }>;

  /**
   * Local/WASM optimized path: one worker decodes the image once, detects grid,
   * then OCRs/extracts bars using that grid. Implementations without this
   * capability can omit it and callers fall back to detectGrid + processImage.
   */
  processImageWithGridDetection?(
    imageData: ImageData | Blob,
    config: ProcessingConfig & { gridDetectionMethod: "ocr_anchored" | "line_based" },
    onProgress?: ProcessingProgressCallback
  ): Promise<{
    hourlyData: HourlyData;
    title: string | null;
    total: string | null;
    gridCoordinates?: GridCoordinates;
    gridDetectionFailed?: boolean;
    gridDetectionError?: string;
    alignmentScore?: number | null;
    gridRegistrationScore?: number | null;
    /** Reading direction of the hour axis, `"rtl"` when iOS mirrored the chart
     *  (Hebrew, Arabic). `hourlyData` is already in clock order; the flag is
     *  stored so a later manual grid adjustment can re-apply the orientation. */
    axisDirection?: "ltr" | "rtl";
    suspectedAllDevices?: boolean;
    axisMaxMinutes?: number | null;
    allDevicesReasons?: string[];
    ocrFailed?: boolean;
    ocrError?: string | null;
  }>;

  extractTitle(imageData: ImageData | Blob): Promise<string | null>;

  extractTotal(imageData: ImageData | Blob): Promise<string | null>;

  extractHourlyData(
    imageData: ImageData | Blob,
    gridCoordinates: GridCoordinates,
    imageType: ImageType
  ): Promise<HourlyData>;

  /**
   * Optional local/WASM fast path for manual grid adjustment: recompute hourly
   * bars and framing scores from a known grid without re-running title/total OCR.
   */
  extractBarsOnly?(
    imageData: ImageData | Blob,
    gridCoordinates: GridCoordinates,
    imageType: ImageType,
    options?: {
      totalText?: string | null;
      axisDirection?: "ltr" | "rtl";
      /** Top-gridline value in minutes for an hour-scaled ("All Devices") chart,
       *  carried from the original pass. No OCR runs here, so without it such a
       *  chart's bars come back at half their measured value. */
      axisMaxMinutes?: number | null;
    }
  ): Promise<{
    hourlyData: HourlyData;
    gridCoordinates?: GridCoordinates;
    alignmentScore?: number | null;
    gridRegistrationScore?: number | null;
  }>;

  detectGrid(imageData: ImageData | Blob, imageType: ImageType, method?: "ocr_anchored" | "line_based"): Promise<GridCoordinates | null>;

  /** Like {@link detectGrid} but also returns the failure reason / weekly flag so
   * callers can show an actionable rejection. Optional: only local (WASM) mode
   * carries the Rust detector diagnostics; implementations without it fall back to
   * the coordinate-only `detectGrid`. */
  detectGridDetailed?(imageData: ImageData | Blob, imageType: ImageType, method?: "ocr_anchored" | "line_based"): Promise<GridDetectionDetail>;

  /**
   * Fill ratio (0..1) of each of the 24 hourly columns inside `gridCoordinates`,
   * measured off the pixels by the Rust pipeline so every browser engine reads
   * the same bar heights. Entries are null where the graph cannot be measured.
   */
  measureColumnFills(imageData: ImageData | Blob, gridCoordinates: GridCoordinates): Promise<(number | null)[]>;

  initialize(targetPoolSize?: number): Promise<void>;

  isInitialized(): boolean;

  /** Terminate the processing worker. It will be lazily recreated on next use. */
  terminate(): void;

  /** Number of parallel processing workers in the pool. Callers that
   *  drive a batch of OCR work use this to size their concurrency to
   *  exactly the pool depth — going wider just queues messages on a
   *  busy worker, going narrower wastes idle workers. Returns 1 for
   *  implementations without a pool. */
  getPoolSize?(): number;

  /** Optional local-mode scheduler telemetry. Used by benchmark and diagnostics
   *  code to verify that resource-budgeted queues are doing real backpressure
   *  instead of hiding work inside worker mailboxes. */
  getSchedulerSnapshot?(): ProcessingSchedulerSnapshot;
}

/**
 * The WASM/local-mode processing surface.
 *
 * `IProcessingService` keeps `getPoolSize` optional because server mode has
 * no worker pool. Local-mode callers that genuinely depend on pool sizing
 * should accept this narrower type instead of optional-chaining on the base
 * interface — `getPoolSize` is guaranteed here.
 *
 * This is an additive sub-interface: WASM implementations already satisfy it.
 * It does not change the base `IProcessingService` contract.
 */
export interface ILocalProcessingService extends IProcessingService {
  /** Always present in local mode — the worker-pool depth. */
  getPoolSize(): number;

  /** Always present in local mode — queue and worker timing counters. */
  getSchedulerSnapshot(): ProcessingSchedulerSnapshot;
}
