import type {
  Screenshot,
  Annotation,
  ScreenshotListResponse,
  NavigationResponse,
} from "@/types";

export interface PaginationParams {
  group_id?: string;
  processing_status?: string;
  verified_by_me?: boolean;
  verified_by_others?: boolean;
  /** "Needs attention" filter — bar/OCR total mismatch or missing title. */
  totals_mismatch?: boolean;
  search?: string;
  sort_by?: string;
  sort_order?: "asc" | "desc";
  page?: number;
  page_size?: number;
}

export interface NavigationQueryParams {
  group_id?: string;
  processing_status?: string;
  verified_by_me?: boolean;
  verified_by_others?: boolean;
  /** "Needs attention" filter — bar/OCR total mismatch or missing title. */
  totals_mismatch?: boolean;
  /** Free-text search (id / participant_id / title) — same matcher as the list. */
  search?: string;
  direction?: "prev" | "next" | "current";
}

/** Storage-level statistics. */
export interface StorageStats {
  screenshotCount: number;
  annotationCount: number;
  blobCount: number;
  totalSize: number;
}

/** Per-status counts used by queue statistics. */
export interface StatusCounts {
  annotation: Record<string, number>;
  processing: Record<string, number>;
  totalScreenshots: number;
  totalAnnotations: number;
}

/** A single group aggregation row, computed in one full-table pass. */
export interface GroupAggregateRow {
  id: string;
  count: number;
  image_type: string;
  created_at: string;
  processing_pending: number;
  processing_completed: number;
  processing_failed: number;
  processing_skipped: number;
  processing_deleted: number;
  /** Count of "needs attention" screenshots (totals mismatch or missing title). */
  totals_mismatch: number;
}

export interface IStorageService {
  saveScreenshot(screenshot: Screenshot): Promise<number>;

  getScreenshot(id: number): Promise<Screenshot | null>;

  getAllScreenshots(filter?: {
    annotation_status?: string;
    group_id?: string;
    processing_status?: string;
  }): Promise<Screenshot[]>;

  updateScreenshot(id: number, data: Partial<Screenshot>): Promise<void>;

  deleteScreenshot(id: number): Promise<void>;

  saveAnnotation(annotation: Annotation): Promise<number>;

  getAnnotation(id: number): Promise<Annotation | null>;

  getAnnotationsByScreenshot(screenshotId: number): Promise<Annotation[]>;

  /** Bulk-fetch annotations for a set of screenshot IDs in one query. */
  getAnnotationsByScreenshotIds(screenshotIds: number[]): Promise<Annotation[]>;

  /** Fetch every annotation in the store. */
  getAllAnnotations(): Promise<Annotation[]>;

  updateAnnotation(id: number, data: Partial<Annotation>): Promise<Annotation>;

  /** Annotation history, newest first, paginated. */
  getAnnotationHistory(skip: number, limit: number): Promise<Annotation[]>;

  deleteAnnotation(id: number): Promise<void>;

  saveImageBlob(screenshotId: number, blob: Blob): Promise<void>;

  getImageBlob(screenshotId: number): Promise<Blob | null>;

  /** Save a blob for a specific pipeline stage (e.g., "original", "cropping"). */
  saveStageBlob(screenshotId: number, stage: string, blob: Blob): Promise<void>;

  /** Retrieve a blob for a specific pipeline stage. */
  getStageBlob(screenshotId: number, stage: string): Promise<Blob | null>;

  /**
   * Delete the pre-redaction stage snapshots once a screenshot is redacted —
   * the only way the un-redacted PHI imagery is actually destroyed.
   */
  deletePreRedactionBlobs(screenshotId: number): Promise<void>;

  deleteScreenshotsByGroup(groupId: string): Promise<{ screenshots_deleted: number; annotations_deleted: number }>;

  clearAll(): Promise<void>;

  /** Storage-level statistics (counts + total blob size). */
  getStats(): Promise<StorageStats>;

  /** Per-status counts for queue statistics, computed via indexed counts. */
  getStatusCounts(): Promise<StatusCounts>;

  /** First pending, unfailed, unblocked screenshot — or null. */
  getNextPendingScreenshot(): Promise<Screenshot | null>;

  /** Bulk import screenshots. Returns assigned IDs. */
  bulkSaveScreenshots(screenshots: Screenshot[]): Promise<number[]>;

  /** Bulk import annotations (upsert per screenshot). Returns IDs. */
  bulkSaveAnnotations(annotations: Annotation[]): Promise<number[]>;

  /** Look up a screenshot by its content hash (dedup). */
  findScreenshotByContentHash(hash: string): Promise<Screenshot | null>;

  /**
   * Find an existing screenshot in `groupId` whose perceptual hash is within
   * `maxDistance` (Hamming) of `perceptualHash` — used for near-duplicate
   * WARNINGS (the exact-byte content hash already handles identical files).
   * Returns the closest match, or null. WASM-only; server mode no-ops.
   */
  findNearDuplicate(
    perceptualHash: string,
    groupId: string | null,
    maxDistance: number,
  ): Promise<{ id: number; distance: number } | null>;

  /** Stream every screenshot through a callback without materializing the table. */
  streamScreenshots(callback: (screenshot: Screenshot) => void | Promise<void>): Promise<void>;

  /** Aggregate screenshots into per-group rows in a single full-table pass. */
  getGroupAggregation(): Promise<GroupAggregateRow[]>;

  /**
   * Efficient paginated query that only loads the requested page.
   * Uses IndexedDB indexes for filtering and sorting.
   */
  getScreenshotsPaginated(
    params: PaginationParams,
  ): Promise<ScreenshotListResponse>;

  /**
   * Efficient navigation that finds next/prev screenshot without loading all.
   * Uses cursor-based navigation on indexed fields.
   */
  navigateScreenshots(
    currentId: number,
    params: NavigationQueryParams,
  ): Promise<NavigationResponse>;

  /** Estimate storage usage via navigator.storage.estimate(). Returns null if unsupported. */
  getStorageEstimate(): Promise<StorageEstimate | null>;
}

export interface StorageEstimate {
  usage: number;
  quota: number;
  percentUsed: number;
}
