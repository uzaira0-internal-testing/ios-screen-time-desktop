interface ImportMetaEnv {
  readonly MODE: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

// Non-standard HTML attributes for folder selection. The augmentation must
// echo React's generic signature for the declaration merge to apply; we
// reference T in an optional phantom property so the no-unused-vars rule
// is satisfied without changing the public shape of the interface.
declare namespace React {
  interface InputHTMLAttributes<T> {
    webkitdirectory?: string;
    directory?: string;
    /** @internal Phantom slot to keep generic parameter T referenced. */
    readonly __folderAugmentTarget?: T;
  }
}
