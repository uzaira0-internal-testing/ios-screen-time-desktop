(() => {
  const closeSelect = (select) => {
    const button = select.querySelector(".eq-select-button");
    const list = select.querySelector(".eq-select-list");
    if (!button || !list) return;
    button.setAttribute("aria-expanded", "false");
    list.hidden = true;
  };

  document.addEventListener("click", (event) => {
    document.querySelectorAll(".eq-select").forEach((select) => {
      if (!select.contains(event.target)) closeSelect(select);
    });
  });

  document.querySelectorAll(".eq-select").forEach((select) => {
    const button = select.querySelector(".eq-select-button");
    const list = select.querySelector(".eq-select-list");
    if (!button || !list) return;

    button.addEventListener("click", () => {
      const willOpen = button.getAttribute("aria-expanded") !== "true";
      document.querySelectorAll(".eq-select").forEach(closeSelect);
      button.setAttribute("aria-expanded", String(willOpen));
      list.hidden = !willOpen;
    });

    list.addEventListener("click", (event) => {
      const option = event.target.closest(".eq-select-option");
      if (!option) return;
      button.querySelector("[data-eq-select-value]").textContent = option.textContent.trim();
      list.querySelectorAll(".eq-select-option").forEach((item) => item.setAttribute("aria-selected", "false"));
      option.setAttribute("aria-selected", "true");
      closeSelect(select);
      button.focus();
    });

    button.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        closeSelect(select);
      }
    });
  });

  document.querySelectorAll("[data-eq-theme-toggle]").forEach((button) => {
    button.addEventListener("click", () => {
      const root = document.documentElement;
      const next = root.getAttribute("data-eq-theme") === "dark" ? "light" : "dark";
      root.setAttribute("data-eq-theme", next);
      button.setAttribute("aria-pressed", String(next === "dark"));
      button.textContent = next === "dark" ? "Use light theme" : "Use dark theme";
    });
  });
})();
