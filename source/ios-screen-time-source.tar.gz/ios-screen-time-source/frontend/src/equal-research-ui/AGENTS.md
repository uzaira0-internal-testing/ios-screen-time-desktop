# Agent Instructions

Read `DESIGN.md` before changing UI. Use `tokens.css`, `elements.css`, and the snippets in `elements.html` as the implementation reference.

Rules:

- Preserve keyboard access, visible focus, accessible names, contrast, reduced motion, dark mode, forced colors, and zoom behavior.
- Use .eq- classes directly or translate them into the host project component system without changing behavior.
- If the target repo has no design system, install Equal as a generated package boundary and make LinkML the component, token, state, requirement, and proof inventory before building screens.
- If the target repo already has a design system, map existing tokens/components/states into LinkML first, then generate bridge CSS, wrappers, or examples from that mapping instead of overwriting local UI.
- Do not repeatedly copy-paste snippets into application code. Change the SSOT, regenerate package/drop-in assets, run validation, and consume the generated assets through imports or thin adapters.
- Use generated packages for framework support: @eqds/react for React wrappers, @eqds/icons for Lucide React icons, @eqds/radix for Radix behavior wrappers, @eqds/tailwind for Tailwind token utilities, and @eqds/shadcn for shadcn registry installation.
- For Headless UI, React Aria, MUI, Chakra, Mantine, or another existing library, map its tokens/components/states into LinkML and generate bridge guidance before changing production screens.
- Keep dropdowns custom and themed when consistency across dark/light/high-contrast modes matters.
- Do not use color or ornament as the only state carrier.
- Keep notebook flair, rails, stamps, rulers, and ledgers decorative unless paired with text or ARIA.
- Do not add marketing claims, certification claims, or institutional endorsement.
- When adapting to a project, replace sample research content with real domain content and keep the same accessibility contracts.

Adoption workflow:

- New project with no design system: Install the drop-in kit, keep `DESIGN.md` with the target repo, create or copy the LinkML catalog/SSOT folder, and treat generated CSS, snippets, wrappers, and page examples as build artifacts.
- Project with an existing design system: Inventory existing tokens, components, variants, states, accessibility requirements, and proof artifacts into LinkML records before changing UI. Generate adapters that map Equal roles onto existing local components.
- Ongoing use: Do not repeatedly copy-paste snippets or make repeated manual copies the maintenance path. Update the SSOT, regenerate outputs, run SSOT/package/design checks, and then consume generated assets by import, package dependency, or thin wrapper.
- Framework and library adapters: Use @eqds/react, @eqds/icons, @eqds/radix, @eqds/tailwind, and @eqds/shadcn where they match the host stack. For Headless UI, React Aria, MUI, Chakra, or Mantine, inventory the host library in LinkML first and generate bridge assets instead of replacing the project design system.
