# Equal Research UI Drop-in Kit

Portable version of the Equal accessibility design system for open-source research web apps.

## Files

- `DESIGN.md` - Google DESIGN.md-style agent-readable design specification.
- `tokens.css` - Portable CSS custom properties for light, dark, contrast, status, type, spacing, and shape.
- `elements.css` - Prefixed .eq- element classes.
- `elements.js` - Minimal progressive enhancement for custom dropdowns and theme toggles.
- `elements.html` - Copyable snippets.
- `example.html` - Standalone smoke-test page.
- `AGENTS.md` - Instructions for coding agents applying this kit in another repo.
- `PROMPT.md` - Copyable agent prompt for applying Equal to an existing repository without overwriting its design system.

## Install

Copy this folder into the target project, usually as `design/equal-research-ui/` or `public/equal-research-ui/`, then include:

```html
<link rel="stylesheet" href="/equal-research-ui/tokens.css">
<link rel="stylesheet" href="/equal-research-ui/elements.css">
<script defer src="/equal-research-ui/elements.js"></script>
```

For agentic coding, put `DESIGN.md` where the agent can read it, preferably at the project root or next to the UI package being changed.

## Use In A Target Repository

### New project with no design system

Install the drop-in kit, keep `DESIGN.md` with the target repo, create or copy the LinkML catalog/SSOT folder, and treat generated CSS, snippets, wrappers, and page examples as build artifacts.

### Project with an existing design system

Inventory existing tokens, components, variants, states, accessibility requirements, and proof artifacts into LinkML records before changing UI. Generate adapters that map Equal roles onto existing local components.

### Ongoing use

Do not repeatedly copy-paste snippets or make repeated manual copies the maintenance path. Update the SSOT, regenerate outputs, run SSOT/package/design checks, and then consume generated assets by import, package dependency, or thin wrapper.

### Framework and library adapters

Use @eqds/react, @eqds/icons, @eqds/radix, @eqds/tailwind, and @eqds/shadcn where they match the host stack. For Headless UI, React Aria, MUI, Chakra, or Mantine, inventory the host library in LinkML first and generate bridge assets instead of replacing the project design system.

## Validate

```sh
npx @google/design.md lint DESIGN.md
```

The source design catalog remains `ontology/catalog.yaml`, with generated-surface metadata in `ontology/ssot/`; regenerate this folder from the repository renderer after ontology changes.
