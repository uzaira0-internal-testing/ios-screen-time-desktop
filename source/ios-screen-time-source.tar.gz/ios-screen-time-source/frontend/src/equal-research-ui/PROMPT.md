# Equal Existing-Repo Adoption Prompt

Use this prompt when asking an agent to apply Equal to an existing repository.

```text
Read AGENTS.md, then design/equal-research-ui/DESIGN.md. Do not overwrite the existing design system.

First inventory existing tokens, components, variants, states, keyboard behavior, ARIA semantics, and proof artifacts. Map them to Equal LinkML/SSOT roles.

Use Equal generated assets through imports, CSS variables, thin wrappers, or adapters. Do not repeatedly copy-paste snippets.

If a needed component/token/state is missing, update the LinkML/SSOT source, regenerate assets, run validation, then integrate the generated output.

Preserve dark/light/high-contrast/forced-colors/reduced-motion/zoom behavior and do not use native select/datalist where themed dropdown parity is required.
```
