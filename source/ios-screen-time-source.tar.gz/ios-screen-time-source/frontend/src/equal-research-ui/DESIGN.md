---
version: alpha
name: Equal Research UI
description: Drop-in accessible design system for open-source research web applications.
colors:
  primary: '#0C6B57'
  on-primary: '#FFFFFF'
  secondary: '#1F3FB8'
  on-secondary: '#FFFFFF'
  background: '#F7F8F8'
  surface: '#FFFFFF'
  surface-muted: '#EEF5F2'
  text: '#111A17'
  muted: '#52645D'
  border: '#C9D6D0'
  focus: '#FFB400'
  success: '#0D6F3F'
  success-surface: '#DDF5E8'
  warning: '#7A5200'
  warning-surface: '#FFF2CC'
  danger: '#B5152B'
  danger-surface: '#FFE3E7'
  info: '#0B5390'
  info-surface: '#E2F0FF'
  dark-background: '#101513'
  dark-surface: '#17211D'
  dark-text: '#EDF5F1'
typography:
  display:
    fontFamily: Atkinson Hyperlegible
    fontSize: 3rem
    fontWeight: '800'
    lineHeight: '1.05'
    letterSpacing: 0px
  heading:
    fontFamily: Atkinson Hyperlegible
    fontSize: 1.75rem
    fontWeight: '800'
    lineHeight: '1.16'
    letterSpacing: 0px
  body:
    fontFamily: Atkinson Hyperlegible
    fontSize: 1rem
    fontWeight: '500'
    lineHeight: '1.55'
    letterSpacing: 0px
  label:
    fontFamily: Atkinson Hyperlegible
    fontSize: 0.875rem
    fontWeight: '800'
    lineHeight: '1.25'
    letterSpacing: 0px
  code:
    fontFamily: IBM Plex Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: '1.45'
    letterSpacing: 0px
rounded:
  sm: 4px
  md: 8px
  lg: 12px
spacing:
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
components:
  button-primary:
    backgroundColor: '{colors.primary}'
    textColor: '{colors.on-primary}'
    typography: '{typography.label}'
    rounded: '{rounded.md}'
    padding: 12px
    height: 44px
  button-secondary:
    backgroundColor: '{colors.surface}'
    textColor: '{colors.primary}'
    typography: '{typography.label}'
    rounded: '{rounded.md}'
    padding: 12px
    height: 44px
  card:
    backgroundColor: '{colors.surface}'
    textColor: '{colors.text}'
    typography: '{typography.body}'
    rounded: '{rounded.md}'
    padding: 24px
  alert-warning:
    backgroundColor: '{colors.warning-surface}'
    textColor: '{colors.warning}'
    typography: '{typography.body}'
    rounded: '{rounded.md}'
    padding: 16px
  button-secondary-action:
    backgroundColor: '{colors.secondary}'
    textColor: '{colors.on-secondary}'
    typography: '{typography.label}'
    rounded: '{rounded.md}'
    padding: 12px
    height: 44px
  page:
    backgroundColor: '{colors.background}'
    textColor: '{colors.text}'
    typography: '{typography.body}'
  muted-panel:
    backgroundColor: '{colors.surface-muted}'
    textColor: '{colors.muted}'
    typography: '{typography.body}'
    rounded: '{rounded.md}'
    padding: 16px
  border-swatch:
    backgroundColor: '{colors.border}'
  focus-swatch:
    backgroundColor: '{colors.focus}'
  status-success:
    backgroundColor: '{colors.success-surface}'
    textColor: '{colors.success}'
    typography: '{typography.label}'
    rounded: '{rounded.sm}'
    padding: 8px
  status-danger:
    backgroundColor: '{colors.danger-surface}'
    textColor: '{colors.danger}'
    typography: '{typography.label}'
    rounded: '{rounded.sm}'
    padding: 8px
  status-info:
    backgroundColor: '{colors.info-surface}'
    textColor: '{colors.info}'
    typography: '{typography.label}'
    rounded: '{rounded.sm}'
    padding: 8px
  dark-page:
    backgroundColor: '{colors.dark-background}'
    textColor: '{colors.dark-text}'
    typography: '{typography.body}'
  dark-card:
    backgroundColor: '{colors.dark-surface}'
    textColor: '{colors.dark-text}'
    typography: '{typography.body}'
    rounded: '{rounded.md}'
    padding: 24px
---

## Overview

Equal Research UI is a portable design system for open-source research software. It is not a product brand. It is a care signal: dense, legible, evidence-oriented interfaces with visible review states, proof trails, and restrained research-document ornament.

Use it when a repository needs production UI primitives, page patterns, and agent-readable instructions that keep accessibility, color-blind safety, contrast, keyboard support, and research provenance visible.

The generated catalog currently contains 57 LinkML-backed element records. This drop-in folder is the portable subset that can be copied into another project.

## Colors

The palette uses neutral surfaces, deep readable text, and status colors that never carry meaning alone. Primary green marks committed actions and proof-bearing states. Secondary blue is reserved for navigation, information, and review context. Warning, danger, success, and info colors require text labels, icons, or shape changes.

Dark mode is a first-class mode, not an inverted afterthought. High contrast and forced color modes must keep borders, focus rings, and labels visible.

## Typography

Use Atkinson Hyperlegible or the closest installed readable sans-serif. Text defaults to `1rem` or larger. Labels are bold because research apps are often scanned repeatedly under load. Letter spacing remains `0`; do not use condensed or negative tracking.

Small text may be used for metadata only when it remains readable at browser zoom and in large text modes. Code and identifiers use a monospace face only when they are values users need to inspect.

## Layout

Prefer dense but calm work surfaces: side navigation, clear section anchors, tables for comparable records, forms grouped by task, and summary metrics near the decision point. Avoid landing-page composition, oversized hero marketing, decorative page wrappers, and cards inside cards.

Page structure should preserve skip links, semantic headings, labeled controls, and stable regions that agents and users can understand. Route sections must contain real use-case content, not generic filler.

## Elevation & Depth

Use shallow depth. Cards and panels may have a subtle shadow only to separate repeated items from the page. Do not stack shadows. Dialogs and popovers must remain above surrounding content and must not be clipped by parent overflow.

## Shapes

Use small radii. Default radius is 8px; 12px is reserved for larger panels. Avoid pill-shaped controls except switches, badges, and segmented status tapes. Focus rings are strong and external.

## Components

Core elements are generated from the LinkML catalog and represented by prefixed CSS classes in this folder. Keep the source ontology as the source of truth and regenerate the gallery/drop-in outputs after changing component scope.

- **Accordion:** `disclosure`; status `candidate`.
- **Alert:** `feedback`; status `candidate`.
- **Anchor Nav:** `navigation`; status `candidate`.
- **Avatar:** `data_display`; status `candidate`.
- **Badge:** `feedback`; status `candidate`.
- **Breadcrumb:** `navigation`; status `candidate`.
- **Button:** `action`; status `candidate`.
- **Button Group:** `action`; status `candidate`.
- **Card:** `data_display`; status `candidate`.
- **Character Count:** `feedback`; status `candidate`.
- **Checkbox:** `selection`; status `candidate`.
- **Code Block:** `code`; status `candidate`.
- **Combobox:** `selection`; status `placeholder`.
- **Command Palette:** `overlay`; status `candidate`.
- **Copy Button:** `action`; status `candidate`.
- **Date Input:** `form`; status `candidate`.
- **Description List:** `data_display`; status `candidate`.
- **Dialog:** `overlay`; status `candidate`.
- **Drawer:** `overlay`; status `candidate`.
- **Empty State:** `feedback`; status `candidate`.
- **Error Summary:** `feedback`; status `candidate`.
- **Evidence Packet:** `data_display`; status `candidate`.
- **Fieldset:** `form`; status `candidate`.
- **File Upload:** `upload`; status `placeholder`.
- **Icon Button:** `action`; status `candidate`.
- **Inline Error:** `feedback`; status `candidate`.
- **Link:** `navigation`; status `candidate`.
- **Log Viewer:** `code`; status `candidate`.
- **Menu:** `overlay`; status `candidate`.
- **Metric:** `data_display`; status `candidate`.
- **Pagination:** `navigation`; status `candidate`.
- **Popover:** `overlay`; status `placeholder`.
- **Progress:** `feedback`; status `candidate`.
- **Provenance Marker:** `data_display`; status `candidate`.
- **Radio:** `selection`; status `candidate`.
- **Search Input:** `form`; status `candidate`.
- **Select:** `selection`; status `candidate`.
- **Sidebar:** `layout`; status `candidate`.
- **Skeleton:** `feedback`; status `candidate`.
- **Skip Link:** `navigation`; status `candidate`.
- **Slider:** `form`; status `placeholder`.
- **Sortable Table:** `data_display`; status `candidate`.
- **Spinner:** `feedback`; status `candidate`.
- **Split Button:** `action`; status `candidate`.
- **Steps:** `navigation`; status `candidate`.
- **Switch:** `selection`; status `candidate`.
- **Table:** `data_display`; status `candidate`.
- **Tabs:** `navigation`; status `candidate`.

## Do's and Don'ts

Do use actual controls, real labels, visible state, and keyboard-reachable interactions.

Do keep notebook flair, rails, stamps, rulers, and ledgers non-semantic unless they are paired with text or ARIA state.

Do not advertise nonexistent compliance, certification, support, funding, or institutional endorsement.

Do not use native select or datalist where themed dropdown color consistency is required; use the included custom dropdown pattern.

Do not encode status only with color, ornament, or position.

## Accessibility

Meet WCAG 2.2 AA as a baseline and test beyond it: keyboard-only navigation, visible focus, screen reader names, high contrast, forced colors, reduced motion, zoom, large text, color vision deficiency simulation, and dark/light parity.

All ornaments are decorative by default. When an ornament implies a process state, provide an adjacent text label, status badge, or table value with the same meaning.

## Agent Usage

For agentic coding, read this file before changing UI. Then use `tokens.css`, `elements.css`, `elements.js`, and the snippets in `elements.html`. Preserve the `.eq-` prefix unless intentionally adapting the system to a project namespace.

If the target project has no design system, install Equal as a new generated package boundary and make LinkML the inventory source of truth before building pages.

If the target project already has a design system, map existing tokens, components, states, and accessibility contracts into the LinkML catalog first. Generate bridge assets from that mapping instead of replacing the existing system by hand.

Do not copy-paste component markup repeatedly or overwrite local UI files directly from examples. Update the LinkML/SSOT records, regenerate assets, run validation, then adapt through package imports or small wrapper components.

For React apps, prefer `@eqds/react` plus `@eqds/css`. Use `@eqds/icons` for actual Lucide React icons, `@eqds/radix` when a project needs Radix-managed overlays or disclosure behavior, `@eqds/tailwind` when utility classes should consume Equal tokens, and `@eqds/shadcn` when the host app uses the shadcn registry workflow. For Headless UI, React Aria, MUI, Chakra, or Mantine, read the generated common-library bridge guidance and map the host design system through LinkML before writing adapters.

Validate this file with `npx @google/design.md lint DESIGN.md` when the Google DESIGN.md CLI is available.
