import { defineConfig, devices } from "@playwright/test";

/**
 * Persona suite for the WASM-offline build.
 *
 * This is the ONLY persona suite. The server-mode suite it replaced
 * (playwright.persona.config.ts) drove a login form, /api/v1 and WebSockets —
 * none of which exist in the build that ships. It was retired rather than
 * repointed, because a spec that asserts "no service worker is registered" is
 * not repairable by changing its base URL; it was asserting the opposite of
 * the deployed app's behaviour.
 *
 * Two targets, one suite (see tests/wasm-persona-base-url.ts):
 *   - default: the real production app served locally by the static SPA server
 *     (no backend, no mocks), root-served — the CI wrappers build it into an
 *     isolated directory so they cannot overwrite a Pages-ready `dist`
 *   - `PERSONA_WASM_BASE_URL=…`: the LIVE GitHub Pages deployment, which is the
 *     artifact users actually load
 */
import {
  IS_REMOTE_TARGET,
  WASM_PERSONA_BASE_URL,
  WASM_PERSONA_PORT,
} from "./tests/wasm-persona-base-url";

const PORT = WASM_PERSONA_PORT;
const LOCAL_DIST_DIR = process.env.PERSONA_WASM_DIST_DIR || "dist";
const shellQuote = (value: string) => `'${value.replaceAll("'", "'\\''")}'`;

/** Specs that drive the OCR pipeline end to end — see the note in `projects`. */
const PIPELINE_HEAVY =
  /persona-wasm-(apportionment|asset-resilience|expert-researcher|input-contract|localized-total|long-running)\.spec\.ts$/;

export default defineConfig({
  testDir: "./tests",
  testMatch: /persona-wasm-.*\.spec\.ts$/,
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [["list"]],
  use: {
    baseURL: WASM_PERSONA_BASE_URL,
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    actionTimeout: 10_000,
    navigationTimeout: 30_000,
  },
  // No local server when the target is remote: building and serving a dist
  // nobody reads would report THAT dist's failures against the live site.
  ...(IS_REMOTE_TARGET
    ? {}
    : {
        webServer: {
          command: `python3 tests/spa-server.py ${PORT} ${shellQuote(LOCAL_DIST_DIR)}`,
          url: `http://127.0.0.1:${PORT}/`,
          reuseExistingServer: !process.env.CI,
          timeout: 30_000,
          stdout: "pipe" as const,
          stderr: "pipe" as const,
        },
      }),
  // chromium is the default gate (`ci.sh wasm-persona` / `wasm-persona-live`,
  // which both pass --project=chromium). firefox and webkit exist for the
  // cross-browser sweep in `ci.sh persona`; webkit needs GLIBC 2.38 and so runs
  // only inside the Playwright docker image — see scripts/ci/persona.sh.
  projects: [
    { name: "chromium", use: { ...devices["Desktop Chrome"] } },
    // firefox runs the ENGINE-facing personas — boot, routing, a11y, offline,
    // storage, service worker, multi-tab, crash recovery. It skips the six
    // specs that drive the OCR pipeline end to end.
    //
    // Two reasons, in order. First, those specs assert on pipeline OUTPUT
    // (`3h 25m`, 205 bar-minutes, apportionment gaps), which comes out of the
    // same Rust/wasm binary whatever engine hosts it; chromium already covers
    // them against the local dist AND the live deployment, and a third and
    // fourth run of the same numbers buys nothing.
    //
    // Second, and the reason this is written down rather than just done:
    // Firefox is markedly slower on /preprocessing once a group has rows in
    // it. Clicks on the stage-wizard tabs do not complete within 30s, and with
    // 40 records loaded even `page.goto("/preprocessing")` times out waiting
    // for `load`. Nothing in this suite causes that — no change here touches
    // that page — and it has simply never been measured, because Firefox has
    // never run these specs before. It is an open question about the app in
    // Firefox, and it deserves profiling on its own rather than being absorbed
    // into an ever-larger timeout here.
    {
      name: "firefox",
      use: { ...devices["Desktop Firefox"], actionTimeout: 30_000 },
      testIgnore: PIPELINE_HEAVY,
    },
    // webkit runs everything: it is the engine inside the macOS and Linux
    // desktop apps, so the end-to-end pipeline specs must pass there too.
    { name: "webkit", use: { ...devices["Desktop Safari"], actionTimeout: 30_000 } },
  ],
  timeout: 60_000,
  expect: { timeout: 5_000 },
  outputDir: "test-results-persona-wasm/",
});
