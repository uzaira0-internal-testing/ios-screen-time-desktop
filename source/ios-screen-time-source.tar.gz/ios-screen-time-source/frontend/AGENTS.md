# Equal Research UI

This repository uses the Equal Research UI drop-in design system.

Before changing UI:

- Read `src/equal-research-ui/DESIGN.md`.
- For one-shot agent setup, use `src/equal-research-ui/PROMPT.md`.
- Use `src/equal-research-ui/tokens.css`, `src/equal-research-ui/elements.css`, and `src/equal-research-ui/elements.js`.
- If this repo has no design system, treat Equal as a generated package boundary and add local component/token/state/proof records to LinkML before building screens.
- If this repo already has a design system, map existing tokens, components, variants, states, and accessibility contracts into LinkML before generating adapters.
- Do not repeatedly copy-paste snippets into app code. Update the SSOT, regenerate assets, validate, and consume generated files through imports or thin wrappers.
- Preserve keyboard access, visible focus, accessible names, dark/light parity, high contrast, forced colors, reduced motion, zoom, and color-vision-deficiency safety.
- Do not use native select or datalist when themed dropdown parity is required.
- Do not use color or ornament as the only state carrier.
- Keep notebook, rail, stamp, ruler, and ledger treatments decorative unless paired with text or ARIA state.
- Do not add marketing, certification, support, funding, or institutional endorsement claims.
