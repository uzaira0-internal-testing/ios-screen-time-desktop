//! Regression coverage for real iOS 26 / iPhone 15 Screen Time screenshots.
//!
//! These fixtures cover the light/dark daily-total and app-total screenshots that
//! exposed OCR total regressions after the performance work. The assertions lock
//! visible title/total OCR plus the reconciled bar total from the native pipeline.

#![cfg(feature = "ocr")]

use std::path::PathBuf;

use ios_screen_time_image_pipeline::{
    process_image,
    types::{DetectionMethod, ImageType},
};

#[derive(Debug, Clone, serde::Deserialize)]
struct Fixture {
    name: String,
    path: String,
    title: Option<String>,
    total_text: String,
    bar_total_minutes: i32,
    daily_total: bool,
    /// Top-gridline value in minutes, present only for an hour-scaled ("All
    /// Devices") chart. Absent means the ordinary 60-minute axis.
    #[serde(default)]
    axis_max_minutes: Option<i32>,
}

#[derive(Debug, serde::Deserialize)]
struct Expectations {
    fixtures: Vec<Fixture>,
}

fn fixtures_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../tests/fixtures/images")
}

fn fixture_path(fixture: &Fixture) -> PathBuf {
    fixtures_dir().join(&fixture.path)
}

/// The expectations are shared with `scripts/ci/run_wasm_ocr_corpus.sh`, which
/// runs the SAME assertions against the compiled WASM in a real browser. Keeping
/// one file means the native and offline paths can never quietly disagree about
/// what a screenshot says — and a value can only change by editing it here,
/// deliberately, rather than by a test being silently wrong (which is how
/// `IMG_7869`/`IMG_7880` both came to claim `5h 14m` for a chart printing
/// `8h 14m`).
fn all_fixtures() -> Vec<Fixture> {
    let path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../../tests/fixtures/ocr_corpus_expectations.json");
    let raw =
        std::fs::read_to_string(&path).unwrap_or_else(|e| panic!("Failed to read {path:?}: {e}"));
    let parsed: Expectations =
        serde_json::from_str(&raw).unwrap_or_else(|e| panic!("Failed to parse {path:?}: {e}"));
    parsed.fixtures
}

#[test]
#[ignore = "prints rollback-baseline values for new iOS 26 fixtures"]
fn print_ios26_fixture_baseline() {
    for fixture in &all_fixtures() {
        let path = fixture_path(fixture);
        let result = process_image(
            path.to_str().expect("fixture path must be valid UTF-8"),
            ImageType::ScreenTime,
            DetectionMethod::LineBased,
        );
        match result {
            Ok(result) => {
                println!(
                    "{}\t{:?}\t{:?}\t{}\t{}",
                    fixture.name,
                    result.title,
                    result.total_text,
                    result.total.round() as i32,
                    result.is_daily_total
                );
            }
            Err(err) => {
                println!("{}\tERROR\t{err}", fixture.name);
            }
        }
    }
}

#[test]
fn ios26_fixture_ocr_and_bar_totals_match_rollback_baseline() {
    let mut failures = Vec::new();

    for fixture in &all_fixtures() {
        let path = fixture_path(fixture);
        let Ok(result) = process_image(
            path.to_str().expect("fixture path must be valid UTF-8"),
            ImageType::ScreenTime,
            DetectionMethod::LineBased,
        ) else {
            failures.push(format!("{} failed pipeline processing", fixture.name));
            continue;
        };

        if let Some(expected_title) = fixture.title.as_deref() {
            if result.title.as_deref() != Some(expected_title) {
                failures.push(format!(
                    "{} title changed: expected {:?}, got {:?}",
                    fixture.name,
                    Some(expected_title),
                    result.title
                ));
            }
        }
        if result.total_text.as_deref() != Some(fixture.total_text.as_str()) {
            failures.push(format!(
                "{} OCR total changed: expected {:?}, got {:?}",
                fixture.name,
                Some(fixture.total_text.as_str()),
                result.total_text
            ));
        }
        let bar_total = result.total.round() as i32;
        if bar_total != fixture.bar_total_minutes {
            failures.push(format!(
                "{} bar total changed: expected {}, got {}",
                fixture.name, fixture.bar_total_minutes, bar_total
            ));
        }
        if result.is_daily_total != fixture.daily_total {
            failures.push(format!(
                "{} daily-total classification changed: expected {}, got {}",
                fixture.name, fixture.daily_total, result.is_daily_total
            ));
        }
        // A chart iOS scaled in hours is 120 minutes tall, not 60. Reading it at
        // 60 does not fail — it halves every bar and reports a plausible wrong
        // number, which is exactly what IMG_7876 did (74 against a printed 151).
        if result.axis_max_minutes != fixture.axis_max_minutes {
            failures.push(format!(
                "{} y-axis ceiling changed: expected {:?}, got {:?}",
                fixture.name, fixture.axis_max_minutes, result.axis_max_minutes
            ));
        }
        let expected_all_devices = fixture.path == "ios26_light/IMG_7876.PNG";
        if result.suspected_all_devices != expected_all_devices {
            failures.push(format!(
                "{} All Devices classification changed: expected {}, got {} ({:?})",
                fixture.name,
                expected_all_devices,
                result.suspected_all_devices,
                result.all_devices_reasons
            ));
        }
    }

    if !failures.is_empty() {
        panic!("\n{}\n", failures.join("\n"));
    }
}

#[test]
fn anomalous_multi_device_fixture_is_retained_and_flagged() {
    let path = fixtures_dir().join("ios26_light/IMG_7877.PNG");
    let result = process_image(
        path.to_str().expect("fixture path must be valid UTF-8"),
        ImageType::ScreenTime,
        DetectionMethod::LineBased,
    )
    .expect("the invalid-for-study screenshot must still remain processable");

    assert!(result.suspected_all_devices);
    assert!(
        result
            .all_devices_reasons
            .iter()
            .any(|reason| reason.contains("All Devices")),
        "expected explicit All Devices evidence, got {:?}",
        result.all_devices_reasons
    );
}
