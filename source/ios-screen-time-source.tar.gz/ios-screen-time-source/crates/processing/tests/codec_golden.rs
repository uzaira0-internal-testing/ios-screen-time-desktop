use std::{collections::BTreeMap, fs, io::Cursor, path::Path, process::Command};

use image::{DynamicImage, ImageDecoder, ImageReader};
use ios_screen_time_image_pipeline::codec::decode_rgba;
use serde::Deserialize;

#[derive(Deserialize)]
struct Golden {
    width: u32,
    height: u32,
    sha256: String,
}

fn sha256(bytes: &[u8]) -> String {
    const K: [u32; 64] = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4,
        0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe,
        0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f,
        0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
        0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
        0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116,
        0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7,
        0xc67178f2,
    ];
    let mut state = [
        0x6a09e667_u32,
        0xbb67ae85,
        0x3c6ef372,
        0xa54ff53a,
        0x510e527f,
        0x9b05688c,
        0x1f83d9ab,
        0x5be0cd19,
    ];
    let mut padded = bytes.to_vec();
    padded.push(0x80);
    while padded.len() % 64 != 56 {
        padded.push(0);
    }
    padded.extend_from_slice(&(bytes.len() as u64 * 8).to_be_bytes());

    for block in padded.chunks_exact(64) {
        let mut w = [0u32; 64];
        for (i, chunk) in block.chunks_exact(4).enumerate() {
            w[i] = u32::from_be_bytes(chunk.try_into().unwrap());
        }
        for i in 16..64 {
            let s0 = w[i - 15].rotate_right(7) ^ w[i - 15].rotate_right(18) ^ (w[i - 15] >> 3);
            let s1 = w[i - 2].rotate_right(17) ^ w[i - 2].rotate_right(19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16]
                .wrapping_add(s0)
                .wrapping_add(w[i - 7])
                .wrapping_add(s1);
        }
        let [mut a, mut b, mut c, mut d, mut e, mut f, mut g, mut h] = state;
        for i in 0..64 {
            let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
            let choose = (e & f) ^ (!e & g);
            let t1 = h
                .wrapping_add(s1)
                .wrapping_add(choose)
                .wrapping_add(K[i])
                .wrapping_add(w[i]);
            let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
            let majority = (a & b) ^ (a & c) ^ (b & c);
            let t2 = s0.wrapping_add(majority);
            h = g;
            g = f;
            f = e;
            e = d.wrapping_add(t1);
            d = c;
            c = b;
            b = a;
            a = t1.wrapping_add(t2);
        }
        for (slot, value) in state.iter_mut().zip([a, b, c, d, e, f, g, h]) {
            *slot = slot.wrapping_add(value);
        }
    }
    state.iter().map(|word| format!("{word:08x}")).collect()
}

fn rgba16_candidates(bytes: &[u8]) -> Vec<(&'static str, Vec<u8>)> {
    let mut decoder = ImageReader::with_format(Cursor::new(bytes), image::ImageFormat::Png)
        .into_decoder()
        .unwrap();
    let orientation = decoder.orientation().unwrap();
    let mut image = DynamicImage::from_decoder(decoder).unwrap();
    image.apply_orientation(orientation);
    let rgba16 = image.to_rgba16();
    let samples = rgba16.as_raw();
    let candidate = |convert: fn(u16) -> u8| samples.iter().copied().map(convert).collect();
    vec![
        ("image::to_rgba8", image.to_rgba8().into_raw()),
        ("v >> 8", candidate(|v| (v >> 8) as u8)),
        (
            "(v + 128) / 257",
            candidate(|v| ((u32::from(v) + 128) / 257) as u8),
        ),
        (
            "round(v * 255 / 65535)",
            candidate(|v| ((u32::from(v) * 255 + 32767) / 65535) as u8),
        ),
    ]
}

fn chromium_rgba(root: &Path, fixture: &Path) -> Result<Vec<u8>, String> {
    let script = r#"
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
const [root, fixture] = process.argv.slice(1);
const { default: pw } = await import(pathToFileURL(join(root, 'frontend/node_modules/@playwright/test/index.js')));
const browser = await pw.chromium.launch({ headless: true });
try {
  const page = await browser.newPage();
  await page.route('http://localhost/**', async route => {
    if (new URL(route.request().url()).pathname === '/') {
      await route.fulfill({ contentType: 'text/html', body: '<!doctype html>' });
    } else {
      await route.fulfill({ contentType: 'image/png', body: await readFile(fixture) });
    }
  });
  await page.goto('http://localhost/');
  const base64 = await page.evaluate(async () => {
    const bitmap = await createImageBitmap(await (await fetch('/img')).blob(), { colorSpaceConversion: 'none' });
    try {
      const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
      const context = canvas.getContext('2d', { willReadFrequently: true });
      context.drawImage(bitmap, 0, 0);
      const data = context.getImageData(0, 0, bitmap.width, bitmap.height).data;
      let binary = '';
      for (let i = 0; i < data.length; i += 32768) binary += String.fromCharCode(...data.subarray(i, i + 32768));
      return btoa(binary);
    } finally { bitmap.close(); }
  });
  process.stdout.write(Buffer.from(base64, 'base64'));
} finally { await browser.close(); }
"#;
    let output = Command::new("node")
        .args(["--input-type=module", "-e", script])
        .arg(root.join("../..").canonicalize().unwrap())
        .arg(fixture)
        .output()
        .map_err(|error| error.to_string())?;
    if output.status.success() {
        Ok(output.stdout)
    } else {
        Err(String::from_utf8_lossy(&output.stderr).into_owned())
    }
}

#[test]
fn sha256_known_vector() {
    assert_eq!(
        sha256(b"abc"),
        "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
    );
}

#[test]
fn chromium_png_decode_matches_rust() {
    let root = Path::new(env!("CARGO_MANIFEST_DIR"));
    let golden_path = root.join("tests/data/decode_golden.json");
    let json = fs::read_to_string(&golden_path).unwrap_or_else(|error| {
        panic!("Chromium decode golden missing at {}: {error}. Run node tests/wasm/capture_decode_golden.mjs", golden_path.display())
    });
    let golden: BTreeMap<String, Golden> = serde_json::from_str(&json).unwrap();
    assert!(!golden.is_empty(), "Chromium decode golden is empty");
    let fixtures = root.join("../../tests/fixtures/images");
    let mut png_count = 0;
    let mut jpeg_mismatches = 0;
    let mut png_mismatches = Vec::new();
    for (name, expected) in golden {
        let extension = Path::new(&name)
            .extension()
            .and_then(|ext| ext.to_str())
            .unwrap_or("");
        if !extension.eq_ignore_ascii_case("png")
            && !extension.eq_ignore_ascii_case("jpg")
            && !extension.eq_ignore_ascii_case("jpeg")
        {
            continue;
        }
        let fixture = fixtures.join(&name);
        let bytes = fs::read(&fixture).unwrap();
        let (width, height, rgba) = match decode_rgba(&bytes) {
            Ok(result) => result,
            Err(error) => {
                png_mismatches.push(format!("{name}: decode failed: {error}"));
                continue;
            }
        };
        let digest = sha256(&rgba);
        if extension.eq_ignore_ascii_case("png") {
            png_count += 1;
            if (width, height) != (expected.width, expected.height) || digest != expected.sha256 {
                let bit_depth = bytes[24];
                let reference = if bit_depth == 16 {
                    rgba16_candidates(&bytes)
                        .into_iter()
                        .find(|(_, candidate)| sha256(candidate) == expected.sha256)
                        .map(|(_, candidate)| candidate)
                } else {
                    None
                };
                let reference = reference
                    .map(Ok)
                    .unwrap_or_else(|| chromium_rgba(root, &fixture));
                let detail = match reference {
                    Ok(reference) if reference.len() == rgba.len() => {
                        let mut differences = 0usize;
                        let mut max_abs = [0u8; 4];
                        for (index, (&actual, &chrome)) in rgba.iter().zip(&reference).enumerate() {
                            if actual != chrome {
                                differences += 1;
                            }
                            max_abs[index % 4] = max_abs[index % 4].max(actual.abs_diff(chrome));
                        }
                        format!("byte differences={differences}, max abs RGBA={max_abs:?}")
                    }
                    Ok(reference) => format!(
                        "Chrome RGBA length={} vs Rust {}",
                        reference.len(),
                        rgba.len()
                    ),
                    Err(error) => format!("Chrome pixels unavailable: {error}"),
                };
                let message = format!(
                    "{name}: bit depth={bit_depth}, {detail}; dimensions={width}x{height} vs {}x{}, SHA-256={digest} vs {}",
                    expected.width, expected.height, expected.sha256
                );
                println!("{message}");
                png_mismatches.push(message);
            }
        } else if digest != expected.sha256 {
            jpeg_mismatches += 1;
        }
    }
    assert!(png_count > 0, "Chromium decode golden has no PNG entries");
    println!(
        "PNG checked: {png_count}, mismatches: {}; JPEG SHA-256 differences: {jpeg_mismatches}",
        png_mismatches.len()
    );
    assert!(
        png_mismatches.is_empty(),
        "PNG decode differs from Chromium"
    );
}

#[test]
#[ignore]
fn diagnose_16_bit_png_conversion() {
    let root = Path::new(env!("CARGO_MANIFEST_DIR"));
    let golden: BTreeMap<String, Golden> =
        serde_json::from_slice(&fs::read(root.join("tests/data/decode_golden.json")).unwrap())
            .unwrap();
    let fixtures = root.join("../../tests/fixtures/images");
    for (name, expected) in golden {
        if !name.to_ascii_lowercase().ends_with(".png") {
            continue;
        }
        let bytes = fs::read(fixtures.join(&name)).unwrap();
        if bytes[24] != 16 {
            continue;
        }
        let results: Vec<String> = rgba16_candidates(&bytes)
            .into_iter()
            .map(|(label, rgba)| format!("{label}={}", sha256(&rgba) == expected.sha256))
            .collect();
        println!("{name}: {}", results.join(", "));
    }
}
