//! AUTO-GENERATED from shared/*.json — do not edit manually.
//! Hash: cbd2968221a3ae3e
//! Regenerate: python scripts/generate-shared-constants.py

use lazy_static::lazy_static;
use std::collections::HashMap;

#[derive(Debug, Clone, Copy)]
pub struct LookupEntry {
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
}

lazy_static! {
    pub static ref RESOLUTION_LOOKUP_TABLE: HashMap<&'static str, LookupEntry> = {
        let mut m = HashMap::new();
        m.insert(
            "640x1136",
            LookupEntry {
                x: 30,
                y: 270,
                width: 510,
                height: 180,
            },
        );
        m.insert(
            "750x1334",
            LookupEntry {
                x: 60,
                y: 670,
                width: 560,
                height: 180,
            },
        );
        m.insert(
            "750x1624",
            LookupEntry {
                x: 60,
                y: 450,
                width: 560,
                height: 180,
            },
        );
        m.insert(
            "828x1792",
            LookupEntry {
                x: 70,
                y: 450,
                width: 620,
                height: 180,
            },
        );
        m.insert(
            "848x2266",
            LookupEntry {
                x: 70,
                y: 390,
                width: 640,
                height: 180,
            },
        );
        m.insert(
            "858x2160",
            LookupEntry {
                x: 70,
                y: 390,
                width: 640,
                height: 180,
            },
        );
        m.insert(
            "896x2048",
            LookupEntry {
                x: 70,
                y: 500,
                width: 670,
                height: 180,
            },
        );
        m.insert(
            "906x2160",
            LookupEntry {
                x: 70,
                y: 390,
                width: 690,
                height: 180,
            },
        );
        m.insert(
            "960x2079",
            LookupEntry {
                x: 80,
                y: 620,
                width: 720,
                height: 270,
            },
        );
        m.insert(
            "980x2160",
            LookupEntry {
                x: 80,
                y: 390,
                width: 730,
                height: 180,
            },
        );
        m.insert(
            "990x2160",
            LookupEntry {
                x: 80,
                y: 390,
                width: 740,
                height: 180,
            },
        );
        m.insert(
            "1000x2360",
            LookupEntry {
                x: 80,
                y: 420,
                width: 790,
                height: 180,
            },
        );
        m.insert(
            "1028x2224",
            LookupEntry {
                x: 80,
                y: 400,
                width: 820,
                height: 180,
            },
        );
        m.insert(
            "1028x2388",
            LookupEntry {
                x: 80,
                y: 400,
                width: 820,
                height: 180,
            },
        );
        m.insert(
            "1028x2420",
            LookupEntry {
                x: 80,
                y: 405,
                width: 820,
                height: 180,
            },
        );
        m.insert(
            "1170x2532",
            LookupEntry {
                x: 90,
                y: 640,
                width: 880,
                height: 270,
            },
        );
        m.insert(
            "1179x2556",
            LookupEntry {
                x: 90,
                y: 1275,
                width: 885,
                height: 270,
            },
        );
        m.insert(
            "1206x2622",
            LookupEntry {
                x: 96,
                y: 1394,
                width: 906,
                height: 270,
            },
        );
        m.insert(
            "1258x2732",
            LookupEntry {
                x: 80,
                y: 450,
                width: 1020,
                height: 180,
            },
        );
        m.insert(
            "1274x2752",
            LookupEntry {
                x: 81,
                y: 453,
                width: 1033,
                height: 180,
            },
        );
        m.insert(
            "1320x2868",
            LookupEntry {
                x: 120,
                y: 1352,
                width: 984,
                height: 270,
            },
        );
        m
    };
}

pub const DAILY_PAGE_MARKERS: &[&str] = &[
    "WEEK",
    "DAY",
    "MOST",
    "USED",
    "CATEGORIES",
    "TODAY",
    "SHOW",
    "ENTERTAINMENT",
    "EDUCATION",
    "INFORMATION",
    "READING",
    "קטגוריות",
    "הנפוץ",
];
pub const APP_PAGE_MARKERS: &[&str] = &[
    "INFO",
    "DEVELOPER",
    "RATING",
    "LIMIT",
    "AGE",
    "DAILY",
    "AVERAGE",
];

pub const NUM_SLICES: usize = 24;
pub const MAX_Y: f64 = 60.0;
pub const LOWER_GRID_BUFFER: usize = 2;
pub const BAR_GAP_TOLERANCE_PX: usize = 2;
pub const DARK_MODE_THRESHOLD: f64 = 100.0;
pub const DARKEN_NON_WHITE_LUMA_THRESHOLD: u32 = 240;
pub const DARKEN_NON_WHITE_LUMA_COEFFS: [u32; 3] = [77, 150, 29];
pub const DARKEN_NON_WHITE_LUMA_SHIFT: u32 = 8;

pub const GRAY_MIN: u8 = 195;
pub const GRAY_MAX: u8 = 210;
pub const MIN_WIDTH_PCT: f64 = 0.35;
pub const MAX_SPACING_DEVIATION: i32 = 10;
pub const V_GRAY_MIN: u8 = 190;
pub const V_GRAY_MAX: u8 = 215;
pub const MIN_HEIGHT_PCT: f64 = 0.4;
pub const GRID_LINE_GRAY_MIN: u8 = 190;
pub const GRID_LINE_GRAY_MAX: u8 = 220;
pub const GRID_REG_DEADBAND: f64 = 0.03;
pub const GRID_REG_TOL: f64 = 0.1;
pub const APPORTION_MAX_MINUTES: i32 = 2;
pub const APPORTION_MAX_PERCENT: f64 = 2.0;
pub const APPORTION_MIN_REGISTRATION: f64 = 0.5;

pub const TITLE_X_ORIGIN_INFO_W_MULT: f64 = 1.5;
pub const TITLE_X_END_INFO_W_MULT: i32 = 12;
pub const TITLE_APP_HEIGHT_INFO_H_MULT: i32 = 7;
pub const MAX_TITLE_LENGTH: usize = 50;
pub const TITLE_FALLBACK_BAND_TOP_FRAC: f64 = 0.02;
pub const TITLE_FALLBACK_BAND_BOTTOM_FRAC: f64 = 0.2;
pub const TITLE_FALLBACK_BAND_LEFT_FRAC: f64 = 0.15;
pub const TITLE_FALLBACK_BAND_RIGHT_FRAC: f64 = 0.85;
pub const TITLE_FALLBACK_ROW_TOL_FRAC: f64 = 0.03;
pub const TITLE_INFO_REOCR_TOP_FRAC: f64 = 0.35;
pub const TITLE_INFO_REOCR_BOTTOM_FRAC: f64 = 0.65;

pub const TOTAL_HEADER_REOCR_TOP_FRAC: f64 = 0.18;
pub const TOTAL_HEADER_REOCR_BOTTOM_FRAC: f64 = 0.38;
pub const TOTAL_MAX_PLAUSIBLE_HOURS: u32 = 24;

pub const BLUE_HUE_MIN: u8 = 100;
pub const BLUE_HUE_MAX: u8 = 130;
pub const CYAN_HUE_MIN: u8 = 80;
pub const CYAN_HUE_MAX: u8 = 100;
pub const COLOR_MIN_SATURATION: u8 = 50;
pub const COLOR_MIN_VALUE: u8 = 50;
pub const MIN_BLUE_RATIO: f64 = 0.5;

/// Optional OCR language packs — single source of truth
/// (shared/language_packs.json). The pipeline works without any of these;
/// they raise TEXT accuracy (app names, total string) for non-English UIs.
pub struct LanguagePack {
    pub code: &'static str,
    pub english_name: &'static str,
    pub native_name: &'static str,
    pub direction: &'static str,
    pub bytes: u64,
    pub unit_hour: &'static [&'static str],
    pub unit_minute: &'static [&'static str],
}
pub const LANGUAGE_PACKS: [LanguagePack; 28] = [
    LanguagePack {
        code: "heb",
        english_name: "Hebrew",
        native_name: "עברית",
        direction: "rtl",
        bytes: 961404,
        unit_hour: &["שע׳", "שעה", "שעות", "שעתיים"],
        unit_minute: &["דק׳", "דקה", "דקות"],
    },
    LanguagePack {
        code: "ara",
        english_name: "Arabic",
        native_name: "العربية",
        direction: "rtl",
        bytes: 1432056,
        unit_hour: &["ساعة", "ساعات", "س"],
        unit_minute: &["دقيقة", "دقائق", "د"],
    },
    LanguagePack {
        code: "deu",
        english_name: "German",
        native_name: "Deutsch",
        direction: "ltr",
        bytes: 1525436,
        unit_hour: &["Std.", "Stunde", "Stunden"],
        unit_minute: &["Min.", "Minute", "Minuten"],
    },
    LanguagePack {
        code: "fra",
        english_name: "French",
        native_name: "Français",
        direction: "ltr",
        bytes: 1130365,
        unit_hour: &["h", "heure", "heures"],
        unit_minute: &["min", "minute", "minutes"],
    },
    LanguagePack {
        code: "spa",
        english_name: "Spanish",
        native_name: "Español",
        direction: "ltr",
        bytes: 2294433,
        unit_hour: &["h", "hora", "horas"],
        unit_minute: &["min", "minuto", "minutos"],
    },
    LanguagePack {
        code: "ita",
        english_name: "Italian",
        native_name: "Italiano",
        direction: "ltr",
        bytes: 2701314,
        unit_hour: &["h", "ora", "ore"],
        unit_minute: &["min", "minuto", "minuti"],
    },
    LanguagePack {
        code: "por",
        english_name: "Portuguese",
        native_name: "Português",
        direction: "ltr",
        bytes: 1982756,
        unit_hour: &["h", "hora", "horas"],
        unit_minute: &["min", "minuto", "minutos"],
    },
    LanguagePack {
        code: "nld",
        english_name: "Dutch",
        native_name: "Nederlands",
        direction: "ltr",
        bytes: 6050296,
        unit_hour: &["u", "uur"],
        unit_minute: &["m", "min", "minuut", "minuten"],
    },
    LanguagePack {
        code: "rus",
        english_name: "Russian",
        native_name: "Русский",
        direction: "ltr",
        bytes: 3861738,
        unit_hour: &["ч", "час", "часа", "часов"],
        unit_minute: &["мин", "минута", "минуты", "минут"],
    },
    LanguagePack {
        code: "ukr",
        english_name: "Ukrainian",
        native_name: "Українська",
        direction: "ltr",
        bytes: 3825102,
        unit_hour: &["год"],
        unit_minute: &["хв"],
    },
    LanguagePack {
        code: "pol",
        english_name: "Polish",
        native_name: "Polski",
        direction: "ltr",
        bytes: 4765518,
        unit_hour: &["godz."],
        unit_minute: &["min"],
    },
    LanguagePack {
        code: "tur",
        english_name: "Turkish",
        native_name: "Türkçe",
        direction: "ltr",
        bytes: 4550554,
        unit_hour: &["sa", "saat"],
        unit_minute: &["dk", "dakika"],
    },
    LanguagePack {
        code: "ces",
        english_name: "Czech",
        native_name: "Čeština",
        direction: "ltr",
        bytes: 3795684,
        unit_hour: &["h", "hod."],
        unit_minute: &["min"],
    },
    LanguagePack {
        code: "swe",
        english_name: "Swedish",
        native_name: "Svenska",
        direction: "ltr",
        bytes: 4167034,
        unit_hour: &["tim", "timme", "timmar"],
        unit_minute: &["min"],
    },
    LanguagePack {
        code: "dan",
        english_name: "Danish",
        native_name: "Dansk",
        direction: "ltr",
        bytes: 2580059,
        unit_hour: &["t.", "time", "timer"],
        unit_minute: &["min."],
    },
    LanguagePack {
        code: "nor",
        english_name: "Norwegian",
        native_name: "Norsk",
        direction: "ltr",
        bytes: 3610079,
        unit_hour: &["t", "time", "timer"],
        unit_minute: &["min"],
    },
    LanguagePack {
        code: "fin",
        english_name: "Finnish",
        native_name: "Suomi",
        direction: "ltr",
        bytes: 7865732,
        unit_hour: &["t", "tunti", "tuntia"],
        unit_minute: &["min"],
    },
    LanguagePack {
        code: "ell",
        english_name: "Greek",
        native_name: "Ελληνικά",
        direction: "ltr",
        bytes: 1419514,
        unit_hour: &["ώ", "ώρα", "ώρες"],
        unit_minute: &["λ", "λεπτό", "λεπτά"],
    },
    LanguagePack {
        code: "hun",
        english_name: "Hungarian",
        native_name: "Magyar",
        direction: "ltr",
        bytes: 5296273,
        unit_hour: &["ó", "óra"],
        unit_minute: &["p", "perc"],
    },
    LanguagePack {
        code: "ron",
        english_name: "Romanian",
        native_name: "Română",
        direction: "ltr",
        bytes: 2376323,
        unit_hour: &["h", "oră", "ore"],
        unit_minute: &["min", "minute"],
    },
    LanguagePack {
        code: "jpn",
        english_name: "Japanese",
        native_name: "日本語",
        direction: "ltr",
        bytes: 2471260,
        unit_hour: &["時間"],
        unit_minute: &["分"],
    },
    LanguagePack {
        code: "chi_sim",
        english_name: "Chinese (Simplified)",
        native_name: "简体中文",
        direction: "ltr",
        bytes: 2469156,
        unit_hour: &["小时"],
        unit_minute: &["分钟"],
    },
    LanguagePack {
        code: "chi_tra",
        english_name: "Chinese (Traditional)",
        native_name: "繁體中文",
        direction: "ltr",
        bytes: 2366642,
        unit_hour: &["小時"],
        unit_minute: &["分鐘"],
    },
    LanguagePack {
        code: "kor",
        english_name: "Korean",
        native_name: "한국어",
        direction: "ltr",
        bytes: 1677415,
        unit_hour: &["시간"],
        unit_minute: &["분"],
    },
    LanguagePack {
        code: "tha",
        english_name: "Thai",
        native_name: "ไทย",
        direction: "ltr",
        bytes: 1072600,
        unit_hour: &["ชม.", "ชั่วโมง"],
        unit_minute: &["นาที"],
    },
    LanguagePack {
        code: "vie",
        english_name: "Vietnamese",
        native_name: "Tiếng Việt",
        direction: "ltr",
        bytes: 531275,
        unit_hour: &["giờ"],
        unit_minute: &["phút"],
    },
    LanguagePack {
        code: "hin",
        english_name: "Hindi",
        native_name: "हिन्दी",
        direction: "ltr",
        bytes: 1122751,
        unit_hour: &["घं", "घंटा", "घंटे"],
        unit_minute: &["मि", "मिनट"],
    },
    LanguagePack {
        code: "ind",
        english_name: "Indonesian",
        native_name: "Bahasa Indonesia",
        direction: "ltr",
        bytes: 1122661,
        unit_hour: &["j", "jam"],
        unit_minute: &["mnt", "menit"],
    },
];

pub const SHARED_CONSTANTS_HASH: &str = "cbd2968221a3ae3e";
