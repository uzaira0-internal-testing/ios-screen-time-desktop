//! Boundary optimizer for fine-tuning grid bounds to match OCR totals.
//!
//! Port of Python boundary_optimizer.py — tries small shifts in x, y, and width
//! to find the grid configuration where extracted bar totals best match the
//! OCR-extracted total time string.

use std::collections::HashSet;

use image::RgbImage;
use lazy_static::lazy_static;
use log::{debug, info, warn};
use regex::Regex;

use super::{
    bar_extraction::{
        compute_bar_total_from_scaled, preprocess_for_optimizer, slice_image_fast_total,
    },
    image_utils::remove_all_but,
    ocr::normalize_ocr_digits,
    types::{GridBounds, ImageType},
};

lazy_static! {
    static ref RE_HOURS: Regex = Regex::new(r"(\d{1,2})\s*h").unwrap();
    // Rust regex doesn't support lookahead (?!s). Use \b (word boundary)
    // which rejects "ms" since 's' is a word character following 'm'.
    static ref RE_MINUTES: Regex = Regex::new(r"(\d{1,2})\s*m\b").unwrap();
    static ref RE_SECONDS: Regex = Regex::new(r"(\d{1,2})\s*s").unwrap();
}

/// Result of boundary optimization.
#[derive(Debug, Clone)]
pub struct OptimizationResult {
    pub bounds: GridBounds,
    pub bar_total_minutes: i32,
    pub ocr_total_minutes: i32,
    /// OCR total string after evidence-gated 1↔7 correction (may differ from the raw OCR input).
    pub corrected_total: String,
    pub shift_x: i32,
    pub shift_y: i32,
    pub shift_width: i32,
    pub iterations: u32,
    pub converged: bool,
}

/// Parse an OCR total string like "1h 31m", "45m", "2h" into total minutes.
/// Returns None if parsing fails.
pub fn parse_ocr_total(ocr_total: &str) -> Option<i32> {
    if ocr_total.is_empty() || ocr_total == "N/A" {
        return None;
    }

    let normalized = normalize_ocr_digits(ocr_total);
    let text = normalized.trim().to_lowercase();

    let mut total_minutes: i32 = 0;

    // Extract hours: digits followed by 'h'
    if let Some(cap) = RE_HOURS.captures(&text)
        && let Ok(h) = cap[1].parse::<i32>()
    {
        total_minutes += h * 60;
    }

    // Extract minutes: digits followed by 'm' (not 'ms')
    if let Some(cap) = RE_MINUTES.captures(&text)
        && let Ok(m) = cap[1].parse::<i32>()
    {
        total_minutes += m;
    }

    // Seconds-only → rounds to 0 minutes
    if total_minutes == 0 && RE_SECONDS.is_match(&text) {
        return Some(0);
    }

    if total_minutes > 0 {
        Some(total_minutes)
    } else {
        None
    }
}

const OCR_DIGIT_CORRECTION_NEAR_MATCH_MINUTES: u32 = 1;
const OCR_DIGIT_CORRECTION_MIN_GAIN_MINUTES: u32 = 3;
const OCR_DIGIT_CORRECTION_MIN_RELATIVE_GAIN: f64 = 0.50;
const OCR_DIGIT_CORRECTION_MIN_NORMALIZED_GAIN: f64 = 0.05;

fn generate_1_7_alternatives(ocr_total: &str) -> Vec<String> {
    let chars: Vec<char> = ocr_total.chars().collect();
    let ambiguous_positions: Vec<usize> = chars
        .iter()
        .enumerate()
        .filter(|&(_, &c)| c == '1' || c == '7')
        .map(|(i, _)| i)
        .collect();
    if ambiguous_positions.is_empty() {
        return Vec::new();
    }

    let mut seen = HashSet::new();
    let mut alternatives = Vec::new();
    for mask in 1usize..(1usize << ambiguous_positions.len()) {
        let mut alt = chars.clone();
        for (bit, &pos) in ambiguous_positions.iter().enumerate() {
            if (mask & (1usize << bit)) != 0 {
                alt[pos] = if alt[pos] == '1' { '7' } else { '1' };
            }
        }
        let alt: String = alt.into_iter().collect();
        if seen.insert(alt.clone()) {
            alternatives.push(alt);
        }
    }
    alternatives
}

fn correction_has_enough_evidence(
    original_diff: u32,
    candidate_diff: u32,
    original_minutes: i32,
    candidate_minutes: i32,
    bar_total_minutes: i32,
) -> bool {
    if candidate_diff >= original_diff {
        return false;
    }

    let gain = original_diff - candidate_diff;
    if candidate_diff <= OCR_DIGIT_CORRECTION_NEAR_MATCH_MINUTES
        && gain >= OCR_DIGIT_CORRECTION_MIN_GAIN_MINUTES
    {
        return true;
    }

    let relative_gain = gain as f64 / original_diff.max(1) as f64;
    let scale = original_minutes
        .unsigned_abs()
        .max(candidate_minutes.unsigned_abs())
        .max(bar_total_minutes.unsigned_abs())
        .max(60);
    let normalized_gain = gain as f64 / scale as f64;

    relative_gain >= OCR_DIGIT_CORRECTION_MIN_RELATIVE_GAIN
        && normalized_gain >= OCR_DIGIT_CORRECTION_MIN_NORMALIZED_GAIN
}

/// Apply OCR 1↔7 correction when the measured bar total gives strong evidence.
///
/// This intentionally is not a string-only normalization. Candidate totals are
/// accepted only when they materially improve the error against the optimized
/// bar total, with exact/near-exact matches allowed for small minute corrections.
fn correct_ocr_1_7_with_bar_metric(ocr_total: &str, bar_total_minutes: i32) -> (String, i32) {
    let original_minutes = parse_ocr_total(ocr_total).unwrap_or(0);
    let mut best_total = ocr_total.to_string();
    let mut best_minutes = original_minutes;
    let original_diff = (best_minutes - bar_total_minutes).unsigned_abs();
    let mut best_diff = original_diff;

    for alt in generate_1_7_alternatives(ocr_total) {
        if let Some(mins) = parse_ocr_total(&alt) {
            let diff = (mins - bar_total_minutes).unsigned_abs();
            if diff < best_diff
                && correction_has_enough_evidence(
                    original_diff,
                    diff,
                    original_minutes,
                    mins,
                    bar_total_minutes,
                )
            {
                info!(
                    "OCR 1<->7 correction: '{}' ({}) -> '{}' ({}) [bar={}, diff {}->{}]",
                    ocr_total, best_minutes, alt, mins, bar_total_minutes, original_diff, diff
                );
                best_total = alt;
                best_minutes = mins;
                best_diff = diff;
            }
        }
    }

    (best_total, best_minutes)
}

/// Extract bar total for given bounds from the precomputed 4x-scaled buffer.
/// For battery images, falls back to per-call extraction (battery needs color filtering).
fn extract_bar_total_fast(
    scaled_data: &[u8],
    scaled_width: u32,
    img: &RgbImage,
    bounds: &GridBounds,
    image_type: ImageType,
) -> Option<f64> {
    let (img_w, img_h) = img.dimensions();

    let roi_x = bounds.roi_x();
    let roi_y = bounds.roi_y();
    let roi_w = bounds.width();
    let roi_h = bounds.height();

    if roi_x < 0 || roi_y < 0 || roi_w <= 0 || roi_h <= 0 {
        return None;
    }
    if (roi_x + roi_w) as u32 > img_w || (roi_y + roi_h) as u32 > img_h {
        return None;
    }

    let total = if image_type == ImageType::Battery {
        // Battery needs color filtering — can't use precomputed buffer
        let roi_base =
            image::imageops::crop_imm(img, roi_x as u32, roi_y as u32, roi_w as u32, roi_h as u32)
                .to_image();
        let mut roi = roi_base.clone();
        remove_all_but(&mut roi, [255, 121, 0], 30);
        let t = slice_image_fast_total(&roi, 0, 0, roi_w as u32, roi_h as u32);
        if t == 0.0 {
            let mut roi2 = roi_base;
            remove_all_but(&mut roi2, [0, 134, 255], 30);
            slice_image_fast_total(&roi2, 0, 0, roi_w as u32, roi_h as u32)
        } else {
            t
        }
    } else {
        // Screen time: read directly from precomputed 4x buffer (zero allocation)
        compute_bar_total_from_scaled(
            scaled_data,
            scaled_width,
            roi_x as u32,
            roi_y as u32,
            roi_w as u32,
            roi_h as u32,
        )
    };

    Some(total)
}

/// Optimize grid boundaries to match OCR total.
///
/// Port of Python `optimize_boundaries()`. Tries shifts in x, y, and width
/// to find the configuration where extracted bar totals best match the OCR total.
///
/// - x and width use step=2
/// - y uses step=1 (finer vertical control)
/// - horizontal shifts (x, width) penalized 5× more than vertical (y) in tie-breaks
pub fn optimize_boundaries(
    img: &RgbImage,
    initial_bounds: &GridBounds,
    ocr_total: &str,
    max_shift: i32,
    image_type: ImageType,
) -> OptimizationResult {
    let (img_w, img_h) = img.dimensions();

    let target_minutes = match parse_ocr_total(ocr_total) {
        Some(m) => m,
        None => {
            warn!("Could not parse OCR total: '{}'", ocr_total);
            let bar_total = slice_image_fast_total(
                img,
                initial_bounds.roi_x() as u32,
                initial_bounds.roi_y() as u32,
                initial_bounds.width() as u32,
                initial_bounds.height() as u32,
            ) as i32;
            return OptimizationResult {
                bounds: *initial_bounds,
                bar_total_minutes: bar_total,
                ocr_total_minutes: 0,
                corrected_total: ocr_total.to_string(),
                shift_x: 0,
                shift_y: 0,
                shift_width: 0,
                iterations: 0,
                converged: false,
            };
        }
    };

    // Keep normal phone screenshots on the optimizer path; skip oversized upscales.
    const MAX_SCALED_BYTES: u64 = 256 * 1024 * 1024;
    let scaled_bytes = (img_w as u64)
        .checked_mul(img_h as u64)
        .and_then(|pixels| pixels.checked_mul(4 * 4 * 3));
    if scaled_bytes.is_none_or(|bytes| bytes > MAX_SCALED_BYTES) {
        return OptimizationResult {
            bounds: *initial_bounds,
            bar_total_minutes: slice_image_fast_total(
                img,
                initial_bounds.roi_x() as u32,
                initial_bounds.roi_y() as u32,
                initial_bounds.width() as u32,
                initial_bounds.height() as u32,
            ) as i32,
            ocr_total_minutes: target_minutes,
            corrected_total: ocr_total.to_string(),
            shift_x: 0,
            shift_y: 0,
            shift_width: 0,
            iterations: 0,
            converged: false,
        };
    }

    // Precompute binarized + 4x-scaled image ONCE for the optimizer loop.
    // This gives 4x precision on every iteration with zero per-iteration allocation.
    let (scaled_data, scaled_width, _scaled_height) = preprocess_for_optimizer(img);

    let mut best_bounds = *initial_bounds;
    let mut best_diff = i32::MAX;
    let mut best_bar_total = 0i32;
    let mut best_shift_x = 0i32;
    let mut best_shift_y = 0i32;
    let mut best_shift_width = 0i32;
    let mut iterations = 0u32;

    // x and width step=2, y step=1
    let mut sx = -max_shift;
    while sx <= max_shift {
        let mut sy = -max_shift;
        while sy <= max_shift {
            let mut sw = -max_shift;
            while sw <= max_shift {
                iterations += 1;

                let new_x = initial_bounds.upper_left_x + sx;
                let new_y = initial_bounds.upper_left_y + sy;
                let new_w = initial_bounds.width() + sw;
                let new_h = initial_bounds.height();

                // Validate
                if new_x < 0 || new_y < 0 || new_w <= 0 {
                    sw += 2;
                    continue;
                }
                if (new_x + new_w) as u32 > img_w || (new_y + new_h) as u32 > img_h {
                    sw += 2;
                    continue;
                }

                let test_bounds = GridBounds::new(new_x, new_y, new_x + new_w, new_y + new_h);

                let bar_total = match extract_bar_total_fast(
                    &scaled_data,
                    scaled_width,
                    img,
                    &test_bounds,
                    image_type,
                ) {
                    Some(t) => t as i32,
                    None => {
                        sw += 2;
                        continue;
                    }
                };

                let diff = (bar_total - target_minutes).abs();
                let shift_penalty = 5 * sx.abs() + sy.abs() + 5 * sw.abs();
                let best_shift_penalty =
                    5 * best_shift_x.abs() + best_shift_y.abs() + 5 * best_shift_width.abs();

                let is_better =
                    diff < best_diff || (diff == best_diff && shift_penalty < best_shift_penalty);

                if is_better {
                    best_diff = diff;
                    best_bounds = test_bounds;
                    best_bar_total = bar_total;
                    best_shift_x = sx;
                    best_shift_y = sy;
                    best_shift_width = sw;

                    // Early exit: exact match with no shift
                    if diff == 0 && shift_penalty == 0 {
                        debug!("Boundary optimizer: exact match at origin");
                        return OptimizationResult {
                            bounds: best_bounds,
                            bar_total_minutes: best_bar_total,
                            ocr_total_minutes: target_minutes,
                            corrected_total: ocr_total.to_string(),
                            shift_x: best_shift_x,
                            shift_y: best_shift_y,
                            shift_width: best_shift_width,
                            iterations,
                            converged: true,
                        };
                    }
                }

                sw += 2;
            }
            sy += 1;
        }
        sx += 2;
    }

    // Apply 1↔7 OCR correction using bar total as a measured hint.
    let (corrected_str, corrected_minutes) =
        correct_ocr_1_7_with_bar_metric(ocr_total, best_bar_total);
    let final_diff = (best_bar_total - corrected_minutes).abs();

    debug!(
        "Boundary optimizer: shift=({},{},{}) bar={} ocr={} (orig={}) diff={}",
        best_shift_x,
        best_shift_y,
        best_shift_width,
        best_bar_total,
        corrected_minutes,
        target_minutes,
        final_diff
    );

    OptimizationResult {
        bounds: best_bounds,
        bar_total_minutes: best_bar_total,
        ocr_total_minutes: corrected_minutes,
        corrected_total: corrected_str,
        shift_x: best_shift_x,
        shift_y: best_shift_y,
        shift_width: best_shift_width,
        iterations,
        converged: final_diff <= 1,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn review_optimizer_skips_over_budget_upscale() {
        let img = RgbImage::from_pixel(2400, 2400, image::Rgb([255, 255, 255]));
        let bounds = GridBounds::from_roi(10, 10, 100, 60);
        let result = optimize_boundaries(&img, &bounds, "1h 15m", 2, ImageType::ScreenTime);
        assert_eq!(result.bounds, bounds);
        assert_eq!(result.iterations, 0);
        assert_eq!(result.corrected_total, "1h 15m");
        assert_eq!(result.ocr_total_minutes, 75);
    }

    #[test]
    fn test_parse_ocr_total_hours_and_minutes() {
        assert_eq!(parse_ocr_total("1h 31m"), Some(91));
        assert_eq!(parse_ocr_total("4h 36m"), Some(276));
        assert_eq!(parse_ocr_total("2h"), Some(120));
        assert_eq!(parse_ocr_total("45m"), Some(45));
    }

    #[test]
    fn test_parse_ocr_total_seconds_only() {
        assert_eq!(parse_ocr_total("30s"), Some(0));
    }

    #[test]
    fn test_parse_ocr_total_invalid() {
        assert_eq!(parse_ocr_total(""), None);
        assert_eq!(parse_ocr_total("N/A"), None);
        assert_eq!(parse_ocr_total("no time"), None);
    }

    #[test]
    fn test_parse_ocr_total_normalized() {
        // normalize_ocr_digits converts I→1, O→0
        assert_eq!(parse_ocr_total("Ih 31m"), Some(91));
    }

    #[test]
    fn corrects_7_to_1_when_bar_metric_is_decisive() {
        let (text, minutes) = correct_ocr_1_7_with_bar_metric("7h 31m", 91);
        assert_eq!(text, "1h 31m");
        assert_eq!(minutes, 91);
    }

    #[test]
    fn corrects_1_to_7_when_bar_metric_is_decisive() {
        let (text, minutes) = correct_ocr_1_7_with_bar_metric("1h 31m", 451);
        assert_eq!(text, "7h 31m");
        assert_eq!(minutes, 451);
    }

    #[test]
    fn corrects_small_minute_digit_when_it_nearly_matches_bars() {
        let (text, minutes) = correct_ocr_1_7_with_bar_metric("17m", 11);
        assert_eq!(text, "11m");
        assert_eq!(minutes, 11);
    }

    #[test]
    fn keeps_original_when_digit_flip_gain_is_weak() {
        let (text, minutes) = correct_ocr_1_7_with_bar_metric("17m", 13);
        assert_eq!(text, "17m");
        assert_eq!(minutes, 17);
    }

    // Parity: parse_ocr_total uses \b word boundary for minutes to reject "ms" (milliseconds).
    // Canvas uses a simple character map that also blocks "ms" via unit normalization.
    #[test]
    fn parity_parse_ocr_total_rejects_ms() {
        // "30ms" should not match minutes — 's' after 'm' is a word char, \b rejects it.
        assert_eq!(parse_ocr_total("30ms"), None);
        // "30m" with no following word char must match.
        assert_eq!(parse_ocr_total("30m"), Some(30));
    }

    // Parity: seconds-only returns Some(0) — canvas extractTimeFromText also returns 0 for "Xs".
    #[test]
    fn parity_parse_ocr_total_seconds_returns_zero() {
        assert_eq!(parse_ocr_total("45s"), Some(0));
        assert_eq!(parse_ocr_total("1s"), Some(0));
    }

    // Parity: mixed hours+minutes+seconds — only h and m count, s is ignored.
    #[test]
    fn parity_parse_ocr_total_hms_ignores_seconds() {
        assert_eq!(parse_ocr_total("1h 30m 45s"), Some(90)); // same as 1h 30m
    }

    // Parity: canvas optimizeBoundaries has NO bogus-optimization rejection.
    // When bar_total=0 and ocr_total>0, canvas returns the best-scoring (possibly blank) bounds.
    // Rust must do the same — no early revert to initial_bounds.
    // This test verifies optimize_boundaries runs to completion and returns a result
    // (even if suboptimal) rather than reverting when bar extraction yields 0.
    #[test]
    fn parity_no_bogus_optimization_rejection() {
        // All-white image: bar extraction gives 0 for every candidate. OCR total = "30m".
        let img = image::RgbImage::from_fn(400, 600, |_, _| image::Rgb([255, 255, 255]));
        let bounds = GridBounds::from_roi(10, 100, 380, 400);
        let result = optimize_boundaries(&img, &bounds, "30m", 2, ImageType::ScreenTime);
        // Must complete and return a result (not panic). bar_total may be 0.
        // Canvas: no rejection, just returns whatever the optimizer found.
        let _ = result.bar_total_minutes; // no assertion on value — parity is about not crashing/reverting
    }
}
