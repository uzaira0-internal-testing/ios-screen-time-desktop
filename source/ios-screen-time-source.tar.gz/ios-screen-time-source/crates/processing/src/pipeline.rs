//! Full image processing pipeline orchestration.
//!
//! Port of Python image_processor.py — ties together all processing stages:
//! dark mode conversion, grid detection, bar extraction, OCR, and alignment scoring.

use std::{path::Path, time::Instant};

use image::RgbImage;
use log::info;

#[cfg(feature = "ocr")]
use super::ocr;
use super::{
    bar_extraction::{
        ScoringConfig, apportion_to_total_cfg, compute_bar_alignment_score_scaled,
        compute_grid_registration_score_cfg, orient_hours, slice_image, slice_image_with_residuals,
        snap_roi_to_gridlines,
    },
    boundary_optimizer::{optimize_boundaries, parse_ocr_total},
    grid_detection,
    image_utils::{convert_dark_mode, remove_all_but},
    types::{
        AxisDirection, DetectionMethod, GridBounds, ImageType, ProcessingError, ProcessingResult,
    },
};

/// Load an image from disk and convert to RGB.
fn load_image(path: &str) -> Result<RgbImage, ProcessingError> {
    let img = image::open(path)?;
    Ok(img.to_rgb8())
}

/// Load image and apply dark mode conversion.
fn load_and_prepare(path: &str) -> Result<RgbImage, ProcessingError> {
    let mut img = load_image(path)?;
    convert_dark_mode(&mut img);
    Ok(img)
}

/// Extract bar values and compute alignment + grid-registration scores for bounds.
/// Returns (hourly_values_24, total, alignment_score, grid_registration_score).
///
/// `axis_direction` describes how the hour axis runs in the source screenshot. On a
/// right-to-left locale (Hebrew, Arabic) iOS mirrors the chart, so column 0 of the
/// ROI is hour 23, not hour 0. Slicing, apportionment and both scores work in IMAGE
/// order — they are geometric and must stay aligned with the pixels — so the values
/// are re-ordered into clock order only at the very end.
/// `axis_max_minutes` is the chart's top-gridline value when it is NOT the usual
/// 60 (see `ocr_anchored::detect_axis_max_minutes`); pass `None` for an ordinary
/// chart. The fifth return value is the ceiling actually used, which the caller
/// reports as review evidence — it is not always the detected one, because a
/// printed total that disagrees overrules the label.
fn extract_and_score(
    img: &RgbImage,
    bounds: &GridBounds,
    image_type: ImageType,
    ocr_total_minutes: Option<i32>,
    cfg: ScoringConfig,
    axis_direction: AxisDirection,
    axis_max_minutes: Option<i32>,
) -> (Vec<f64>, f64, f64, f64, f64, Option<f64>) {
    let roi_x = bounds.roi_x() as u32;
    let roi_y = bounds.roi_y() as u32;
    let roi_w = bounds.width() as u32;
    let roi_h = bounds.height() as u32;

    // For battery images, apply color isolation to a copy of the ROI only (not full image).
    // Canvas order: orange [255, 121, 0] first, blue [0, 134, 255] fallback.
    // Fallback condition: inverted_sum of ROI < 10 (canvas: darkBlueSum < 10),
    // meaning no orange pixels were found (all pixels white after filter).
    let mut applied_axis_max = 60.0;
    let mut detected_axis_max = None;
    let (hourly_row, residual_row) = if image_type == ImageType::Battery {
        let roi_base = image::imageops::crop_imm(img, roi_x, roi_y, roi_w, roi_h).to_image();
        let mut roi = roi_base.clone();
        remove_all_but(&mut roi, [255, 121, 0], 30);
        let inverted_sum: u32 = roi.as_raw().iter().map(|&p| 255u32 - p as u32).sum();
        if inverted_sum < 10 {
            let mut roi2 = roi_base;
            remove_all_but(&mut roi2, [0, 134, 255], 30);
            slice_image_with_residuals(&roi2, 0, 0, roi_w, roi_h)
        } else {
            slice_image_with_residuals(&roi, 0, 0, roi_w, roi_h)
        }
    } else {
        let (row, residuals, applied, detected) = crate::bar_extraction::slice_with_axis_scale(
            img,
            roi_x,
            roi_y,
            roi_w,
            roi_h,
            axis_max_minutes,
            ocr_total_minutes,
        );
        applied_axis_max = applied;
        detected_axis_max = detected;
        (row, residuals)
    };

    // Ensure we have at least 24 values (slice_image returns 25: 24 hours + total)
    let mut hourly_values = if hourly_row.len() > 24 {
        hourly_row[..24].to_vec()
    } else {
        let mut v = hourly_row.clone();
        v.resize(24, 0.0);
        v
    };
    let residuals = if residual_row.len() >= 24 {
        residual_row[..24].to_vec()
    } else {
        let mut v = residual_row.clone();
        v.resize(24, 0.0);
        v
    };

    // Grid registration is value-independent → compute it before apportionment so it
    // can gate it. Alignment depends on the values, so compute it after.
    let roi_original = image::imageops::crop_imm(img, roi_x, roi_y, roi_w, roi_h).to_image();
    let grid_registration_score =
        compute_grid_registration_score_cfg(&roi_original, cfg.grid_reg_deadband, cfg.grid_reg_tol);

    // Hand the floored-away minutes back to the least-overlapping bars when the OCR
    // total is known and the bar-sum is within tolerance of it (no-op otherwise).
    if let Some(target) = ocr_total_minutes {
        apportion_to_total_cfg(
            &mut hourly_values,
            &residuals,
            target,
            grid_registration_score,
            cfg.apportion_max_minutes,
            cfg.apportion_max_percent,
            cfg.apportion_min_registration,
        );
    }

    let total: f64 = hourly_values.iter().sum();
    // Cross-check at the ceiling the values were MEASURED at, not a fixed 60 —
    // otherwise a correctly rescaled chart re-measures at half scale and scores
    // ~0.5, flagging good data as poorly aligned.
    let alignment_score =
        compute_bar_alignment_score_scaled(&roi_original, &hourly_values, applied_axis_max);

    // Last step: image order → clock order. A no-op for LTR.
    orient_hours(&mut hourly_values, axis_direction);

    (
        hourly_values,
        total,
        alignment_score,
        grid_registration_score,
        applied_axis_max,
        detected_axis_max,
    )
}

/// Read the chart's top-gridline value, for screen-time charts only.
///
/// Battery charts are a percentage axis, not minutes, so the minute label the
/// detector looks for is meaningless there. Returns `None` without the `ocr`
/// feature, which leaves every caller on the 60-minute default.
#[cfg_attr(not(feature = "ocr"), allow(unused_variables))]
fn detect_axis_max(
    img: &RgbImage,
    original_img: &RgbImage,
    bounds: &GridBounds,
    image_type: ImageType,
    axis_direction: AxisDirection,
) -> Option<i32> {
    #[cfg(feature = "ocr")]
    {
        if image_type == ImageType::Battery {
            return None;
        }
        return grid_detection::ocr_anchored::detect_axis_max_minutes(
            img,
            original_img,
            bounds,
            axis_direction,
        );
    }
    #[cfg(not(feature = "ocr"))]
    None
}

/// Fold a non-60 y-axis ceiling into the review-quality evidence.
///
/// `AllDevicesSignals` has always carried `axis_max_minutes` and an "axis
/// exceeds 1 hour" reason, but nothing could populate them from a real
/// screenshot — the full-page OCR never reads the axis labels. This is what
/// finally does, so the warning the UI already knows how to show can fire.
/// `applied_axis_max` is the ceiling the values were measured at; `detected` is
/// what the label said, which may be a ceiling that was read and then rejected
/// for lack of a printed total to check it against. Both are worth flagging: the
/// first because the hours really are hour-scaled, the second because the chart
/// looks hour-scaled and nothing could confirm it, so a human should look.
///
/// The reason string is the CANONICAL one. `ocr.rs`, `core/ocr.py`,
/// `core/data_quality.py` and `frontend/src/utils/dataQuality.ts` all emit and
/// parse `"Chart axis exceeds 1 hour (N min)"`, and both consumers de-duplicate
/// by exact text — so a fifth wording here would show the reviewer the same fact
/// twice and slip past `getDataQualityFlags`'s legacy-recovery regex.
pub fn note_axis_scale(
    quality: &mut crate::ocr::AllDevicesSignals,
    applied_axis_max: f64,
    detected_axis_max: Option<f64>,
) {
    let ceiling = detected_axis_max
        .unwrap_or(applied_axis_max)
        .max(applied_axis_max);
    if ceiling <= 60.0 {
        return;
    }
    quality.suspected = true;
    quality.axis_max_minutes = Some(ceiling as i32);
    let reason = format!("Chart axis exceeds 1 hour ({} min)", ceiling as i32);
    if !quality.reasons.contains(&reason) {
        quality.reasons.push(reason);
    }
    if applied_axis_max <= 60.0 {
        // Covers BOTH ways a ceiling goes unapplied: no printed total to check it
        // against, and a printed total that voted it down. Naming only the first
        // would be wrong half the time.
        let unapplied = format!(
            "Chart y-axis reads {} min but the printed total did not confirm it — hours were measured at 60",
            ceiling as i32
        );
        if !quality.reasons.contains(&unapplied) {
            quality.reasons.push(unapplied);
        }
    }
}

#[allow(clippy::too_many_arguments)]
#[cfg_attr(not(feature = "ocr"), allow(unused_mut, unused_variables))]
fn grid_failure_result(
    start: Instant,
    original_img: &RgbImage,
    converted_img: &RgbImage,
    image_type: ImageType,
    detection_method: &str,
    confidence: f64,
    error: String,
    primary_ocr_error: Option<String>,
) -> ProcessingResult {
    let mut issues = vec![error];
    #[cfg(feature = "ocr")]
    let (quality, quality_ocr_error) = if image_type == ImageType::ScreenTime {
        match ocr::find_all_devices_quality_from_sources(original_img, converted_img) {
            Ok(quality) => (quality, None),
            Err(ocr_error) => {
                let message = ocr_error.to_string();
                issues.push(format!("All Devices quality OCR failed: {message}"));
                (ocr::AllDevicesSignals::default(), Some(message))
            }
        }
    } else {
        (ocr::AllDevicesSignals::default(), None)
    };
    #[cfg(not(feature = "ocr"))]
    let (quality, quality_ocr_error) = (super::ocr::AllDevicesSignals::default(), None);
    let ocr_error = primary_ocr_error.or(quality_ocr_error);

    ProcessingResult {
        hourly_values: None,
        total: 0.0,
        title: None,
        total_text: None,
        grid_bounds: None,
        alignment_score: None,
        grid_registration_score: None,
        detection_method: detection_method.to_string(),
        processing_time_ms: start.elapsed().as_millis() as u64,
        is_daily_total: false,
        issues,
        has_blocking_issues: true,
        grid_detection_confidence: Some(confidence),
        title_y_position: None,
        suspected_all_devices: quality.suspected,
        axis_max_minutes: quality.axis_max_minutes,
        all_devices_reasons: quality.reasons,
        ocr_failed: ocr_error.is_some(),
        ocr_error,
    }
}

/// Run title/total/quality OCR without throwing away usable grid and bar data
/// when the OCR engine fails. The caller records the OCR failure as blocking,
/// while continuing extraction with empty OCR fields.
#[cfg(feature = "ocr")]
fn extract_ocr_fields(
    original_img: &RgbImage,
    converted_img: &RgbImage,
    bounds: &GridBounds,
    image_type: ImageType,
) -> (
    String,
    Option<i32>,
    String,
    ocr::AllDevicesSignals,
    Option<String>,
) {
    match ocr::find_title_total_and_quality_region_first_from_sources(
        original_img,
        converted_img,
        Some(bounds),
    ) {
        Ok((title, title_y, total_text, mut quality)) => {
            if image_type == ImageType::Battery {
                quality = ocr::AllDevicesSignals::default();
            }
            (title, title_y, total_text, quality, None)
        }
        Err(error) => (
            String::new(),
            None,
            String::new(),
            ocr::AllDevicesSignals::default(),
            Some(error.to_string()),
        ),
    }
}

#[cfg(not(feature = "ocr"))]
fn extract_ocr_fields(
    _original_img: &RgbImage,
    _converted_img: &RgbImage,
    _bounds: &GridBounds,
    _image_type: ImageType,
) -> (
    String,
    Option<i32>,
    String,
    super::ocr::AllDevicesSignals,
    Option<String>,
) {
    (String::new(), None, String::new(), Default::default(), None)
}

/// Process a screenshot with automatic grid detection.
pub fn process_image(
    path: &str,
    image_type: ImageType,
    detection_method: DetectionMethod,
) -> Result<ProcessingResult, ProcessingError> {
    let start = Instant::now();
    let original_img = load_image(path)?;
    let mut img = original_img.clone();
    convert_dark_mode(&mut img);

    // Detect grid bounds (pass original for dark mode OCR fallback)
    let grid_result = match grid_detection::detect_grid_with_original(
        &img,
        detection_method,
        Some(&original_img),
    ) {
        Ok(result) => result,
        Err(error) => {
            let primary_ocr_error =
                matches!(&error, ProcessingError::Ocr(_)).then(|| error.to_string());
            return Ok(grid_failure_result(
                start,
                &original_img,
                &img,
                image_type,
                detection_method.as_str(),
                0.0,
                error.to_string(),
                primary_ocr_error,
            ));
        }
    };

    // Captured before `bounds` consumes the result: a mirrored (RTL) chart is
    // recognised during grid detection, from the hour labels' reading order.
    let axis_direction = grid_result.axis_direction;

    let bounds = match (grid_result.success, grid_result.bounds) {
        // OcrAnchored can land the ROI bottom on an intermediate gridline; snap the
        // edges onto the real 0m/60m gridlines. LineBased already frames on them.
        (true, Some(b)) if grid_result.method == "ocr_anchored" => snap_roi_to_gridlines(&img, &b),
        (true, Some(b)) => b,
        _ => {
            return Ok(grid_failure_result(
                start,
                &original_img,
                &img,
                image_type,
                &grid_result.method,
                grid_result.confidence,
                grid_result
                    .error
                    .unwrap_or_else(|| "Grid detection failed".to_string()),
                None,
            ));
        }
    };

    // OCR after grid geometry succeeds. Failed geometry is a blocking stage
    // failure, so title/total OCR would only spend Tesseract time on a screenshot
    // we cannot extract. Dark mode: OCR text on a plain invert (the high-contrast
    // convert_dark_mode merges bold total digits; see text_ocr_image).
    let (title, _title_y, total_text, mut quality, ocr_error) =
        extract_ocr_fields(&original_img, &img, &bounds, image_type);
    let is_daily_total = title == "Daily Total";

    // Don't skip daily total pages — they still have bar charts (all apps combined).
    // The is_daily_total flag is propagated so callers can decide to skip or use the data.

    let ocr_total_minutes = parse_ocr_total(&total_text).filter(|&m| m > 0);
    // An "All Devices" chart sums devices into one hour, so iOS relabels the axis
    // `2h / 1h / 0`. Reading it at 60 halves every bar without failing.
    let axis_max_minutes =
        detect_axis_max(&img, &original_img, &bounds, image_type, axis_direction);
    let (
        hourly_values,
        total,
        alignment_score,
        grid_registration_score,
        applied_axis_max,
        detected_axis_max,
    ) = extract_and_score(
        &img,
        &bounds,
        image_type,
        ocr_total_minutes,
        ScoringConfig::default(),
        axis_direction,
        axis_max_minutes,
    );
    note_axis_scale(&mut quality, applied_axis_max, detected_axis_max);

    let elapsed = start.elapsed().as_millis() as u64;
    info!(
        "Processed {} in {elapsed}ms (method={}, title='{}', total_text='{}', alignment={alignment_score:.2})",
        Path::new(path)
            .file_name()
            .unwrap_or_default()
            .to_string_lossy(),
        grid_result.method,
        title,
        total_text,
    );

    Ok(ProcessingResult {
        hourly_values: Some(hourly_values),
        total,
        title: if title.is_empty() { None } else { Some(title) },
        total_text: if total_text.is_empty() {
            None
        } else {
            Some(total_text)
        },
        grid_bounds: Some(bounds),
        alignment_score: Some(alignment_score),
        grid_registration_score: Some(grid_registration_score),
        detection_method: grid_result.method,
        processing_time_ms: elapsed,
        is_daily_total,
        issues: ocr_error
            .iter()
            .map(|error| format!("OCR failed: {error}"))
            .collect(),
        has_blocking_issues: ocr_error.is_some(),
        grid_detection_confidence: Some(grid_result.confidence),
        title_y_position: _title_y,
        suspected_all_devices: quality.suspected,
        axis_max_minutes: quality.axis_max_minutes,
        all_devices_reasons: quality.reasons,
        ocr_failed: ocr_error.is_some(),
        ocr_error,
    })
}

/// Process a screenshot with user-provided grid coordinates.
pub fn process_image_with_grid(
    path: &str,
    upper_left: [i32; 2],
    lower_right: [i32; 2],
    image_type: ImageType,
    cfg: ScoringConfig,
) -> Result<ProcessingResult, ProcessingError> {
    let start = Instant::now();
    let original_img = load_image(path)?;
    let mut img = original_img.clone();
    convert_dark_mode(&mut img);
    let (w, h) = img.dimensions();

    let bounds = grid_detection::calculate_roi_from_clicks(upper_left, lower_right, w, h)?;

    // OCR before extraction so the total can drive apportionment. Dark mode: OCR on a
    // plain invert so the bold total's digits aren't merged (see text_ocr_image).
    let (title, _title_y, total_text, mut quality, ocr_error) =
        extract_ocr_fields(&original_img, &img, &bounds, image_type);
    let is_daily_total = title == "Daily Total";

    let ocr_total_minutes = parse_ocr_total(&total_text).filter(|&m| m > 0);
    // Click-driven ROIs carry no axis DIRECTION evidence — the user framed the
    // region, not a label reader — so hours stay in image order. The axis
    // CEILING is different: it is printed on the screenshot either way, and the
    // user framing the plot does not make its top gridline mean 60 minutes.
    let axis_max_minutes =
        detect_axis_max(&img, &original_img, &bounds, image_type, AxisDirection::Ltr);
    let (
        hourly_values,
        total,
        alignment_score,
        grid_registration_score,
        applied_axis_max,
        detected_axis_max,
    ) = extract_and_score(
        &img,
        &bounds,
        image_type,
        ocr_total_minutes,
        cfg,
        AxisDirection::Ltr,
        axis_max_minutes,
    );
    note_axis_scale(&mut quality, applied_axis_max, detected_axis_max);
    Ok(ProcessingResult {
        hourly_values: Some(hourly_values),
        total,
        title: if title.is_empty() { None } else { Some(title) },
        total_text: if total_text.is_empty() {
            None
        } else {
            Some(total_text)
        },
        grid_bounds: Some(bounds),
        alignment_score: Some(alignment_score),
        grid_registration_score: Some(grid_registration_score),
        detection_method: "manual".to_string(),
        processing_time_ms: start.elapsed().as_millis() as u64,
        is_daily_total,
        issues: ocr_error
            .iter()
            .map(|error| format!("OCR failed: {error}"))
            .collect(),
        has_blocking_issues: ocr_error.is_some(),
        grid_detection_confidence: None,
        title_y_position: _title_y,
        suspected_all_devices: quality.suspected,
        axis_max_minutes: quality.axis_max_minutes,
        all_devices_reasons: quality.reasons,
        ocr_failed: ocr_error.is_some(),
        ocr_error,
    })
}

/// Process with automatic grid detection + boundary optimization.
///
/// Runs the full pipeline then fine-tunes the detected grid bounds by trying
/// small shifts to minimise the difference between extracted bar totals and
/// the OCR total string.
///
/// If `detection_method` is `LineBased` and grid detection fails, automatically
/// retries with `OcrAnchored`. A final grid failure is returned as a structured,
/// blocking `ProcessingResult` so partial quality OCR evidence is not lost.
pub fn process_image_optimized(
    path: &str,
    image_type: ImageType,
    detection_method: DetectionMethod,
    max_shift: i32,
    cfg: ScoringConfig,
) -> Result<ProcessingResult, ProcessingError> {
    let start = Instant::now();
    let original_img = load_image(path)?;
    let mut img = original_img.clone();
    convert_dark_mode(&mut img);

    // Grid detection — fall back from line_based to ocr_anchored automatically.
    let grid_result = match grid_detection::detect_grid_with_original(
        &img,
        detection_method,
        Some(&original_img),
    ) {
        Ok(result) => result,
        Err(error) => {
            let primary_ocr_error =
                matches!(&error, ProcessingError::Ocr(_)).then(|| error.to_string());
            return Ok(grid_failure_result(
                start,
                &original_img,
                &img,
                image_type,
                detection_method.as_str(),
                0.0,
                error.to_string(),
                primary_ocr_error,
            ));
        }
    };

    #[cfg(feature = "ocr")]
    let mut resolved_method = grid_result.method.clone();
    #[cfg(not(feature = "ocr"))]
    let resolved_method = grid_result.method.clone();
    #[cfg(feature = "ocr")]
    let mut resolved_confidence = grid_result.confidence;
    #[cfg(not(feature = "ocr"))]
    let resolved_confidence = grid_result.confidence;
    // LineBased is purely geometric and always reports Ltr; when it fails and the
    // OcrAnchored fallback below succeeds, that fallback's reading of the hour
    // labels is the only real axis evidence, so it replaces this.
    #[cfg(feature = "ocr")]
    let mut axis_direction = grid_result.axis_direction;
    #[cfg(not(feature = "ocr"))]
    let axis_direction = grid_result.axis_direction;
    let initial_bounds = if let (true, Some(b)) = (grid_result.success, grid_result.bounds) {
        // Snap OcrAnchored ROIs onto the real 0m/60m gridlines (LineBased already does).
        if grid_result.method == "ocr_anchored" {
            snap_roi_to_gridlines(&img, &b)
        } else {
            b
        }
    } else if detection_method == DetectionMethod::LineBased {
        // line_based found nothing — try ocr_anchored before giving up (native only).
        #[cfg(feature = "ocr")]
        {
            let fallback = match grid_detection::detect_grid_with_original(
                &img,
                DetectionMethod::OcrAnchored,
                Some(&original_img),
            ) {
                Ok(result) => result,
                Err(error) => {
                    let primary_ocr_error =
                        matches!(&error, ProcessingError::Ocr(_)).then(|| error.to_string());
                    return Ok(grid_failure_result(
                        start,
                        &original_img,
                        &img,
                        image_type,
                        DetectionMethod::OcrAnchored.as_str(),
                        0.0,
                        error.to_string(),
                        primary_ocr_error,
                    ));
                }
            };
            match (fallback.success, fallback.bounds) {
                (true, Some(b)) => {
                    resolved_method = fallback.method;
                    resolved_confidence = fallback.confidence;
                    axis_direction = fallback.axis_direction;
                    snap_roi_to_gridlines(&img, &b)
                }
                _ => {
                    return Ok(grid_failure_result(
                        start,
                        &original_img,
                        &img,
                        image_type,
                        &fallback.method,
                        fallback.confidence,
                        fallback.error.unwrap_or_else(|| {
                            "Grid detection failed (line_based + ocr_anchored)".to_string()
                        }),
                        None,
                    ));
                }
            }
        }
        #[cfg(not(feature = "ocr"))]
        return Ok(grid_failure_result(
            start,
            &original_img,
            &img,
            image_type,
            &grid_result.method,
            grid_result.confidence,
            grid_result
                .error
                .unwrap_or_else(|| "Grid detection failed (line_based)".to_string()),
            None,
        ));
    } else {
        return Ok(grid_failure_result(
            start,
            &original_img,
            &img,
            image_type,
            &grid_result.method,
            grid_result.confidence,
            grid_result
                .error
                .unwrap_or_else(|| "Grid detection failed".to_string()),
            None,
        ));
    };

    // OCR once, after usable grid geometry is known. It drives daily-total
    // detection and boundary optimization. Failed geometry takes the separate
    // quality-only path above rather than attempting title/bar extraction.
    let (title, _title_y, total_text, mut quality, ocr_error) =
        extract_ocr_fields(&original_img, &img, &initial_bounds, image_type);
    let is_daily_total = title == "Daily Total";

    // NOTE: the equivalent axis-direction re-read in `pipeline_em.rs` has no
    // counterpart here on purpose. It is gated on `ocr::rtl_language_enabled()`,
    // and the PyO3 wheel exposes no binding for `ocr::set_ocr_language` — the
    // server's Rust accelerator is permanently on "eng", so the gate can never
    // open and the block would be dead code. Server-mode RTL needs that binding
    // first; until then `line_based` still reports Ltr for a mirrored chart on
    // this path.

    // Don't skip — daily total pages still have bar charts. Propagate the flag instead.

    // Boundary optimization
    let opt = optimize_boundaries(&img, &initial_bounds, &total_text, max_shift, image_type);
    let bounds = opt.bounds;

    // Apportion against the optimizer's evidence-corrected OCR total.
    let ocr_total_minutes = (opt.ocr_total_minutes > 0).then_some(opt.ocr_total_minutes);
    // Read the axis against the OPTIMIZED bounds: the optimizer can shift the
    // plot's top edge, and the label window is anchored on it.
    let axis_max_minutes =
        detect_axis_max(&img, &original_img, &bounds, image_type, axis_direction);
    let (
        hourly_values,
        total,
        alignment_score,
        grid_registration_score,
        applied_axis_max,
        detected_axis_max,
    ) = extract_and_score(
        &img,
        &bounds,
        image_type,
        ocr_total_minutes,
        cfg,
        axis_direction,
        axis_max_minutes,
    );
    note_axis_scale(&mut quality, applied_axis_max, detected_axis_max);

    let elapsed = start.elapsed().as_millis() as u64;
    info!(
        "Processed (optimized) {} in {elapsed}ms (method={}, shift=({},{},{}), converged={}, title='{}', total_text='{}', is_daily_total={is_daily_total})",
        Path::new(path)
            .file_name()
            .unwrap_or_default()
            .to_string_lossy(),
        resolved_method,
        opt.shift_x,
        opt.shift_y,
        opt.shift_width,
        opt.converged,
        title,
        total_text,
    );

    Ok(ProcessingResult {
        hourly_values: Some(hourly_values),
        total,
        title: if title.is_empty() { None } else { Some(title) },
        total_text: if total_text.is_empty() {
            None
        } else {
            Some(total_text)
        },
        grid_bounds: Some(bounds),
        alignment_score: Some(alignment_score),
        grid_registration_score: Some(grid_registration_score),
        detection_method: resolved_method,
        processing_time_ms: elapsed,
        is_daily_total,
        issues: ocr_error
            .iter()
            .map(|error| format!("OCR failed: {error}"))
            .collect(),
        has_blocking_issues: ocr_error.is_some(),
        grid_detection_confidence: Some(resolved_confidence),
        title_y_position: _title_y,
        suspected_all_devices: quality.suspected,
        axis_max_minutes: quality.axis_max_minutes,
        all_devices_reasons: quality.reasons,
        ocr_failed: ocr_error.is_some(),
        ocr_error,
    })
}

/// Extract only hourly data (skip OCR, fast path).
pub fn extract_hourly_data(
    path: &str,
    upper_left: [i32; 2],
    lower_right: [i32; 2],
    image_type: ImageType,
) -> Result<Vec<f64>, ProcessingError> {
    let img = load_and_prepare(path)?;
    let (w, h) = img.dimensions();
    let bounds = grid_detection::calculate_roi_from_clicks(upper_left, lower_right, w, h)?;

    let hourly_row = if image_type == ImageType::Battery {
        let roi_x = bounds.roi_x() as u32;
        let roi_y = bounds.roi_y() as u32;
        let roi_w = bounds.width() as u32;
        let roi_h = bounds.height() as u32;
        let roi_base = image::imageops::crop_imm(&img, roi_x, roi_y, roi_w, roi_h).to_image();
        let mut roi = roi_base.clone();
        remove_all_but(&mut roi, [255, 121, 0], 30);
        let inverted_sum: u32 = roi.as_raw().iter().map(|&p| 255u32 - p as u32).sum();
        if inverted_sum < 10 {
            let mut roi2 = roi_base;
            remove_all_but(&mut roi2, [0, 134, 255], 30);
            slice_image(&roi2, 0, 0, roi_w, roi_h)
        } else {
            slice_image(&roi, 0, 0, roi_w, roi_h)
        }
    } else {
        slice_image(
            &img,
            bounds.roi_x() as u32,
            bounds.roi_y() as u32,
            bounds.width() as u32,
            bounds.height() as u32,
        )
    };

    Ok(hourly_row)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_extract_and_score_white_image() {
        let img = RgbImage::from_fn(240, 100, |_, _| image::Rgb([255, 255, 255]));
        let bounds = GridBounds::from_roi(0, 0, 240, 100);
        let (values, total, _score, _reg, _axis, _detected) = extract_and_score(
            &img,
            &bounds,
            ImageType::ScreenTime,
            None,
            ScoringConfig::default(),
            AxisDirection::Ltr,
            None,
        );
        assert_eq!(values.len(), 24);
        assert!(total.abs() < 0.01);
    }

    #[test]
    fn rtl_reverses_the_hour_order_and_leaves_the_total_alone() {
        // A ramp whose 24 ROI columns rise left→right. Read as LTR that is hour 0
        // smallest; read as RTL the same pixels mean hour 0 is the RIGHTMOST column,
        // so the returned series must be reversed while the sum is untouched.
        let img = RgbImage::from_fn(240, 100, |x, y| {
            let col = (x / 10) as u32;
            let bar_top = 100u32.saturating_sub(col * 4);
            if u32::from(y) >= bar_top {
                image::Rgb([0, 0, 0])
            } else {
                image::Rgb([255, 255, 255])
            }
        });
        let bounds = GridBounds::from_roi(0, 0, 240, 100);
        let ltr = extract_and_score(
            &img,
            &bounds,
            ImageType::ScreenTime,
            None,
            ScoringConfig::default(),
            AxisDirection::Ltr,
            None,
        );
        let rtl = extract_and_score(
            &img,
            &bounds,
            ImageType::ScreenTime,
            None,
            ScoringConfig::default(),
            AxisDirection::Rtl,
            None,
        );
        let mut expected = ltr.0.clone();
        expected.reverse();
        assert_eq!(rtl.0, expected);
        assert!((rtl.1 - ltr.1).abs() < 1e-9);
        assert_ne!(rtl.0, ltr.0, "the ramp must not be symmetric");
    }

    #[test]
    fn grid_failure_returns_structured_blocking_result() {
        #[cfg(feature = "ocr")]
        crate::ocr::reset_ocr_telemetry();
        let path = std::env::temp_dir().join(format!(
            "ios_screen_time_invalid_landscape_{}.png",
            std::process::id()
        ));
        let img = RgbImage::from_fn(640, 320, |_, _| image::Rgb([255, 255, 255]));
        img.save(&path).expect("write invalid test image");

        let result = process_image(
            path.to_str().expect("temp path should be utf-8"),
            ImageType::ScreenTime,
            DetectionMethod::LineBased,
        );
        let _ = std::fs::remove_file(&path);

        let result = result.expect("grid failure should remain a structured result");
        assert!(result.has_blocking_issues);
        assert!(result.hourly_values.is_none());
        assert!(result.grid_bounds.is_none());
        assert!(!result.issues.is_empty());
        #[cfg(feature = "ocr")]
        {
            let telemetry = crate::ocr::ocr_telemetry_snapshot();
            assert_eq!(telemetry.title_total_region_calls, 0);
            assert_eq!(telemetry.title_total_full_frame_calls, 0);
        }
    }
}
