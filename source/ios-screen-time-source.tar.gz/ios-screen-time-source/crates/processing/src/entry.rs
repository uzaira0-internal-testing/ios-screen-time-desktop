//! Per-image entry points of the offline app.
//!
//! The wasm build's C-ABI (`bin/pipeline_em.rs`) and the desktop app's native
//! pipeline both call these, so the two cannot drift. Each returns the JSON the
//! frontend reads.

#[cfg(feature = "ocr")]
use crate::ocr;
use crate::{
    bar_extraction::{
        ScoringConfig, apportion_to_total_cfg, compute_bar_alignment_score_scaled,
        compute_grid_registration_score_cfg, orient_hours, slice_image_with_residuals,
        slice_with_axis_scale, snap_roi_to_gridlines,
    },
    boundary_optimizer, grid_detection,
    image_utils::{convert_dark_mode, remove_all_but, rgba_to_rgb_image},
    types::{
        AxisDirection, DetectionMethod, GridBounds, ImageType, PIPELINE_SCHEMA_VERSION,
        ProcessingError,
    },
};

fn grid_detection_error_json(error: &ProcessingError, method: &str) -> String {
    serde_json::json!({
        "success": false,
        "confidence": 0.0,
        "method": method,
        "error": error.to_string(),
        "ocr_error": matches!(error, ProcessingError::Ocr(_)).then(|| error.to_string()),
    })
    .to_string()
}

pub fn json_err(msg: &str) -> String {
    serde_json::json!({
        "pipeline_schema_version": PIPELINE_SCHEMA_VERSION,
        "error": msg,
    })
    .to_string()
}

/// Full pipeline (grid, OCR, bars) for one RGBA image.
///
/// Grid coordinates of -1 mean "detect the grid"; `cfg` carries the Settings UI's
/// apportionment and grid-registration knobs.
#[allow(clippy::too_many_arguments)]
pub fn process(
    rgba: &[u8],
    width: u32,
    height: u32,
    img_type: ImageType,
    max_shift: i32,
    grid_ul_x: i32,
    grid_ul_y: i32,
    grid_lr_x: i32,
    grid_lr_y: i32,
    cfg: ScoringConfig,
) -> String {
    let Some(mut img) = rgba_to_rgb_image(rgba, width, height) else {
        return json_err("RGBA size mismatch");
    };
    // Portrait-only input contract: every iOS Screen Time chart is taller than it
    // is wide. A landscape frame is a rotated/invalid capture — reject loudly
    // rather than mis-frame the grid. Defense-in-depth; the frontend also guards
    // this at the device-detection stage before any pipeline call.
    if width >= height {
        return json_err("Landscape orientation — capture the Screen Time chart in portrait");
    }
    // Keep the pristine (pre-dark-mode-convert) image so OcrAnchored can run its
    // adaptive-threshold dark-mode OCR fallback. convert_dark_mode's contrast=3.0
    // clips faint axis labels ("12 AM" / "60m") to hollow near-white outlines that
    // Tesseract can't read; without the original, detect_grid sees the already-
    // inverted (now light) image, is_dark_mode() returns false, and the fallback
    // that recovers those anchors never fires — exactly the server path's behaviour.
    let original_img = img.clone();
    convert_dark_mode(&mut img);

    // Determine grid bounds: use pre-supplied coordinates if valid, else try
    // LineBased first and fall back to OcrAnchored for unknown resolutions.
    let manual_grid_requested = [grid_ul_x, grid_ul_y, grid_lr_x, grid_lr_y]
        .iter()
        .any(|coordinate| *coordinate >= 0);
    // `axis_direction` is Rtl only when the detector read the hour labels in
    // right-to-left order (a mirrored Hebrew/Arabic chart). Manual coordinates
    // carry no such evidence, so they stay Ltr.
    let (
        grid_success,
        grid_bounds_opt,
        grid_confidence,
        grid_error,
        grid_is_weekly,
        axis_direction,
    ) = if manual_grid_requested {
        match grid_detection::calculate_roi_from_clicks(
            [grid_ul_x, grid_ul_y],
            [grid_lr_x, grid_lr_y],
            width,
            height,
        ) {
            Ok(bounds) => (
                true,
                Some(bounds),
                1.0_f64,
                None::<String>,
                false,
                AxisDirection::Ltr,
            ),
            Err(error) => (
                false,
                None,
                0.0_f64,
                Some(error.to_string()),
                false,
                AxisDirection::Ltr,
            ),
        }
    } else {
        // Try LineBased (pixel gridlines, NO OCR) FIRST. It's lookup-table-gated,
        // returning success=false for unknown resolutions, in which case we fall
        // through to the OcrAnchored path. This removes the expensive dark-mode
        // anchor OCR (~975 ms) for known resolutions — measured 1.71× overall /
        // 1.59× dark vs OcrAnchored-first, output-exact on kept data. LineBased
        // already frames on detected gridlines — no snap needed.
        match grid_detection::detect_grid_with_original(
            &img,
            DetectionMethod::LineBased,
            Some(&original_img),
        ) {
            Ok(r) if r.success => (
                r.success,
                r.bounds,
                r.confidence,
                r.error,
                false,
                r.axis_direction,
            ),
            // LineBased positively identified the WEEKLY (7-column) view. Reject
            // definitively and SKIP the OcrAnchored fallback: a weekly chart has
            // no "12 AM"/"60" hourly anchors, so OcrAnchored can only fail or
            // mis-anchor. Surfacing the weekly signal gives a clear user message.
            Ok(r) if r.is_weekly => (false, None, r.confidence, r.error, true, r.axis_direction),
            // Fallback: OcrAnchored places the ROI by text anchors, which can
            // land the bottom on an intermediate gridline (clipping the bars /
            // scaling them short). Snap the edges onto the real 0m/60m gridlines.
            _ => match grid_detection::detect_grid_with_original(
                &img,
                DetectionMethod::OcrAnchored,
                Some(&original_img),
            ) {
                Ok(r) if r.success => {
                    let snapped = r.bounds.map(|b| snap_roi_to_gridlines(&img, &b));
                    (
                        r.success,
                        snapped,
                        r.confidence,
                        r.error,
                        false,
                        r.axis_direction,
                    )
                }
                Ok(r) => (
                    r.success,
                    r.bounds,
                    r.confidence,
                    r.error,
                    false,
                    r.axis_direction,
                ),
                Err(e) => return json_err(&format!("Grid: {e}")),
            },
        }
    };

    // Run OCR on the FULL image. Daily-total classification depends on markers
    // below the chart ("MOST USED", "CATEGORIES", category rows, etc.) and PSM
    // layout context. Region-only OCR can misclassify daily totals and feed the
    // wrong total into apportionment, which changes the extracted usage bars.
    //
    // In dark mode the title/total OCR runs on a PLAIN INVERT of the original,
    // not the high-contrast `convert_dark_mode` output: contrast=3.0 merges the
    // large bold total's digits ("11h 24m" -> "Mh 24m"), dropping the hours.
    // Bar extraction below still uses the high-contrast `img`.
    #[cfg(feature = "ocr")]
    let ocr_src = crate::image_utils::text_ocr_image(&original_img, &img);
    #[cfg(feature = "ocr")]
    let (title, mut total_text, mut quality, ocr_error) =
        match ocr::find_title_total_and_quality(&ocr_src, grid_bounds_opt.as_ref()) {
            Ok((t, _, tot, quality)) => (t, tot, quality, None::<String>),
            Err(e) => (
                String::new(),
                String::new(),
                ocr::AllDevicesSignals::default(),
                Some(e.to_string()),
            ),
        };
    #[cfg(feature = "ocr")]
    if img_type == ImageType::Battery {
        quality = ocr::AllDevicesSignals::default();
    }
    #[cfg(not(feature = "ocr"))]
    let (title, mut total_text, mut quality, ocr_error) = (
        String::new(),
        String::new(),
        crate::ocr::AllDevicesSignals::default(),
        None::<String>,
    );
    let is_daily_total = title == "Daily Total";

    // Axis direction belongs to the SCREENSHOT, not to whichever detector won.
    // Two live paths reach here still claiming Ltr on a mirrored chart: caller-
    // supplied grid coordinates (the app detects the grid in a separate call and
    // hands the box back, which is the DEFAULT path) and a successful
    // `line_based` detect, which is purely geometric and reports Ltr
    // unconditionally. Both then slice a mirrored chart left-to-right and store
    // every hour against the wrong time, with a correct total and no warning.
    // Re-read the labels here, once, for anyone who could be looking at one.
    // The hour labels sit just BELOW the plot rectangle, so the band to read is
    // anchored on the ROI we just established — not on a fraction of the page.
    #[cfg(feature = "ocr")]
    let axis_direction = match (
        axis_direction,
        crate::ocr::rtl_language_enabled(),
        grid_bounds_opt.as_ref(),
    ) {
        (AxisDirection::Ltr, true, Some(bounds)) => {
            grid_detection::ocr_anchored::detect_axis_direction(
                &img,
                &original_img,
                bounds.upper_left_y,
                bounds.lower_right_y,
            )
            .unwrap_or(axis_direction)
        }
        _ => axis_direction,
    };

    if let (true, Some(mut bounds)) = (grid_success, grid_bounds_opt) {
        // Run boundary optimizer if requested and OCR total is available.
        if max_shift > 0 && !total_text.is_empty() {
            let opt = boundary_optimizer::optimize_boundaries(
                &img,
                &bounds,
                &total_text,
                max_shift,
                img_type,
            );
            bounds = opt.bounds;
            total_text = opt.corrected_total;
        }

        let roi_x = bounds.roi_x() as u32;
        let roi_y = bounds.roi_y() as u32;
        let roi_w = bounds.width() as u32;
        let roi_h = bounds.height() as u32;

        let mut applied_axis_max = 60.0f64;
        let (row, residual_row) = if img_type == ImageType::Battery {
            let base = image::imageops::crop_imm(&img, roi_x, roi_y, roi_w, roi_h).to_image();
            let mut roi = base.clone();
            // Try orange bars first (matches canvas: [255, 121, 0] primary, [0, 134, 255] fallback)
            remove_all_but(&mut roi, [255, 121, 0], 30);
            let (v, vr) = slice_image_with_residuals(&roi, 0, 0, roi_w, roi_h);
            if v.iter().take(24).sum::<f64>() > 0.0 {
                (v, vr)
            } else {
                let mut roi2 = base;
                remove_all_but(&mut roi2, [0, 134, 255], 30);
                slice_image_with_residuals(&roi2, 0, 0, roi_w, roi_h)
            }
        } else {
            // The y-axis is not always 60 minutes — an "All Devices" chart sums
            // devices into one hour and iOS relabels the axis `2h / 1h / 0`.
            // Reading such a chart at 60 halves every value silently.
            #[cfg(feature = "ocr")]
            let axis_max = grid_detection::ocr_anchored::detect_axis_max_minutes(
                &img,
                &original_img,
                &bounds,
                axis_direction,
            );
            #[cfg(not(feature = "ocr"))]
            let axis_max: Option<i32> = None;
            let (row, residual_row, applied, detected) = slice_with_axis_scale(
                &img,
                roi_x,
                roi_y,
                roi_w,
                roi_h,
                axis_max,
                boundary_optimizer::parse_ocr_total(&total_text),
            );
            applied_axis_max = applied;
            // Report the ceiling actually used. `AllDevicesSignals` already owns
            // this field and its "axis exceeds 1 hour" reason; until now nothing
            // could populate it from a real screenshot, so the warning it drives
            // never appeared. A rescaled chart is by definition the aggregated
            // view the reviewer needs to know about.
            //
            // Delegates to the SAME helper the three native entry points use, so
            // the offline build and the server cannot drift on the threshold or
            // the wording. This binary links the library as an external crate, so
            // the helper is `pub`, not `pub(crate)`.
            crate::pipeline::note_axis_scale(&mut quality, applied, detected);
            (row, residual_row)
        };

        let mut hourly: Vec<f64> = {
            let mut v = if row.len() > 24 {
                row[..24].to_vec()
            } else {
                row
            };
            v.resize(24, 0.0);
            v
        };
        let residuals: Vec<f64> = {
            let mut v = if residual_row.len() > 24 {
                residual_row[..24].to_vec()
            } else {
                residual_row
            };
            v.resize(24, 0.0);
            v
        };
        let roi_crop = image::imageops::crop_imm(&img, roi_x, roi_y, roi_w, roi_h).to_image();
        // Grid registration is value-independent → compute before apportionment so it
        // can gate it; alignment depends on the values, so compute it after.
        let grid_registration =
            compute_grid_registration_score_cfg(&roi_crop, cfg.grid_reg_deadband, cfg.grid_reg_tol);
        // Hand the floored-away minutes back to the least-overlapping bars when the
        // evidence-corrected OCR total is known and within tolerance (no-op otherwise).
        if let Some(target) = boundary_optimizer::parse_ocr_total(&total_text).filter(|&m| m > 0) {
            apportion_to_total_cfg(
                &mut hourly,
                &residuals,
                target,
                grid_registration,
                cfg.apportion_max_minutes,
                cfg.apportion_max_percent,
                cfg.apportion_min_registration,
            );
        }
        let total: f64 = hourly.iter().sum();
        // Cross-check at the ceiling the values were measured at (see
        // `compute_bar_alignment_score_scaled`) — a fixed 60 scores every
        // correctly rescaled chart at ~0.5 and cries "Poor Bar Alignment".
        let alignment = compute_bar_alignment_score_scaled(&roi_crop, &hourly, applied_axis_max);
        // Image order → clock order, after every geometric step. No-op for LTR.
        orient_hours(&mut hourly, axis_direction);

        serde_json::json!({
            "pipeline_schema_version": PIPELINE_SCHEMA_VERSION,
            "success": true,
            "hourly_values": hourly,
            "axis_direction": axis_direction,
            "total": total,
            "alignment_score": alignment,
            "grid_registration_score": grid_registration,
            "title": if title.is_empty() { serde_json::Value::Null } else { title.into() },
            "total_text": if total_text.is_empty() { serde_json::Value::Null } else { total_text.into() },
            "is_daily_total": is_daily_total,
            "grid_bounds": bounds,
            "grid_confidence": grid_confidence,
            "suspected_all_devices": quality.suspected,
            "axis_max_minutes": quality.axis_max_minutes,
            "all_devices_reasons": quality.reasons,
            "ocr_error": ocr_error,
        })
        .to_string()
    } else {
        serde_json::json!({
            "pipeline_schema_version": PIPELINE_SCHEMA_VERSION,
            "success": false,
            "error": grid_error.unwrap_or_default(),
            "is_weekly": grid_is_weekly,
            "title": if title.is_empty() { serde_json::Value::Null } else { title.into() },
            "total_text": if total_text.is_empty() { serde_json::Value::Null } else { total_text.into() },
            "is_daily_total": is_daily_total,
            "suspected_all_devices": quality.suspected,
            "axis_max_minutes": quality.axis_max_minutes,
            "all_devices_reasons": quality.reasons,
            "ocr_error": ocr_error,
        })
        .to_string()
    }
}

/// Bars/scoring-only extraction for a known grid.
///
/// This is the manual grid-adjustment fast path: callers already have title and
/// total text and only need hourly bars plus framing scores recomputed for the
/// new bounds. It deliberately avoids Tesseract/leptess initialization and OCR.
///
/// No detector runs, so there is nothing to re-read the hour labels from: the
/// caller passes back the `axis_direction` stored when the screenshot was first
/// processed (an empty string, or an older caller, means Ltr).
#[allow(clippy::too_many_arguments)]
pub fn extract_bars(
    rgba: &[u8],
    width: u32,
    height: u32,
    img_type: ImageType,
    grid_ul_x: i32,
    grid_ul_y: i32,
    grid_lr_x: i32,
    grid_lr_y: i32,
    total_text: &str,
    cfg: ScoringConfig,
    axis_direction: AxisDirection,
    axis_max_minutes: i32,
) -> String {
    // The y-axis CEILING likewise comes from the first run. An hour-scaled "All
    // Devices" chart (`2h / 1h / 0`) is 120 minutes tall, and this path cannot
    // read the label because it runs no OCR — so without the stored value,
    // dragging the grid on such a screenshot would silently halve every bar it
    // had just got right. Non-positive (or an older caller passing nothing)
    // means the ordinary 60.
    let axis_max_minutes = (axis_max_minutes > 60).then_some(axis_max_minutes);
    let Some(mut img) = rgba_to_rgb_image(rgba, width, height) else {
        return json_err("RGBA size mismatch");
    };
    if width >= height {
        return json_err("Landscape orientation — capture the Screen Time chart in portrait");
    }
    if grid_ul_x < 0 || grid_ul_y < 0 || grid_lr_x <= grid_ul_x || grid_lr_y <= grid_ul_y {
        return json_err("Valid grid coordinates are required");
    }
    convert_dark_mode(&mut img);

    let bounds = GridBounds::new(grid_ul_x, grid_ul_y, grid_lr_x, grid_lr_y);
    let roi_x = bounds.roi_x() as u32;
    let roi_y = bounds.roi_y() as u32;
    let roi_w = bounds.width() as u32;
    let roi_h = bounds.height() as u32;
    if roi_x.saturating_add(roi_w) > width || roi_y.saturating_add(roi_h) > height {
        return json_err("Grid coordinates are outside the image");
    }

    let mut applied_axis_max = 60.0f64;
    let (row, residual_row) = if img_type == ImageType::Battery {
        let base = image::imageops::crop_imm(&img, roi_x, roi_y, roi_w, roi_h).to_image();
        let mut roi = base.clone();
        remove_all_but(&mut roi, [255, 121, 0], 30);
        let (v, vr) = slice_image_with_residuals(&roi, 0, 0, roi_w, roi_h);
        if v.iter().take(24).sum::<f64>() > 0.0 {
            (v, vr)
        } else {
            let mut roi2 = base;
            remove_all_but(&mut roi2, [0, 134, 255], 30);
            slice_image_with_residuals(&roi2, 0, 0, roi_w, roi_h)
        }
    } else {
        let (row, residuals, applied, _detected) = slice_with_axis_scale(
            &img,
            roi_x,
            roi_y,
            roi_w,
            roi_h,
            axis_max_minutes,
            boundary_optimizer::parse_ocr_total(total_text),
        );
        applied_axis_max = applied;
        (row, residuals)
    };

    let mut hourly: Vec<f64> = {
        let mut v = if row.len() > 24 {
            row[..24].to_vec()
        } else {
            row
        };
        v.resize(24, 0.0);
        v
    };
    let residuals: Vec<f64> = {
        let mut v = if residual_row.len() > 24 {
            residual_row[..24].to_vec()
        } else {
            residual_row
        };
        v.resize(24, 0.0);
        v
    };
    let roi_crop = image::imageops::crop_imm(&img, roi_x, roi_y, roi_w, roi_h).to_image();
    let grid_registration =
        compute_grid_registration_score_cfg(&roi_crop, cfg.grid_reg_deadband, cfg.grid_reg_tol);
    if let Some(target) = boundary_optimizer::parse_ocr_total(total_text).filter(|&m| m > 0) {
        apportion_to_total_cfg(
            &mut hourly,
            &residuals,
            target,
            grid_registration,
            cfg.apportion_max_minutes,
            cfg.apportion_max_percent,
            cfg.apportion_min_registration,
        );
    }
    let total: f64 = hourly.iter().sum();
    let alignment = compute_bar_alignment_score_scaled(&roi_crop, &hourly, applied_axis_max);
    // Image order → clock order, after every geometric step. No-op for LTR.
    orient_hours(&mut hourly, axis_direction);

    serde_json::json!({
        "pipeline_schema_version": PIPELINE_SCHEMA_VERSION,
        "success": true,
        "hourly_values": hourly,
        "axis_direction": axis_direction,
        // The ceiling these bars were MEASURED at. This path re-arbitrates the
        // stored ceiling against the printed total, so it can legitimately fall
        // back to 60 for a new ROI. Without reporting it the caller would keep a
        // stored `axis_max_minutes` of 120 over hours computed at 60 — a record
        // permanently inconsistent with its own warning, and one that feeds the
        // stale 120 back in on every subsequent grid drag.
        "applied_axis_max_minutes": applied_axis_max,
        "total": total,
        "alignment_score": alignment,
        "grid_registration_score": grid_registration,
        "grid_bounds": bounds,
    })
    .to_string()
}

/// Detect grid boundaries.
///
/// `method`: 0 = LineBased with OcrAnchored fallback (matches [`process`]),
///           1 = LineBased only (fast, no OCR — use for benchmarks).
pub fn detect_grid(rgba: &[u8], width: u32, height: u32, method: i32) -> String {
    let Some(mut img) = rgba_to_rgb_image(rgba, width, height) else {
        return json_err("RGBA size mismatch");
    };
    // Portrait-only input contract (see pipeline_process). Reject landscape frames
    // with a clear message instead of a generic "resolution not supported".
    if width >= height {
        return json_err("Landscape orientation — capture the Screen Time chart in portrait");
    }
    // Pristine copy for OcrAnchored's dark-mode adaptive-threshold OCR fallback
    // (see pipeline_process for why this matters).
    let original_img = img.clone();
    convert_dark_mode(&mut img);

    let line_result = match grid_detection::detect_grid_with_original(
        &img,
        DetectionMethod::LineBased,
        Some(&original_img),
    ) {
        Ok(r) => r,
        Err(e) => return grid_detection_error_json(&e, "line_based"),
    };

    let result = if method == 1 || line_result.success || line_result.is_weekly {
        line_result
    } else {
        match grid_detection::detect_grid_with_original(
            &img,
            DetectionMethod::OcrAnchored,
            Some(&original_img),
        ) {
            Ok(r) => r,
            Err(e) => {
                return grid_detection_error_json(&e, "ocr_anchored");
            }
        }
    };

    serde_json::to_string(&result).unwrap_or_else(|_| json_err("serialize failed"))
}

/// OCR-only extraction — no grid detection, no bar extraction.
///
/// Runs region-first Tesseract OCR to extract title and total usage text.
/// Used by EXTRACT_TITLE and EXTRACT_TOTAL to skip grid detection and bar
/// extraction when only the OCR fields are needed.
pub fn extract_ocr(rgba: &[u8], width: u32, height: u32) -> String {
    let Some(mut img) = rgba_to_rgb_image(rgba, width, height) else {
        return json_err("RGBA size mismatch");
    };
    #[cfg(feature = "ocr")]
    let original_img = img.clone();
    convert_dark_mode(&mut img);

    // Region-first title/total OCR, with full-frame fallback inside the helper.
    #[cfg(feature = "ocr")]
    let (title, total_text, ocr_error) = {
        match ocr::find_title_and_total_region_first_from_sources(&original_img, &img) {
            Ok((t, _, tot)) => (t, tot, None::<String>),
            Err(e) => (String::new(), String::new(), Some(e.to_string())),
        }
    };
    #[cfg(not(feature = "ocr"))]
    let (title, total_text, ocr_error) = (String::new(), String::new(), None::<String>);
    let is_daily_total = title == "Daily Total";

    serde_json::json!({
        "title": if title.is_empty() { serde_json::Value::Null } else { title.into() },
        "total_text": if total_text.is_empty() { serde_json::Value::Null } else { total_text.into() },
        "is_daily_total": is_daily_total,
        "ocr_error": ocr_error,
    })
    .to_string()
}

/// Full-page OCR for PHI detection. Returns every word with bbox +
/// confidence + character offsets so the JS side can map matches back to
/// image coordinates.
pub fn phi_words(rgba: &[u8], width: u32, height: u32) -> String {
    let Some(img) = rgba_to_rgb_image(rgba, width, height) else {
        return json_err("RGBA size mismatch");
    };

    #[cfg(feature = "ocr")]
    let json = match ocr::run_phi_ocr_words(&img) {
        Ok(phi_words) => {
            let mut full_text = String::new();
            let mut total_conf: i64 = 0;
            let mut counted = 0i64;

            let words: Vec<serde_json::Value> = phi_words
                .iter()
                .map(|w| {
                    let char_start = full_text.chars().count();
                    full_text.push_str(&w.text);
                    let char_end = full_text.chars().count();
                    full_text.push(' ');

                    if w.conf >= 0 {
                        total_conf += w.conf as i64;
                        counted += 1;
                    }

                    serde_json::json!({
                        "text": w.text,
                        "x": w.x,
                        "y": w.y,
                        "w": w.w,
                        "h": w.h,
                        "conf": w.conf,
                        "char_start": char_start,
                        "char_end": char_end,
                    })
                })
                .collect();

            let avg_conf = if counted > 0 {
                total_conf as f64 / counted as f64
            } else {
                0.0
            };

            serde_json::json!({
                "success": true,
                "words": words,
                "full_text": full_text.trim_end(),
                "avg_confidence": avg_conf,
            })
            .to_string()
        }
        Err(e) => json_err(&format!("OCR: {e}")),
    };
    #[cfg(not(feature = "ocr"))]
    let json = json_err("PHI OCR not available: ocr feature disabled");
    let _ = img; // silence unused on no-ocr builds

    json
}
