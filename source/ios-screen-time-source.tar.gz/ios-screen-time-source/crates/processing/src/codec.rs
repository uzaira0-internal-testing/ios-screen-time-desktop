use std::io::Cursor;

use image::{
    DynamicImage, ExtendedColorType, ImageDecoder, ImageEncoder, ImageReader, Limits, RgbaImage,
};

use crate::redaction::{RedactRegion, RedactionMethod, redact_regions_rgba};

pub const MAX_DECODED_PIXELS: u64 = 50_000_000;

#[derive(Debug, thiserror::Error)]
pub enum CodecError {
    #[error("image is too large: {width}x{height}")]
    TooLarge { width: u32, height: u32 },
    #[error("RGBA byte length does not match image dimensions")]
    InvalidRgbaLength,
    #[error("crop rectangle is empty or outside the image")]
    InvalidCrop,
    #[error(transparent)]
    Image(#[from] image::ImageError),
}

pub fn decode_rgba(bytes: &[u8]) -> Result<(u32, u32, Vec<u8>), CodecError> {
    let format = image::guess_format(bytes)?;
    let mut header = ImageReader::with_format(Cursor::new(bytes), format);
    header.no_limits();
    let (width, height) = header.into_dimensions()?;
    if u64::from(width) * u64::from(height) > MAX_DECODED_PIXELS {
        return Err(CodecError::TooLarge { width, height });
    }

    let mut limits = Limits::default();
    limits.max_image_width = Some(MAX_DECODED_PIXELS as u32);
    limits.max_image_height = Some(MAX_DECODED_PIXELS as u32);
    limits.max_alloc = Some(MAX_DECODED_PIXELS * 4);
    let mut reader = ImageReader::with_format(Cursor::new(bytes), format);
    reader.limits(limits);
    let mut decoder = reader.into_decoder()?;
    let orientation = decoder.orientation()?;
    let mut image = DynamicImage::from_decoder(decoder)?;
    image.apply_orientation(orientation);
    let (width, height) = (image.width(), image.height());
    let rgba_len = width as usize * height as usize * 4;
    let rgba = match image {
        DynamicImage::ImageLuma16(image) => {
            let mut rgba = Vec::with_capacity(rgba_len);
            for pixel in image.pixels() {
                let grey = (pixel.0[0] >> 8) as u8;
                rgba.extend_from_slice(&[grey, grey, grey, 255]);
            }
            rgba
        }
        DynamicImage::ImageLumaA16(image) => {
            let mut rgba = Vec::with_capacity(rgba_len);
            for pixel in image.pixels() {
                let grey = (pixel.0[0] >> 8) as u8;
                rgba.extend_from_slice(&[grey, grey, grey, (pixel.0[1] >> 8) as u8]);
            }
            rgba
        }
        DynamicImage::ImageRgb16(image) => {
            let mut rgba = Vec::with_capacity(rgba_len);
            for pixel in image.pixels() {
                rgba.extend_from_slice(&[
                    (pixel.0[0] >> 8) as u8,
                    (pixel.0[1] >> 8) as u8,
                    (pixel.0[2] >> 8) as u8,
                    255,
                ]);
            }
            rgba
        }
        DynamicImage::ImageRgba16(image) => {
            let mut rgba = Vec::with_capacity(rgba_len);
            for pixel in image.pixels() {
                rgba.extend_from_slice(&pixel.0.map(|sample| (sample >> 8) as u8));
            }
            rgba
        }
        image => image.to_rgba8().into_raw(),
    };
    Ok((width, height, rgba))
}

pub fn encode_png(rgba: &[u8], width: u32, height: u32) -> Result<Vec<u8>, CodecError> {
    let expected = usize::try_from(u64::from(width) * u64::from(height) * 4)
        .map_err(|_| CodecError::InvalidRgbaLength)?;
    if rgba.len() != expected {
        return Err(CodecError::InvalidRgbaLength);
    }
    let mut png = Vec::new();
    image::codecs::png::PngEncoder::new(&mut png).write_image(
        rgba,
        width,
        height,
        ExtendedColorType::Rgba8,
    )?;
    Ok(png)
}

pub fn crop_png(bytes: &[u8], x: u32, y: u32, w: u32, h: u32) -> Result<Vec<u8>, CodecError> {
    let (width, height, rgba) = decode_rgba(bytes)?;
    if w == 0
        || h == 0
        || x.checked_add(w).is_none_or(|end| end > width)
        || y.checked_add(h).is_none_or(|end| end > height)
    {
        return Err(CodecError::InvalidCrop);
    }
    let image = RgbaImage::from_raw(width, height, rgba).ok_or(CodecError::InvalidRgbaLength)?;
    let crop = image::imageops::crop_imm(&image, x, y, w, h).to_image();
    encode_png(crop.as_raw(), w, h)
}

pub fn redact_png(
    bytes: &[u8],
    regions: &[RedactRegion],
    method: RedactionMethod,
    padding: i32,
) -> Result<Vec<u8>, CodecError> {
    let (width, height, mut rgba) = decode_rgba(bytes)?;
    redact_regions_rgba(&mut rgba, width, height, regions, method, padding);
    encode_png(&rgba, width, height)
}

const DHASH_W: usize = 33;
const DHASH_H: usize = 32;

/// 1024-bit difference hash as 256 hex chars, for near-duplicate warnings.
/// The image is area-averaged to 33x32 luma cells (integer maths, so every
/// engine agrees); bit `y * 32 + x` is set when cell `x` is brighter than cell
/// `x + 1` in row `y`, and the bits are printed as one big-endian hex number.
pub fn dhash_hex(bytes: &[u8]) -> Result<String, CodecError> {
    let (width, height, rgba) = decode_rgba(bytes)?;
    let (w, h) = (width as usize, height as usize);
    let mut sum = [0u64; DHASH_W * DHASH_H];
    let mut count = [0u64; DHASH_W * DHASH_H];
    let cell_x: Vec<usize> = (0..w).map(|x| x * DHASH_W / w).collect();
    for (y, row) in rgba.chunks_exact(w * 4).enumerate() {
        let cell_row = y * DHASH_H / h * DHASH_W;
        for (px, &cx) in row.chunks_exact(4).zip(&cell_x) {
            let cell = cell_row + cx;
            sum[cell] += 299 * u64::from(px[0]) + 587 * u64::from(px[1]) + 114 * u64::from(px[2]);
            count[cell] += 1;
        }
    }
    let mut bits = [0u8; (DHASH_W - 1) * DHASH_H / 8];
    let last = bits.len() - 1;
    for y in 0..DHASH_H {
        for x in 0..DHASH_W - 1 {
            let (a, b) = (y * DHASH_W + x, y * DHASH_W + x + 1);
            // Compare cell means without dividing: a/na > b/nb.
            if sum[a] * count[b] > sum[b] * count[a] {
                let bit = y * (DHASH_W - 1) + x;
                bits[last - bit / 8] |= 1 << (bit % 8);
            }
        }
    }
    Ok(bits.iter().map(|b| format!("{b:02x}")).collect())
}

#[cfg(test)]
mod tests {
    use image::EncodableLayout;

    use super::*;

    #[test]
    fn png_round_trip_preserves_rgba() {
        let rgba = [0, 1, 2, 3, 250, 240, 230, 255, 17, 34, 51, 0, 4, 5, 6, 128];
        let png = encode_png(&rgba, 2, 2).unwrap();
        assert_eq!(decode_rgba(&png).unwrap(), (2, 2, rgba.to_vec()));
    }

    #[test]
    fn png_16_bit_rgb_and_luma_use_high_bytes() {
        let rgb = image::ImageBuffer::<image::Rgb<u16>, Vec<u16>>::from_raw(
            2,
            1,
            vec![0x12ab, 0x34cd, 0x56ef, 0xff00, 0x00ff, 0x8001],
        )
        .unwrap();
        let mut rgb_png = Vec::new();
        image::codecs::png::PngEncoder::new(&mut rgb_png)
            .write_image(rgb.as_raw().as_bytes(), 2, 1, ExtendedColorType::Rgb16)
            .unwrap();
        assert_eq!(
            decode_rgba(&rgb_png).unwrap(),
            (2, 1, vec![0x12, 0x34, 0x56, 255, 0xff, 0x00, 0x80, 255])
        );

        let luma =
            image::ImageBuffer::<image::Luma<u16>, Vec<u16>>::from_raw(2, 1, vec![0x01fe, 0xfe01])
                .unwrap();
        let mut luma_png = Vec::new();
        image::codecs::png::PngEncoder::new(&mut luma_png)
            .write_image(luma.as_raw().as_bytes(), 2, 1, ExtendedColorType::L16)
            .unwrap();
        assert_eq!(
            decode_rgba(&luma_png).unwrap(),
            (2, 1, vec![0x01, 0x01, 0x01, 255, 0xfe, 0xfe, 0xfe, 255])
        );
    }

    #[test]
    fn crop_matches_source_rectangle() {
        let rgba: Vec<u8> = (0..4)
            .flat_map(|y| (0..5).flat_map(move |x| [x, y, x + y, 255]))
            .collect();
        let png = encode_png(&rgba, 5, 4).unwrap();
        let crop = crop_png(&png, 1, 1, 3, 2).unwrap();
        let expected: Vec<u8> = (1..3)
            .flat_map(|y| (1..4).flat_map(move |x| [x, y, x + y, 255]))
            .collect();
        assert_eq!(decode_rgba(&crop).unwrap(), (3, 2, expected));
        assert!(matches!(
            crop_png(&png, 4, 0, 2, 1),
            Err(CodecError::InvalidCrop)
        ));
    }

    #[test]
    fn redact_png_fills_only_the_padded_region() {
        let rgba: Vec<u8> = (0..4)
            .flat_map(|y| (0..5).flat_map(move |x| [x, y, x + y, 255]))
            .collect();
        let png = encode_png(&rgba, 5, 4).unwrap();
        let region = RedactRegion {
            x: 2,
            y: 1,
            w: 1,
            h: 1,
        };
        let out = redact_png(&png, &[region], RedactionMethod::RedBox, 1).unwrap();
        let (_, _, got) = decode_rgba(&out).unwrap();
        for y in 0..4u8 {
            for x in 0..5u8 {
                let i = (usize::from(y) * 5 + usize::from(x)) * 4;
                let inside = (1..=3).contains(&x) && y <= 2;
                let want = if inside {
                    [255, 0, 0, 255]
                } else {
                    [x, y, x + y, 255]
                };
                assert_eq!(got[i..i + 4], want, "pixel {x},{y}");
            }
        }
    }

    #[test]
    fn dhash_sets_one_bit_per_brighter_left_neighbour() {
        let (w, h) = (66u32, 64u32);
        let pixel = |x: u32, y: u32| {
            // Row band 0 falls left to right; every other row rises.
            let v = if y < 2 {
                255 - x as u8 * 3
            } else {
                x as u8 * 3
            };
            [v, v, v, 255]
        };
        let rgba: Vec<u8> = (0..h)
            .flat_map(|y| (0..w).flat_map(move |x| pixel(x, y)))
            .collect();
        let hash = dhash_hex(&encode_png(&rgba, w, h).unwrap()).unwrap();
        assert_eq!(hash, format!("{}{}", "0".repeat(248), "f".repeat(8)));

        let flat = encode_png(&[9, 9, 9, 255].repeat(40 * 40), 40, 40).unwrap();
        assert_eq!(dhash_hex(&flat).unwrap(), "0".repeat(256));
    }

    #[test]
    fn oversized_header_is_rejected_before_decode() {
        let mut png = encode_png(&[0, 0, 0, 255], 1, 1).unwrap();
        png[16..20].copy_from_slice(&10_000_u32.to_be_bytes());
        png[20..24].copy_from_slice(&10_000_u32.to_be_bytes());
        let mut crc = !0_u32;
        for &byte in &png[12..29] {
            crc ^= u32::from(byte);
            for _ in 0..8 {
                crc = if crc & 1 != 0 {
                    (crc >> 1) ^ 0xedb8_8320
                } else {
                    crc >> 1
                };
            }
        }
        png[29..33].copy_from_slice(&(!crc).to_be_bytes());
        assert!(matches!(
            decode_rgba(&png),
            Err(CodecError::TooLarge {
                width: 10_000,
                height: 10_000
            })
        ));
    }
}
