//! Resolution lookup helpers for known iPhone screen dimensions.
//!
//! Port of Python line_based_detection/strategies/lookup.py.
//!
//! The table itself is the shared SSoT (`shared/lookup_table.json` →
//! `generated_constants::RESOLUTION_LOOKUP_TABLE`); this module only provides the
//! grid-detection-facing lookup helpers over it. It previously kept a SECOND
//! hand-maintained copy that silently drifted from the JSON — so resolutions added
//! to the JSON (e.g. 1179x2556, the iPhone 14 Pro/15/15 Pro) never reached the
//! line-based detector and it failed on those phones. Delegating here keeps the two
//! in lockstep.

pub use crate::generated_constants::LookupEntry;
use crate::generated_constants::RESOLUTION_LOOKUP_TABLE;

/// Max portrait-aspect-ratio gap (|Δ(longSide/shortSide)|) for the proportional
/// fallback to fire. ~0.06 spans the entire modern Face-ID / Dynamic-Island
/// iPhone family (iPhone X 2.165 … 16 Pro Max 2.173) yet excludes 16:9
/// home-button phones (~1.78) and 4:3 iPads (~1.33), whose chart layout differs
/// enough that scaling would mis-frame. Beyond it we decline and let OcrAnchored
/// handle it — exactly today's behaviour for an unsupported resolution.
const FALLBACK_ASPECT_TOL: f64 = 0.06;

/// Native, full-screen (uncropped) iPhone resolutions used as scaling references
/// for the proportional fallback. Restricting the reference pool to these is what
/// keeps the fallback ACCURATE: the table also holds cropped-iPad strips (e.g.
/// `1258x2732` = an iPad Pro 12.9″ with its 790-px sidebar removed) whose portrait
/// aspect ratio collides with the iPhone band (~2.17) but whose chart layout
/// differs (width/W ≈ 0.81 vs the iPhone 0.75) — scaling from one would mis-frame
/// every Pro/Pro Max phone. These six span the modern iPhone layout: 750×1334
/// (16:9 home-button, x/W 0.080) and 828/1170/1179/1206/1320 (notch + Dynamic
/// Island, x/W ≈ 0.077, width/W ≈ 0.751). The actual bound numbers are still read from the
/// SSoT table by key — this list only curates which rows may serve as a template.
const CANONICAL_IPHONE_REFS: [&str; 6] = [
    "750x1334",
    "828x1792",
    "1170x2532",
    "1179x2556",
    "1206x2622",
    "1320x2868",
];

/// Look up grid bounds for a given resolution.
pub fn lookup_resolution(width: u32, height: u32) -> Option<&'static LookupEntry> {
    let key = format!("{width}x{height}");
    RESOLUTION_LOOKUP_TABLE.get(key.as_str())
}

/// Get partial bounds (x, width, height) for hints to other strategies.
///
/// Exact table hit wins (most accurate). On a miss, derive the bounds by
/// proportionally scaling the nearest-aspect-ratio known entry — see
/// [`derive_partial_bounds`].
pub fn get_partial_bounds(width: u32, height: u32) -> Option<(i32, i32, i32)> {
    lookup_resolution(width, height)
        .map(|e| (e.x, e.width, e.height))
        .or_else(|| derive_partial_bounds(width, height))
}

fn parse_resolution_key(key: &str) -> Option<(u32, u32)> {
    let (w, h) = key.split_once('x')?;
    Some((w.parse().ok()?, h.parse().ok()?))
}

/// Round half away from zero (all inputs here are positive, so round-half-up).
/// Matches Python's `math.floor(v + 0.5)` exactly so the Rust and Python
/// detectors derive byte-identical bounds (parity is gated).
fn round_half_up(v: f64) -> i32 {
    (v + 0.5).floor() as i32
}

/// Derive (x, width, height) for an UNKNOWN resolution by proportionally scaling
/// the known entry whose portrait aspect ratio is closest (ties broken by the
/// lexically-smallest "WxH" key, so Rust and Python pick the SAME reference
/// regardless of hash-map order).
///
/// iOS lays the Screen Time chart out with Auto Layout, so the chart's left
/// margin (x), width, and bar-zone height are near-constant FRACTIONS of the
/// screen within an aspect-ratio family — measured x/W ≈ 0.077 and width/W ≈
/// 0.751 across 828-, 1170-, and 1179-wide phones. Scaling those fractions
/// reaches every current and future iPhone resolution (16 Pro 1206×2622, Pro Max
/// 1290/1320, iPhone Air 1260×2736, 12/13 mini 1080×2340, …) without a
/// hand-entered row. A wrong guess simply fails the downstream
/// horizontal-line / vertical-line / bar-colour validation in `line_based` and
/// falls back to OcrAnchored — so robustness rises with no accuracy risk, and
/// the curated table stays the authoritative source for measured resolutions.
fn derive_partial_bounds(width: u32, height: u32) -> Option<(i32, i32, i32)> {
    // Ask FIRST whether the table already holds this exact width. Cropping removes
    // rows and resizes nothing, so a taller row of the same width is this frame's
    // own device, measured, at ratio 1 — there is nothing a scaled neighbour can
    // add to that. Answering from a neighbour instead is how a cropped `1258x2732`
    // (an iPad Pro 12.9" with its sidebar removed, whose chart is width/W 0.81
    // against the iPhone's 0.75) came back as (100, 945, 282) in place of its own
    // (80, 1020, 180) — a bar zone 57% too tall.
    //
    // This has to run ahead of the aspect scan, not just ahead of the crop path.
    // A shallow crop still LOOKS like its parent, so it clears FALLBACK_ASPECT_TOL
    // and never reaches `derive_cropped_bounds`: `1258x2731`, one row of trim, was
    // scaled to (114, 938, 257) while `1258x2000` — deep enough to fail the aspect
    // gate — was answered correctly. Which of the two paths a crop landed on
    // decided whether it got its own device's numbers, which is no rule at all.
    if let Some(own) = table_row_for_crop(width, height) {
        return Some((own.x, own.width, own.height));
    }

    let qw = width.min(height) as f64;
    let qh = width.max(height) as f64;
    let q_aspect = qh / qw;

    // Scan ONLY the curated native-iPhone references (ties broken by the
    // lexically-smallest key so Rust and Python agree regardless of order).
    let mut best: Option<(f64, &str, &LookupEntry)> = None;
    for key in CANONICAL_IPHONE_REFS {
        let Some(entry) = RESOLUTION_LOOKUP_TABLE.get(key) else {
            continue; // reference absent from the table — skip, never invent bounds
        };
        let Some((rw, rh)) = parse_resolution_key(key) else {
            continue;
        };
        let rw_p = rw.min(rh) as f64;
        let rh_p = rw.max(rh) as f64;
        let dist = (q_aspect - rh_p / rw_p).abs();
        let better = match best {
            None => true,
            Some((best_dist, best_key, _)) => {
                dist < best_dist || (dist == best_dist && key < best_key)
            }
        };
        if better {
            best = Some((dist, key, entry));
        }
    }

    let (dist, key, entry) = best?;
    if dist > FALLBACK_ASPECT_TOL {
        return derive_cropped_bounds(width, height);
    }
    let (rw, rh) = parse_resolution_key(key)?;
    let rw_p = rw.min(rh) as f64;
    let rh_p = rw.max(rh) as f64;
    let h_scale = qw / rw_p; // x and width track screen WIDTH
    let v_scale = qh / rh_p; // bar-zone height tracks screen HEIGHT
    Some((
        round_half_up(entry.x as f64 * h_scale),
        round_half_up(entry.width as f64 * h_scale),
        round_half_up(entry.height as f64 * v_scale),
    ))
}

/// Widest and narrowest a capture may be relative to its scaling reference.
///
/// Aspect ratio cannot gate a cropped frame — trim enough off the bottom and a
/// real capture goes square (this batch contains a genuine `1320x1464`, aspect
/// 1.11) — so WIDTH carries the whole burden of deciding whether a frame came
/// off an iPhone. Cropping does not resize, so the width should still be a
/// device width, and the reference chosen is always the one nearest it. Outside
/// the band we decline, which is what keeps a bogus frame from being handed
/// plausible-looking bounds.
///
/// The top was 1.15 when the widest phone had no reference of its own and had to
/// be reached from 1179 (1320/1179 = 1.12). Adding 1206 and 1320 to
/// [`CANONICAL_IPHONE_REFS`] retired that stretch and left the ceiling behind as
/// dead slack: 1320 x 1.15 = 1518, wide enough to swallow an iPad. A 1488x2266
/// iPad mini — and the 1500x1600 frame this guard was written to refuse — were
/// both handed iPhone proportions instead. Measured against its NEAREST
/// reference no real phone needs more than 1242/1206 = 1.030, so 1.05 keeps
/// every device with room to spare while restoring the refusal.
///
/// This band only ever decides frames of an UNKNOWN width. A width the table
/// already measures is answered by [`table_row_for_crop`] before the scan runs,
/// so tightening here cannot cost the 896- and 906-wide rows that reach their
/// nearest reference only at 1.082 and 1.094.
const CROP_WIDTH_SCALE: (f64, f64) = (0.93, 1.05);

/// The table row a vertically-cropped frame came from: same width, and the
/// SHORTEST row still taller than the frame.
///
/// Nearest-taller, not lexically-first: the key is a string, so `"1028x2224"`
/// sorts before `"1028x980"` and a plain key compare would reach past a nearer
/// row to a taller one whenever two heights differ in digit count. Every
/// same-width group in the table happens to carry identical bounds today, so the
/// distinction is currently unobservable — which is exactly why it should be
/// stated in the rule rather than left to the data. Heights tie-break on the
/// lexically-smallest key so Rust and Python still pick the same row regardless
/// of map iteration order.
fn table_row_for_crop(width: u32, height: u32) -> Option<&'static LookupEntry> {
    let mut best: Option<(u32, &str, &LookupEntry)> = None;
    for (key, entry) in RESOLUTION_LOOKUP_TABLE.iter() {
        let Some((rw, rh)) = parse_resolution_key(key) else {
            continue;
        };
        // Only a row this frame could be a crop OF: same width, more rows.
        if rw != width || rh <= height {
            continue;
        }
        let better = match best {
            None => true,
            Some((best_h, best_key, _)) => rh < best_h || (rh == best_h && *key < best_key),
        };
        if better {
            best = Some((rh, key, entry));
        }
    }
    best.map(|(_, _, entry)| entry)
}

/// Derive bounds for a capture the user CROPPED — a native-width screenshot with
/// its height cut, which the aspect gate above rejects.
///
/// Half this batch of real participant captures arrives this way: `1206x1854`
/// where the device is `1206x2622`, `1290x2601` where it is `1290x2796`. The
/// aspect collapses (1.54 against the iPhone band's ~2.17) so the proportional
/// fallback declines, the resolution is not in the table, and `line_based` gives
/// up — dropping the capture onto `OcrAnchored`, which measured 1 exact result in
/// 65 against `line_based`'s 79 in 92.
///
/// Cropping does not resize anything: the chart's pixels are exactly what the
/// device rendered, so the bar-zone height is a function of the screen WIDTH,
/// not of how much of the screenshot survived. Scaling all three values by the
/// width ratio is therefore the correct rule — and it is the same rule the
/// uncropped path already applies to x and width. It is not used for uncropped
/// captures, whose two ratios agree anyway, so nothing measured changes.
///
/// Only a SHORTER-than-native frame qualifies. A frame taller than its aspect
/// family was not produced by cropping, and guessing at it would be inventing
/// bounds rather than recovering them.
fn derive_cropped_bounds(width: u32, height: u32) -> Option<(i32, i32, i32)> {
    let qw = width.min(height) as f64;
    let q_aspect = width.max(height) as f64 / qw;

    let mut best: Option<(f64, &str, &LookupEntry, f64)> = None;
    for key in CANONICAL_IPHONE_REFS {
        let Some(entry) = RESOLUTION_LOOKUP_TABLE.get(key) else {
            continue; // reference absent from the table — skip, never invent bounds
        };
        let Some((rw, rh)) = parse_resolution_key(key) else {
            continue;
        };
        let rw_p = rw.min(rh) as f64;
        let ref_aspect = rw.max(rh) as f64 / rw_p;
        // A crop only ever removes rows, so the frame must be SHORTER than the
        // reference's proportions, never taller.
        if q_aspect >= ref_aspect {
            continue;
        }
        let scale = qw / rw_p;
        if scale < CROP_WIDTH_SCALE.0 || scale > CROP_WIDTH_SCALE.1 {
            continue;
        }
        // Closest width wins; ties break on the lexically-smallest key so Rust
        // and Python pick the same reference regardless of map order.
        let dist = (scale - 1.0).abs();
        let better = match best {
            None => true,
            Some((best_dist, best_key, _, _)) => {
                dist < best_dist || (dist == best_dist && key < best_key)
            }
        };
        if better {
            best = Some((dist, key, entry, scale));
        }
    }

    let (_, _, entry, scale) = best?;

    Some((
        round_half_up(entry.x as f64 * scale),
        round_half_up(entry.width as f64 * scale),
        round_half_up(entry.height as f64 * scale),
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_lookup_known_resolution() {
        let entry = lookup_resolution(1170, 2532);
        assert!(entry.is_some());
        let e = entry.unwrap();
        assert_eq!(e.x, 90);
        assert_eq!(e.width, 880);
        assert_eq!(e.height, 270);
    }

    #[test]
    fn test_lookup_unknown_resolution() {
        let entry = lookup_resolution(999, 999);
        assert!(entry.is_none());
    }

    #[test]
    fn test_exact_hit_skips_fallback() {
        // A measured entry must come through untouched, not via scaling.
        assert_eq!(get_partial_bounds(1179, 2556), Some((90, 885, 270)));
    }

    #[test]
    fn test_proportional_fallback_iphone_air() {
        // 1260×2736 is NOT in the table; it must be derived by scaling the
        // nearest-aspect entry. 1206×2622 and 1320×2868 used to be derived the
        // same way and are now measured rows, so the proportional path is
        // exercised here instead.
        assert!(
            lookup_resolution(1260, 2736).is_none(),
            "1260x2736 must not be an exact hit, or this no longer tests derivation"
        );
        let (x, w, h) = get_partial_bounds(1260, 2736).expect("iPhone Air must derive");
        // Nearest curated aspect is 1320x2868 (2.1727 vs 2.1714); x and width
        // scale by WIDTH, the bar zone by HEIGHT.
        assert_eq!(x, round_half_up(120.0 * 1260.0 / 1320.0));
        assert_eq!(w, round_half_up(984.0 * 1260.0 / 1320.0));
        assert_eq!(h, round_half_up(270.0 * 2736.0 / 2868.0));
        // width/W is the stable family fraction (0.745-0.752 across every
        // curated reference); the left margin is NOT — it measures 0.076 on the
        // 1179 and 0.091 on the 1320 — so only the former is pinned as a band.
        assert!((w as f64 / 1260.0 - 0.748).abs() < 0.006);
    }

    #[test]
    fn measured_rows_beat_the_proportional_guess() {
        // 1206×2622 and 1320×2868 were derived from 1179×2556 until this batch
        // measured them: 26 and 39 captures agreed on x to the pixel. The rows
        // hold the measurement, and — being curated references now — a CROPPED
        // capture of either scales from its own device at ratio 1 instead of
        // from a neighbour 27 or 141 px narrower.
        assert_eq!(
            lookup_resolution(1206, 2622).map(|e| (e.x, e.width)),
            Some((96, 906))
        );
        assert_eq!(
            lookup_resolution(1320, 2868).map(|e| (e.x, e.width)),
            Some((120, 984))
        );
        assert_eq!(derive_partial_bounds(1206, 1854), Some((96, 906, 270)));
        assert_eq!(derive_partial_bounds(1320, 1464), Some((120, 984, 270)));
    }

    #[test]
    fn test_proportional_fallback_covers_modern_iphones() {
        // Every common modern iPhone resolution must now resolve (was None).
        for (w, h) in [
            (1206, 2622),
            (1290, 2796),
            (1320, 2868),
            (1260, 2736),
            (1080, 2340),
        ] {
            assert!(get_partial_bounds(w, h).is_some(), "{w}x{h} should derive");
        }
    }

    #[test]
    fn cropped_captures_scale_from_screen_width() {
        // Real participant captures: a native-width screenshot with its height
        // cut. The aspect gate rejects these, so before this they reached
        // OcrAnchored, which measured 1 exact result in 65.
        // Values are pinned so the Python twin cannot drift.
        assert_eq!(derive_partial_bounds(1206, 1854), Some((96, 906, 270)));
        assert_eq!(derive_partial_bounds(1290, 2601), Some((117, 962, 264)));
        assert_eq!(derive_partial_bounds(1179, 1885), Some((90, 885, 270)));
        assert_eq!(derive_partial_bounds(1170, 1935), Some((90, 880, 270)));
        // Trim enough off the bottom and a genuine capture goes square — width,
        // not aspect, is what says this came off an iPhone.
        assert_eq!(derive_partial_bounds(1320, 1464), Some((120, 984, 270)));
    }

    #[test]
    fn cropped_fallback_leaves_uncropped_captures_alone() {
        // The aspect path still owns every native frame. 1206x2622 and
        // 1320x2868 are now MEASURED table rows, so a crop of either scales from
        // its own device at ratio 1 rather than from a neighbour.
        assert_eq!(get_partial_bounds(1206, 2622), Some((96, 906, 270)));
        assert_eq!(get_partial_bounds(1320, 2868), Some((120, 984, 270)));
        assert_eq!(derive_partial_bounds(1179, 2556), Some((90, 885, 270)));
    }

    /// The band's ceiling exists to refuse frames that did not come off a phone.
    /// It was sized when 1320 had to be reached from 1179 (= 1.12); once 1206 and
    /// 1320 became references that stretch was dead slack, and 1320 x 1.15 = 1518
    /// let iPad widths through — including the exact frame the guard was written
    /// to refuse.
    #[test]
    fn the_crop_band_still_refuses_a_frame_no_phone_is_that_wide() {
        assert_eq!(get_partial_bounds(1488, 2266), None, "iPad mini 6");
        assert_eq!(get_partial_bounds(1500, 1600), None, "not a capture");
        // ...while every real phone width still resolves, cropped or not.
        assert_eq!(get_partial_bounds(1206, 1854), Some((96, 906, 270)));
        assert_eq!(get_partial_bounds(1290, 2601), Some((117, 962, 264)));
        assert_eq!(get_partial_bounds(1179, 2556), Some((90, 885, 270)));
    }

    /// A vertical crop changes neither x nor width, so when the table holds a row
    /// of exactly this width that row IS the answer — scaling a curated iPhone
    /// instead handed a cropped iPad strip a bar zone 57% too tall.
    ///
    /// At EVERY depth. The rule used to sit inside the cropped path, which only
    /// runs once a frame has failed the aspect gate, so a shallow crop that still
    /// looked like its parent was scaled from a neighbour instead: `1258x2731`
    /// came back as (114, 938, 257) while `1258x2000` was answered correctly.
    #[test]
    fn a_cropped_frame_uses_its_own_devices_row_when_the_table_has_one() {
        let own_1258 = lookup_resolution(1258, 2732).unwrap();
        let want_1258 = Some((own_1258.x, own_1258.width, own_1258.height));
        for h in [2731, 2600, 2400, 2200, 2000, 1800, 1464] {
            assert_eq!(get_partial_bounds(1258, h), want_1258, "1258x{h}");
        }
        // Widths whose nearest reference is further than the crop band allows are
        // reached the same way — the band never decides a width the table holds.
        assert_eq!(get_partial_bounds(896, 1433), Some((70, 670, 180)));
        assert_eq!(get_partial_bounds(906, 1512), Some((70, 690, 180)));
        assert_eq!(get_partial_bounds(990, 1800), Some((80, 740, 180)));
        assert_eq!(get_partial_bounds(848, 1800), Some((70, 640, 180)));

        let own_1274 = lookup_resolution(1274, 2752).unwrap();
        assert_eq!(
            get_partial_bounds(1274, 2000),
            Some((own_1274.x, own_1274.width, own_1274.height))
        );
        // The crop path proper still declines a width it cannot reach from any
        // reference; the own-row rule sits above it, not inside it.
        assert!(derive_cropped_bounds(1000, 1100).is_none());
    }

    /// Same width, nearest height — not the lexically-first key. `"1028x2224"`
    /// sorts before `"1028x980"`, so a plain string compare would reach past a
    /// nearer row whenever two heights differ in digit count.
    #[test]
    fn a_crop_is_matched_to_the_nearest_taller_row_not_the_first_key() {
        // Every same-width group in the shipped table carries identical bounds, so
        // pin the rule on the selection itself.
        let near = table_row_for_crop(1028, 2300).expect("1028 rows exist");
        let far = lookup_resolution(1028, 2388).unwrap();
        assert_eq!(
            (near.x, near.width, near.height),
            (far.x, far.width, far.height)
        );
        // A frame taller than every row of its width is not a crop of any of them.
        assert!(table_row_for_crop(1028, 9999).is_none());
        assert!(table_row_for_crop(1027, 100).is_none());
    }

    #[test]
    fn cropped_fallback_declines_a_frame_that_is_not_iphone_wide() {
        // No iPhone is 1000 px across, so this is not a cropped capture.
        assert!(derive_cropped_bounds(1000, 1100).is_none());
        // Taller than its family: a crop removes rows, it never adds them.
        assert!(derive_cropped_bounds(1179, 4000).is_none());
    }

    #[test]
    fn test_fallback_declines_foreign_aspect() {
        // A 4:3 iPad-native frame (aspect 1.33) is too far from any iPhone entry
        // and from the cropped-iPad strips — must decline, not mis-scale.
        assert!(
            get_partial_bounds(2048, 2732).is_none() || lookup_resolution(2048, 2732).is_some()
        );
        // 1000 is NOT a bogus width — `1000x2360` is a measured row — so a
        // 1000-wide frame is answered from its own device however deep the trim.
        // (This assertion used to read `is_none()`, on the stated grounds that
        // "no iPhone is 1000 px across"; the table disagrees.)
        assert_eq!(derive_partial_bounds(1000, 1100), Some((80, 790, 180)));
    }

    #[test]
    fn test_new_ipad_m4_m5_cropped_entries_are_exact() {
        // iPad Pro 11" M4/M5 crops 1668→1028 wide (same as older 11"), taller panel.
        assert_eq!(get_partial_bounds(1028, 2420), Some((80, 820, 180)));
        // iPad Pro 13" M4/M5 crops 2064→1274 wide.
        assert_eq!(get_partial_bounds(1274, 2752), Some((81, 1033, 180)));
        // These must come through as EXACT entries, never the iPhone fallback —
        // their x/W (~0.078) and width/W (~0.80) are the iPad layout, not iPhone.
        assert!(lookup_resolution(1028, 2420).is_some());
        assert!(lookup_resolution(1274, 2752).is_some());
    }

    #[test]
    fn test_fallback_is_deterministic() {
        // Repeated calls must yield identical results despite HashMap iteration
        // order (tie-break on lexically-smallest key).
        let a = get_partial_bounds(1206, 2622);
        let b = get_partial_bounds(1206, 2622);
        assert_eq!(a, b);
    }
}
