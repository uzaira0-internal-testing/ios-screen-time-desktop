//! Line detection strategies — horizontal and vertical grid line analysis.
//!
//! Port of Python strategies/horizontal_lines.py and strategies/vertical_lines.py.
//!
//! Optimized: uses raw RGB buffer indexing instead of get_pixel() and avoids
//! allocating a full grayscale image (computes luma inline).

use image::RgbImage;

/// Gray value range for detecting grid lines.
const GRAY_MIN: u8 = 195;
const GRAY_MAX: u8 = 210;
/// Minimum percentage of row width that must be gray for horizontal line detection.
const MIN_WIDTH_PCT: f64 = 0.35;
/// Gray range for vertical lines (slightly wider).
const V_GRAY_MIN: u8 = 190;
const V_GRAY_MAX: u8 = 215;
/// Gray range for the chart's left/right edge lines (boundary refinement).
const EDGE_GRAY_MIN: u8 = 190;
const EDGE_GRAY_MAX: u8 = 220;
/// Minimum percentage of column height for vertical line detection.
const MIN_HEIGHT_PCT: f64 = 0.4;
/// Maximum spacing deviation (pixels) for evenly-spaced lines.
const MAX_SPACING_DEVIATION: i32 = 10;
/// Maximum pixel width of a vertical grid line. Real dotted grid lines are 1-4 px
/// thin; a solid bar is ~20-30 px wide. In light mode bars are excluded by color so
/// every detected column-run is already thin (this filter is a no-op); in dark mode
/// bars convert to the *same black ink* as grid lines, so width is the only
/// theme-agnostic way to tell a thin grid line from a fat bar.
const MAX_VERTICAL_LINE_WIDTH: i32 = 8;

/// Dark-mode grid-line ink window. After `convert_dark_mode`, the keep-dark-gray
/// clause collapses inverted gray hairlines onto near-black (`[0,0,0]`, luma ≈ 0,
/// chroma 0) while the colored bars invert to a *bright, saturated* color
/// (luma ≳ 150, high chroma). So a dark-mode grid line is "dark AND achromatic":
/// `max_luma` rejects the bright bars, `max_chroma` rejects any colored pixel that
/// happens to be dark. Mirrored in the Python `line_based_detection` strategies and
/// pinned by the Rust↔Python parity gate.
const DARK_GRIDLINE_MAX_LUMA: u8 = 120;
const DARK_GRIDLINE_MAX_CHROMA: u8 = 40;

/// Dark-mode grid-line ink window for the PRISTINE (pre-`convert_dark_mode`) image,
/// expressed as a step above the measured card background instead of an absolute
/// band. iOS draws the card at luma 28 and the hairline separator at 58 (Δ30); a
/// phone rendering dark mode brighter draws the same pair at 36 and 84 (Δ48).
/// `convert_dark_mode`'s keep-dark-gray clause is anchored at a FIXED inverted gray
/// (197 ± 17, i.e. raw 41..75), so it collapses the first pair to black ink but sends
/// the second through the contrast LUT, where card and hairline both saturate to
/// white and the grid is simply gone. Measuring the background per image is what
/// makes the classifier survive that. Mirrored in the Python
/// `line_based_detection` strategies and pinned by the Rust↔Python parity gate.
const DARK_RAW_MIN_DELTA: u8 = 12;
const DARK_RAW_MAX_DELTA: u8 = 70;

/// Theme-aware classifier deciding whether a pixel is grid-line "ink".
///
/// iOS draws grid lines as faint *light-gray* hairlines in light mode, so a narrow
/// luma band cleanly isolates them from the darker bars and text. After
/// `convert_dark_mode` the picture inverts: grid lines collapse onto the near-black
/// achromatic class and the bars become bright and saturated, so the discriminator
/// becomes chroma, not a luma band.
///
/// Injecting this classifier is what lets ONE line detector serve both themes — the
/// light-mode gray band is a *special case*, not a universal pixel rule baked into
/// the hot loop. Callers pick the variant from the source image's theme (see
/// `line_based::detect_themed`); the strategies depend only on this abstraction.
#[derive(Debug, Clone, Copy)]
pub enum LineInk {
    /// Light mode: grid lines fall in the narrow gray luma band `[min, max]`
    /// (bars/text are darker and fall below it).
    GrayBand { min: u8, max: u8 },
    /// Dark mode (post-`convert_dark_mode`): grid lines are the near-black achromatic
    /// class; bars are rejected by `max_luma`/`max_chroma`.
    DarkGray { max_luma: u8, max_chroma: u8 },
    /// Dark mode read on the PRISTINE capture: grid lines are the achromatic band a
    /// fixed step above the card background (see `DARK_RAW_MIN_DELTA`). Bars are
    /// rejected by `max_chroma`, bright text by `max_luma`.
    DarkRelative {
        min_luma: u8,
        max_luma: u8,
        max_chroma: u8,
    },
}

impl LineInk {
    /// Classifier for horizontal grid-line rows.
    #[inline]
    pub fn horizontal(dark_mode: bool) -> Self {
        if dark_mode {
            Self::DarkGray {
                max_luma: DARK_GRIDLINE_MAX_LUMA,
                max_chroma: DARK_GRIDLINE_MAX_CHROMA,
            }
        } else {
            Self::GrayBand {
                min: GRAY_MIN,
                max: GRAY_MAX,
            }
        }
    }

    /// Classifier for vertical dotted-line columns.
    #[inline]
    pub fn vertical(dark_mode: bool) -> Self {
        if dark_mode {
            Self::DarkGray {
                max_luma: DARK_GRIDLINE_MAX_LUMA,
                max_chroma: DARK_GRIDLINE_MAX_CHROMA,
            }
        } else {
            Self::GrayBand {
                min: V_GRAY_MIN,
                max: V_GRAY_MAX,
            }
        }
    }

    /// Classifier for the chart's left/right vertical edges (boundary refinement).
    #[inline]
    pub fn edge(dark_mode: bool) -> Self {
        if dark_mode {
            Self::DarkGray {
                max_luma: DARK_GRIDLINE_MAX_LUMA,
                max_chroma: DARK_GRIDLINE_MAX_CHROMA,
            }
        } else {
            Self::GrayBand {
                min: EDGE_GRAY_MIN,
                max: EDGE_GRAY_MAX,
            }
        }
    }

    /// Classifier for a pristine dark-mode capture whose card background measures
    /// `background` (see [`background_luma`]).
    #[inline]
    pub fn dark_relative(background: u8) -> Self {
        Self::DarkRelative {
            min_luma: background.saturating_add(DARK_RAW_MIN_DELTA),
            max_luma: background.saturating_add(DARK_RAW_MAX_DELTA),
            max_chroma: DARK_GRIDLINE_MAX_CHROMA,
        }
    }

    /// True if the pixel `(r, g, b)` belongs to a grid line under this classifier.
    #[inline(always)]
    pub fn matches(self, r: u8, g: u8, b: u8) -> bool {
        match self {
            LineInk::GrayBand { min, max } => {
                let luma = fast_luma(r, g, b);
                min <= luma && luma <= max
            }
            LineInk::DarkGray {
                max_luma,
                max_chroma,
            } => {
                let luma = fast_luma(r, g, b);
                let chroma = r.max(g).max(b) - r.min(g).min(b);
                luma <= max_luma && chroma <= max_chroma
            }
            LineInk::DarkRelative {
                min_luma,
                max_luma,
                max_chroma,
            } => {
                let luma = fast_luma(r, g, b);
                let chroma = r.max(g).max(b) - r.min(g).min(b);
                min_luma <= luma && luma <= max_luma && chroma <= max_chroma
            }
        }
    }
}

/// The page behind the card is true black; the card it sits on is not.
///
/// Levels below this are the page, never the surface a grid line is drawn on, so
/// the mode is taken from here up. iOS renders the dark card at #1C1C1E (luma 28)
/// and the page at #000000, and across 78 real dark captures the modal level was
/// 28 in every one — so nothing measured moves, and the floor only decides the
/// case where the page would otherwise outvote the card.
const CARD_LUMA_FLOOR: usize = 8;

/// The top of the same band. A dark card is dark: iOS draws the base surface at
/// luma 28 and its most elevated one still well under 100. Bars, white text and
/// the status bar are far above that, so bounding the search keeps the floor from
/// answering with something that is emphatically not a background — see
/// [`background_luma`].
const CARD_LUMA_CEILING: usize = 96;

/// Modal gray level of an image — the card surface a dark-mode grid line is drawn on.
///
/// The card covers over half of every dark capture measured, so the histogram peak is
/// it (the true-black page behind the card is the runner-up). Ties resolve to the
/// darkest level, matching Python's `np.bincount(...).argmax()`.
///
/// That margin is real but not wide — measured worst case the page holds 82% of the
/// card's pixel count — and the ink window is derived from whatever this returns.
/// Let the page win and the window becomes one that classifies the CARD as grid-line
/// ink: every row of it then looks identical, `row_stands_out` finds nothing, and a
/// perfectly good dark capture fails to detect a grid at all. A capture with a short
/// app list, or one scrolled past the end of it, is all it would take. Since this
/// function wants the card by definition, [`CARD_LUMA_FLOOR`] keeps the page out of
/// the running rather than leaving the answer to an area contest.
pub fn background_luma(img: &RgbImage) -> u8 {
    let mut hist = [0u32; 256];
    for px in img.as_raw().chunks_exact(3) {
        hist[fast_luma(px[0], px[1], px[2]) as usize] += 1;
    }
    let mut mode = 0usize;
    for (level, &count) in hist.iter().enumerate() {
        if count > hist[mode] {
            mode = level;
        }
    }
    // The ordinary answer, and the only one on every capture measured.
    if mode >= CARD_LUMA_FLOOR {
        return mode as u8;
    }
    // The page won the area contest. Look for a card in the band a card can
    // actually occupy — NOT simply "the most common level that is not the page",
    // which on a frame that is mostly page black with a white status bar returns
    // 255 and makes `dark_relative` saturate the ink window to [255, 255]: no row
    // then reads as grid ink and the capture detects nothing at all, which is the
    // very failure this floor exists to prevent, relocated to another input.
    let mut card = CARD_LUMA_FLOOR;
    for (level, &count) in hist
        .iter()
        .enumerate()
        .take(CARD_LUMA_CEILING + 1)
        .skip(CARD_LUMA_FLOOR)
    {
        if count > hist[card] {
            card = level;
        }
    }
    // No card in that band — a genuinely sub-floor surface, or an all-black
    // frame. The page IS the background then; answer as before.
    if hist[card] == 0 {
        return mode as u8;
    }
    card as u8
}

/// Compute BT.601 luma from RGB, matching canvas `Math.round(R*0.299 + G*0.587 + B*0.114)`.
/// Uses high-precision integer coefficients (19595/65536 ≈ 0.299, 38469/65536 ≈ 0.587,
/// 7472/65536 ≈ 0.114) with rounding via +32768 before >> 16.
#[inline(always)]
pub fn fast_luma(r: u8, g: u8, b: u8) -> u8 {
    ((r as u32 * 19595 + g as u32 * 38469 + b as u32 * 7472 + 32768) >> 16) as u8
}

/// A group of evenly-spaced horizontal lines.
#[derive(Debug, Clone)]
pub struct LineGroup {
    pub y_start: i32,
    pub y_end: i32,
    pub num_lines: usize,
    pub mean_spacing: f64,
    pub max_deviation: f64,
    pub height_score: f64,
    pub lines: Vec<i32>,
}

/// Find horizontal grid lines in an image region.
///
/// Uses direct buffer access instead of get_pixel() and computes
/// grayscale inline to avoid allocating a separate GrayImage.
pub fn find_horizontal_lines(img: &RgbImage, x_start: u32, x_end: u32, ink: LineInk) -> Vec<i32> {
    let (w, h) = img.dimensions();
    let region_w = x_end.saturating_sub(x_start);
    if region_w == 0 {
        return Vec::new();
    }

    let raw = img.as_raw();
    let stride = w as usize * 3; // bytes per row
    let threshold = (region_w as f64 * MIN_WIDTH_PCT) as u32;

    let mut coverage = vec![0u32; h as usize];
    for (y, cell) in coverage.iter_mut().enumerate() {
        let row_offset = y * stride;
        let mut gray_count = 0u32;
        for x in x_start..x_end {
            let idx = row_offset + x as usize * 3;
            if ink.matches(raw[idx], raw[idx + 1], raw[idx + 2]) {
                gray_count += 1;
            }
        }
        *cell = gray_count;
    }

    let mut line_positions = Vec::new();
    for y in 0..h as usize {
        if coverage[y] <= threshold {
            continue;
        }
        if row_stands_out(&coverage, y, region_w) {
            line_positions.push(y as i32);
        }
    }

    cluster_positions(&line_positions, 3)
}

/// Rows this far above/below are the local background a hairline must stand out from.
/// The inner bound skips the line's own anti-aliased shoulder; the outer one stays
/// clear of the next grid line (~67 px away on a real chart, and 10 px apart in the
/// synthetic lattices the unit tests use).
const ROW_BACKGROUND_NEAR: usize = 4;
const ROW_BACKGROUND_FAR: usize = 8;
/// How much of the scanned width a grid line must beat its local background by.
const ROW_PEAK_MARGIN: f64 = 0.25;

/// Does row `y` read as a hairline rather than part of a tall band?
///
/// A grid line is a 1-3 px spike: the rows a few pixels above and below it are
/// chart background. A BAR is a plateau — hundreds of rows at a similar coverage.
/// Coverage alone cannot tell them apart when the bars are drawn in a pale tint
/// that falls inside the light-mode gray band (measured: a capture whose bars sit
/// at luma 210, the top of the band, put 200 consecutive rows over the 35%
/// threshold). Merging that band yields one phantom line at its centre, which
/// breaks the even-spacing search and hides the real five-line lattice; dropping
/// the band wholesale would take the real lines inside it too. Requiring a row to
/// beat its own neighbourhood keeps exactly the spikes — including the ones drawn
/// across a bar, which is where they matter.
fn row_stands_out(coverage: &[u32], y: usize, region_w: u32) -> bool {
    let mut background = 0u32;
    let mut seen = false;
    for offset in ROW_BACKGROUND_NEAR..=ROW_BACKGROUND_FAR {
        for probe in [y.checked_sub(offset), y.checked_add(offset)] {
            if let Some(p) = probe
                && p < coverage.len()
            {
                background = background.max(coverage[p]);
                seen = true;
            }
        }
    }
    if !seen {
        return true; // nothing to compare against at the frame edge
    }
    (coverage[y] as f64 - background as f64) > ROW_PEAK_MARGIN * region_w as f64
}

/// Find groups of evenly-spaced horizontal lines.
pub fn find_evenly_spaced_groups(lines: &[i32], expected_height: Option<i32>) -> Vec<LineGroup> {
    let min_lines = 4usize;
    let max_lines = 8usize;
    let mut groups = Vec::new();

    for start_idx in 0..lines.len().saturating_sub(min_lines - 1) {
        let end_max = (start_idx + max_lines + 1).min(lines.len() + 1);
        for end_idx in (start_idx + min_lines)..end_max {
            let group = &lines[start_idx..end_idx];
            let spacings: Vec<i32> = group.windows(2).map(|w| w[1] - w[0]).collect();
            let mean_spacing: f64 = spacings.iter().sum::<i32>() as f64 / spacings.len() as f64;
            let max_dev = spacings
                .iter()
                .map(|&s| (s as f64 - mean_spacing).abs())
                .fold(0.0f64, f64::max);

            if max_dev > MAX_SPACING_DEVIATION as f64 {
                continue;
            }
            if !(20.0..=150.0).contains(&mean_spacing) {
                continue;
            }

            let height_score = if let Some(expected) = expected_height {
                let group_height = group.last().unwrap() - group.first().unwrap();
                let error = (group_height - expected).abs() as f64;
                (1.0 - error / expected as f64).max(0.5)
            } else {
                1.0
            };

            groups.push(LineGroup {
                y_start: *group.first().unwrap(),
                y_end: *group.last().unwrap(),
                num_lines: group.len(),
                mean_spacing,
                max_deviation: max_dev,
                height_score,
                lines: group.to_vec(),
            });
        }
    }

    // Sort: most lines DESC, height_score DESC, max_deviation ASC
    // (matches Python: key=lambda g: (-g["num_lines"], -g["height_score"], g["max_deviation"]))
    groups.sort_by(|a, b| {
        b.num_lines
            .cmp(&a.num_lines)
            .then(b.height_score.partial_cmp(&a.height_score).unwrap())
            .then(a.max_deviation.partial_cmp(&b.max_deviation).unwrap())
    });

    // Remove overlapping groups
    let mut non_overlapping = Vec::new();
    for g in &groups {
        let overlaps = non_overlapping.iter().any(|existing: &LineGroup| {
            let start = g.y_start.max(existing.y_start);
            let end = g.y_end.min(existing.y_end);
            end > start
        });
        if !overlaps {
            non_overlapping.push(g.clone());
        }
    }

    non_overlapping
}

/// Count vertical dotted lines in a region and return their x-positions.
///
/// Uses direct buffer access for speed.
pub fn count_vertical_lines(
    img: &RgbImage,
    x_start: u32,
    width: u32,
    y_start: u32,
    y_end: u32,
    ink: LineInk,
) -> (usize, Vec<i32>) {
    let (w, _h) = img.dimensions();
    let region_h = y_end.saturating_sub(y_start);
    if region_h == 0 || width == 0 {
        return (0, Vec::new());
    }

    let raw = img.as_raw();
    let stride = w as usize * 3;
    let threshold = (region_h as f64 * MIN_HEIGHT_PCT) as u32;

    let mut positions = Vec::new();

    for x in x_start..(x_start + width).min(w) {
        let mut gray_count = 0u32;
        for y in y_start..y_end.min(img.height()) {
            let idx = y as usize * stride + x as usize * 3;
            if ink.matches(raw[idx], raw[idx + 1], raw[idx + 2]) {
                gray_count += 1;
            }
        }
        if gray_count > threshold {
            positions.push(x as i32);
        }
    }

    // Cluster nearby columns (gap ≤ 5), dropping clusters wider than a grid line —
    // those are solid bars, which in dark mode share the grid lines' black ink.
    let clusters = cluster_thin_columns(&positions, 5, MAX_VERTICAL_LINE_WIDTH);
    (clusters.len(), clusters)
}

/// Cluster nearby column positions (merge within `max_gap`) and return cluster
/// centers, but DROP any cluster whose pixel span exceeds `max_width`. A thin
/// vertical grid line spans a few pixels; a solid bar spans ~20-30, so width is
/// what separates a grid line from a bar once they share a color (dark mode).
fn cluster_thin_columns(positions: &[i32], max_gap: i32, max_width: i32) -> Vec<i32> {
    if positions.is_empty() {
        return Vec::new();
    }
    let mut clusters = Vec::new();
    let mut start = 0usize;
    for i in 1..=positions.len() {
        let is_break = i == positions.len() || positions[i] - positions[i - 1] > max_gap;
        if is_break {
            let run = &positions[start..i];
            let span = run[run.len() - 1] - run[0];
            if span <= max_width {
                // Same Math.round mean as cluster_positions (canvas parity).
                let mean = (run.iter().sum::<i32>() as f64 / run.len() as f64).round() as i32;
                clusters.push(mean);
            }
            start = i;
        }
    }
    clusters
}

/// Validate that a region matches daily chart vertical line pattern.
///
/// Returns (is_daily, confidence, v_count, v_positions).
pub fn validate_vertical_lines(
    img: &RgbImage,
    x_start: u32,
    width: u32,
    y_start: u32,
    y_end: u32,
    ink: LineInk,
) -> (bool, f64, usize, Vec<i32>) {
    let (v_count, v_positions) = count_vertical_lines(img, x_start, width, y_start, y_end, ink);

    // Expected: 3-5 vertical lines (daily chart)
    if !(3..=5).contains(&v_count) {
        return (false, 0.0, v_count, v_positions);
    }

    if v_positions.len() < 2 {
        return (false, 0.0, v_count, v_positions);
    }

    // Check spacing ≈ width/4
    let spacings = restore_dropped_gridlines(&v_positions);
    let mean_spacing: f64 = spacings.iter().sum::<i32>() as f64 / spacings.len() as f64;
    let expected_spacing = width as f64 / 4.0;

    let spacing_error = (mean_spacing - expected_spacing).abs() / expected_spacing;
    if spacing_error > 0.25 {
        return (false, 0.0, v_count, v_positions);
    }

    // Check consistency
    let max_deviation = spacings
        .iter()
        .map(|&s| (s as f64 - mean_spacing).abs())
        .fold(0.0f64, f64::max);
    if max_deviation > mean_spacing * 0.15 {
        return (false, 0.0, v_count, v_positions);
    }

    let confidence =
        (0.8 + (1.0 - spacing_error) * 0.1 + (1.0 - max_deviation / mean_spacing) * 0.1).min(0.99);

    (true, confidence, v_count, v_positions)
}

/// Gaps between the daily chart's vertical gridlines, with a gap that spans a
/// gridline the detector missed split back into two.
///
/// iOS draws the day chart's verticals at the quarter positions, so a clean read
/// is four equal gaps. A single faint line going undetected leaves a gap of
/// double width — `[6, 222, 653, 869]` is the quarter lattice with the one at
/// ~437 missing — and the evenness check below then rejects a perfectly good
/// daily chart. Measured on five captures from a participant batch, every one of
/// which was a Day view that got hard-rejected as "weekly" because a genuine
/// weekly summary chart elsewhere on the same page was the only candidate left.
///
/// Splitting is deliberately narrow: only a gap within 15% of exactly twice the
/// smallest gap is split, so a weekly lattice (seven or eight evenly spaced
/// lines, no double gaps) is untouched, and a genuinely irregular pattern still
/// fails.
fn restore_dropped_gridlines(positions: &[i32]) -> Vec<i32> {
    let raw: Vec<i32> = positions.windows(2).map(|w| w[1] - w[0]).collect();
    let Some(&unit) = raw.iter().filter(|&&s| s > 0).min() else {
        return raw;
    };
    raw.iter()
        .flat_map(|&gap| {
            if ((gap as f64) - 2.0 * unit as f64).abs() <= 0.15 * 2.0 * unit as f64 {
                vec![gap / 2, gap - gap / 2]
            } else {
                vec![gap]
            }
        })
        .collect()
}

/// How far past one lattice unit the bars may run before the ink below the last
/// gridline stops looking like the missing bottom row of the same chart.
const BASELINE_UNIT_TOLERANCE: f64 = 0.25;
/// Fraction of the scanned width that must be bar-coloured for a row to count as
/// "still inside the bars".
const BASELINE_MIN_INK_FRAC: f64 = 0.02;
/// Luma step between the baseline and the card background below it. Measured 47
/// (dark) and 56 (light); JPEG noise on flat background stays under 10.
const BASELINE_MIN_LUMA_STEP: i32 = 16;

/// The plot's bottom, corrected to the baseline the BARS actually sit on.
///
/// The daily chart has five gridlines (0/15/30/45/60), and the 0-line is the one
/// that goes missing: it is drawn under the bars and under the hour labels, and
/// on a dark capture it can fall below the ink window entirely. Losing it does
/// not fail detection — four lines is still a valid evenly-spaced group — it
/// silently frames the plot one unit short, at 202 px instead of 270. Every bar
/// is then measured from the 15-minute line instead of from zero AND scaled as
/// if 202 px were the full hour, so a 30-minute bar reads 20. Measured on two
/// participant captures whose bar ink ran 68 px past the "bottom" gridline and
/// stopped exactly one unit below it.
///
/// The bars are the evidence: they are drawn from the baseline up, so ink
/// continuing below the last gridline and stopping within a quarter unit of
/// exactly one unit down is the missing row. The returned bottom is placed on
/// the LATTICE (`y_end + unit`), not on the last inked pixel — the pitch is what
/// sets the scale, and antialiasing moves the ink by a pixel or two.
///
/// Returns `None` unless every part of that evidence holds, so a chart whose
/// baseline was found (nothing below it) is untouched.
pub fn extend_to_bar_baseline(
    img: &RgbImage,
    x_start: u32,
    width: u32,
    y_end: u32,
    unit: f64,
) -> Option<u32> {
    let (img_w, img_h) = img.dimensions();
    if unit <= 1.0 || y_end + 1 >= img_h {
        return None;
    }
    let raw = img.as_raw();
    let stride = img_w as usize * 3;
    let x_end = (x_start + width).min(img_w);
    if x_end <= x_start {
        return None;
    }
    let needed = ((x_end - x_start) as f64 * BASELINE_MIN_INK_FRAC).max(1.0) as u32;

    let inked = |y: u32| -> bool {
        let row_off = y as usize * stride;
        let mut count = 0u32;
        for x in x_start..x_end {
            let idx = row_off + x as usize * 3;
            let (_, s, v) = rgb_to_hsv(raw[idx], raw[idx + 1], raw[idx + 2]);
            if s >= COLOR_MIN_SATURATION && v >= COLOR_MIN_VALUE {
                count += 1;
                if count >= needed {
                    return true;
                }
            }
        }
        false
    };

    // Nothing below the last gridline: the baseline was found. Leave it alone.
    if !inked(y_end + 1) {
        return None;
    }
    // Search PAST the acceptance window on purpose: ink that fills the whole
    // window has not stopped, and must fail the check below rather than land on
    // its edge.
    let limit =
        ((y_end as f64 + unit * (1.0 + 2.0 * BASELINE_UNIT_TOLERANCE)) as u32).min(img_h - 1);
    let mut last = y_end;
    let mut terminated = false;
    for y in (y_end + 1)..=limit {
        if !inked(y) {
            terminated = true;
            break;
        }
        last = y;
    }
    // The ink has to STOP about one unit down. Running the whole way to the
    // search limit means it is something else — a legend, a second chart, a
    // block of colour — not the bottom row of this lattice.
    let run = (last - y_end) as f64;
    if !terminated || (run - unit).abs() > unit * BASELINE_UNIT_TOLERANCE {
        return None;
    }
    // The lattice sets the bottom, then the real baseline corrects it by a row or
    // two when it is there to be seen. iOS pitches the gridlines 67.5 px apart, so
    // the three gaps that survive average 67.33 and `y_end + round(unit)` lands ONE
    // ROW ABOVE the baseline: measured on a busy dark capture (lines at
    // 1385/1452/1520/1587, estimate 1654, baseline at 1655), where that cut the
    // lowest row off all 23 bars.
    //
    // The baseline is recognised without the line-ink band, because the band is
    // what lost it: in dark mode the 0-line is drawn brighter than the interior
    // gridlines (luma 83 on a 36 background, where the band tops out lower), so
    // only 31% of it matched. What marks it is that it runs under every gutter: it
    // differs from the card background below the chart across the WHOLE width,
    // where a bar row differs only where there are bars (64% on that capture).
    let lattice = y_end + unit.round() as u32;
    if lattice >= img_h {
        return None;
    }
    let lo = lattice.saturating_sub(2);
    let hi = (lattice + 2).min(img_h - 1);
    if lo > hi {
        return None;
    }
    let reference = (hi + 3).min(img_h - 1);
    let luma_at = |x: u32, y: u32| -> i32 {
        let idx = y as usize * stride + x as usize * 3;
        fast_luma(raw[idx], raw[idx + 1], raw[idx + 2]) as i32
    };
    let differs = |y: u32| -> u32 {
        (x_start..x_end)
            .filter(|&x| (luma_at(x, y) - luma_at(x, reference)).abs() > BASELINE_MIN_LUMA_STEP)
            .count() as u32
    };
    let best = (lo..=hi)
        // Ties go to the LOWER row: the baseline sits under the bars.
        .max_by_key(|&y| (differs(y), std::cmp::Reverse(y.abs_diff(lattice)), y))
        .unwrap_or(lattice);
    let is_baseline = differs(best) as f64 >= (x_end - x_start) as f64 * 0.9;
    Some(if is_baseline { best } else { lattice })
}

/// Cluster nearby integer positions (merge positions within max_gap).
pub fn cluster_positions(positions: &[i32], max_gap: i32) -> Vec<i32> {
    if positions.is_empty() {
        return Vec::new();
    }

    let mut clusters = Vec::new();
    let mut current_cluster = vec![positions[0]];

    for &pos in &positions[1..] {
        if pos - current_cluster.last().unwrap() <= max_gap {
            current_cluster.push(pos);
        } else {
            let mean = (current_cluster.iter().sum::<i32>() as f64 / current_cluster.len() as f64)
                .round() as i32;
            clusters.push(mean);
            current_cluster = vec![pos];
        }
    }

    let mean =
        (current_cluster.iter().sum::<i32>() as f64 / current_cluster.len() as f64).round() as i32;
    clusters.push(mean);

    clusters
}

// ---------------------------------------------------------------------------
// Color validation — reject Pickups charts (cyan bars) vs daily (blue bars)
// ---------------------------------------------------------------------------

use crate::image_utils::rgb_to_hsv;

/// HSV hue ranges (OpenCV convention: H 0-180)
const BLUE_HUE_MIN: u8 = 100;
const BLUE_HUE_MAX: u8 = 130;
const CYAN_HUE_MIN: u8 = 80;
const _CYAN_HUE_MAX: u8 = 100; // used as BLUE_HUE_MIN boundary in validate_bar_colors
const COLOR_MIN_SATURATION: u8 = 50;
const COLOR_MIN_VALUE: u8 = 50;
const MIN_BLUE_RATIO: f64 = 0.5;

/// Validate that a region contains blue bars (daily chart) not cyan (pickups).
///
/// Port of Python `ColorValidationStrategy.validate_region()`.
/// Returns (is_daily, confidence).
pub fn validate_bar_colors(
    img: &RgbImage,
    x_start: u32,
    width: u32,
    y_start: u32,
    y_end: u32,
) -> (bool, f64) {
    let (img_w, img_h) = img.dimensions();
    let raw = img.as_raw();
    let stride = img_w as usize * 3;

    let mut blue_count = 0u32;
    let mut cyan_count = 0u32;

    let x_end = (x_start + width).min(img_w);
    let y_end = y_end.min(img_h);

    for y in y_start..y_end {
        let row_off = y as usize * stride;
        for x in x_start..x_end {
            let idx = row_off + x as usize * 3;
            let (h, s, v) = rgb_to_hsv(raw[idx], raw[idx + 1], raw[idx + 2]);

            // Only consider colored pixels
            if s < COLOR_MIN_SATURATION || v < COLOR_MIN_VALUE {
                continue;
            }

            if (BLUE_HUE_MIN..=BLUE_HUE_MAX).contains(&h) {
                blue_count += 1;
            } else if (CYAN_HUE_MIN..BLUE_HUE_MIN).contains(&h) {
                cyan_count += 1;
            }
        }
    }

    let total = blue_count + cyan_count;

    if total == 0 {
        // No blue or cyan bars — might be empty chart or gray bars, allow it
        return (true, 0.6);
    }

    let blue_ratio = blue_count as f64 / total as f64;
    let is_daily = blue_ratio >= MIN_BLUE_RATIO;

    let confidence = if is_daily {
        (0.7 + (blue_ratio - MIN_BLUE_RATIO) * 0.6).min(0.99)
    } else {
        0.0
    };

    (is_daily, confidence)
}

#[cfg(test)]
mod tests {

    #[test]
    fn review_baseline_requires_ink_termination_in_image() {
        let mut img = RgbImage::from_pixel(120, 1710, image::Rgb([255, 255, 255]));
        for y in 1654..1710 {
            for x in 10..90 {
                img.put_pixel(x, y, image::Rgb([0, 134, 255]));
            }
        }
        assert_eq!(extend_to_bar_baseline(&img, 10, 100, 1653, 68.0), None);
    }

    /// The page is not the card. Let it win the area contest and the ink window
    /// derived from it classifies the CARD as grid-line ink — every row of the card
    /// then looks identical, no horizontal lines are found, and a good dark capture
    /// detects no grid at all. Measured worst case on real captures the page holds
    /// 82% of the card's pixels, so this is decided by a floor rather than by which
    /// happens to cover more of the frame.
    #[test]
    fn the_page_behind_the_card_never_wins_the_background() {
        // A dark capture whose black page outnumbers its card.
        let mut img = RgbImage::from_pixel(100, 100, image::Rgb([28, 28, 30]));
        for y in 0..70 {
            for x in 0..100 {
                img.put_pixel(x, y, image::Rgb([0, 0, 0]));
            }
        }
        assert_eq!(background_luma(&img), 28, "page black outvoted the card");

        // ...and the ordinary case is unchanged.
        let mut card_heavy = RgbImage::from_pixel(100, 100, image::Rgb([28, 28, 30]));
        for y in 0..30 {
            for x in 0..100 {
                card_heavy.put_pixel(x, y, image::Rgb([0, 0, 0]));
            }
        }
        assert_eq!(background_luma(&card_heavy), 28);

        // Light mode is untouched.
        let light = RgbImage::from_pixel(100, 100, image::Rgb([255, 255, 255]));
        assert_eq!(background_luma(&light), 255);

        // Nothing but page black: no card to find, answer as before rather than
        // reporting a level the image does not contain.
        let all_black = RgbImage::from_pixel(10, 10, image::Rgb([0, 0, 0]));
        assert_eq!(background_luma(&all_black), 0);
    }

    /// The floor lifts the page out of the running; it must not put something
    /// brighter than any card in its place. "Most common level that is not the
    /// page" answers 255 on a frame that is mostly page black with a white status
    /// strip, and `dark_relative` then saturates the ink window to [255, 255] —
    /// no row reads as grid ink and the capture detects nothing, which is the
    /// exact failure the floor exists to prevent, moved to another input.
    #[test]
    fn a_frame_with_no_card_is_not_handed_the_status_bar_instead() {
        // Overwhelmingly page black, with a thin bright strip.
        let mut strip = RgbImage::from_pixel(100, 100, image::Rgb([0, 0, 0]));
        for y in 0..2 {
            for x in 0..100 {
                strip.put_pixel(x, y, image::Rgb([255, 255, 255]));
            }
        }
        assert_eq!(
            background_luma(&strip),
            0,
            "status bar answered as background"
        );

        // A card that genuinely renders below the floor keeps its own level: the
        // floor only ever overrides the page, never a real surface.
        let mut sub_floor = RgbImage::from_pixel(100, 100, image::Rgb([5, 5, 5]));
        for y in 0..35 {
            for x in 0..100 {
                sub_floor.put_pixel(x, y, image::Rgb([0, 0, 0]));
            }
        }
        for y in 95..100 {
            for x in 0..100 {
                sub_floor.put_pixel(x, y, image::Rgb([255, 255, 255]));
            }
        }
        assert_eq!(background_luma(&sub_floor), 5);

        // Bars are not a background either — they sit above the card band.
        let mut bars = RgbImage::from_pixel(100, 100, image::Rgb([3, 3, 3]));
        for y in 0..30 {
            for x in 0..100 {
                bars.put_pixel(x, y, image::Rgb([0, 0, 0]));
            }
        }
        for y in 80..100 {
            for x in 0..100 {
                bars.put_pixel(x, y, image::Rgb([100, 130, 200]));
            }
        }
        assert_eq!(background_luma(&bars), 3);
    }
    use super::*;

    #[test]
    fn test_cluster_positions() {
        let positions = vec![10, 11, 12, 30, 31, 50];
        let clusters = cluster_positions(&positions, 3);
        assert_eq!(clusters.len(), 3);
        assert_eq!(clusters[0], 11); // round(33/3) = 11
        assert_eq!(clusters[1], 31); // round(61/2) = round(30.5) = 31 (matches canvas Math.round)
        assert_eq!(clusters[2], 50);
    }

    #[test]
    fn test_cluster_positions_empty() {
        let clusters = cluster_positions(&[], 3);
        assert!(clusters.is_empty());
    }

    #[test]
    fn test_cluster_positions_single() {
        let clusters = cluster_positions(&[42], 3);
        assert_eq!(clusters, vec![42]);
    }

    #[test]
    fn test_fast_luma() {
        assert_eq!(fast_luma(255, 255, 255), 255);
        assert_eq!(fast_luma(0, 0, 0), 0);
        assert_eq!(fast_luma(200, 200, 200), 200);
    }

    // Parity tests: verify fast_luma matches canvas cvtColorToGray formula
    // Canvas: Math.round(R*0.299 + G*0.587 + B*0.114)
    // Rust:   (R*77 + G*150 + B*29) >> 8
    // These differ from simple (R+G+B)/3 for non-gray pixels.
    #[test]
    fn parity_fast_luma_bt601_non_gray() {
        // (200, 100, 50): canvas = round(59.8+58.7+5.7) = round(124.2) = 124
        assert_eq!(fast_luma(200, 100, 50), 124);
        // (100, 200, 50): canvas = round(29.9+117.4+5.7) = round(153.0) = 153
        assert_eq!(fast_luma(100, 200, 50), 153);
        // (50, 50, 200): canvas = round(14.95+29.35+22.8) = round(67.1) = 67
        assert_eq!(fast_luma(50, 50, 200), 67);
    }

    // Parity tests: cluster_positions uses Math.round (not integer truncation)
    // Canvas: Math.round(current.reduce((a,b) => a+b, 0) / current.length)
    #[test]
    fn parity_cluster_positions_rounds_to_nearest() {
        // [10, 11] → mean=10.5 → round=11 (not 10 from truncation)
        let result = cluster_positions(&[10, 11], 3);
        assert_eq!(result, vec![11]);

        // [10, 12, 13] → mean=11.667 → round=12 (not 11 from truncation)
        let result = cluster_positions(&[10, 12, 13], 3);
        assert_eq!(result, vec![12]);

        // [10, 11, 12, 13] → mean=11.5 → round=12 (not 11 from truncation)
        let result = cluster_positions(&[10, 11, 12, 13], 3);
        assert_eq!(result, vec![12]);
    }

    /// A white 20x50 frame with a 2-px hairline at y=20 drawn at `luma`.
    ///
    /// The line has to be a LINE: `find_horizontal_lines` keeps only rows that beat
    /// their own neighbourhood (see `row_stands_out`), so a frame flooded edge to
    /// edge with band-gray is a bar, not fifty hairlines, and detecting nothing in
    /// it is the documented behaviour rather than a band failure.
    #[cfg(test)]
    fn hairline_frame(luma: u8) -> image::RgbImage {
        image::RgbImage::from_fn(20, 50, |_, y| {
            if (20..22).contains(&y) {
                image::Rgb([luma, luma, luma])
            } else {
                image::Rgb([255, 255, 255])
            }
        })
    }

    // Parity: find_horizontal_lines detects rows where ≥35% of pixels have luma in [195, 210].
    // Canvas: GRAY_MIN=195, GRAY_MAX=210, MIN_WIDTH_PCT=0.35.
    #[test]
    fn parity_find_horizontal_lines_luma_195_detected() {
        // luma=195 → exactly at the lower bound of [195, 210].
        // threshold = floor(20 * 0.35) = 7; the line row has 20 matching → detected.
        let lines = find_horizontal_lines(&hairline_frame(195), 0, 20, LineInk::horizontal(false));
        assert_eq!(lines, vec![21], "luma=195 (GRAY_MIN) must be detected");
    }

    #[test]
    fn parity_find_horizontal_lines_luma_210_detected() {
        let lines = find_horizontal_lines(&hairline_frame(210), 0, 20, LineInk::horizontal(false));
        assert_eq!(lines, vec![21], "luma=210 (GRAY_MAX) must be detected");
    }

    #[test]
    fn parity_find_horizontal_lines_luma_194_rejected() {
        let lines = find_horizontal_lines(&hairline_frame(194), 0, 20, LineInk::horizontal(false));
        assert!(
            lines.is_empty(),
            "luma=194 (below GRAY_MIN=195) must not be detected"
        );
    }

    #[test]
    fn a_grid_line_drawn_across_a_pale_bar_survives() {
        // Same band, with a hairline crossing it: the line must still be found.
        let img = image::RgbImage::from_fn(20, 60, |_, y| {
            if (30..32).contains(&y) {
                image::Rgb([200, 200, 200])
            } else if (10..50).contains(&y) {
                image::Rgb([228, 228, 228]) // pale bar, just outside the band
            } else {
                image::Rgb([255, 255, 255])
            }
        });
        let lines = find_horizontal_lines(&img, 0, 20, LineInk::horizontal(false));
        assert_eq!(lines, vec![31]);
    }

    /// A chart 200px wide with blue bars rising from the baseline.
    /// `drawn_bottom` is where the bars actually stop.
    #[cfg(test)]
    fn chart_with_bars(top: u32, drawn_bottom: u32) -> image::RgbImage {
        image::RgbImage::from_fn(200, drawn_bottom + 60, |x, y| {
            // Bars end on the row ABOVE the baseline, as iOS draws them.
            if y >= top && y < drawn_bottom && (20..180).contains(&x) {
                image::Rgb([0, 122, 255]) // iOS blue
            } else {
                image::Rgb([255, 255, 255])
            }
        })
    }

    #[test]
    fn the_bars_put_the_bottom_back_when_the_zero_line_is_missing() {
        // The lattice came up one line short: `y_end` is the 15-minute line, and
        // the bars run on to the real baseline a unit below it.
        let unit = 68;
        let img = chart_with_bars(100, 100 + 4 * unit);
        let short_bottom = 100 + 3 * unit;
        assert_eq!(
            extend_to_bar_baseline(&img, 0, 200, short_bottom, unit as f64),
            Some(short_bottom + unit)
        );
    }

    #[test]
    fn a_half_pixel_pitch_snaps_to_the_baseline_that_is_really_there() {
        // Lines at 100/167/235/302 of a 270-px plot: the surviving gaps average
        // 67.33, so the lattice estimate is 369. The baseline is drawn at 370.
        let mut img = chart_with_bars(100, 370);
        for x in 0..200 {
            img.put_pixel(x, 370, image::Rgb([205, 205, 205]));
        }
        assert_eq!(
            extend_to_bar_baseline(&img, 0, 200, 302, 202.0 / 3.0),
            Some(370)
        );
    }

    #[test]
    fn an_estimate_past_the_frame_is_rejected_without_reading_outside_it() {
        // 118 rows tall, bars to the last row: the lattice bottom (120) is off-frame.
        let img = image::RgbImage::from_fn(200, 118, |x, y| {
            if y >= 60 && (20..180).contains(&x) {
                image::Rgb([0, 122, 255])
            } else {
                image::Rgb([255, 255, 255])
            }
        });
        assert_eq!(extend_to_bar_baseline(&img, 0, 200, 100, 20.0), None);
    }

    #[test]
    fn equal_baseline_candidates_resolve_to_the_lower_row() {
        // Full-width gray rows at 119 and 121 around a lattice estimate of 120.
        let img = image::RgbImage::from_fn(200, 160, |x, y| {
            if y == 119 || y == 121 {
                image::Rgb([205, 205, 205])
            } else if (60..=120).contains(&y) && (20..180).contains(&x) {
                image::Rgb([0, 122, 255])
            } else {
                image::Rgb([255, 255, 255])
            }
        });
        assert_eq!(extend_to_bar_baseline(&img, 0, 200, 100, 20.0), Some(121));
    }

    #[test]
    fn a_chart_whose_baseline_was_found_is_left_alone() {
        let unit = 68;
        let img = chart_with_bars(100, 100 + 4 * unit);
        // Bottom already on the baseline: nothing below it, nothing to extend.
        assert_eq!(
            extend_to_bar_baseline(&img, 0, 200, 100 + 4 * unit, unit as f64),
            None
        );
    }

    #[test]
    fn ink_that_never_stops_is_not_a_missing_gridline() {
        // A block of colour running well past a unit — a legend, a second chart —
        // must not be mistaken for the bottom row of this lattice.
        let unit = 68;
        let img = chart_with_bars(100, 100 + 8 * unit);
        assert_eq!(
            extend_to_bar_baseline(&img, 0, 200, 100 + 3 * unit, unit as f64),
            None
        );
    }

    #[test]
    fn a_pale_bar_band_is_not_a_grid_line() {
        // The 4757 capture: bars drawn at luma 210 (top of the band) put 200
        // consecutive rows over the threshold, which used to merge into one
        // phantom line at the band's centre and break the even-spacing search.
        let img = image::RgbImage::from_fn(20, 60, |_, y| {
            if (10..50).contains(&y) {
                image::Rgb([210, 210, 210])
            } else {
                image::Rgb([255, 255, 255])
            }
        });
        let lines = find_horizontal_lines(&img, 0, 20, LineInk::horizontal(false));
        assert!(lines.is_empty(), "a 40-row band is a bar, not a grid line");
    }

    #[test]
    fn parity_find_horizontal_lines_luma_211_rejected() {
        use image::RgbImage;
        let img = RgbImage::from_fn(20, 50, |_, _| image::Rgb([211, 211, 211]));
        let lines = find_horizontal_lines(&img, 0, 20, LineInk::horizontal(false));
        assert!(
            lines.is_empty(),
            "luma=211 (above GRAY_MAX=210) must not be detected"
        );
    }

    // Parity: <35% coverage → row not detected as a horizontal line.
    // threshold = floor(width * 0.35); row needs gray_count > threshold (strictly).
    #[test]
    fn parity_find_horizontal_lines_low_coverage_rejected() {
        use image::RgbImage;
        // 20-wide: threshold=7; only 7 gray pixels per row = NOT > 7 → rejected.
        let img = RgbImage::from_fn(20, 50, |x, _| {
            if x < 7 {
                image::Rgb([200, 200, 200])
            } else {
                image::Rgb([255, 255, 255])
            }
        });
        let lines = find_horizontal_lines(&img, 0, 20, LineInk::horizontal(false));
        assert!(
            lines.is_empty(),
            "exactly threshold (7) gray pixels must NOT be detected (needs >threshold)"
        );
    }

    // Parity: validate_bar_colors — pure blue (H≈120 in OpenCV) is detected as daily chart.
    // Canvas: BLUE_HUE_MIN=100, BLUE_HUE_MAX=130 in OpenCV 0-180 convention.
    #[test]
    fn parity_validate_bar_colors_blue_is_daily() {
        use image::RgbImage;
        // Pure blue (0, 0, 255): H=120, S=255 > 50, V=255 > 50 → blue_count=total → daily.
        let img = RgbImage::from_fn(100, 100, |_, _| image::Rgb([0, 0, 255]));
        let (is_daily, confidence) = validate_bar_colors(&img, 0, 100, 0, 100);
        assert!(is_daily, "pure blue bars must be detected as daily chart");
        assert!(
            confidence >= 0.7,
            "confidence must be ≥0.7 for all-blue image, got {confidence}"
        );
    }

    // Parity: cyan bars (H=80-99 in OpenCV) → not daily (Pickups chart).
    // Canvas: CYAN_HUE_MIN=80, boundary at BLUE_HUE_MIN=100.
    // Cyan (0, 255, 255): H=60*(1+2)=180° → OpenCV H=90 → in cyan range [80,100).
    #[test]
    fn parity_validate_bar_colors_cyan_is_not_daily() {
        use image::RgbImage;
        let img = RgbImage::from_fn(100, 100, |_, _| image::Rgb([0, 255, 255]));
        let (is_daily, _) = validate_bar_colors(&img, 0, 100, 0, 100);
        assert!(
            !is_daily,
            "cyan bars (H=90) must not be detected as daily chart"
        );
    }

    // Parity: no blue or cyan pixels → (true, 0.6).
    // Canvas: if (total === 0) return { isDaily: true, confidence: 0.6 }.
    #[test]
    fn parity_validate_bar_colors_no_color_returns_true_06() {
        use image::RgbImage;
        // Gray has no saturation → no colored pixels counted.
        let img = RgbImage::from_fn(100, 100, |_, _| image::Rgb([200, 200, 200]));
        let (is_daily, confidence) = validate_bar_colors(&img, 0, 100, 0, 100);
        assert!(is_daily, "no blue/cyan pixels must return is_daily=true");
        assert!(
            (confidence - 0.6).abs() < 0.01,
            "confidence must be 0.6 when no color, got {confidence}"
        );
    }

    // Parity: find_evenly_spaced_groups — spacing 20-150 px is valid range.
    // Canvas: MEAN_SPACING_MIN=20, MEAN_SPACING_MAX=150.
    #[test]
    fn parity_find_evenly_spaced_groups_valid_spacing_30() {
        // 5 lines with exact spacing=30 → mean=30, max_dev=0 → valid group.
        let lines = vec![0, 30, 60, 90, 120];
        let groups = find_evenly_spaced_groups(&lines, None);
        assert!(!groups.is_empty(), "spacing=30 must produce a valid group");
        assert_eq!(groups[0].num_lines, 5);
    }

    #[test]
    fn parity_find_evenly_spaced_groups_spacing_too_small_rejected() {
        // spacing=10 < 20 → rejected.
        let lines = vec![0, 10, 20, 30, 40];
        let groups = find_evenly_spaced_groups(&lines, None);
        assert!(groups.is_empty(), "spacing=10 (<20) must be rejected");
    }

    #[test]
    fn parity_find_evenly_spaced_groups_spacing_too_large_rejected() {
        // spacing=200 > 150 → rejected.
        let lines = vec![0, 200, 400, 600, 800];
        let groups = find_evenly_spaced_groups(&lines, None);
        assert!(groups.is_empty(), "spacing=200 (>150) must be rejected");
    }

    // Parity: max_deviation > 10 → group rejected.
    // Canvas: MAX_SPACING_DEVIATION=10; spacings [30,30,46] → max_dev=10.67 > 10 → skip.
    // Use exactly min_lines=4 so no valid subgroup can form with even spacing.
    #[test]
    fn parity_find_evenly_spaced_groups_high_deviation_rejected() {
        // [0,30,60,106]: spacings=[30,30,46]; mean=35.33; max_dev=|46-35.33|=10.67 > 10 → rejected.
        let lines = vec![0, 30, 60, 106];
        let groups = find_evenly_spaced_groups(&lines, None);
        assert!(groups.is_empty(), "max_dev=10.67 (>10) must be rejected");
    }

    // Parity: validate_vertical_lines requires 3-5 lines (inclusive).
    // Canvas: if (vCount < 3 || vCount > 5) return false.
    #[test]
    fn parity_validate_vertical_lines_count_2_rejected() {
        use image::RgbImage;
        // 2 vertical gray columns → count=2 < 3 → (false, 0.0).
        // V_GRAY_MIN=190, V_GRAY_MAX=215; threshold = floor(100 * 0.4) = 40.
        let mut img = RgbImage::from_fn(200, 100, |_, _| image::Rgb([255, 255, 255]));
        for y in 0..100 {
            img.put_pixel(20, y, image::Rgb([200, 200, 200]));
            img.put_pixel(100, y, image::Rgb([200, 200, 200]));
        }
        let (is_daily, confidence, count, _) =
            validate_vertical_lines(&img, 0, 200, 0, 100, LineInk::vertical(false));
        assert!(!is_daily, "2 vertical lines must fail (need 3-5)");
        assert_eq!(confidence, 0.0);
        assert_eq!(count, 2, "should detect exactly 2 columns");
    }

    // Parity: count_vertical_lines detects columns with luma in [190, 215].
    // Canvas: V_GRAY_MIN=190, V_GRAY_MAX=215; threshold = height * MIN_HEIGHT_PCT = 0.4.
    #[test]
    fn parity_count_vertical_lines_luma_190_detected() {
        use image::RgbImage;
        // 100-tall region: threshold = floor(100 * 0.4) = 40.
        // luma=190 is at V_GRAY_MIN; 100 gray pixels > 40 → detected.
        let mut img = RgbImage::from_fn(50, 100, |_, _| image::Rgb([255, 255, 255]));
        for y in 0..100 {
            img.put_pixel(25, y, image::Rgb([190, 190, 190]));
        }
        let (count, _) = count_vertical_lines(&img, 0, 50, 0, 100, LineInk::vertical(false));
        assert!(
            count >= 1,
            "luma=190 (V_GRAY_MIN) must be detected as vertical line"
        );
    }

    #[test]
    fn parity_count_vertical_lines_luma_189_rejected() {
        use image::RgbImage;
        let mut img = RgbImage::from_fn(50, 100, |_, _| image::Rgb([255, 255, 255]));
        for y in 0..100 {
            img.put_pixel(25, y, image::Rgb([189, 189, 189]));
        }
        let (count, _) = count_vertical_lines(&img, 0, 50, 0, 100, LineInk::vertical(false));
        assert_eq!(
            count, 0,
            "luma=189 (below V_GRAY_MIN=190) must not be detected"
        );
    }

    // --- Dark-mode classifier (LineInk::DarkGray) -------------------------------

    // After convert_dark_mode, grid lines collapse to near-black [0,0,0] (the
    // keep-dark-gray clause), so the dark classifier must accept them...
    #[test]
    fn dark_ink_accepts_near_black_gridline() {
        let ink = LineInk::horizontal(true);
        assert!(ink.matches(0, 0, 0), "pure-black grid line must match");
        assert!(ink.matches(20, 20, 20), "dark gray grid line must match");
    }

    // ...and reject the bright, saturated bars (blue inverts to yellow/orange,
    // luma ≳ 150 with high chroma) so bars are NOT mistaken for grid lines.
    #[test]
    fn dark_ink_rejects_bright_saturated_bar() {
        let ink = LineInk::vertical(true);
        // [255,255,0] yellow: luma≈226, chroma=255 — rejected on BOTH axes.
        assert!(
            !ink.matches(255, 255, 0),
            "bright yellow bar must be rejected"
        );
        // [255,124,0] orange (a typical inverted-blue bar): luma≈149 > 120.
        assert!(
            !ink.matches(255, 124, 0),
            "bright orange bar must be rejected"
        );
        // White background (luma 255) must never count as ink.
        assert!(
            !ink.matches(255, 255, 255),
            "white background must be rejected"
        );
    }

    // A dark pixel that is *colored* (low luma but saturated) is not a grid line.
    #[test]
    fn dark_ink_rejects_dark_but_saturated_pixel() {
        let ink = LineInk::horizontal(true);
        // [10, 10, 90]: luma≈22 (≤120) but chroma=80 (>40) → rejected by chroma.
        assert!(
            !ink.matches(10, 10, 90),
            "dark saturated pixel must be rejected by chroma"
        );
    }

    // A thin dotted line survives the width filter; a fat solid bar is dropped.
    #[test]
    fn cluster_thin_columns_drops_wide_bars() {
        let mut positions: Vec<i32> = vec![10, 50]; // two 1-px grid lines
        positions.extend(100..=125); // a 26-px-wide solid bar run
        let clusters = cluster_thin_columns(&positions, 5, MAX_VERTICAL_LINE_WIDTH);
        assert_eq!(
            clusters,
            vec![10, 50],
            "wide bar run must be dropped, thin grid lines kept"
        );
    }

    #[test]
    fn cluster_thin_columns_keeps_few_px_line() {
        // A 3-px-wide grid line [40,41,42] → one thin cluster at its center.
        let clusters = cluster_thin_columns(&[40, 41, 42], 5, MAX_VERTICAL_LINE_WIDTH);
        assert_eq!(clusters, vec![41]);
    }

    // count_vertical_lines must ignore a fat black bar (dark mode) and count only the
    // thin black grid lines, so a daily chart still reads 3-5 vertical lines.
    #[test]
    fn dark_vertical_lines_ignore_fat_bars() {
        use image::RgbImage;
        // 240×100 white; 4 thin black grid lines at x=20,80,140,200 (width/4≈60),
        // plus a fat black bar 25 px wide at x=100..125 spanning full height.
        let img = RgbImage::from_fn(240, 100, |x, _| {
            let line = x == 20 || x == 80 || x == 140 || x == 200;
            let bar = (100..125).contains(&x);
            if line || bar {
                image::Rgb([0, 0, 0])
            } else {
                image::Rgb([255, 255, 255])
            }
        });
        let (count, pos) = count_vertical_lines(&img, 0, 240, 0, 100, LineInk::vertical(true));
        assert_eq!(
            count, 4,
            "fat bar must be dropped; only the 4 thin grid lines counted, got {pos:?}"
        );
    }

    // End-to-end: full-width near-black rows on a white field are detected as
    // horizontal grid lines by the dark classifier (and NOT by the light one).
    #[test]
    fn dark_ink_detects_black_full_width_rows() {
        use image::RgbImage;
        // 30 wide × 50 tall, white, with black rows at y=10,20,30,40.
        let img = RgbImage::from_fn(30, 50, |_, y| {
            if y % 10 == 0 && y > 0 {
                image::Rgb([0, 0, 0])
            } else {
                image::Rgb([255, 255, 255])
            }
        });
        let dark = find_horizontal_lines(&img, 0, 30, LineInk::horizontal(true));
        assert!(
            dark.len() >= 4,
            "dark classifier must detect the black grid rows, got {dark:?}"
        );
        // The light-mode band [195,210] sees neither black rows nor white field.
        let light = find_horizontal_lines(&img, 0, 30, LineInk::horizontal(false));
        assert!(
            light.is_empty(),
            "light band must NOT detect black rows, got {light:?}"
        );
    }
}
