//! OCR-anchored grid detector — finds "12 AM" and "60" text anchors.
//!
//! Port of Python grid_anchors.py + ocr_integration.py.
//! Uses leptess (Tesseract binding) to find text anchors that mark
//! the grid boundaries, then calculates the ROI from their positions.

use image::RgbImage;
use log::{debug, info, warn};

use super::{axis_label_rect, calculate_roi, topmost_axis_minutes};
use crate::{
    image_utils::{
        adjust_contrast_brightness, convert_dark_mode_for_ocr, extract_line, get_pixel,
        is_dark_mode,
    },
    ocr::{OcrWord, run_tesseract_anchor},
    types::{AxisDirection, GridBounds, GridDetectionResult, ProcessingError},
};

/// Prepare left and right image chunks for OCR anchor detection.
///
/// Port of Python `prepare_image_chunks()`.
fn prepare_image_chunks(img: &RgbImage) -> (RgbImage, RgbImage, u32) {
    let (img_w, img_h) = img.dimensions();
    let chunk_num = 3u32;
    let top_removal = (img_h as f64 * 0.05) as u32;
    let chunk_w = img_w / chunk_num;

    // Left chunk: first 1/3
    let mut img_left = image::imageops::crop_imm(img, 0, 0, chunk_w, img_h).to_image();
    // Right chunk: last 1/3
    let mut img_right =
        image::imageops::crop_imm(img, img_w - chunk_w, 0, chunk_w, img_h).to_image();

    // Blank out top 5% with most common pixel (removes status bar)
    if let Some(bg) = get_pixel(&img_left, 1) {
        for y in 0..top_removal.min(img_h) {
            for x in 0..chunk_w {
                img_left.put_pixel(x, y, image::Rgb(bg));
            }
        }
    }
    if let Some(bg) = get_pixel(&img_right, 1) {
        for y in 0..top_removal.min(img_h) {
            for x in 0..chunk_w {
                img_right.put_pixel(x, y, image::Rgb(bg));
            }
        }
    }

    let right_offset = img_w - chunk_w;
    (img_left, img_right, right_offset)
}

/// Find the "12AM" anchor on the left side of the graph.
///
/// Port of Python `find_left_anchor()`.
fn find_left_anchor(
    ocr_boxes: &[OcrWord],
    img: &RgbImage,
    detections_to_skip: usize,
) -> Option<(i32, i32)> {
    let buffer = 25i32;
    let max_offset = 100;
    let keys = ["2A", "12", "AM"];
    let (img_w, _img_h) = img.dimensions();

    let mut detection_count = 0usize;

    for b in ocr_boxes {
        let text_upper = b.text.to_uppercase();
        if !keys.iter().any(|k| text_upper.contains(k)) {
            continue;
        }

        detection_count += 1;
        if detection_count <= detections_to_skip {
            continue;
        }

        let (x, y, w, h) = (b.x, b.y, b.w, b.h);

        // Move up to find horizontal grid line
        for offset in 0..max_offset {
            let x0 = (x - buffer).max(0) as u32;
            let x1 = ((x + w + buffer) as u32).min(img_w);
            let y0 = (y - offset as i32 - buffer).max(0) as u32;
            let y1 = ((y - offset as i32 + buffer) as u32).min(img.height());
            if x1 <= x0 || y1 <= y0 {
                continue;
            }
            let row = extract_line(img, x0, x1, y0, y1, true);
            if row > 0 {
                let lower_left_y = y - buffer + row as i32 - offset as i32;

                // Move left to find vertical grid line
                for v_offset in 0..max_offset {
                    let vx0 = (x - v_offset as i32 - buffer).max(0) as u32;
                    let vx1 = ((x - v_offset as i32 + buffer) as u32).min(img_w);
                    let vy0 = (y - buffer).max(0) as u32;
                    let vy1 = y.max(0) as u32;
                    if vx1 <= vx0 || vy1 <= vy0 {
                        continue;
                    }
                    let col = extract_line(img, vx0, vx1, vy0, vy1, false);
                    if col > 0 {
                        let lower_left_x = x - buffer + col as i32 - v_offset as i32;
                        info!(
                            "Found left anchor '12AM' at ({lower_left_x}, {lower_left_y}) from text '{}' at ({x},{y})",
                            b.text
                        );
                        return Some((lower_left_x, lower_left_y));
                    }
                }

                // Fallback: use x position directly
                return Some((x - buffer, lower_left_y));
            }
        }

        // If loop completed without finding a grid line, use text position as approximation
        return Some((x - buffer, y + h));
    }

    None
}

/// Find the "60" anchor on the right side of the graph.
///
/// Port of Python `find_right_anchor()`.
fn find_right_anchor(ocr_boxes: &[OcrWord], img: &RgbImage) -> Option<(i32, i32)> {
    let buffer = 25i32;
    let max_offset = 100;
    let keys = ["60"];
    let (img_w, _img_h) = img.dimensions();

    for b in ocr_boxes {
        let text_upper = b.text.to_uppercase();
        if !keys.iter().any(|k| text_upper.contains(k)) {
            continue;
        }

        let (x, y, _w, h) = (b.x, b.y, b.w, b.h);

        // Move up to find horizontal grid line
        for offset in 0..max_offset {
            let x0 = (x - buffer).max(0) as u32;
            let x1 = (x as u32).min(img_w);
            let y0 = (y - offset as i32).max(0) as u32;
            let y1 = ((y - offset as i32 + h + buffer) as u32).min(img.height());
            if x1 <= x0 || y1 <= y0 {
                continue;
            }
            let row = extract_line(img, x0, x1, y0, y1, true);
            if row > 0 {
                let upper_right_y = y + row as i32 - offset as i32;

                // Move left to find vertical grid line
                for v_offset in 0..max_offset {
                    let vx0 = (x - buffer - v_offset as i32).max(0) as u32;
                    let vx1 = ((x - v_offset as i32) as u32).min(img_w);
                    let vy0 = y.max(0) as u32;
                    let vy1 = ((y + h + buffer) as u32).min(img.height());
                    if vx1 <= vx0 || vy1 <= vy0 {
                        continue;
                    }
                    let col = extract_line(img, vx0, vx1, vy0, vy1, false);
                    if col > 0 {
                        let upper_right_x = x - buffer + col as i32 - v_offset as i32;
                        info!(
                            "Found right anchor '60' at ({upper_right_x}, {upper_right_y}) from text '{}' at ({x},{y})",
                            b.text
                        );
                        return Some((upper_right_x, upper_right_y));
                    }
                }

                return Some((x - buffer, upper_right_y));
            }
        }

        // Fallback: use text position
        return Some((x - buffer, y));
    }

    None
}

/// Normalise an OCR token to a bare integer string, stripping the punctuation
/// Tesseract commonly hallucinates around small isolated numerals on a chart
/// axis (`"0}"`, `"18|"`, `"60,"`).
fn bare_numeral(text: &str) -> Option<&str> {
    let t = text.trim_matches(|c: char| !c.is_ascii_digit());
    if !t.is_empty() && t.chars().all(|c| c.is_ascii_digit()) {
        Some(t)
    } else {
        None
    }
}

/// The four hour labels a 24-hour-clock locale prints under the daily chart.
const RTL_HOUR_LABELS: [&str; 4] = ["0", "6", "12", "18"];

/// Locate the hour-label row of a 24-hour-clock chart and report whether it
/// reads right-to-left.
///
/// Returns `(rightmost_hour_zero_box, is_rtl)`. Requires at least two of
/// `0/6/12/18` sharing a horizontal band, which is what distinguishes a real
/// axis from an isolated numeral elsewhere on the page — `"0"` alone is far too
/// generic to anchor on.
///
/// `min_y` discards numerals above the axis. Pass the midpoint when the words
/// come from a whole-page read; pass the top of the strip when they come from a
/// band that is already positioned on the axis — a chart can sit entirely in the
/// upper half of a tall screenshot, and the midpoint rule then throws away the
/// very labels the caller just OCR'd.
fn find_hour_axis_row<'a>(
    ocr_boxes: &'a [OcrWord],
    img: &RgbImage,
    min_y: i32,
) -> Option<(&'a OcrWord, bool)> {
    let (_img_w, img_h) = img.dimensions();

    let mut labels: Vec<(&OcrWord, i32)> = Vec::new();
    for b in ocr_boxes {
        if b.y < min_y {
            continue;
        }
        let Some(bare) = bare_numeral(&b.text) else {
            continue;
        };
        if let Some(pos) = RTL_HOUR_LABELS.iter().position(|k| *k == bare) {
            labels.push((b, pos as i32));
        }
    }
    if labels.len() < 2 {
        return None;
    }

    // Keep the largest set sharing a y-band (labels are one text line).
    let band = (img_h as f64 * 0.02).max(8.0) as i32;
    let mut best: Vec<(&OcrWord, i32)> = Vec::new();
    for (pivot, _) in &labels {
        let group: Vec<(&OcrWord, i32)> = labels
            .iter()
            .filter(|(b, _)| (b.y - pivot.y).abs() <= band)
            .copied()
            .collect();
        if group.len() > best.len() {
            best = group;
        }
    }
    if best.len() < 2 {
        return None;
    }

    // A 12-hour axis is NOT a mirrored 24-hour one. English charts label
    // `12 AM / 6 AM / 12 PM / 6 PM`, whose bare numerals read 12, 6, 12, 6 —
    // descending across the page, which votes "mirrored" and reverses a
    // perfectly ordinary English day. Measured: without this, 4 of the 38
    // corpus fixtures flipped (darkmode_daily_03, ios26_dark/IMG_7858, _7861,
    // _7872) as soon as any RTL language was enabled.
    //
    // The discriminator is the AM/PM token, not a repeated numeral: the y-axis
    // "0" shares this horizontal band with the hour labels, so repeats are
    // normal here and rejecting them killed the reference Hebrew detection
    // outright. Requiring a literal 0 or 18 fails too — under Tesseract 5.5 the
    // reference Hebrew band reads only "12)" and "6".
    if ocr_boxes.iter().any(|b| {
        (b.y - best[0].0.y).abs() <= band && {
            let t = b.text.trim().to_ascii_lowercase();
            t == "am" || t == "pm"
        }
    }) {
        return None;
    }

    // Direction: LTR prints 0,6,12,18 with x ascending; RTL mirrors it. Compare
    // label ordinal against x-position ordering across every pair.
    let mut rtl_votes = 0i32;
    let mut ltr_votes = 0i32;
    for i in 0..best.len() {
        for j in (i + 1)..best.len() {
            let (bi, oi) = best[i];
            let (bj, oj) = best[j];
            if oi == oj {
                continue;
            }
            let ascending_ordinal = oj > oi;
            let ascending_x = bj.x > bi.x;
            if ascending_ordinal == ascending_x {
                ltr_votes += 1;
            } else {
                rtl_votes += 1;
            }
        }
    }
    if rtl_votes == ltr_votes {
        return None;
    }
    let is_rtl = rtl_votes > ltr_votes;

    // The box for hour 0 — rightmost under RTL, leftmost under LTR. Reported for
    // diagnostics only: the plot rectangle comes from the gridline lattice, not
    // from this box. It must therefore NOT be a precondition. Requiring a literal
    // "0" cost a real detection: under Tesseract 5.5 the reference Hebrew
    // screenshot's axis band OCRs as "12)" and "6" with no readable zero, which is
    // ample evidence of a mirrored axis, yet direction detection returned None and
    // the whole screenshot failed. Fall back to the label at the start of the axis.
    let pick_start = |a: &'a OcrWord, b: &'a OcrWord| {
        if is_rtl {
            if b.x > a.x { b } else { a }
        } else if b.x < a.x {
            b
        } else {
            a
        }
    };
    let zero = best
        .iter()
        .filter(|(b, _)| bare_numeral(&b.text) == Some("0"))
        .map(|(b, _)| *b)
        .reduce(pick_start)
        .or_else(|| best.iter().map(|(b, _)| *b).reduce(pick_start))?;

    Some((zero, is_rtl))
}
/// A gridline pixel sits at least this far below the local background. The
/// chart lattice is drawn in light grey against a near-white card. Mirrors
/// Python `grid_anchors.py::GRIDLINE_DELTA`.
const GRIDLINE_DELTA: i32 = 8;

/// Fraction of the scanned span that must be line-dark for a row to count.
const GRIDLINE_COVERAGE: f64 = 0.6;

/// How far above/below the "60" label to hunt for the top gridline.
const GRIDLINE_SEARCH_FRAC: f64 = 0.02;

/// How far below the top gridline to look for the rest of the lattice.
const GRIDLINE_WINDOW_FRAC: f64 = 0.25;

/// Longest contiguous span of line-dark pixels in one row of the image.
fn longest_dark_run(
    img: &RgbImage,
    y: u32,
    x_from: u32,
    x_to: u32,
    threshold: i32,
) -> Option<(u32, u32)> {
    let mut best: Option<(u32, u32)> = None;
    let mut start: Option<u32> = None;
    for x in x_from..x_to {
        let p = img.get_pixel(x, y).0;
        // Rec. 601 luma, matching OpenCV's BGR2GRAY in the Python mirror.
        let luma = (0.114 * p[2] as f64 + 0.587 * p[1] as f64 + 0.299 * p[0] as f64).round() as i32;
        if luma < threshold {
            if start.is_none() {
                start = Some(x);
            }
        } else if let Some(s) = start.take() {
            let run = (s, x - 1);
            if best.is_none_or(|b| run.1 - run.0 > b.1 - b.0) {
                best = Some(run);
            }
        }
    }
    if let Some(s) = start {
        let run = (s, x_to - 1);
        if best.is_none_or(|b| run.1 - run.0 > b.1 - b.0) {
            best = Some(run);
        }
    }
    best
}

/// Modal luma over a region — the card background the gridlines sit on.
fn modal_luma(img: &RgbImage, x_from: u32, y_from: u32, y_to: u32) -> i32 {
    let mut hist = [0u32; 256];
    let w = img.width();
    for y in y_from..y_to {
        for x in x_from..w {
            let p = img.get_pixel(x, y).0;
            let luma =
                (0.114 * p[2] as f64 + 0.587 * p[1] as f64 + 0.299 * p[0] as f64).round() as usize;
            hist[luma.min(255)] += 1;
        }
    }
    hist.iter()
        .enumerate()
        .max_by_key(|(_, c)| **c)
        .map(|(v, _)| v as i32)
        .unwrap_or(255)
}

/// Derive the daily chart's plot rectangle from its gridline lattice.
///
/// Given the approximate y of the "60" minute label, locate the top gridline it
/// annotates, measure its horizontal extent, then walk the evenly-spaced lattice
/// down to the baseline. Returns `(x, y, width, height)`.
///
/// This replaces hunting the corner labels with OCR. The hour numerals are
/// small, light grey and frequently lost — on the reference Hebrew screenshot a
/// full-width band scan recovered only two of four, and the OCR-derived baseline
/// landed 44px below the true one, zeroing every bar. The lattice needs no text
/// at all, so it holds in any locale.
///
/// `img` must be the dark-mode-converted image, NOT the contrast-boosted one:
/// the boost drives every pixel below any useful threshold. Mirrors Python
/// `grid_anchors.py::find_plot_rect_from_gridlines`.
fn find_plot_rect_from_gridlines(
    img: &RgbImage,
    y_hint: i32,
    x_min: i32,
) -> Option<(i32, i32, i32, i32)> {
    let (img_w, img_h) = img.dimensions();
    let x_min_u = x_min.max(0) as u32;
    if x_min_u >= img_w {
        return None;
    }

    let win_top = (y_hint - 20).max(0) as u32;
    let win_bottom = ((y_hint as f64 + img_h as f64 * 0.2) as u32).min(img_h);
    if win_bottom <= win_top {
        return None;
    }
    let background = modal_luma(img, x_min_u, win_top, win_bottom);
    let threshold = background - GRIDLINE_DELTA;
    if threshold <= 0 {
        return None;
    }

    let span = (img_w - x_min_u) as f64;
    let search = ((img_h as f64 * GRIDLINE_SEARCH_FRAC) as i32).max(6);

    // Top gridline: first mostly-dark row near the "60" label.
    let mut top_y = None;
    let mut extent = None;
    let from = (y_hint - search).max(0) as u32;
    let to = ((y_hint + search + 1) as u32).min(img_h);
    for y in from..to {
        if let Some(run) = longest_dark_run(img, y, x_min_u, img_w, threshold)
            && (run.1 - run.0) as f64 >= GRIDLINE_COVERAGE * span
        {
            top_y = Some(y as i32);
            extent = Some(run);
            break;
        }
    }
    let (top_y, (plot_x0, plot_x1)) = (top_y?, extent?);
    let width = (plot_x1 - plot_x0) as i32;

    // Collect candidate gridline rows below the top line.
    let window = ((top_y as f64 + img_h as f64 * GRIDLINE_WINDOW_FRAC) as u32).min(img_h);
    let mut candidates: Vec<i32> = Vec::new();
    let mut y = top_y as u32 + 1;
    while y < window {
        match longest_dark_run(img, y, plot_x0, plot_x1 + 1, threshold) {
            Some(run) if (run.1 - run.0) as f64 >= GRIDLINE_COVERAGE * width as f64 => {
                candidates.push(y as i32);
                y += ((width as f64 * 0.01) as u32).max(3); // skip the line's thickness
            }
            _ => y += 1,
        }
    }
    let first = *candidates.first()?;

    // Gridlines are evenly spaced — walk the progression and stop at the first
    // gap. Without this the walk runs into the app-list row separators below the
    // card, which span a similar width; on the reference screenshot that carried
    // the baseline to y=1988 instead of y=1267 and zeroed every bar.
    let spacing = first - top_y;
    if spacing <= 0 {
        return None;
    }
    let tolerance = ((spacing as f64 * 0.2) as i32).max(3);
    let mut baseline = first;
    let mut expected = first + spacing;
    for &c in candidates.iter().skip(1) {
        if (c - expected).abs() <= tolerance {
            baseline = c;
            expected = c + spacing;
        } else if c > expected + tolerance {
            break;
        }
    }

    if baseline <= top_y {
        return None;
    }
    Some((plot_x0 as i32, top_y, width, baseline - top_y))
}

/// Height of the full-width hour-label band, as a fraction of image height.
/// Mirrors Python `grid_anchors.py::HOUR_AXIS_BAND_FRAC`.
const HOUR_AXIS_BAND_FRAC: f64 = 0.25;

/// Rough word count reserved for the band scan; only affects allocation.
const HOUR_AXIS_BAND_HINT: usize = 16;

/// OCR a full-width band starting at `y_from` and return ABSOLUTE-coordinate words.
///
/// Returns an empty vector rather than an error: the band is supplementary
/// evidence, and a failed scan should leave the chunk-derived words to speak for
/// themselves instead of failing the whole detector.
fn ocr_hour_axis_band(img: &RgbImage, y_from: i32) -> Vec<OcrWord> {
    let (img_w, img_h) = img.dimensions();
    let y0 = y_from.max(0) as u32;
    let y1 = (y0 + (img_h as f64 * HOUR_AXIS_BAND_FRAC) as u32).min(img_h);
    if y1 <= y0 {
        return Vec::new();
    }

    let band = image::imageops::crop_imm(img, 0, y0, img_w, y1 - y0).to_image();
    match run_tesseract_anchor(&band, "6") {
        Ok(mut words) => {
            for w in &mut words {
                w.y += y0 as i32;
            }
            words
        }
        Err(e) => {
            debug!("Hour-axis band OCR failed: {e}");
            Vec::new()
        }
    }
}

/// Read the hour-label row and report whether the chart is mirrored.
///
/// Exists because axis direction is a property of the SCREENSHOT, not of
/// whichever grid detector happened to win. `line_based` is the primary
/// detector and reports `Ltr` unconditionally, and caller-supplied grid
/// coordinates carry no label evidence at all — so on both of those paths the
/// mirrored chart would otherwise be sliced left-to-right and every hour stored
/// against the wrong time, with a correct-looking total and no warning.
///
/// `y_from` should be the TOP of the plot area. The band runs 25% of the image
/// height from there, which is how the RTL anchor detector already reads this
/// row (it starts at the `60` label, i.e. the top gridline). Starting at the
/// plot BOTTOM instead reads nothing: `calculate_roi` trims the ROI inside the
/// gridlines, so the label row can fall just ABOVE the bottom edge and land
/// outside the band entirely — measured on the reference Hebrew capture, whose
/// ROI ends at y=1267 with the hour labels above it.
/// Returns `None` when the band yields no usable evidence, which leaves the
/// caller's existing direction untouched.
///
/// Callers MUST gate this on the user having an RTL language enabled. An English
/// daily chart labels its axis `12 AM / 6 AM / 12 PM / 6 PM`, whose bare
/// numerals (12, 6, 12, 6) descend across the page and would vote "mirrored".
/// The gate — not this function — is what keeps LTR screenshots untouched.
/// This reads the axis band directly rather than reusing the full-page
/// title/total OCR. Measured on the reference Hebrew capture: that full-page
/// PSM-3 pass returns 26 words below the midpoint and NOT ONE hour label — it
/// reads the app rows and the header, never the numerals under the chart — so a
/// word-list-based check silently answered `None` on every image. The band read
/// is one extra Tesseract call, taken only when an RTL language is enabled.
///
/// The band is read through the SAME `adjust_contrast_brightness(2.0, -220)`
/// preparation the anchor detector uses, with the dark-mode retry behind it.
/// Reading the raw pipeline image instead returns no labels at all: the hour
/// numerals are small, light grey, and only separate from the background once
/// that contrast stretch has run.
#[cfg(feature = "ocr")]
pub fn detect_axis_direction(
    img: &RgbImage,
    original: &RgbImage,
    plot_top: i32,
    plot_bottom: i32,
) -> Option<AxisDirection> {
    let (_, img_h) = img.dimensions();
    // The label row sits just under the plot. `calculate_roi` trims inside the
    // gridlines, so allow a little slack above the nominal bottom edge.
    let row_from = plot_bottom - (img_h as f64 * 0.01) as i32;
    let row_to = plot_bottom + (img_h as f64 * 0.06) as i32;

    let read = |source: &RgbImage| {
        let processed = adjust_contrast_brightness(source, 2.0, -220);
        // Read from the TOP of the plot: a strip that starts at the axis line
        // reads as one merged text line under PSM 6 and returns no labels at
        // all, while the whole-chart band reads them reliably. The row window
        // below — not the band — is what confines the vote to the axis.
        let band: Vec<OcrWord> = ocr_hour_axis_band(&processed, plot_top)
            .into_iter()
            .filter(|w| w.y >= row_from && w.y <= row_to)
            .collect();

        // A 12-hour axis is not a mirrored 24-hour one, and Tesseract fuses the
        // meridiem into the numeral often enough that a bare "am"/"pm" token is
        // not a reliable signal: `ios26_light/IMG_7879` reads `12AM 6AM 12PM
        // 6PM`, whose bare numerals 12,6,12,6 descend across the page and vote
        // "mirrored". Reject anything carrying a meridiem, fused or not, and
        // require a label a 12-hour axis never prints.
        if band.iter().any(|w| {
            let t = w.text.to_ascii_lowercase();
            t.contains("am") || t.contains("pm")
        }) {
            return None;
        }
        if !band
            .iter()
            .filter_map(|w| bare_numeral(&w.text))
            .any(|n| n == "0" || n == "18")
        {
            return None;
        }

        find_hour_axis_row(&band, &processed, row_from).map(|(_, is_rtl)| is_rtl)
    };

    let is_rtl = read(img).or_else(|| {
        is_dark_mode(original).then(|| read(&convert_dark_mode_for_ocr(original)))?
    })?;
    Some(if is_rtl {
        AxisDirection::Rtl
    } else {
        AxisDirection::Ltr
    })
}

// ── y-axis scale ─────────────────────────────────────────────────────────────
/// The labels are small grey text; Tesseract reads them far more reliably
/// upscaled. Measured: at 1x the `1h` label reads as `th`/`4h`.
const AXIS_LABEL_SCALE: u32 = 2;

/// Read the minute value of the chart's TOP gridline.
///
/// The hourly chart's y-axis is not always 60 minutes. iOS scales it to the
/// busiest hour, so an "All Devices" capture — which sums several devices into
/// one hour — routinely prints `2h / 1h / 0`. `slice_image` assumes the plot's
/// full height is 60 minutes, so such a chart reports exactly half of every
/// hour: `ios26_light/IMG_7876.PNG` prints `2h 31m` (151 minutes) and extracted
/// 74. It does not fail — it succeeds with plausible wrong numbers, which is
/// worse than the outright rejection `IMG_7877.PNG` gets.
///
/// Returns `None` for an ordinary chart, which leaves the caller on the
/// compiled 60-minute default. Only a label ABOVE 60 is reported: a normal
/// chart needs no adjustment, so a misread there could only do harm. Measured
/// on the corpus, ordinary charts read `60m` (→ 60, rejected here) or nothing.
///
/// This cannot be answered from the full-page title/total OCR. That PSM-3 pass
/// returns not one axis label on `IMG_7876` — it reads the header and the app
/// rows and skips the axis entirely, which is why `AllDevicesSignals`'
/// `axis_max_minutes` has always been `None` on real captures and its "axis
/// exceeds 1 hour" reason has never once fired outside a unit test. The labels
/// only separate from the background after the same
/// `adjust_contrast_brightness(2.0, -220)` stretch the anchor detector uses,
/// and only when upscaled.
#[cfg(feature = "ocr")]
pub fn detect_axis_max_minutes(
    img: &RgbImage,
    original: &RgbImage,
    bounds: &GridBounds,
    axis_direction: AxisDirection,
) -> Option<i32> {
    let (x0, y0, x1, y1) = axis_label_rect(img.width(), img.height(), bounds, axis_direction)?;

    let read = |source: &RgbImage| -> Option<i32> {
        let strip = image::imageops::crop_imm(source, x0, y0, x1 - x0, y1 - y0).to_image();
        let strip = crate::image_utils::resize_lanczos3(
            &strip,
            (x1 - x0) * AXIS_LABEL_SCALE,
            (y1 - y0) * AXIS_LABEL_SCALE,
        );
        let prepared = adjust_contrast_brightness(&strip, 2.0, -220);
        // PSM 6 reads the strip as one text block; PSM 3 is the retry because
        // the two disagree on isolated short labels often enough to matter.
        //
        // An engine ERROR is not the same as "the axis says 60", but both end up
        // as `None` and leave the caller on the 60-minute default — i.e. an
        // hour-scaled chart silently halved on a run that otherwise looks healthy.
        // Nothing else notices: the title/total pass has its own error channel,
        // so `ocr_error` stays clear. Log it so the difference is at least
        // recoverable from the console.
        let mut words = run_tesseract_anchor(&prepared, "6")
            .inspect_err(|e| {
                warn!("Axis-label OCR failed (PSM 6); chart will be read at 60 min unless the retry succeeds: {e}");
            })
            .unwrap_or_default();
        if topmost_axis_minutes(&words).is_none() {
            words = run_tesseract_anchor(&prepared, "3")
                .inspect_err(|e| warn!("Axis-label OCR failed (PSM 3 retry): {e}"))
                .unwrap_or_default();
        }
        topmost_axis_minutes(&words)
    };

    let minutes = read(img).or_else(|| {
        is_dark_mode(original).then(|| read(&convert_dark_mode_for_ocr(original)))?
    })?;
    if minutes > 60 {
        info!("Chart y-axis reads {minutes} minutes at the top gridline, not 60");
        Some(minutes)
    } else {
        None
    }
}

/// Detect a mirrored (RTL) daily chart and return its ROI.
///
/// Three steps, only the first of which reads text:
///   1. `60` on the LEFT — in LTR locales the minute labels sit on the right, so
///      finding them left is itself the mirror signal.
///   2. Hour labels `0/6/12/18` ordered against their x-positions confirm the
///      axis runs right-to-left.
///   3. The plot rectangle comes from the gridline lattice, not from OCR.
///
/// Returns `None` for every LTR screenshot, so this runs on the failure path
/// only and never perturbs the LTR path.
fn try_find_anchors_rtl(
    img_processed: &RgbImage,
    img_lattice: &RgbImage,
    left_boxes: &[OcrWord],
    right_boxes: &[OcrWord],
) -> Option<GridDetectionResult> {
    let (w, h) = img_processed.dimensions();

    // "60" must be on the LEFT for a mirrored chart.
    let sixty = left_boxes
        .iter()
        .find(|b| bare_numeral(&b.text) == Some("60"))?;

    // The left/right thirds that `prepare_image_chunks` feeds the LTR anchors do
    // not cover the MIDDLE of the chart, so the hour labels that fall in the gap
    // are never seen — on the reference Hebrew screenshot the chunks yield no
    // usable hour row at all and direction detection fails. Scan one short
    // full-width band under the "60" label as well; it is far cheaper than a
    // full-frame pass. Mirrors Python `grid_anchors.py::ocr_hour_axis_band`.
    let mut all: Vec<OcrWord> =
        Vec::with_capacity(left_boxes.len() + right_boxes.len() + HOUR_AXIS_BAND_HINT);
    all.extend_from_slice(left_boxes);
    all.extend_from_slice(right_boxes);
    all.extend(ocr_hour_axis_band(img_processed, sixty.y));

    let (_zero, is_rtl) = find_hour_axis_row(&all, img_processed, (h / 2) as i32)?;
    if !is_rtl {
        return None;
    }

    let (x, y, width, height) =
        find_plot_rect_from_gridlines(img_lattice, sixty.y, sixty.x + sixty.w)?;

    match calculate_roi(x, y, width, height, w, h) {
        Ok(bounds) => {
            info!(
                "RTL lattice detection succeeded: ({},{}) {}x{}",
                bounds.roi_x(),
                bounds.roi_y(),
                bounds.width(),
                bounds.height()
            );
            Some(GridDetectionResult {
                success: true,
                bounds: Some(bounds),
                confidence: 1.0,
                method: "ocr_anchored_rtl".to_string(),
                error: None,
                is_weekly: false,
                axis_direction: AxisDirection::Rtl,
            })
        }
        Err(e) => {
            debug!("RTL lattice ROI rejected: {e}");
            None
        }
    }
}

/// Try to find grid anchors from OCR boxes on a processed image.
///
/// Returns Some(GridDetectionResult) on success, None if anchors not found.
fn try_find_anchors(
    img_processed: &RgbImage,
    img_lattice: &RgbImage,
) -> Result<Option<GridDetectionResult>, ProcessingError> {
    let (w, h) = img_processed.dimensions();
    let (img_left, img_right, right_offset) = prepare_image_chunks(img_processed);

    // Anchor reads are pinned to English on purpose — see `ocr::LEPTESS_ANCHOR`.
    // The strings being matched ("60", "0/6/12/18") are Western numerals in every
    // locale, and loading a user's pack here makes Tesseract miss them.
    let left_boxes = run_tesseract_anchor(&img_left, "6")?;
    let mut right_boxes = run_tesseract_anchor(&img_right, "6")?;

    for b in &mut right_boxes {
        b.x += right_offset as i32;
    }

    info!(
        "OCR anchored: {} left boxes, {} right boxes",
        left_boxes.len(),
        right_boxes.len()
    );

    // LTR first — it is the overwhelmingly common case and its anchors ("12 AM"
    // bottom-left / "60" top-right) cannot be produced by a mirrored chart.
    for skip in 0..4 {
        let left = find_left_anchor(&left_boxes, img_processed, skip);
        let right = find_right_anchor(&right_boxes, img_processed);

        if let (Some((ll_x, ll_y)), Some((ur_x, ur_y))) = (left, right) {
            let roi_width = ur_x - ll_x;
            let roi_height = ll_y - ur_y;

            match calculate_roi(ll_x, ur_y, roi_width, roi_height, w, h) {
                Ok(bounds) => {
                    info!(
                        "OCR anchored detection succeeded: ({},{}) {}x{} (skip={skip})",
                        bounds.roi_x(),
                        bounds.roi_y(),
                        bounds.width(),
                        bounds.height()
                    );
                    return Ok(Some(GridDetectionResult {
                        success: true,
                        bounds: Some(bounds),
                        confidence: 1.0,
                        method: "ocr_anchored".to_string(),
                        error: None,
                        is_weekly: false,
                        axis_direction: AxisDirection::Ltr,
                    }));
                }
                Err(e) => {
                    debug!("OCR anchor attempt skip={skip} failed: {e}");
                    continue;
                }
            }
        }
    }

    // RTL (Hebrew, Arabic): the chart is mirrored, so the minute label "60"
    // marks the upper-LEFT corner and the 24-hour label "0" the lower-RIGHT.
    if let Some(result) =
        try_find_anchors_rtl(img_processed, img_lattice, &left_boxes, &right_boxes)
    {
        return Ok(Some(result));
    }

    Ok(None)
}

/// Detect grid using OCR text anchors ("12 AM" and "60").
///
/// IMPORTANT: Caller must have already applied `convert_dark_mode()`.
/// Pass `original_img` (before dark mode conversion) to enable adaptive
/// threshold fallback for dark mode screenshots.
pub fn detect(img: &RgbImage) -> Result<GridDetectionResult, ProcessingError> {
    detect_with_original(img, None)
}

/// Detect grid using OCR text anchors, with optional original image for dark mode fallback.
pub fn detect_with_original(
    img: &RgbImage,
    original_img: Option<&RgbImage>,
) -> Result<GridDetectionResult, ProcessingError> {
    // Standard path: contrast/brightness for OCR readability
    let img_processed = adjust_contrast_brightness(img, 2.0, -220);

    if let Some(result) = try_find_anchors(&img_processed, img)? {
        return Ok(result);
    }

    // Dark mode fallback: standard preprocessing destroys faint text contrast
    // (contrast=3.0 clips both text and background to ~255). Use adaptive
    // thresholding which preserves text for Tesseract anchor detection.
    let orig = original_img.unwrap_or(img);
    if is_dark_mode(orig) {
        info!(
            "Standard anchor detection failed on dark mode image, retrying with adaptive threshold OCR"
        );
        let img_ocr = convert_dark_mode_for_ocr(orig);
        let img_ocr_processed = adjust_contrast_brightness(&img_ocr, 2.0, -220);

        if let Some(result) = try_find_anchors(&img_ocr_processed, &img_ocr)? {
            return Ok(result);
        }
    }

    Ok(GridDetectionResult {
        success: false,
        bounds: None,
        confidence: 0.0,
        method: "ocr_anchored".to_string(),
        // Surfaced verbatim to the user as the blocking issue, so it has to say
        // what to do about it — the anchor names are the diagnostic tail, not
        // the message.
        error: Some(
            "Could not detect a daily Screen Time chart — no axis anchors found \
             (12 AM / 60, or mirrored 60 / 0). Make sure the screenshot is the Day view \
             (not Week), in portrait, at Standard display zoom."
                .to_string(),
        ),
        is_weekly: false,
        axis_direction: AxisDirection::Ltr,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_detect_returns_failure_on_small_image() {
        let img = RgbImage::new(100, 100);
        let result = detect(&img).unwrap();
        assert!(!result.success);
    }
}
