//! Line-based grid detector — finds the chart using visual line patterns.
//!
//! Port of Python line_based_detection/detector.py and combined.py.
//! This is the recommended detection method (no OCR dependency).

use image::RgbImage;

use super::{
    lookup,
    strategies::{
        LineInk, background_luma, extend_to_bar_baseline, find_evenly_spaced_groups,
        find_horizontal_lines, validate_bar_colors, validate_vertical_lines,
    },
};
use crate::types::{AxisDirection, GridBounds, GridDetectionResult, ProcessingError};

/// Detect grid using the combined line-based strategy (light mode).
///
/// Thin wrapper over [`detect_themed`] with `dark_mode = false`, preserving the
/// original light-mode behavior for callers that don't know the source theme.
pub fn detect(img: &RgbImage) -> Result<GridDetectionResult, ProcessingError> {
    detect_themed(img, false)
}

/// Detect the grid, preferring the pristine capture in dark mode.
///
/// `original` is the image as it came off the phone, before `convert_dark_mode`.
/// When the source was dark and the original is available, every pixel check reads
/// it instead of `img`: the conversion's invert + contrast=3 LUT is calibrated for
/// how iOS normally renders dark mode, and on a phone that renders it brighter the
/// LUT saturates the card and its hairline separators to the same white (the grid
/// vanishes) and shifts the bar hues out of the blue band (colour validation then
/// rejects a perfectly good daily chart). The pristine pixels carry both signals
/// intact, and the bar hues there are the same ones the light-mode check uses.
pub fn detect_themed_with_original(
    img: &RgbImage,
    original: Option<&RgbImage>,
    dark_mode: bool,
) -> Result<GridDetectionResult, ProcessingError> {
    match original {
        Some(orig) if dark_mode && orig.dimensions() == img.dimensions() => {
            detect_inner(orig, LineInk::dark_relative(background_luma(orig)), false)
        }
        _ => detect_themed(img, dark_mode),
    }
}

/// Detect grid using the combined line-based strategy, theme-aware.
///
/// Steps:
/// 1. Get x, width, height from resolution lookup table
/// 2. Find horizontal line groups
/// 3. Validate with vertical line count (4-5 = daily, 7+ = weekly)
/// 4. Refine x boundaries using actual grid edges
///
/// `dark_mode` selects the grid-line pixel classifier ([`LineInk`]): the narrow
/// gray band for light mode, the near-black achromatic class for dark mode (post
/// `convert_dark_mode`). This is the only theme-dependent knob — every step below
/// asks the injected classifier "is this grid-line ink?" rather than hard-coding a
/// single light-mode luma band.
///
/// IMPORTANT: Caller must have already applied `convert_dark_mode()` to the image.
/// This function does NOT clone or re-convert the image. `dark_mode` must reflect
/// the *original* (pre-convert) image's theme — see `is_dark_mode`.
pub fn detect_themed(
    img: &RgbImage,
    dark_mode: bool,
) -> Result<GridDetectionResult, ProcessingError> {
    detect_inner(img, LineInk::horizontal(dark_mode), dark_mode)
}

/// Shared body of [`detect_themed`] / [`detect_themed_with_original`].
///
/// `h_ink` is the horizontal grid-line classifier; the vertical and edge classifiers
/// follow from it (the relative dark classifier serves all three, since on the
/// pristine image every grid line is the same ink).
fn detect_inner(
    img: &RgbImage,
    h_ink: LineInk,
    dark_mode: bool,
) -> Result<GridDetectionResult, ProcessingError> {
    let (v_ink, edge_ink) = match h_ink {
        LineInk::DarkRelative { .. } => (h_ink, h_ink),
        _ => (LineInk::vertical(dark_mode), LineInk::edge(dark_mode)),
    };

    let (w, h) = img.dimensions();
    let resolution = format!("{w}x{h}");

    // Step 1: Lookup table for approximate bounds
    let partial = match lookup::get_partial_bounds(w, h) {
        Some(p) => p,
        None => {
            return Ok(GridDetectionResult {
                success: false,
                bounds: None,
                confidence: 0.0,
                method: "line_based".to_string(),
                error: Some(format!("Resolution {resolution} not supported")),
                is_weekly: false,
                // Line-based detection is purely geometric and reads no axis labels, so it
                // cannot establish direction; the caller re-checks via OCR when needed.
                axis_direction: AxisDirection::Ltr,
            });
        }
    };

    let (x_start, width, expected_height) = (partial.0 as u32, partial.1 as u32, partial.2);

    // Step 2: Find horizontal lines
    let x_end = (x_start + width).min(w);
    let lines = find_horizontal_lines(img, x_start, x_end, h_ink);

    if lines.len() < 4 {
        return Ok(GridDetectionResult {
            success: false,
            bounds: None,
            confidence: 0.0,
            method: "line_based".to_string(),
            error: Some(format!(
                "Only found {} horizontal lines (need 4+)",
                lines.len()
            )),
            is_weekly: false,
            // Line-based detection is purely geometric and reads no axis labels, so it
            // cannot establish direction; the caller re-checks via OCR when needed.
            axis_direction: AxisDirection::Ltr,
        });
    }

    // Step 3: Find evenly-spaced groups and validate with vertical lines
    let groups = find_evenly_spaced_groups(&lines, Some(expected_height));

    if groups.is_empty() {
        return Ok(GridDetectionResult {
            success: false,
            bounds: None,
            confidence: 0.0,
            method: "line_based".to_string(),
            error: Some("No evenly-spaced horizontal line groups found".to_string()),
            is_weekly: false,
            // Line-based detection is purely geometric and reads no axis labels, so it
            // cannot establish direction; the caller re-checks via OCR when needed.
            axis_direction: AxisDirection::Ltr,
        });
    }

    // Try each candidate region: vertical line validation + color validation
    let mut best_result: Option<(GridBounds, f64, Vec<i32>, f64)> = None;
    // Positive evidence that a chart-like region is actually the WEEKLY (7-column)
    // view: a vertical-line count in the weekly band (disjoint from the strict
    // daily 3-5) spaced ≈ width/7. Used only to turn the no-daily-match failure
    // below into a definitive, actionable "weekly view" rejection.
    let mut weekly_signal = false;

    for group in &groups {
        let y_start = group.y_start as u32;
        let y_end = group.y_end as u32;

        // Step 3a: Validate vertical line pattern (daily = 3-5 lines)
        let (is_daily, confidence, v_count, v_positions) =
            validate_vertical_lines(img, x_start, width, y_start, y_end, v_ink);

        if !is_daily {
            if is_weekly_vertical_pattern(width, v_count, &v_positions) {
                weekly_signal = true;
            }
            continue;
        }

        // Step 3b: Color validation — reject pickups charts (cyan bars)
        let (color_valid, _color_conf) = validate_bar_colors(img, x_start, width, y_start, y_end);
        if !color_valid {
            continue;
        }

        if best_result.is_none() || confidence > best_result.as_ref().unwrap().1 {
            let bounds = GridBounds::from_roi(
                x_start as i32,
                y_start as i32,
                width as i32,
                (y_end - y_start) as i32,
            );
            best_result = Some((bounds, confidence, v_positions, group.mean_spacing));
        }
    }

    match best_result {
        Some((bounds, confidence, v_positions, unit)) => {
            // Step 4: Refine x boundaries
            let mut refined = refine_x_boundaries(img, &bounds, &v_positions, edge_ink);

            // Step 5: put the bottom back on the baseline if the 0-line was never
            // found. The bars run past a short lattice and stop where the plot
            // really ends; nothing happens when they don't.
            if let Some(bottom) = extend_to_bar_baseline(
                img,
                refined.roi_x().max(0) as u32,
                refined.width().max(0) as u32,
                refined.lower_right_y.max(0) as u32,
                unit,
            ) {
                refined = GridBounds::from_roi(
                    refined.roi_x(),
                    refined.roi_y(),
                    refined.width(),
                    bottom as i32 - refined.roi_y(),
                );
            }

            Ok(GridDetectionResult {
                success: true,
                bounds: Some(refined),
                confidence,
                method: "line_based".to_string(),
                error: None,
                is_weekly: false,
                // Line-based detection is purely geometric and reads no axis labels, so it
                // cannot establish direction; the caller re-checks via OCR when needed.
                axis_direction: AxisDirection::Ltr,
            })
        }
        None => {
            // No candidate passed daily vertical validation. If a region showed a
            // weekly-consistent vertical pattern, reject it as the weekly view
            // *definitively* (the caller skips the OcrAnchored fallback, which can't
            // read a weekly chart's hourly anchors anyway). Otherwise keep the
            // generic message and let the OcrAnchored fallback try — a degraded
            // daily chart may still be rescued there.
            if weekly_signal {
                Ok(GridDetectionResult {
                    success: false,
                    bounds: None,
                    confidence: 0.0,
                    method: "line_based".to_string(),
                    error: Some(
                        "Weekly view detected — capture the daily (24-hour) Screen Time chart"
                            .to_string(),
                    ),
                    is_weekly: true,
                    // Line-based detection is purely geometric and reads no axis labels, so it
                    // cannot establish direction; the caller re-checks via OCR when needed.
                    axis_direction: AxisDirection::Ltr,
                })
            } else {
                Ok(GridDetectionResult {
                    success: false,
                    bounds: None,
                    confidence: 0.0,
                    method: "line_based".to_string(),
                    error: Some(
                        "Horizontal lines found but no region matches daily chart vertical pattern (may be weekly chart)".to_string()
                    ),
                    is_weekly: false,
                    // Line-based detection is purely geometric and reads no axis labels, so it
                    // cannot establish direction; the caller re-checks via OCR when needed.
                    axis_direction: AxisDirection::Ltr,
                })
            }
        }
    }
}

/// Does a region's vertical-line pattern look like the WEEKLY (7-column) view
/// rather than the daily (24-hour) chart?
///
/// Used only to turn a daily-detection failure into a clear, definitive "weekly
/// view" rejection. The count band (6-10) is **disjoint** from the strict daily
/// band (3-5 enforced in [`validate_vertical_lines`]), so a real daily chart can
/// never be mis-flagged as weekly. The width/7 spacing check is a secondary
/// confirmation (daily lines sit at width/4 ≈ 0.25·W, weekly at width/7 ≈
/// 0.14·W). Best-effort: when it does not fire, callers fall back to the generic
/// "no daily pattern" failure, which is still a clear (if less specific) reject.
fn is_weekly_vertical_pattern(width: u32, v_count: usize, v_positions: &[i32]) -> bool {
    if !(6..=10).contains(&v_count) || v_positions.len() < 2 {
        return false;
    }
    let spacings: Vec<i32> = v_positions.windows(2).map(|w| w[1] - w[0]).collect();
    let mean_spacing = spacings.iter().sum::<i32>() as f64 / spacings.len() as f64;
    if mean_spacing <= 0.0 {
        return false;
    }
    let expected_spacing = width as f64 / 7.0;
    let spacing_error = (mean_spacing - expected_spacing).abs() / expected_spacing;
    spacing_error <= 0.35
}

/// Refine x boundaries by detecting actual grid edges.
fn refine_x_boundaries(
    img: &RgbImage,
    bounds: &GridBounds,
    v_positions: &[i32],
    edge_ink: LineInk,
) -> GridBounds {
    let (w, _h) = img.dimensions();

    let search_margin = 50i32;
    let search_x_start = (bounds.upper_left_x - search_margin).max(0) as u32;
    let search_x_end = ((bounds.lower_right_x + search_margin) as u32).min(w);

    let y_start = bounds.upper_left_y as u32;
    let y_end = bounds.lower_right_y as u32;

    // Find vertical grid lines at edges
    if let Some((left, right)) =
        find_grid_edges(img, search_x_start, search_x_end, y_start, y_end, edge_ink)
    {
        let (left, right) =
            complete_four_spans(img, left, right, v_positions, y_start, y_end, edge_ink);
        return GridBounds::new(left, bounds.upper_left_y, right, bounds.lower_right_y);
    }

    // Fallback: extrapolate from vertical line positions
    if v_positions.len() >= 3 {
        let spacings: Vec<i32> = v_positions.windows(2).map(|w| w[1] - w[0]).collect();
        let mean_spacing = spacings.iter().sum::<i32>() as f64 / spacings.len() as f64;

        let left_edge = (v_positions[0] as f64 - mean_spacing).round() as i32 + bounds.upper_left_x;
        let right_edge = (*v_positions.last().unwrap() as f64 + mean_spacing).round() as i32
            + bounds.upper_left_x;

        let left_edge = left_edge.max(0);
        let right_edge = (right_edge as u32).min(w) as i32;

        if right_edge > left_edge {
            return GridBounds::new(
                left_edge,
                bounds.upper_left_y,
                right_edge,
                bounds.lower_right_y,
            );
        }
    }

    *bounds
}

/// A daily chart is four equal 6-hour spans between its outer edges. The search
/// window for those edges comes from the capture's SIZE, so a capture cropped on
/// one side (narrower than the screen its chart was laid out for) can leave the
/// far edge just outside the window; the nearest line inside it is then the
/// 18-hour line and the grid covers three spans. Measured on a participant
/// capture 1096 px wide with gridlines every 220 px: the true right edge sat 17 px
/// past the window and the day read 182 minutes short.
///
/// When the edges are three spans apart, look where the fourth line must be and
/// take it ONLY if a real line is there. Anything else is left alone.
fn complete_four_spans(
    img: &RgbImage,
    left: i32,
    right: i32,
    v_positions: &[i32],
    y_start: u32,
    y_end: u32,
    edge_ink: LineInk,
) -> (i32, i32) {
    if v_positions.len() < 2 {
        return (left, right);
    }
    // Lower-median gap, not the mean: one missing interior line doubles a gap, and
    // a mean of [200, 400, 200] would call a complete 800-px chart three spans.
    let mut gaps: Vec<i32> = v_positions.windows(2).map(|w| w[1] - w[0]).collect();
    gaps.sort_unstable();
    let span = gaps[(gaps.len() - 1) / 2] as f64;
    if span <= 0.0 || ((right - left) as f64 / span).round() as i32 != 3 {
        return (left, right);
    }
    let tol = (span * 0.05).max(3.0);
    let w = img.width() as i32;

    let want_right = left as f64 + 4.0 * span;
    let window_end = ((want_right + tol).ceil() as i32 + 1).min(w);
    if let Some((_, r)) = find_grid_edges(
        img,
        left.max(0) as u32,
        window_end.max(0) as u32,
        y_start,
        y_end,
        edge_ink,
    ) && (r as f64 - want_right).abs() <= tol
    {
        return (left, r);
    }

    let want_left = right as f64 - 4.0 * span;
    let window_start = ((want_left - tol).floor() as i32 - 1).max(0);
    if let Some((l, _)) = find_grid_edges(
        img,
        window_start as u32,
        (right + 1).min(w).max(0) as u32,
        y_start,
        y_end,
        edge_ink,
    ) && (l as f64 - want_left).abs() <= tol
    {
        return (l, right);
    }
    (left, right)
}

/// Find left and right grid edges by detecting vertical lines.
/// Uses direct RGB buffer access; `edge_ink` decides what counts as edge ink.
fn find_grid_edges(
    img: &RgbImage,
    x_start: u32,
    x_end: u32,
    y_start: u32,
    y_end: u32,
    edge_ink: LineInk,
) -> Option<(i32, i32)> {
    let region_h = y_end.saturating_sub(y_start);
    if region_h == 0 {
        return None;
    }

    let (w, h) = img.dimensions();
    let raw = img.as_raw();
    let stride = w as usize * 3;
    let min_coverage = 0.3f64;
    let threshold = (region_h as f64 * min_coverage) as u32;
    let mut positions = Vec::new();

    for x in x_start..x_end.min(w) {
        let mut count = 0u32;
        for y in y_start..y_end.min(h) {
            let idx = y as usize * stride + x as usize * 3;
            if edge_ink.matches(raw[idx], raw[idx + 1], raw[idx + 2]) {
                count += 1;
            }
        }
        if count >= threshold {
            positions.push(x as i32);
        }
    }

    if positions.len() < 2 {
        return None;
    }

    // Cluster
    let clusters = super::strategies::cluster_positions(&positions, 3);
    if clusters.len() < 2 {
        return None;
    }

    // Pick the cluster closest to x_start as the left edge,
    // and the cluster closest to x_end as the right edge.
    // Using first/last would pick up gray UI elements at the extreme
    // edges of the search window as false grid boundaries.
    let x_start_i = x_start as i32;
    let x_end_i = x_end as i32;
    let left = *clusters
        .iter()
        .min_by_key(|&&c| (c - x_start_i).abs())
        .unwrap();
    let right = *clusters
        .iter()
        .min_by_key(|&&c| (c - x_end_i).abs())
        .unwrap();

    if right <= left {
        return None;
    }

    Some((left, right))
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Synthesize a dark-mode daily chart the way a phone with a raised-contrast
    /// dark theme draws it: card at luma `bg`, hairlines `bg + delta` above it.
    fn dark_chart(bg: u8, delta: u8) -> RgbImage {
        let (w, h) = (1179u32, 2556u32);
        let line = bg + delta;
        let mut img = RgbImage::from_pixel(w, h, image::Rgb([bg, bg, bg]));
        let (x0, x1) = (90u32, 975u32);
        // 5 hairlines spanning the 270-px plot (the measured 1179x2556 bounds).
        for y in [1275u32, 1343, 1410, 1478, 1545] {
            for x in x0..x1 {
                img.put_pixel(x, y, image::Rgb([line, line, line]));
            }
        }
        // 4 dotted verticals at width/4, and one blue bar so colour validation runs.
        for x in [90u32, 311, 532, 753] {
            for y in 1275..1545 {
                img.put_pixel(x, y, image::Rgb([line, line, line]));
            }
        }
        for x in 400..430 {
            for y in 1400..1545 {
                img.put_pixel(x, y, image::Rgb([55, 108, 235]));
            }
        }
        img
    }

    #[test]
    fn dark_chart_is_read_off_the_pristine_capture() {
        // A phone drawing dark mode brighter than iOS's own 28/58 pair: the card is
        // 36 and the hairlines 84. convert_dark_mode's keep-dark-gray window is
        // anchored at a fixed inverted gray, so both saturate to white and the grid
        // is gone from the converted pixels — the detector has to read the original.
        let original = dark_chart(36, 48);
        let mut converted = original.clone();
        assert!(crate::image_utils::convert_dark_mode(&mut converted));

        let lost = detect_themed(&converted, true).unwrap();
        assert!(
            !lost.success,
            "negative control: converted pixels keep no grid"
        );

        let found = detect_themed_with_original(&converted, Some(&original), true).unwrap();
        assert!(found.success, "{:?}", found.error);
        let bounds = found.bounds.unwrap();
        assert_eq!(bounds.upper_left_y, 1275);
        assert_eq!(bounds.lower_right_y, 1545);
    }

    #[test]
    fn dark_chart_at_the_ios_default_contrast_still_works() {
        // The 28/58 pair iOS itself draws — the case that already worked through the
        // converted image — must keep working through the pristine one.
        let original = dark_chart(28, 30);
        let mut converted = original.clone();
        assert!(crate::image_utils::convert_dark_mode(&mut converted));
        let found = detect_themed_with_original(&converted, Some(&original), true).unwrap();
        assert!(found.success, "{:?}", found.error);
        assert_eq!(found.bounds.unwrap().upper_left_y, 1275);
    }

    #[test]
    fn light_mode_ignores_the_original() {
        // The original is only consulted in dark mode; a light capture takes the
        // unchanged path (same result with and without it).
        let img = RgbImage::new(100, 100);
        let with = detect_themed_with_original(&img, Some(&img), false).unwrap();
        let without = detect(&img).unwrap();
        assert_eq!(with.success, without.success);
        assert_eq!(with.error, without.error);
    }

    /// White frame with full-height gridline-gray verticals at `xs` over rows 100..370.
    fn chart_with_verticals(width: u32, xs: &[u32]) -> RgbImage {
        RgbImage::from_fn(width, 500, |x, y| {
            if (100..370).contains(&y) && xs.contains(&x) {
                image::Rgb([205, 205, 205])
            } else {
                image::Rgb([255, 255, 255])
            }
        })
    }

    // A capture cropped on the right: the size-derived window ended short of the
    // 24-hour line, so the picked edges are three spans apart. The fourth line is
    // really there, so the grid must reach it.
    #[test]
    fn edges_three_spans_apart_reach_the_real_fourth_line() {
        let img = chart_with_verticals(1096, &[96, 316, 536, 755, 975]);
        let got = complete_four_spans(
            &img,
            96,
            755,
            &[12, 232, 452, 671],
            100,
            370,
            LineInk::edge(false),
        );
        assert_eq!(got, (96, 975));
    }

    // Same geometry with no line where the fourth edge would be: nothing is invented.
    #[test]
    fn edges_three_spans_apart_stay_put_without_a_real_line() {
        let img = chart_with_verticals(1096, &[96, 316, 536, 755]);
        let got = complete_four_spans(
            &img,
            96,
            755,
            &[12, 232, 452, 671],
            100,
            370,
            LineInk::edge(false),
        );
        assert_eq!(got, (96, 755));
    }

    // A missing interior line doubles one gap; the chart is still four spans and
    // an unrelated line further right must not pull the edge out.
    #[test]
    fn a_missing_interior_line_does_not_widen_a_complete_chart() {
        let img = chart_with_verticals(1300, &[100, 300, 700, 900, 1167]);
        let got = complete_four_spans(
            &img,
            100,
            900,
            &[0, 200, 600, 800],
            100,
            370,
            LineInk::edge(false),
        );
        assert_eq!(got, (100, 900));
    }

    // Edges already four spans apart are never touched.
    #[test]
    fn edges_four_spans_apart_are_left_alone() {
        let img = chart_with_verticals(1170, &[90, 310, 530, 750, 970, 1100]);
        let got = complete_four_spans(
            &img,
            90,
            970,
            &[0, 220, 440, 660],
            100,
            370,
            LineInk::edge(false),
        );
        assert_eq!(got, (90, 970));
    }

    #[test]
    fn test_detect_unsupported_resolution() {
        let img = RgbImage::new(100, 100);
        let result = detect(&img).unwrap();
        assert!(!result.success);
        assert!(result.error.unwrap().contains("not supported"));
        // Unknown resolution is not a weekly classification.
        assert!(!result.is_weekly);
    }

    #[test]
    fn test_weekly_pattern_seven_columns() {
        // 7 day-columns spaced ≈ width/7 (≈128.6 for width=900) → weekly.
        let positions = [0, 129, 257, 386, 514, 643, 771];
        assert!(is_weekly_vertical_pattern(900, positions.len(), &positions));
    }

    #[test]
    fn test_weekly_pattern_rejects_daily_count() {
        // Daily charts have 3-5 vertical lines — disjoint from the weekly band,
        // so a daily chart can never be mis-flagged as weekly.
        let positions = [0, 225, 450, 675];
        assert!(!is_weekly_vertical_pattern(900, 4, &positions));
        assert!(!is_weekly_vertical_pattern(
            900,
            5,
            &[0, 180, 360, 540, 720]
        ));
    }

    #[test]
    fn test_weekly_pattern_rejects_wrong_spacing() {
        // Right count band (7) but daily-style width/4 spacing → not weekly.
        let positions = [0, 225, 450, 675, 900, 1125, 1350];
        assert!(!is_weekly_vertical_pattern(
            900,
            positions.len(),
            &positions
        ));
    }

    #[test]
    fn test_weekly_pattern_rejects_too_few_positions() {
        assert!(!is_weekly_vertical_pattern(900, 7, &[100]));
    }
}
