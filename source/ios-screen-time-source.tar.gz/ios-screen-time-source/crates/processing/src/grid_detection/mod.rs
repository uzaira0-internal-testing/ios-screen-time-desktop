//! Grid detection strategies for locating the bar chart region.
//!
//! Supports multiple detection methods:
//! - Line-based: visual pattern detection (horizontal/vertical lines)
//! - OCR-anchored: text anchor detection ("12 AM", "60")
//! - Lookup: resolution-based lookup table
//! - Manual: user-provided coordinates

pub mod line_based;
pub mod lookup;
#[cfg(feature = "ocr")]
pub mod ocr_anchored;
pub mod strategies;

use image::RgbImage;

use crate::types::{DetectionMethod, GridBounds, GridDetectionResult, ProcessingError};
#[cfg(any(feature = "ocr", test))]
use crate::{ocr::OcrWord, types::AxisDirection};

#[cfg(any(feature = "ocr", test))]
fn axis_label_rect(
    img_w: u32,
    img_h: u32,
    bounds: &GridBounds,
    axis_direction: AxisDirection,
) -> Option<(u32, u32, u32, u32)> {
    let chart_w = bounds.width().max(1) as f64;
    let chart_h = bounds.height().max(1) as f64;

    let axis_x = if axis_direction.reverses_hours() {
        bounds.upper_left_x
    } else {
        bounds.lower_right_x
    };
    let x0 = (axis_x - (chart_w * (1.0 / 6.0)) as i32).max(0) as u32;
    let y0 = (bounds.upper_left_y - (chart_h * 0.12) as i32).max(0) as u32;
    // Stop a short way past the plot's right edge, NOT at the image edge. The
    // labels sit just inside `lower_right_x` (`calculate_roi` trims to the
    // gridlines, which are drawn under them), so a window running to `img_w`
    // adds only margin — and on a capture where the chart is not flush right
    // (iPad/landscape, a two-column card, page chrome beside the plot) any `Nh`
    // text in that margin becomes the ceiling. `topmost` picks by height alone
    // and cannot tell it apart from a gridline label.
    let x1 = ((axis_x.max(0) as u32) + (chart_w * (1.0 / 6.0)) as u32).min(img_w);
    let y1 = ((bounds.upper_left_y + (chart_h * 0.25) as i32).max(0) as u32).min(img_h);
    if x1 <= x0 || y1 <= y0 {
        return None;
    }
    Some((x0, y0, x1, y1))
}

#[cfg(any(feature = "ocr", test))]
fn topmost_axis_minutes(words: &[OcrWord]) -> Option<i32> {
    let mut values = Vec::new();
    for word in words {
        let center_y = word.y + word.h / 2;
        let mut row: Vec<&OcrWord> = words
            .iter()
            .filter(|candidate| {
                candidate.x >= word.x
                    && (center_y - (candidate.y + candidate.h / 2)).abs()
                        <= word.h.max(candidate.h).max(8)
            })
            .collect();
        row.sort_by_key(|candidate| candidate.x);
        let mut phrase = String::new();
        let mut previous: Option<&OcrWord> = None;
        for candidate in row.into_iter().take(4) {
            if let Some(prev) = previous {
                let tolerance = prev.h.max(candidate.h).max(8);
                let gap = candidate.x - (prev.x + prev.w);
                if gap < -tolerance || gap > tolerance * 3 {
                    break;
                }
                phrase.push(' ');
            }
            phrase.push_str(candidate.text.trim());
            previous = Some(candidate);
            if let Some(minutes) = crate::ocr::parse_axis_minutes(&phrase) {
                values.push((word.y, minutes));
            }
        }
    }
    values
        .into_iter()
        .min_by_key(|(y, _)| *y)
        .map(|(_, minutes)| minutes)
}

const MIN_HOURLY_GRID_WIDTH: i32 = 24;
const MIN_HOURLY_GRID_HEIGHT: i32 = 2;

/// Detect grid bounds using the specified method.
pub fn detect_grid(
    img: &RgbImage,
    method: DetectionMethod,
) -> Result<GridDetectionResult, ProcessingError> {
    detect_grid_with_original(img, method, None)
}

/// Detect grid bounds, with optional original image.
///
/// `original_img` is the pristine (pre-`convert_dark_mode`) image. Both detectors
/// use it to recover the source theme: OcrAnchored runs its adaptive-threshold
/// dark-mode OCR fallback, and LineBased selects the dark-mode grid-line classifier
/// (the converted `img` looks light, so `is_dark_mode(img)` can't tell). LineBased
/// also *reads* it in dark mode — see [`line_based::detect_themed_with_original`].
/// Without an original, both fall back to light-mode behavior.
pub fn detect_grid_with_original(
    img: &RgbImage,
    method: DetectionMethod,
    original_img: Option<&RgbImage>,
) -> Result<GridDetectionResult, ProcessingError> {
    match method {
        DetectionMethod::LineBased => {
            let dark_mode = original_img
                .map(crate::image_utils::is_dark_mode)
                .unwrap_or(false);
            line_based::detect_themed_with_original(img, original_img, dark_mode)
        }
        #[cfg(feature = "ocr")]
        DetectionMethod::OcrAnchored => ocr_anchored::detect_with_original(img, original_img),
        #[cfg(not(feature = "ocr"))]
        DetectionMethod::OcrAnchored => Err(ProcessingError::GridDetection(
            "OcrAnchored detection requires the 'ocr' feature".to_string(),
        )),
        DetectionMethod::Manual => Err(ProcessingError::GridDetection(
            "Manual detection requires user-provided coordinates".to_string(),
        )),
    }
}

/// Calculate ROI from user-provided click coordinates.
///
/// Port of Python `calculate_roi_from_clicks()`.
pub fn calculate_roi_from_clicks(
    upper_left: [i32; 2],
    lower_right: [i32; 2],
    img_width: u32,
    img_height: u32,
) -> Result<GridBounds, ProcessingError> {
    if upper_left[0] < 0 || upper_left[1] < 0 || lower_right[0] < 0 || lower_right[1] < 0 {
        return Err(ProcessingError::InvalidRoi(
            "Coordinates cannot be negative".to_string(),
        ));
    }

    let roi_width = lower_right[0] - upper_left[0];
    let roi_height = lower_right[1] - upper_left[1];

    if roi_width <= 0 || roi_height <= 0 {
        return Err(ProcessingError::InvalidRoi(format!(
            "Invalid region dimensions: width={roi_width}, height={roi_height}"
        )));
    }

    if roi_width < MIN_HOURLY_GRID_WIDTH || roi_height < MIN_HOURLY_GRID_HEIGHT {
        return Err(ProcessingError::InvalidRoi(format!(
            "Region is too small for 24-hour extraction: width={roi_width}, height={roi_height}"
        )));
    }

    if upper_left[0] as u32 >= img_width || upper_left[1] as u32 >= img_height {
        return Err(ProcessingError::InvalidRoi(format!(
            "Upper left ({}, {}) exceeds image bounds ({img_width}, {img_height})",
            upper_left[0], upper_left[1]
        )));
    }

    if lower_right[0] as u32 > img_width || lower_right[1] as u32 > img_height {
        return Err(ProcessingError::InvalidRoi(format!(
            "Lower right ({}, {}) exceeds image bounds ({img_width}, {img_height})",
            lower_right[0], lower_right[1]
        )));
    }

    Ok(GridBounds::new(
        upper_left[0],
        upper_left[1],
        lower_right[0],
        lower_right[1],
    ))
}

/// Calculate ROI from anchor positions.
///
/// Port of Python `calculate_roi()`.
pub fn calculate_roi(
    lower_left_x: i32,
    upper_right_y: i32,
    roi_width: i32,
    roi_height: i32,
    img_width: u32,
    img_height: u32,
) -> Result<GridBounds, ProcessingError> {
    if lower_left_x < 0 {
        return Err(ProcessingError::InvalidRoi(format!(
            "Invalid ROI lower left x: {lower_left_x}"
        )));
    }
    if upper_right_y < 0 {
        return Err(ProcessingError::InvalidRoi(format!(
            "Invalid ROI upper right y: {upper_right_y}"
        )));
    }
    if roi_width <= 0 || roi_height <= 0 {
        return Err(ProcessingError::InvalidRoi(format!(
            "Invalid ROI dimensions: {roi_width}x{roi_height}"
        )));
    }
    if lower_left_x as u32 >= img_width {
        return Err(ProcessingError::InvalidRoi(format!(
            "ROI x {lower_left_x} exceeds image width {img_width}"
        )));
    }
    if upper_right_y as u32 >= img_height {
        return Err(ProcessingError::InvalidRoi(format!(
            "ROI y {upper_right_y} exceeds image height {img_height}"
        )));
    }
    if lower_left_x + roi_width > img_width as i32 {
        return Err(ProcessingError::InvalidRoi(format!(
            "ROI extends beyond image width: {} > {img_width}",
            lower_left_x + roi_width
        )));
    }
    if upper_right_y + roi_height > img_height as i32 {
        return Err(ProcessingError::InvalidRoi(format!(
            "ROI extends beyond image height: {} > {img_height}",
            upper_right_y + roi_height
        )));
    }

    Ok(GridBounds::from_roi(
        lower_left_x,
        upper_right_y,
        roi_width,
        roi_height,
    ))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn review_axis_label_strip_matches_direction() {
        let bounds = GridBounds::new(100, 300, 700, 540);
        assert_eq!(
            axis_label_rect(800, 600, &bounds, AxisDirection::Ltr),
            Some((600, 272, 800, 360))
        );
        assert_eq!(
            axis_label_rect(800, 600, &bounds, AxisDirection::Rtl),
            Some((0, 272, 200, 360))
        );
    }

    #[test]
    fn review_axis_ceiling_joins_adjacent_label_words() {
        let words = [
            OcrWord {
                text: "2".into(),
                x: 10,
                y: 10,
                w: 10,
                h: 20,
            },
            OcrWord {
                text: "h".into(),
                x: 24,
                y: 11,
                w: 10,
                h: 20,
            },
            OcrWord {
                text: "1h".into(),
                x: 10,
                y: 80,
                w: 25,
                h: 20,
            },
        ];
        assert_eq!(topmost_axis_minutes(&words), Some(120));
        let unrelated = [
            words[0].clone(),
            OcrWord {
                text: "h".into(),
                x: 200,
                ..words[1].clone()
            },
        ];
        assert_eq!(topmost_axis_minutes(&unrelated), None);
    }

    #[test]
    fn test_calculate_roi_from_clicks_valid() {
        let result = calculate_roi_from_clicks([10, 20], [100, 200], 500, 500);
        assert!(result.is_ok());
        let b = result.unwrap();
        assert_eq!(b.width(), 90);
        assert_eq!(b.height(), 180);
    }

    #[test]
    fn test_calculate_roi_from_clicks_negative() {
        let result = calculate_roi_from_clicks([-1, 0], [100, 100], 500, 500);
        assert!(result.is_err());
    }

    #[test]
    fn test_calculate_roi_from_clicks_inverted() {
        let result = calculate_roi_from_clicks([100, 100], [10, 10], 500, 500);
        assert!(result.is_err());
    }

    #[test]
    fn test_calculate_roi_from_clicks_rejects_tiny_or_off_image_regions() {
        assert!(calculate_roi_from_clicks([10, 10], [11, 11], 500, 500).is_err());
        assert!(calculate_roi_from_clicks([500, 10], [530, 50], 500, 500).is_err());
        assert!(calculate_roi_from_clicks([480, 10], [510, 50], 500, 500).is_err());
    }

    #[test]
    fn test_calculate_roi_valid() {
        let result = calculate_roi(10, 20, 100, 50, 500, 500);
        assert!(result.is_ok());
        let b = result.unwrap();
        assert_eq!(b.roi_x(), 10);
        assert_eq!(b.roi_y(), 20);
        assert_eq!(b.width(), 100);
        assert_eq!(b.height(), 50);
    }

    #[test]
    fn test_calculate_roi_out_of_bounds() {
        let result = calculate_roi(400, 20, 200, 50, 500, 500);
        assert!(result.is_err());
    }
}
