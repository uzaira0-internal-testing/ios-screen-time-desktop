//! Shared types for the image processing pipeline.

use serde::{Deserialize, Serialize};

/// JSON contract version emitted by the Emscripten full-pipeline entry points.
/// The browser rejects results from older binaries instead of silently treating
/// newly-added fields as absent.
///
/// **Bump this whenever ANY exported C-ABI signature changes, not just when a
/// JSON field is added.** JS→wasm calls are not arity-checked: extra arguments
/// are dropped and missing ones become 0. `pipeline_extract_bars` gained an
/// `axis_max_minutes` parameter *before* `out`/`out_len`, so a stale binary
/// paired with new JS reads the ceiling as `out` and the output pointer as
/// `out_len` — it writes to a bogus address and can trap or corrupt the heap,
/// and the `written < 0` guard never fires because the trap comes first. The
/// version handshake is the only thing that catches that skew, and it only
/// catches it if the number moves.
///
/// 4: `pipeline_extract_bars` takes `axis_max_minutes` and reports
///    `applied_axis_max_minutes`.
pub const PIPELINE_SCHEMA_VERSION: u32 = 4;

/// Grid boundary coordinates (upper-left corner + lower-right corner).
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub struct GridBounds {
    pub upper_left_x: i32,
    pub upper_left_y: i32,
    pub lower_right_x: i32,
    pub lower_right_y: i32,
}

impl GridBounds {
    pub fn new(
        upper_left_x: i32,
        upper_left_y: i32,
        lower_right_x: i32,
        lower_right_y: i32,
    ) -> Self {
        Self {
            upper_left_x,
            upper_left_y,
            lower_right_x,
            lower_right_y,
        }
    }

    /// Create from ROI-style (x, y, width, height).
    pub fn from_roi(x: i32, y: i32, width: i32, height: i32) -> Self {
        Self {
            upper_left_x: x,
            upper_left_y: y,
            lower_right_x: x + width,
            lower_right_y: y + height,
        }
    }

    pub fn width(&self) -> i32 {
        self.lower_right_x - self.upper_left_x
    }

    pub fn height(&self) -> i32 {
        self.lower_right_y - self.upper_left_y
    }

    pub fn roi_x(&self) -> i32 {
        self.upper_left_x
    }

    pub fn roi_y(&self) -> i32 {
        self.upper_left_y
    }
}

/// Reading direction of the hourly chart's time axis.
///
/// iOS lays the Screen Time chart out with the locale's writing direction. In
/// LTR locales the hour axis runs `12 AM → 6 PM` left-to-right and the minute
/// labels ("60"/"30") sit on the RIGHT. In RTL locales (Hebrew, Arabic) the
/// whole chart is mirrored: the hour axis runs `0 → 18` **right-to-left** and
/// the minute labels move to the LEFT. Geometry is otherwise identical, so the
/// only consequences are which corners the anchors occupy and whether the 24
/// extracted slices need reversing before they are read as hours 0..23.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AxisDirection {
    /// Hour 0 at the left edge — English and most Latin-script locales.
    #[default]
    Ltr,
    /// Hour 0 at the right edge — Hebrew, Arabic.
    Rtl,
}

impl AxisDirection {
    /// True when the 24 left-to-right slices must be reversed to become hours 0..23.
    pub fn reverses_hours(self) -> bool {
        matches!(self, AxisDirection::Rtl)
    }

    /// Parse the serialized form (`"ltr"` / `"rtl"`). Anything else — including an
    /// empty string from a caller that predates the field — means Ltr, which is the
    /// behaviour every screenshot had before RTL charts were recognised.
    #[allow(clippy::should_implement_trait)]
    pub fn from_str(s: &str) -> Self {
        if s.eq_ignore_ascii_case("rtl") {
            AxisDirection::Rtl
        } else {
            AxisDirection::Ltr
        }
    }
}

/// Result of grid detection.
#[derive(Debug, Clone, Serialize)]
pub struct GridDetectionResult {
    pub success: bool,
    pub bounds: Option<GridBounds>,
    pub confidence: f64,
    pub method: String,
    pub error: Option<String>,
    /// True when the chart was positively identified as the WEEKLY (7-column)
    /// Screen Time view rather than the daily (24-hour) chart this pipeline
    /// reads. Lets the caller reject it definitively (skip the OcrAnchored
    /// fallback) and surface a clear "capture the daily view" message instead of
    /// a generic grid-detection failure. Defaults to `false`.
    #[serde(default)]
    pub is_weekly: bool,
    /// Reading direction of the detected hour axis. Detectors that cannot
    /// establish direction leave this at `Ltr`, which is the historical
    /// behaviour and keeps existing bar ordering byte-identical.
    #[serde(default)]
    pub axis_direction: AxisDirection,
}

/// Full pipeline processing result returned to the frontend.
#[derive(Debug, Clone, Serialize)]
pub struct ProcessingResult {
    /// 24 hourly values (minutes per clock hour). Values can exceed 60 when a
    /// screenshot aggregates usage from multiple devices.
    pub hourly_values: Option<Vec<f64>>,
    /// Sum of all 24 values.
    pub total: f64,
    /// OCR-extracted app name (if available).
    pub title: Option<String>,
    /// OCR-extracted total time string (e.g. "4h 36m").
    pub total_text: Option<String>,
    /// Detected grid boundaries.
    pub grid_bounds: Option<GridBounds>,
    /// Bar alignment quality score (0.0–1.0). None for daily total pages.
    pub alignment_score: Option<f64>,
    /// Structural grid-registration score (0.0–1.0): how well the ROI is framed on
    /// the chart gridlines, independent of the stored values. Catches coherent
    /// vertical-framing errors the alignment score is blind to. None for daily total.
    pub grid_registration_score: Option<f64>,
    /// Which detection method was used.
    pub detection_method: String,
    /// Wall-clock processing time in milliseconds.
    pub processing_time_ms: u64,
    /// True when OCR identified this as a Daily Total / weekly summary page.
    pub is_daily_total: bool,
    /// Processing issues encountered (e.g. grid detection failure).
    pub issues: Vec<String>,
    /// True if any issue is blocking (e.g. no grid detected).
    pub has_blocking_issues: bool,
    /// Grid detection confidence score (0.0–1.0).
    pub grid_detection_confidence: Option<f64>,
    /// Y position of the title text (used for downstream layout).
    pub title_y_position: Option<i32>,
    /// True when OCR evidence suggests the screenshot is aggregating Screen Time
    /// from more than one device. This is a review flag, never an automatic skip.
    pub suspected_all_devices: bool,
    /// Largest chart-axis label OCR interpreted as minutes (for example, 120
    /// for a "2 hr" y-axis). None when no reliable axis label was found.
    pub axis_max_minutes: Option<i32>,
    /// Human-readable evidence behind `suspected_all_devices`.
    pub all_devices_reasons: Vec<String>,
    /// True only when the OCR engine itself failed. Grid, image-load, and bar
    /// extraction failures must not set this flag.
    pub ocr_failed: bool,
    /// OCR engine error retained for review/export when `ocr_failed` is true.
    pub ocr_error: Option<String>,
}

/// Processing pipeline errors.
#[derive(Debug, thiserror::Error)]
pub enum ProcessingError {
    #[error("Image load error: {0}")]
    ImageLoad(String),

    #[error("Grid detection failed: {0}")]
    GridDetection(String),

    #[error("Invalid ROI: {0}")]
    InvalidRoi(String),

    #[error("OCR error: {0}")]
    Ocr(String),

    #[error("Processing error: {0}")]
    General(String),
}

impl From<image::ImageError> for ProcessingError {
    fn from(e: image::ImageError) -> Self {
        ProcessingError::ImageLoad(e.to_string())
    }
}

/// Image type being processed.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ImageType {
    ScreenTime,
    Battery,
}

impl ImageType {
    #[allow(clippy::should_implement_trait)]
    pub fn from_str(s: &str) -> Self {
        match s {
            "battery" => ImageType::Battery,
            _ => ImageType::ScreenTime,
        }
    }
}

/// Grid detection method to use.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DetectionMethod {
    LineBased,
    OcrAnchored,
    Manual,
}

impl DetectionMethod {
    #[allow(clippy::should_implement_trait)]
    pub fn from_str(s: &str) -> Self {
        match s {
            "ocr_anchored" => DetectionMethod::OcrAnchored,
            "manual" => DetectionMethod::Manual,
            _ => DetectionMethod::LineBased,
        }
    }

    pub fn as_str(&self) -> &'static str {
        match self {
            DetectionMethod::LineBased => "line_based",
            DetectionMethod::OcrAnchored => "ocr_anchored",
            DetectionMethod::Manual => "manual",
        }
    }
}
