//! PHI region redaction — Rust port of the WASM canvas redaction
//! (`frontend/.../preprocessing/phiRedaction.ts`).
//!
//! Roadmap #7 (Rust accelerator coverage): moves the per-pixel redaction hot
//! path off the JS canvas into the shared Rust crate, so the *same* tested
//! implementation backs the server (PyO3) and the offline Emscripten WASM
//! pipeline. No OCR dependency — builds with `--no-default-features`.
//!
//! Redaction is IRREVERSIBLE by construction (ADR-0005): box methods overwrite
//! every pixel in the padded region with one opaque colour, so no original
//! pixel survives; pixelate replaces each block with its mean (lossy and
//! block-uniform). Nothing outside the padded regions is ever touched. An
//! unknown method falls back to an opaque BLACK box — PHI is never left
//! un-redacted (the JS `switch` had no default and would silently no-op, a
//! latent hole this port closes).
//!
//! Buffers are RGBA (4 bytes/pixel) — the layout of canvas `ImageData` and the
//! Emscripten pipeline, so no format conversion is needed at the boundary.

use serde::Deserialize;

/// A rectangular region to redact, in pixel coordinates. Deserialized from the
/// JS `PHIRegion` shape; extra fields (label/source/confidence/text) are
/// ignored.
#[derive(Clone, Copy, Debug, Deserialize)]
pub struct RedactRegion {
    pub x: i32,
    pub y: i32,
    pub w: i32,
    pub h: i32,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RedactionMethod {
    RedBox,
    BlackBox,
    Pixelate,
}

impl RedactionMethod {
    /// Parse the JS method string. Unknown → `BlackBox` (fail safe — never
    /// leave PHI visible).
    pub fn from_js(s: &str) -> Self {
        match s {
            "redbox" => RedactionMethod::RedBox,
            "pixelate" => RedactionMethod::Pixelate,
            _ => RedactionMethod::BlackBox,
        }
    }
}

/// Redact `regions` in place on an RGBA buffer. Returns the number of regions
/// actually applied (zero-area / fully off-image regions are skipped). `padding`
/// expands each region on every side, matching the canvas path's default of 2.
///
/// Returns 0 without touching the buffer if `rgba` is too small for
/// `width * height * 4`.
pub fn redact_regions_rgba(
    rgba: &mut [u8],
    width: u32,
    height: u32,
    regions: &[RedactRegion],
    method: RedactionMethod,
    padding: i32,
) -> usize {
    let Some(required_len) = (width as usize)
        .checked_mul(height as usize)
        .and_then(|pixels| pixels.checked_mul(4))
    else {
        return 0;
    };
    let w = width as i64;
    let h = height as i64;
    if w <= 0 || h <= 0 || rgba.len() < required_len {
        return 0;
    }
    let pad = padding.max(0) as i64;

    let mut applied = 0;
    for r in regions {
        // Clamp the padded rect to the image — mirrors phiRedaction.ts:
        //   rx = max(0, x - pad);  rw = min(width - rx, w + 2*pad)
        let rx = (r.x as i64 - pad).max(0);
        let ry = (r.y as i64 - pad).max(0);
        if rx >= w || ry >= h {
            continue; // region starts past the image edge
        }
        let rw = (r.w as i64 + 2 * pad).min(w - rx).max(0);
        let rh = (r.h as i64 + 2 * pad).min(h - ry).max(0);
        if rw == 0 || rh == 0 {
            continue;
        }

        match method {
            RedactionMethod::RedBox => fill_rect(rgba, w, rx, ry, rw, rh, [255, 0, 0, 255]),
            RedactionMethod::BlackBox => fill_rect(rgba, w, rx, ry, rw, rh, [0, 0, 0, 255]),
            RedactionMethod::Pixelate => pixelate_rect(rgba, w, rx, ry, rw, rh),
        }
        applied += 1;
    }
    applied
}

/// Overwrite every pixel of a rect with one RGBA colour.
fn fill_rect(rgba: &mut [u8], img_w: i64, rx: i64, ry: i64, rw: i64, rh: i64, color: [u8; 4]) {
    for yy in ry..ry + rh {
        let row = ((yy * img_w + rx) * 4) as usize;
        for xx in 0..rw as usize {
            let i = row + xx * 4;
            rgba[i] = color[0];
            rgba[i + 1] = color[1];
            rgba[i + 2] = color[2];
            rgba[i + 3] = color[3];
        }
    }
}

/// Mosaic a rect: replace each `block x block` cell with its mean RGBA. Block
/// size mirrors the canvas path (`ceil(min(rw, rh) / 10)`, min 1).
fn pixelate_rect(rgba: &mut [u8], img_w: i64, rx: i64, ry: i64, rw: i64, rh: i64) {
    let block = (((rw.min(rh)) as f64 / 3.0).ceil() as i64).max(8);
    let mut by = ry;
    while by < ry + rh {
        let bh = block.min(ry + rh - by);
        let mut bx = rx;
        while bx < rx + rw {
            let bw = block.min(rx + rw - bx);
            let (mut sr, mut sg, mut sb, mut sa) = (0u64, 0u64, 0u64, 0u64);
            for yy in by..by + bh {
                let row = ((yy * img_w + bx) * 4) as usize;
                for xx in 0..bw as usize {
                    let i = row + xx * 4;
                    sr += rgba[i] as u64;
                    sg += rgba[i + 1] as u64;
                    sb += rgba[i + 2] as u64;
                    sa += rgba[i + 3] as u64;
                }
            }
            let n = (bw * bh) as u64;
            let avg = [
                (sr / n) as u8,
                (sg / n) as u8,
                (sb / n) as u8,
                (sa / n) as u8,
            ];
            fill_rect(rgba, img_w, bx, by, bw, bh, avg);
            bx += block;
        }
        by += block;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn review_pixelation_obscures_small_name_region() {
        let (w, h) = (34, 10);
        let mut buf = gradient(w, h);
        let before = buf.clone();
        pixelate_rect(&mut buf, w as i64, 0, 0, w as i64, h as i64);
        assert_ne!(buf, before);
        for by in (0..h).step_by(8) {
            for bx in (0..w).step_by(8) {
                let color = px(&buf, w, bx, by);
                let mut changed = false;
                for y in by..(by + 8).min(h) {
                    for x in bx..(bx + 8).min(w) {
                        assert_eq!(px(&buf, w, x, y), color);
                        changed |= px(&buf, w, x, y) != px(&before, w, x, y);
                    }
                }
                assert!(changed);
            }
        }
    }

    // A WxH gradient so every pixel is distinct — makes "original survived?"
    // checks meaningful.
    fn gradient(w: u32, h: u32) -> Vec<u8> {
        let mut v = vec![0u8; (w * h * 4) as usize];
        for y in 0..h {
            for x in 0..w {
                let i = ((y * w + x) * 4) as usize;
                v[i] = (x % 256) as u8;
                v[i + 1] = (y % 256) as u8;
                v[i + 2] = ((x + y) % 256) as u8;
                v[i + 3] = 255;
            }
        }
        v
    }

    fn px(buf: &[u8], w: u32, x: u32, y: u32) -> [u8; 4] {
        let i = ((y * w + x) * 4) as usize;
        [buf[i], buf[i + 1], buf[i + 2], buf[i + 3]]
    }

    #[test]
    fn redbox_fills_region_and_leaves_outside_untouched() {
        let (w, h) = (20, 20);
        let mut buf = gradient(w, h);
        let before = buf.clone();
        let n = redact_regions_rgba(
            &mut buf,
            w,
            h,
            &[RedactRegion {
                x: 5,
                y: 5,
                w: 6,
                h: 6,
            }],
            RedactionMethod::RedBox,
            0,
        );
        assert_eq!(n, 1);
        // Every pixel inside the box is exactly red — no original pixel survives.
        for y in 5..11 {
            for x in 5..11 {
                assert_eq!(px(&buf, w, x, y), [255, 0, 0, 255]);
            }
        }
        // A pixel just outside is unchanged.
        assert_eq!(px(&buf, w, 4, 4), px(&before, w, 4, 4));
        assert_eq!(px(&buf, w, 11, 11), px(&before, w, 11, 11));
    }

    #[test]
    fn blackbox_is_irreversible_single_colour() {
        let (w, h) = (16, 16);
        let mut buf = gradient(w, h);
        redact_regions_rgba(
            &mut buf,
            w,
            h,
            &[RedactRegion {
                x: 2,
                y: 2,
                w: 10,
                h: 10,
            }],
            RedactionMethod::BlackBox,
            0,
        );
        let mut distinct = std::collections::HashSet::new();
        for y in 2..12 {
            for x in 2..12 {
                distinct.insert(px(&buf, w, x, y));
            }
        }
        // Entropy collapsed to a single opaque-black colour ⇒ no information left.
        assert_eq!(distinct.len(), 1);
        assert!(distinct.contains(&[0, 0, 0, 255]));
    }

    #[test]
    fn padding_expands_the_redacted_rect() {
        let (w, h) = (20, 20);
        let mut buf = gradient(w, h);
        redact_regions_rgba(
            &mut buf,
            w,
            h,
            &[RedactRegion {
                x: 8,
                y: 8,
                w: 4,
                h: 4,
            }],
            RedactionMethod::BlackBox,
            2,
        );
        // With padding 2 the box spans x,y in [6, 14).
        assert_eq!(px(&buf, w, 6, 6), [0, 0, 0, 255]);
        assert_eq!(px(&buf, w, 13, 13), [0, 0, 0, 255]);
        // x=5 (one pixel outside the padded box) is untouched.
        assert_ne!(px(&buf, w, 5, 5), [0, 0, 0, 255]);
    }

    #[test]
    fn region_is_clamped_to_image_bounds() {
        let (w, h) = (10, 10);
        let mut buf = gradient(w, h);
        // Region overhangs the right/bottom edge; only the in-bounds part redacts.
        let n = redact_regions_rgba(
            &mut buf,
            w,
            h,
            &[RedactRegion {
                x: 7,
                y: 7,
                w: 50,
                h: 50,
            }],
            RedactionMethod::BlackBox,
            0,
        );
        assert_eq!(n, 1);
        assert_eq!(px(&buf, w, 9, 9), [0, 0, 0, 255]); // last in-bounds pixel redacted
        assert_eq!(px(&buf, w, 6, 6), {
            // just outside the region, original
            let g = gradient(w, h);
            px(&g, w, 6, 6)
        });
    }

    #[test]
    fn fully_offscreen_region_is_skipped() {
        let (w, h) = (10, 10);
        let mut buf = gradient(w, h);
        let before = buf.clone();
        let n = redact_regions_rgba(
            &mut buf,
            w,
            h,
            &[RedactRegion {
                x: 100,
                y: 100,
                w: 5,
                h: 5,
            }],
            RedactionMethod::BlackBox,
            0,
        );
        assert_eq!(n, 0);
        assert_eq!(buf, before); // buffer untouched
    }

    #[test]
    fn pixelate_is_lossy_and_block_uniform() {
        let (w, h) = (20, 20);
        let mut buf = gradient(w, h);
        let before = buf.clone();
        redact_regions_rgba(
            &mut buf,
            w,
            h,
            &[RedactRegion {
                x: 0,
                y: 0,
                w: 20,
                h: 20,
            }],
            RedactionMethod::Pixelate,
            0,
        );
        // block = max(ceil(20/3), 8) = 8, including partial edge blocks.
        for by in (0..20).step_by(8) {
            for bx in (0..20).step_by(8) {
                let c = px(&buf, w, bx, by);
                for y in by..(by + 8).min(h) {
                    for x in bx..(bx + 8).min(w) {
                        assert_eq!(px(&buf, w, x, y), c);
                    }
                }
            }
        }
        // Lossy: the result is not the original gradient.
        assert_ne!(buf, before);
    }

    #[test]
    fn unknown_method_fails_safe_to_black() {
        assert_eq!(
            RedactionMethod::from_js("nonsense"),
            RedactionMethod::BlackBox
        );
        assert_eq!(RedactionMethod::from_js(""), RedactionMethod::BlackBox);
        assert_eq!(RedactionMethod::from_js("redbox"), RedactionMethod::RedBox);
        assert_eq!(
            RedactionMethod::from_js("pixelate"),
            RedactionMethod::Pixelate
        );
        assert_eq!(
            RedactionMethod::from_js("blackbox"),
            RedactionMethod::BlackBox
        );
    }

    #[test]
    fn empty_regions_and_undersized_buffer_are_noops() {
        let (w, h) = (8, 8);
        let mut buf = gradient(w, h);
        let before = buf.clone();
        assert_eq!(
            redact_regions_rgba(&mut buf, w, h, &[], RedactionMethod::BlackBox, 2),
            0
        );
        assert_eq!(buf, before);

        // Buffer too small for the declared dimensions → no-op, no panic.
        let mut tiny = vec![0u8; 4];
        assert_eq!(
            redact_regions_rgba(
                &mut tiny,
                w,
                h,
                &[RedactRegion {
                    x: 0,
                    y: 0,
                    w: 2,
                    h: 2
                }],
                RedactionMethod::BlackBox,
                0,
            ),
            0
        );
    }

    #[test]
    fn deserializes_from_phi_region_json_ignoring_extra_fields() {
        let json = r#"[{"x":1,"y":2,"w":3,"h":4,"label":"PERSON","source":"ner","confidence":0.9,"text":"Jane"}]"#;
        let regions: Vec<RedactRegion> = serde_json::from_str(json).unwrap();
        assert_eq!(regions.len(), 1);
        assert_eq!(
            (regions[0].x, regions[0].y, regions[0].w, regions[0].h),
            (1, 2, 3, 4)
        );
    }
}
