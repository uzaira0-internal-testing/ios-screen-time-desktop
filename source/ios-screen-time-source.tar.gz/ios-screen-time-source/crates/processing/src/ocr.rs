//! OCR text extraction and pattern matching.
//!
//! Port of Python ocr.py — regex patterns for digit normalization,
//! time extraction, and daily total page detection.

#[cfg(feature = "ocr")]
use std::{
    cell::RefCell,
    sync::atomic::{AtomicUsize, Ordering},
};

use lazy_static::lazy_static;
use regex::Regex;

// ---------------------------------------------------------------------------
// Thread-local cached LepTess instance — avoids re-loading eng.traineddata
// on every call (saves ~200ms per image).
// ---------------------------------------------------------------------------

#[cfg(feature = "ocr")]
thread_local! {
    /// Cached engine plus the language string it was built with, so a language
    /// change rebuilds it instead of silently recognising with the old packs.
    static LEPTESS: RefCell<Option<(String, Tess)>> = const { RefCell::new(None) };

    /// Second engine, permanently pinned to [`DEFAULT_OCR_LANG`], used for the
    /// grid-anchor reads in `grid_detection::ocr_anchored`.
    ///
    /// Those reads are pure geometry: they look for the digit strings "60" and
    /// "0/6/12/18" to locate the chart, and every locale renders them in Western
    /// numerals. Adding a language pack to that call measurably HARMS it — with
    /// `eng+heb` loaded, Tesseract stops reporting the "60" minute label on the
    /// reference Hebrew screenshot and grid detection fails outright, so
    /// installing the pack for a Hebrew phone would break the very screenshots it
    /// was installed for. Keeping a separate cached instance also avoids
    /// thrashing: one shared engine would have to be torn down and rebuilt on
    /// every switch between anchor reads and title/total reads.
    static LEPTESS_ANCHOR: RefCell<Option<Tess>> = const { RefCell::new(None) };

    /// Language string handed to Tesseract, e.g. `"eng"` or `"eng+heb"`.
    ///
    /// English is always present: it is the only pack bundled with the app, it
    /// reads the Western digits every locale's chart axis uses, and Latin app
    /// names ("WhatsApp", "Safari") stay readable even on a Hebrew UI. Extra
    /// packs are appended when the user has downloaded them.
    static OCR_LANG: RefCell<String> = RefCell::new(DEFAULT_OCR_LANG.to_string());
}

/// The always-available language. Mirrors
/// `shared/language_packs.json::always_bundled`.
#[cfg(feature = "ocr")]
pub const DEFAULT_OCR_LANG: &str = "eng";

/// Set the Tesseract language string for this thread.
///
/// Accepts Tesseract's `+`-joined form. `eng` is forced to the front when
/// missing so digit and Latin-script reads never regress by adding a pack.
/// Empty input resets to [`DEFAULT_OCR_LANG`].
#[cfg(feature = "ocr")]
pub fn set_ocr_language(lang: &str) {
    let trimmed = lang.trim();
    let resolved = if trimmed.is_empty() {
        DEFAULT_OCR_LANG.to_string()
    } else if trimmed
        .split('+')
        .any(|part| part.trim() == DEFAULT_OCR_LANG)
    {
        trimmed.to_string()
    } else {
        format!("{DEFAULT_OCR_LANG}+{trimmed}")
    };
    OCR_LANG.with(|cell| *cell.borrow_mut() = resolved);
}

/// Current Tesseract language string for this thread.
#[cfg(feature = "ocr")]
pub fn ocr_language() -> String {
    OCR_LANG.with(|cell| cell.borrow().clone())
}

/// Coarse OCR path counters for tests and diagnostics.
///
/// These deliberately count Tesseract entry points, not downstream parsing
/// decisions. The pipeline goal is to keep title/total extraction on bounded
/// regions and make any full-frame fallback explicit.
#[cfg(feature = "ocr")]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct OcrTelemetry {
    pub title_total_region_calls: usize,
    pub title_total_full_frame_calls: usize,
}

#[cfg(feature = "ocr")]
static TITLE_TOTAL_REGION_CALLS: AtomicUsize = AtomicUsize::new(0);
#[cfg(feature = "ocr")]
static TITLE_TOTAL_FULL_FRAME_CALLS: AtomicUsize = AtomicUsize::new(0);

#[cfg(feature = "ocr")]
pub fn reset_ocr_telemetry() {
    TITLE_TOTAL_REGION_CALLS.store(0, Ordering::Relaxed);
    TITLE_TOTAL_FULL_FRAME_CALLS.store(0, Ordering::Relaxed);
}

#[cfg(feature = "ocr")]
pub fn ocr_telemetry_snapshot() -> OcrTelemetry {
    OcrTelemetry {
        title_total_region_calls: TITLE_TOTAL_REGION_CALLS.load(Ordering::Relaxed),
        title_total_full_frame_calls: TITLE_TOTAL_FULL_FRAME_CALLS.load(Ordering::Relaxed),
    }
}

/// Get or initialise the thread-local LepTess instance.
#[cfg(feature = "ocr")]
fn with_leptess<F, T>(psm: &str, f: F) -> Result<T, crate::types::ProcessingError>
where
    F: FnOnce(&mut Tess) -> Result<T, crate::types::ProcessingError>,
{
    let want = ocr_language();
    LEPTESS.with(|cell| {
        let mut opt = cell.borrow_mut();
        // Rebuild when the language changed — Tesseract binds its packs at init,
        // so reusing a stale engine would quietly recognise with the old set.
        if opt.as_ref().is_none_or(|(lang, _)| *lang != want) {
            // NOTE: the Tier-1 perf flags (tessedit_do_invert=0 + user_defined_dpi=300)
            // were REVERTED — `do_invert=0` disables Tesseract's inverted-retry pass,
            // which suppressed the OCR total on some real (non-fixture) screenshots in
            // the live app. The ~1.05x they bought is not worth missing a total; let
            // Tesseract default do_invert=1 (inverted rescue) and estimate DPI per image.
            // A selected pack whose .traineddata is absent (never downloaded,
            // evicted, or a failed download) makes Tesseract refuse to init at
            // all. Degrading to English keeps every screenshot processable —
            // grid, bars and Latin app names are unaffected — instead of
            // failing the whole pipeline over an optional accuracy upgrade.
            let lt = match Tess::new(&want) {
                Ok(lt) => lt,
                Err(e) if want != DEFAULT_OCR_LANG => {
                    log::warn!(
                        "Tesseract init failed for language '{want}' ({e}); \
                         falling back to '{DEFAULT_OCR_LANG}'. A downloaded \
                         language pack is probably missing."
                    );
                    Tess::new(DEFAULT_OCR_LANG).map_err(|e2| {
                        crate::types::ProcessingError::Ocr(format!(
                            "Tesseract init failed for '{DEFAULT_OCR_LANG}': {e2}"
                        ))
                    })?
                }
                Err(e) => {
                    return Err(crate::types::ProcessingError::Ocr(format!(
                        "Tesseract init failed for language '{want}': {e}"
                    )));
                }
            };
            *opt = Some((want.clone(), lt));
        }
        let (_, lt) = opt.as_mut().unwrap();
        // PSM may differ per call — set it every time (cheap)
        if lt
            .set_variable(leptess::Variable::TesseditPagesegMode, psm)
            .is_err()
        {
            log::warn!(
                "Failed to set Tesseract PSM to '{}', using previous setting",
                psm
            );
        }
        f(lt)
    })
}

// ---------------------------------------------------------------------------
// Pre-compiled regex patterns for OCR digit normalization
// ---------------------------------------------------------------------------

lazy_static! {
    // Every `*_BEFORE_UNIT` rule rewrites a LETTER into a digit when a unit
    // follows, so each needs to know what may stand to that letter's left. A
    // confused glyph is the first character of its token — the whole
    // lost-hours machinery models it that way (`RE_LETTER_HOUR` is `^[A-Za-z]h$`,
    // matched against trimmed whole words) — while a letter with another letter
    // before it is just a word. Without the guard `Settings` normalized to
    // `Settin9s` and read as a 9-second total; `High`, `Although`, `Film`,
    // `Anselm` and every `…gs`/`…bs` plural went the same way. Measured over a
    // system word list: 4,314 real words corrupted before, 28 after.
    //
    // `[^\p{L}]` and not `[^A-Za-z]`: an ASCII-only exclusion still rewrites
    // `éSh` and `שעותSh`. Excluding letters rather than naming the few characters
    // allowed to precede a digit is what keeps `.Sh 15m`, `:Bh 14m` and
    // `'gh 4m` — a speck beside the glyph is the normal case, and refusing those
    // silently drops the hour and reports the minutes alone.
    //
    // The `[IlO|SBGbgqZzAT]*` run is what keeps the guard from breaking a reading
    // in HALF. Confusions come in pairs — `50m` reaches us as `SOm`, both digits
    // lost — and each rule can only repair the glyph it names, leaving the other
    // still a letter. Demanding a non-letter immediately to the left therefore made
    // the second repair impossible to reach: `SOm` needs `O`→`0` first, but `S`
    // stands to the `O`'s left. Allowing a run of *confusable* letters (never
    // arbitrary ones) restores those chains without readmitting real words —
    // `USBs` and `Settings` still have a plain letter before the glyph. Measured
    // over 392,567 corrupted readings: 4,184 chained recoveries restored, none
    // lost; over the same word list, 20 words corrupted before, 27 after, against
    // 2,288 with no guard at all.

    // 1-like characters: I, l, |
    static ref RE_1_BEFORE_UNIT: Regex = Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([Il|])(\s*[hm]\b)").unwrap();
    static ref RE_1_AFTER_DIGIT: Regex = Regex::new(r"(\d)([Il|])(\s*[hms]\b)").unwrap();
    static ref RE_1_BEFORE_DIGIT: Regex = Regex::new(r"([Il|])(\d)").unwrap();

    // 0-like characters: O
    static ref RE_0_BEFORE_UNIT: Regex = Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([O])(\s*[hms]\b)").unwrap();
    static ref RE_0_AFTER_DIGIT: Regex = Regex::new(r"(\d)([O])(\s*[hms]\b)").unwrap();
    static ref RE_0_BEFORE_DIGIT: Regex = Regex::new(r"([O])(\d)").unwrap();
    static ref RE_0_BETWEEN_DIGITS: Regex = Regex::new(r"(\d)([O])(\d)").unwrap();

    // 4-like characters: A
    static ref RE_4_BEFORE_UNIT: Regex = Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([A])(\s*[hm]\b)").unwrap();
    static ref RE_4_AFTER_DIGIT: Regex = Regex::new(r"(\d)([A])(\s*[hms]\b)").unwrap();

    // 5-like characters: S
    static ref RE_5_BEFORE_UNIT: Regex = Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([S])(\s*[hm]\b)").unwrap();
    static ref RE_5_AFTER_DIGIT: Regex = Regex::new(r"(\d)([S])(\s*[hm]\b)").unwrap();
    static ref RE_5_BEFORE_DIGIT: Regex = Regex::new(r"([S])(\d)").unwrap();

    // 6-like characters: G, b
    static ref RE_6_BEFORE_UNIT: Regex = Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([Gb])(\s*[hms]\b)").unwrap();
    static ref RE_6_AFTER_DIGIT: Regex = Regex::new(r"(\d)([Gb])(\s*[hms]\b)").unwrap();

    // 8-like characters: B
    static ref RE_8_BEFORE_UNIT: Regex = Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([B])(\s*[hms]\b)").unwrap();
    static ref RE_8_AFTER_DIGIT: Regex = Regex::new(r"(\d)([B])(\s*[hms]\b)").unwrap();

    // 9-like characters: g, q
    static ref RE_9_BEFORE_UNIT: Regex = Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([gq])(\s*[hms]\b)").unwrap();
    static ref RE_9_AFTER_DIGIT: Regex = Regex::new(r"(\d)([gq])(\s*[hms]\b)").unwrap();

    // 2-like characters: Z
    static ref RE_2_BEFORE_UNIT: Regex = Regex::new(
        r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([Zz])(\s*(?:h(?:r|rs|our|ours)?|m(?:in|ins|inute|inutes)?|s)\b)"
    )
    .unwrap();
    static ref RE_2_AFTER_DIGIT: Regex = Regex::new(
        r"(\d)([Zz])(\s*(?:h(?:r|rs|our|ours)?|m(?:in|ins|inute|inutes)?|s)\b)"
    )
    .unwrap();

    // 7-like characters: T, and the bare diagonal `/` left when the 7's top bar
    // fades out (`27m` comes back as `2/m`).
    //
    // What separates the 7 from a real slash is the LETTER to its left: `km/h`,
    // `w/ messages` and `5 €/h` all have one, a faded 7 never does. Excluding
    // letters rather than naming the handful of characters allowed to precede a 7
    // is what keeps `'/h 15m`, `./h 15m` and `·/h 15m` recoverable — a speck or a
    // lost space beside the stroke is the normal case, not a disqualifying one.
    // `\p{L}` and not `[A-Za-z]`, so the six language packs that print the hour as
    // `h` cannot smuggle `é/h 15m` through as seven hours.
    //
    // The unit must sit flush against the stroke. With `\s*` there, a free-standing
    // `5 / h` — a slash that belongs to nothing — became seven hours.
    static ref RE_7_BEFORE_UNIT: Regex = Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([T])(\s*[hms]\b)").unwrap();
    static ref RE_7_SLASH_UNIT: Regex = Regex::new(r"(^|[^\p{L}])/([hms]\b)").unwrap();
    // `/` needs no arm here: a digit is not a letter, so the slash shape is already
    // spent by the time this runs.
    static ref RE_7_AFTER_DIGIT: Regex = Regex::new(r"(\d)([T])(\s*[hms]\b)").unwrap();
    /// The same stroke read *in addition to* the 7 it belongs to (`27m` -> `2/7m`).
    /// Only the doubled *seven* collapses here; `1/2 h` is a fraction, not a `12h`.
    static ref RE_7_SPLIT_DIGIT: Regex = Regex::new(r"([0-9])/(7\s*[hms]\b)").unwrap();
    /// A stroke doubling any OTHER digit, recognised by the hour that precedes it:
    /// `8h 4/5m` is `8h 45m`. Restricting to text already inside a duration is what
    /// separates it from a fraction — `1/2 h` has no hour to its left and is left
    /// alone. Without this the leading digit is not merely un-repaired, it is
    /// DROPPED: `RE_HOUR_MIN_NO_M` reads `8h 4` and reports `8h 4m`.
    static ref RE_7_SPLIT_IN_MINUTES: Regex =
        Regex::new(r"([0-9]{1,2}\s*h\s*)([0-9])/([0-9]{1,2}\s*m\b)").unwrap();

    // Time extraction patterns
    static ref RE_HOUR_MIN: Regex = Regex::new(r"([0-9]{1,2})\s*h\s*([0-9]{1,2})\s*m").unwrap();
    // Rust regex has no lookahead, so the trailing unit is captured and rejected in
    // code. Python mirrors the same shape on purpose: a lookahead there backtracks
    // to a shorter number instead of giving up, turning `5h 30s` into `5h 3m`.
    static ref RE_HOUR_MIN_NO_M: Regex = Regex::new(r"([0-9]{1,2})\s*h\s+([0-9]{1,2})(\s*[hms])?").unwrap();
    static ref RE_MIN_SEC: Regex = Regex::new(r"([0-9]{1,2})\s*m\s*([0O]|[0-9]{1,2})\s*s").unwrap();
    static ref RE_MIN_ONLY: Regex = Regex::new(r"([0-9]{1,2})\s*m\b").unwrap();
    static ref RE_HOURS_ONLY: Regex = Regex::new(r"([0-9]{1,2})\s*h\b").unwrap();
    /// Where an hour token STARTS, with no `\b` so `4h30m` is still found.
    /// Used to ask whether a duration is the first one on a row, never to read
    /// a value.
    static ref RE_HOUR_TOKEN: Regex = Regex::new(r"([0-9]{1,2})\s*h").unwrap();
    static ref RE_SEC_ONLY: Regex = Regex::new(r"([0O]|[0-9]{1,2})\s*s\b").unwrap();
    static ref RE_HAS_TIME: Regex = Regex::new(r"[0-9]+\s*[hms]").unwrap();
    /// A whole-hour total with no minutes, exactly as iOS prints it: `8h`.
    static ref RE_BARE_HOUR: Regex = Regex::new(r"^([0-9]{1,2})h$").unwrap();
    // A letter sitting where the hours digit belongs: `Sh`, `gh`, `Oh`.
    static ref RE_LETTER_HOUR: Regex = Regex::new(r"^[A-Za-z]h$").unwrap();
    static ref RE_ALL_DEVICES: Regex = Regex::new(r"(?i)\ball\s+devices\b").unwrap();
    static ref RE_AXIS_HOURS: Regex = Regex::new(
        r"(?i)^\s*([0-9]{1,2})(?:[.,]([0-9]{1,2}))?\s*(?:h|hr|hrs|hour|hours)(?:\s*([0-9]{1,2})\s*(?:m|min|mins|minute|minutes))?\s*$"
    )
    .unwrap();
    static ref RE_AXIS_MINUTES: Regex =
        Regex::new(r"(?i)^\s*([0-9]{2,3})\s*(?:m|min|mins|minute|minutes)\s*$").unwrap();
    // --- the deferred chain pass ---
    //
    // Confusions come in PAIRS, and the per-digit blocks above run in a fixed
    // order (1, 0, 4, 5, 6, 8, 9, 2, 7), so the LEADING glyph of a pair is
    // visited before its partner has become a digit and survives as a letter:
    // `IOm` (a misread `10m`) leaves the 1-block untouched, the 0-block then
    // yields `I0m`, and nothing revisits the `I` — the reading ships as `0m`,
    // a confident wrong number that suppresses the empty-total re-read fallback.
    // Only 1, 0 and 5 ever had a before-digit arm at all, so `BOm` (80m), `ZOm`
    // (20m) and `TOm` (70m) all shipped their minutes with the hours digit gone.
    //
    // These rules run AFTER every block above, so the partner is a digit by the
    // time they look, whichever of the pair the rule order favoured. They demand
    // a digit run ENDING IN A UNIT to the glyph's right — `(\d+\s*[hm]\b)`,
    // each digit keeping its own unit class from its BEFORE_UNIT rule — which is
    // what the bare 1/0/5 before-digit arms above never did. A plain word has no
    // digit, so no word can match; a bare code has no unit, so `B12`, `A4`, `Z3`
    // and `T20` stay what they are. The left guard and the confusable-run prefix
    // are the same as BEFORE_UNIT's, for the same reasons.
    //
    // Every rule takes the SAME unit class, `[hms]`. 1, 4 and 5 used to omit
    // seconds, which made the repair depend on which digit was lost rather than
    // on the evidence: `B5s` closed to `85s` and `G5s` to `65s`, while the
    // identically-shaped `A5s` — the OCR of a real `45s` app row — stayed `A5s`
    // and read as `5s`, dropping the tens digit. 1 and 5 were rescued anyway by
    // their unguarded before-digit arms above; 4 has no such arm, so it was the
    // one that stayed wrong. Widening costs nothing measurable: over the
    // 479,826-entry system word list the set of corrupted words is IDENTICAL
    // with `[hm]` and with `[hms]` (43 either way, all of them pre-existing
    // single-glyph BEFORE_UNIT hits like `Ah` -> `4h`), because a word carries
    // no digit for the rule to stand in front of.
    static ref RE_1_CHAIN_BEFORE_DIGIT: Regex =
        Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([Il|])(\d+\s*[hms]\b)").unwrap();
    static ref RE_0_CHAIN_BEFORE_DIGIT: Regex =
        Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([O])(\d+\s*[hms]\b)").unwrap();
    static ref RE_4_CHAIN_BEFORE_DIGIT: Regex =
        Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([A])(\d+\s*[hms]\b)").unwrap();
    static ref RE_5_CHAIN_BEFORE_DIGIT: Regex =
        Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([S])(\d+\s*[hms]\b)").unwrap();
    static ref RE_6_CHAIN_BEFORE_DIGIT: Regex =
        Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([Gb])(\d+\s*[hms]\b)").unwrap();
    static ref RE_8_CHAIN_BEFORE_DIGIT: Regex =
        Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([B])(\d+\s*[hms]\b)").unwrap();
    static ref RE_9_CHAIN_BEFORE_DIGIT: Regex =
        Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([gq])(\d+\s*[hms]\b)").unwrap();
    static ref RE_2_CHAIN_BEFORE_DIGIT: Regex = Regex::new(
        r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([Zz])(\d+\s*(?:h(?:r|rs|our|ours)?|m(?:in|ins|inute|inutes)?|s)\b)"
    )
    .unwrap();
    static ref RE_7_CHAIN_BEFORE_DIGIT: Regex =
        Regex::new(r"(^|[^\p{L}])([IlO|SBGbgqZzAT]*)([T])(\d+\s*[hms]\b)").unwrap();
}

/// Cost ceiling on the deferred chain pass. Not a correctness bound — the pass
/// is monotone (letters become digits, never the reverse), so it converges on
/// its own; this only caps adversarial input.
const MAX_CHAIN_ROUNDS: usize = 8;

/// Normalize common OCR misreadings of digits in time contexts.
///
/// Port of Python `_normalize_ocr_digits()`.
pub fn normalize_ocr_digits(text: &str) -> String {
    let mut result = text.to_string();

    // 1-like: I, l, |
    result = RE_1_BEFORE_UNIT
        .replace_all(&result, "${1}${2}1$4")
        .to_string();
    result = RE_1_AFTER_DIGIT.replace_all(&result, "${1}1$3").to_string();
    result = RE_1_BEFORE_DIGIT.replace_all(&result, "1$2").to_string();

    // 0-like: O
    result = RE_0_BEFORE_UNIT
        .replace_all(&result, "${1}${2}0$4")
        .to_string();
    result = RE_0_AFTER_DIGIT.replace_all(&result, "${1}0$3").to_string();
    result = RE_0_BEFORE_DIGIT.replace_all(&result, "0$2").to_string();
    result = RE_0_BETWEEN_DIGITS
        .replace_all(&result, "${1}0$3")
        .to_string();

    // 4-like: A
    result = RE_4_BEFORE_UNIT
        .replace_all(&result, "${1}${2}4$4")
        .to_string();
    result = RE_4_AFTER_DIGIT.replace_all(&result, "${1}4$3").to_string();

    // 5-like: S
    result = RE_5_BEFORE_UNIT
        .replace_all(&result, "${1}${2}5$4")
        .to_string();
    result = RE_5_AFTER_DIGIT.replace_all(&result, "${1}5$3").to_string();
    result = RE_5_BEFORE_DIGIT.replace_all(&result, "5$2").to_string();

    // 6-like: G, b
    result = RE_6_BEFORE_UNIT
        .replace_all(&result, "${1}${2}6$4")
        .to_string();
    result = RE_6_AFTER_DIGIT.replace_all(&result, "${1}6$3").to_string();

    // 8-like: B
    result = RE_8_BEFORE_UNIT
        .replace_all(&result, "${1}${2}8$4")
        .to_string();
    result = RE_8_AFTER_DIGIT.replace_all(&result, "${1}8$3").to_string();

    // 9-like: g, q
    result = RE_9_BEFORE_UNIT
        .replace_all(&result, "${1}${2}9$4")
        .to_string();
    result = RE_9_AFTER_DIGIT.replace_all(&result, "${1}9$3").to_string();

    // 2-like: Z
    result = RE_2_BEFORE_UNIT
        .replace_all(&result, "${1}${2}2$4")
        .to_string();
    result = RE_2_AFTER_DIGIT.replace_all(&result, "${1}2$3").to_string();

    // 7-like: T, /
    result = RE_7_SPLIT_IN_MINUTES
        .replace_all(&result, "${1}${2}${3}")
        .to_string();
    result = RE_7_SPLIT_DIGIT.replace_all(&result, "${1}$2").to_string();
    result = RE_7_BEFORE_UNIT
        .replace_all(&result, "${1}${2}7$4")
        .to_string();
    result = RE_7_SLASH_UNIT
        .replace_all(&result, "${1}7${2}")
        .to_string();
    result = RE_7_AFTER_DIGIT.replace_all(&result, "${1}7$3").to_string();

    // The deferred chain pass — see the RE_*_CHAIN_BEFORE_DIGIT block. Iterated
    // because each round repairs one glyph and a longer chain exposes the next:
    // `lIOm` is `lI0m` after the blocks above, `l10m` after one round, `110m`
    // after two.
    //
    // The loop runs to a FIXED POINT, and terminates without needing the bound:
    // every rule replaces a letter with a digit and none does the reverse, so
    // each round that changes anything strictly reduces the letters left in the
    // string. `MAX_CHAIN_ROUNDS` is therefore a cost ceiling, not a correctness
    // one, and it is set well above the longest chain any reading can produce.
    //
    // It used to be 3, which stopped mid-chain: `IIIIOm` came out `I1110m`. The
    // real cost of stopping early was not the half-repair but that normalizing
    // was not IDEMPOTENT — `IBs` read `8s` after one call and `18s` after two,
    // so the answer depended on how many times a call site happened to
    // normalize (the row path normalizes twice, `boundary_optimizer` once).
    // Running to convergence makes every call site agree.
    //
    // The equality check makes untouched text cost one comparison.
    for _ in 0..MAX_CHAIN_ROUNDS {
        let before_pass = result.clone();
        result = RE_1_CHAIN_BEFORE_DIGIT
            .replace_all(&result, "${1}${2}1$4")
            .to_string();
        result = RE_0_CHAIN_BEFORE_DIGIT
            .replace_all(&result, "${1}${2}0$4")
            .to_string();
        result = RE_4_CHAIN_BEFORE_DIGIT
            .replace_all(&result, "${1}${2}4$4")
            .to_string();
        result = RE_5_CHAIN_BEFORE_DIGIT
            .replace_all(&result, "${1}${2}5$4")
            .to_string();
        result = RE_6_CHAIN_BEFORE_DIGIT
            .replace_all(&result, "${1}${2}6$4")
            .to_string();
        result = RE_8_CHAIN_BEFORE_DIGIT
            .replace_all(&result, "${1}${2}8$4")
            .to_string();
        result = RE_9_CHAIN_BEFORE_DIGIT
            .replace_all(&result, "${1}${2}9$4")
            .to_string();
        result = RE_2_CHAIN_BEFORE_DIGIT
            .replace_all(&result, "${1}${2}2$4")
            .to_string();
        result = RE_7_CHAIN_BEFORE_DIGIT
            .replace_all(&result, "${1}${2}7$4")
            .to_string();
        if result == before_pass {
            break;
        }
    }

    result
}

/// Extract a time duration value from text using regex patterns.
///
/// Port of Python `_extract_time_from_text()`.
pub fn extract_time_from_text(text: &str) -> String {
    // First normalize OCR errors
    let text = normalize_ocr_digits(text);

    // Try patterns in priority order

    // "Xh Ym" — a candidate whose hours exceed a day is skipped and the search
    // CONTINUES, the same handling an "Xh Y" match carrying a trailing unit
    // already gets below. See `TOTAL_MAX_PLAUSIBLE_HOURS`.
    if let Some(caps) = RE_HOUR_MIN.captures_iter(&text).find(|caps| {
        caps[1].parse::<u32>().unwrap_or(0) <= TOTAL_MAX_PLAUSIBLE_HOURS
            && caps[2].parse::<u32>().unwrap_or(0) < 60
    }) {
        let h: u32 = caps[1].parse().unwrap_or(0);
        let m: u32 = caps[2].parse().unwrap_or(0);
        return format!("{h}h {m}m");
    }

    // "Xh Y" (missing m) — only match when NOT followed by h/m/s unit. Group 3
    // captures that trailing unit; a match carrying one is skipped, not returned.
    //
    // Skipped, and the search CONTINUES. Taking only the leftmost match would
    // abandon the whole tier on the first disqualified candidate, so
    // `9h 4h 36` — a Daily Average sharing the row — would report `9h` instead of
    // reaching the `4h 36` that is actually the total.
    if let Some(caps) = RE_HOUR_MIN_NO_M.captures_iter(&text).find(|caps| {
        caps.get(3).is_none()
            && caps[1].parse::<u32>().unwrap_or(0) <= TOTAL_MAX_PLAUSIBLE_HOURS
            && caps[2].parse::<u32>().unwrap_or(0) < 60
    }) {
        let h: u32 = caps[1].parse().unwrap_or(0);
        let m: u32 = caps[2].parse().unwrap_or(0);
        return format!("{h}h {m}m");
    }

    // "Xm Ys"
    if let Some(caps) = RE_MIN_SEC.captures_iter(&text).find(|caps| {
        caps[1].parse::<u32>().unwrap_or(0) < 60
            && caps[2].replace('O', "0").parse::<u32>().unwrap_or(0) < 60
    }) {
        let m: u32 = caps[1].parse().unwrap_or(0);
        let s_str = caps[2].replace('O', "0");
        let s: u32 = s_str.parse().unwrap_or(0);
        return format!("{m}m {s}s");
    }

    // "Xh"
    if let Some(caps) = RE_HOURS_ONLY
        .captures_iter(&text)
        .find(|caps| caps[1].parse::<u32>().unwrap_or(0) <= TOTAL_MAX_PLAUSIBLE_HOURS)
    {
        let h: u32 = caps[1].parse().unwrap_or(0);
        return format!("{h}h");
    }

    // "Xm"
    if let Some(caps) = RE_MIN_ONLY.captures(&text) {
        let m: u32 = caps[1].parse().unwrap_or(0);
        return format!("{m}m");
    }

    // "Xs"
    if let Some(caps) = RE_SEC_ONLY.captures(&text) {
        let s_str = caps[1].replace('O', "0");
        let s: u32 = s_str.parse().unwrap_or(0);
        return format!("{s}s");
    }

    String::new()
}

/// Check if text contains any time pattern.
pub fn has_time_pattern(text: &str) -> bool {
    RE_HAS_TIME.is_match(text)
}

// ---------------------------------------------------------------------------
// Daily total page detection
// ---------------------------------------------------------------------------

// Page-detection markers are the shared SSoT (`shared/page_markers.json` →
// `generated_constants::{DAILY,APP}_PAGE_MARKERS`). These previously kept a SECOND
// hand-maintained copy here that could silently drift from the JSON; delegating to
// the generated module keeps them in lockstep (same template as grid_detection/lookup.rs).
use crate::generated_constants::{
    APP_PAGE_MARKERS, DAILY_PAGE_MARKERS, MAX_TITLE_LENGTH, TITLE_APP_HEIGHT_INFO_H_MULT,
    TITLE_FALLBACK_BAND_BOTTOM_FRAC, TITLE_FALLBACK_BAND_LEFT_FRAC, TITLE_FALLBACK_BAND_RIGHT_FRAC,
    TITLE_FALLBACK_BAND_TOP_FRAC, TITLE_FALLBACK_ROW_TOL_FRAC, TITLE_X_END_INFO_W_MULT,
    TITLE_X_ORIGIN_INFO_W_MULT, TOTAL_MAX_PLAUSIBLE_HOURS,
};
// Only referenced by the OCR-gated INFO-recovery re-OCR helper.
#[cfg(feature = "ocr")]
use crate::generated_constants::{
    TITLE_INFO_REOCR_BOTTOM_FRAC, TITLE_INFO_REOCR_TOP_FRAC, TOTAL_HEADER_REOCR_BOTTOM_FRAC,
    TOTAL_HEADER_REOCR_TOP_FRAC,
};

/// Determine if OCR text indicates a daily total page (vs app-specific).
///
/// Port of Python `is_daily_total_page()`.
pub fn is_daily_total_page(texts: &[String]) -> bool {
    let mut daily_count = 0;
    let mut app_count = 0;

    for text in texts {
        let upper = text.to_uppercase();

        for marker in DAILY_PAGE_MARKERS {
            if upper.contains(marker) {
                daily_count += 1;
                break;
            }
        }

        for marker in APP_PAGE_MARKERS {
            if upper.contains(marker) {
                app_count += 1;
                break;
            }
        }
    }

    daily_count > app_count
}

// ---------------------------------------------------------------------------
// OCR-based title and total extraction (requires leptess)
// ---------------------------------------------------------------------------

use image::RgbImage;
use log::{debug, info};

#[cfg(feature = "ocr")]
use crate::image_utils::{
    adjust_contrast_brightness, dark_text_contrast, invert_image, is_dark_mode, text_ocr_image,
};
use crate::types::ProcessingError;

/// OCR bounding box from Tesseract (word-level).
/// Shared between ocr.rs and ocr_anchored.rs.
#[derive(Clone)]
pub struct OcrWord {
    pub text: String,
    pub x: i32,
    pub y: i32,
    pub w: i32,
    pub h: i32,
}

/// Review-only data-quality evidence derived from the OCR words already read
/// for title/total extraction. The pipeline intentionally does not reject the
/// screenshot automatically: a reviewer can inspect and correct false positives.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct AllDevicesSignals {
    pub suspected: bool,
    pub axis_max_minutes: Option<i32>,
    pub reasons: Vec<String>,
}

pub(crate) fn parse_axis_minutes(text: &str) -> Option<i32> {
    let normalized = normalize_ocr_digits(text);
    if let Some(captures) = RE_AXIS_HOURS.captures(&normalized) {
        let hours = captures.get(1)?.as_str().parse::<i32>().ok()?;
        let fractional_minutes = captures.get(2).map_or(0, |fraction| {
            let digits = fraction.as_str();
            let numerator = digits.parse::<i32>().unwrap_or(0);
            let denominator = 10_i32.pow(digits.len() as u32);
            (numerator * 60 + denominator / 2) / denominator
        });
        let explicit_minutes = captures
            .get(3)
            .and_then(|minutes| minutes.as_str().parse::<i32>().ok())
            .unwrap_or(0);
        return Some(hours * 60 + fractional_minutes + explicit_minutes);
    }
    RE_AXIS_MINUTES
        .captures(&normalized)
        .and_then(|captures| captures.get(1))
        .and_then(|m| m.as_str().parse::<i32>().ok())
}

fn selector_word(text: &str) -> &str {
    text.trim()
        .trim_matches(|character: char| !character.is_alphanumeric())
}

/// Detect evidence that the Screen Time chart is aggregating "All Devices".
///
/// Explicit text must appear as one OCR token or two nearby words on the same
/// selector row. Axis labels are deliberately constrained to the chart's right
/// edge so the large daily total (for example "4h 36m") cannot be mistaken for
/// a >1-hour y-axis.
pub fn detect_all_devices_signals(
    words: &[OcrWord],
    img_width: u32,
    img_height: u32,
    bounds: Option<&crate::types::GridBounds>,
) -> AllDevicesSignals {
    let explicit_limit_y = bounds
        .map(|bounds| bounds.upper_left_y.max(1))
        .unwrap_or_else(|| (img_height as f64 * 0.55) as i32);
    let explicit_all_devices = words.iter().any(|word| {
        let center_y = word.y + word.h / 2;
        if center_y <= explicit_limit_y && RE_ALL_DEVICES.is_match(word.text.trim()) {
            return true;
        }
        if !selector_word(&word.text).eq_ignore_ascii_case("all") {
            return false;
        }
        words.iter().any(|next| {
            if !selector_word(&next.text).eq_ignore_ascii_case("devices") {
                return false;
            }
            let next_center_y = next.y + next.h / 2;
            let tolerance = word.h.max(next.h).max(8);
            let gap = next.x - (word.x + word.w);
            center_y <= explicit_limit_y
                && (center_y - next_center_y).abs() <= tolerance
                && gap >= -tolerance
                && gap <= tolerance * 6
        })
    });

    let (min_x, max_x, min_y, max_y) = if let Some(bounds) = bounds {
        let chart_width = bounds.width().max(1);
        let chart_height = bounds.height().max(1);
        (
            bounds.lower_right_x - chart_width / 5,
            img_width as i32,
            (bounds.upper_left_y - chart_height / 2).max(0),
            (bounds.lower_right_y + chart_height / 5).min(img_height as i32),
        )
    } else {
        (
            (img_width as f64 * 0.62) as i32,
            img_width as i32,
            (img_height as f64 * 0.08) as i32,
            (img_height as f64 * 0.55) as i32,
        )
    };

    let candidates: Vec<&OcrWord> = words
        .iter()
        .filter(|word| {
            let center_x = word.x + word.w / 2;
            let center_y = word.y + word.h / 2;
            center_x >= min_x && center_x <= max_x && center_y >= min_y && center_y <= max_y
        })
        .collect();
    let mut axis_max_minutes = None;
    for word in &candidates {
        let center_y = word.y + word.h / 2;
        let mut row_words: Vec<&OcrWord> = candidates
            .iter()
            .copied()
            .filter(|candidate| {
                let tolerance = word.h.max(candidate.h).max(8);
                candidate.x >= word.x
                    && (center_y - (candidate.y + candidate.h / 2)).abs() <= tolerance
            })
            .collect();
        row_words.sort_by_key(|candidate| candidate.x);

        let mut phrase = String::new();
        let mut previous: Option<&OcrWord> = None;
        for candidate in row_words.into_iter().take(4) {
            if let Some(previous) = previous {
                let tolerance = previous.h.max(candidate.h).max(8);
                let gap = candidate.x - (previous.x + previous.w);
                if gap < -tolerance || gap > tolerance * 3 {
                    break;
                }
                phrase.push(' ');
            }
            phrase.push_str(candidate.text.trim());
            previous = Some(candidate);
            if let Some(minutes) = parse_axis_minutes(&phrase) {
                axis_max_minutes =
                    Some(axis_max_minutes.map_or(minutes, |current: i32| current.max(minutes)));
            }
        }
    }

    let mut reasons = Vec::new();
    if explicit_all_devices {
        reasons.push("OCR found 'All Devices' text".to_string());
    }
    let axis_max_minutes = axis_max_minutes.filter(|minutes| *minutes > 60);
    if let Some(minutes) = axis_max_minutes {
        reasons.push(format!("Chart axis exceeds 1 hour ({minutes} min)"));
    }

    AllDevicesSignals {
        suspected: !reasons.is_empty(),
        axis_max_minutes,
        reasons,
    }
}

/// PHI-detection OCR word — like `OcrWord` but carries Tesseract's
/// per-word confidence (0–100).
pub struct PhiWord {
    pub text: String,
    pub x: i32,
    pub y: i32,
    pub w: i32,
    pub h: i32,
    pub conf: i32,
}

/// A Tesseract engine that takes the pipeline's RGB pixels directly.
///
/// leptess's `LepTess` only accepts an encoded image (`set_image_from_mem`), so
/// every read used to BMP-encode the crop and have Leptonica decode it again.
/// Its lower-level `TessApi` (public, and what `LepTess` wraps) exposes
/// `TessBaseAPISetImage`, which copies raw pixels straight in. The recognised
/// text is unchanged: Tesseract sees the same 32-bpp RGB image either way.
#[cfg(feature = "ocr")]
pub struct Tess(leptess::tesseract::TessApi);

#[cfg(feature = "ocr")]
impl Tess {
    fn new(lang: &str) -> Result<Self, leptess::tesseract::TessInitError> {
        leptess::tesseract::TessApi::new(None, lang).map(Self)
    }

    fn set_variable(&mut self, name: leptess::Variable, value: &str) -> Result<(), ()> {
        let value = std::ffi::CString::new(value).map_err(|_| ())?;
        self.0
            .raw
            .set_variable(name.as_cstr(), &value)
            .map_err(|_| ())
    }

    fn set_rgb_image(&mut self, img: &RgbImage) -> Result<(), ProcessingError> {
        let (w, h) = (img.width() as i32, img.height() as i32);
        self.0
            .raw
            .set_image(img.as_raw(), w, h, 3, 3 * w)
            .map_err(|e| ProcessingError::Ocr(format!("Set image failed: {e}")))
    }

    fn recognize(&mut self) -> i32 {
        self.0.recognize()
    }

    fn get_tsv_text(&mut self, page: i32) -> Result<String, std::str::Utf8Error> {
        self.0.get_tsv_text(page)
    }
}

#[cfg(any(feature = "ocr", test))]
fn ensure_tesseract_recognized(status: i32) -> Result<(), ProcessingError> {
    if status == 0 {
        Ok(())
    } else {
        Err(ProcessingError::Ocr(format!(
            "Tesseract recognition failed with status {status}"
        )))
    }
}

/// Run Tesseract for a GRID-ANCHOR read, always in [`DEFAULT_OCR_LANG`].
///
/// Same output shape as [`run_tesseract`], different engine — see
/// `LEPTESS_ANCHOR` for why the user's language must not reach these reads.
#[cfg(feature = "ocr")]
pub fn run_tesseract_anchor(img: &RgbImage, psm: &str) -> Result<Vec<OcrWord>, ProcessingError> {
    LEPTESS_ANCHOR.with(|cell| {
        let mut opt = cell.borrow_mut();
        if opt.is_none() {
            *opt = Some(Tess::new(DEFAULT_OCR_LANG).map_err(|e| {
                ProcessingError::Ocr(format!(
                    "Tesseract init failed for '{DEFAULT_OCR_LANG}': {e}"
                ))
            })?);
        }
        let lt = opt.as_mut().unwrap();
        if lt
            .set_variable(leptess::Variable::TesseditPagesegMode, psm)
            .is_err()
        {
            log::warn!("Failed to set Tesseract PSM to '{psm}', using previous setting");
        }
        lt.set_variable(leptess::Variable::TesseditCharWhitelist, "")
            .ok();
        lt.set_rgb_image(img)?;
        ensure_tesseract_recognized(lt.recognize())?;
        parse_tsv_words(lt)
    })
}

/// Run Tesseract on an image and return word-level results.
///
/// Pixels go to Tesseract directly (see [`Tess`]); no temp file, no encode.
#[cfg(feature = "ocr")]
pub fn run_tesseract(img: &RgbImage, psm: &str) -> Result<Vec<OcrWord>, ProcessingError> {
    with_leptess(psm, |lt| {
        // Match the Python reference, which uses pytesseract's default
        // (no character whitelist). Any whitelist drops characters that
        // legitimately appear in app names — apostrophes, ampersands,
        // accented letters, parentheses, slashes, etc. — and silently
        // blanks the title. Tesseract's eng.traineddata is constrained
        // enough on its own without a hand-curated allow-list.
        lt.set_variable(leptess::Variable::TesseditCharWhitelist, "")
            .ok();
        lt.set_rgb_image(img)?;
        ensure_tesseract_recognized(lt.recognize())?;
        parse_tsv_words(lt)
    })
}

/// [`run_tesseract`] restricted to the characters a duration can contain.
///
/// The unrestricted engine classifies the bold header `8` as `S` on some
/// captures, and [`normalize_ocr_digits`] then rewrites `Sh` to `5h` — a
/// confident three-hour error. Denying it every letter but `h`/`m` forces the
/// digit decision the glyph actually supports: measured on the captures where
/// this happens, `8h 16m`, `8h 4m` and `8h 45m` come back correctly at every
/// scale, while the plain reader flips between `8h` and `Sh` with the scale.
///
/// Restricted to short duration crops for exactly the reason [`run_tesseract`]
/// documents — a whitelist silently blanks app names — so it must never be used
/// for title or full-page text.
#[cfg(feature = "ocr")]
fn run_tesseract_duration(img: &RgbImage, psm: &str) -> Result<Vec<OcrWord>, ProcessingError> {
    with_leptess(psm, |lt| {
        // The LepTess handle is thread-local and shared with every other
        // reader, so the whitelist must not outlive this call — a leaked one
        // silently blanks the next title pass. Set it only once the image is
        // loaded (so a decode failure cannot return early with it still on),
        // and take it off before the recognition status is checked.
        lt.set_rgb_image(img)?;
        lt.set_variable(leptess::Variable::TesseditCharWhitelist, "0123456789hm")
            .ok();
        let recognized = lt.recognize();
        lt.set_variable(leptess::Variable::TesseditCharWhitelist, "")
            .ok();
        ensure_tesseract_recognized(recognized)?;
        parse_tsv_words(lt)
    })
}

#[cfg(feature = "ocr")]
fn crop_text_ocr_region(
    original: &RgbImage,
    converted: &RgbImage,
    original_is_dark: bool,
    x: u32,
    y: u32,
    w: u32,
    h: u32,
) -> RgbImage {
    let src = if original_is_dark {
        original
    } else {
        converted
    };
    let region = image::imageops::crop_imm(src, x, y, w, h).to_image();
    if original_is_dark {
        // Same stretch the full-frame path uses — see `dark_text_contrast`.
        // Without it the large bold total loses a stroke and 8h reads as 5h.
        dark_text_contrast(&invert_image(&region))
    } else {
        region
    }
}

/// Bottom of the header crop the region-first readers stitch in first, moved off
/// any line of text it would otherwise cut through.
///
/// The cut used to be a flat 0.30 of the height. Where the daily total actually
/// lands depends on what iOS printed above it — measured across one participant's
/// captures on the same 2556-tall device, the 87-px total row starts anywhere from
/// y=647 to y=722 against a cut at 767. When the cut falls inside the row the crop
/// keeps the top of the digits and drops the bottom, and Tesseract reads the
/// remnant with no sign that anything is missing: `9h 30m` came back as `Oh 20m`,
/// `12h 3m` as `Om`, `8h 35m` as `Qh 2Am`. The hour-healing pass cannot rescue
/// those, because the minutes were truncated too and its re-read is accepted only
/// when the minutes agree. Cropping the same pixels a little lower reads all three
/// correctly.
///
/// So slide down to the first blank row instead. `converted` is post dark-mode
/// conversion, so the background is light in both appearances and text is ink
/// either way. If nothing is blank inside the search window the flat cut stands —
/// this only ever moves a boundary that is demonstrably mid-glyph.
///
/// Deliberately NOT behind `#[cfg(feature = "ocr")]`, though both callers are:
/// this is pure geometry over an image and needs no libtesseract, and the host
/// cannot build the `ocr` feature at all (no `tesseract.pc`), so gating it would
/// put the only new measurement in this change beyond the reach of every local
/// gate. `read_total_row` was split for the same reason — see `accept_row_reading`.
///
/// Takes its height from the image rather than a parameter so no caller can hand
/// it a stale one and walk `get_pixel` off the end.
#[cfg_attr(not(feature = "ocr"), allow(dead_code))]
fn header_crop_bottom(converted: &RgbImage) -> u32 {
    const INK_LUMA: u8 = 224;
    let img_h = converted.height();
    if img_h == 0 {
        return 0;
    }
    let flat = ((img_h as f64 * 0.30).ceil() as u32).clamp(1, img_h);
    // Far enough to clear a row of the height iOS prints the total at, no further:
    // past this the INFO card starts and a longer slide would swallow it.
    let limit = ((img_h as f64 * 0.36).ceil() as u32).min(img_h);
    let img_w = converted.width();
    // A handful of antialiased pixels is not a line of text.
    let tolerance = (img_w / 200).max(1);
    for y in flat..limit {
        let ink = (0..img_w)
            .filter(|&x| {
                let px = converted.get_pixel(x, y);
                crate::grid_detection::strategies::fast_luma(px[0], px[1], px[2]) < INK_LUMA
            })
            .take(tolerance as usize + 1)
            .count();
        if ink <= tolerance as usize {
            return y;
        }
    }
    flat
}

#[cfg(feature = "ocr")]
fn run_title_total_region_ocr_from_sources(
    original: &RgbImage,
    converted: &RgbImage,
    bounds: Option<&crate::types::GridBounds>,
) -> Result<Vec<OcrWord>, ProcessingError> {
    TITLE_TOTAL_REGION_CALLS.fetch_add(1, Ordering::Relaxed);
    let (img_w, img_h) = converted.dimensions();
    if img_w == 0 || img_h == 0 {
        return Ok(Vec::new());
    }
    let original_is_dark = is_dark_mode(original);
    let top_h = header_crop_bottom(converted);
    // The header crop may have slid past where the INFO card would start; begin it
    // at the cut so the two crops stay adjacent and no row is read twice.
    let info_y0 = ((img_h as f64 * (TITLE_INFO_REOCR_TOP_FRAC - 0.05)).floor() as u32)
        .min(img_h)
        .max(top_h);
    let info_y1 = ((img_h as f64 * (TITLE_INFO_REOCR_BOTTOM_FRAC + 0.05)).ceil() as u32).min(img_h);
    let info_h = info_y1.saturating_sub(info_y0);
    const SEPARATOR_PX: u32 = 16;
    let lower_offset = top_h + SEPARATOR_PX;
    let axis_region = bounds.and_then(|bounds| {
        let chart_width = bounds.width().max(1);
        let chart_height = bounds.height().max(1);
        let x0 = (bounds.lower_right_x - chart_width / 5).clamp(0, img_w as i32) as u32;
        // The top crop already covers labels above this point. Starting here avoids
        // duplicate title/total words while still including every chart-axis label.
        let y0 = (bounds.upper_left_y - chart_height / 2)
            .max(top_h as i32)
            .clamp(0, img_h as i32) as u32;
        let y1 = (bounds.lower_right_y + chart_height / 5).clamp(0, img_h as i32) as u32;
        if x0 >= img_w || y0 >= y1 {
            return None;
        }
        Some((x0, y0, img_w - x0, y1 - y0))
    });
    let axis_offset = lower_offset + info_h + SEPARATOR_PX;
    let stitched_h = axis_region
        .map(|(_, _, _, axis_h)| axis_offset + axis_h)
        .unwrap_or_else(|| {
            if info_h > 0 {
                lower_offset + info_h
            } else {
                top_h
            }
        });
    let mut stitched = RgbImage::from_pixel(img_w, stitched_h, image::Rgb([255, 255, 255]));
    let top = crop_text_ocr_region(original, converted, original_is_dark, 0, 0, img_w, top_h);
    image::imageops::replace(&mut stitched, &top, 0, 0);
    if info_h > 0 {
        let lower = crop_text_ocr_region(
            original,
            converted,
            original_is_dark,
            0,
            info_y0,
            img_w,
            info_h,
        );
        image::imageops::replace(&mut stitched, &lower, 0, lower_offset as i64);
    }
    if let Some((axis_x, axis_y, axis_w, axis_h)) = axis_region {
        let axis = crop_text_ocr_region(
            original,
            converted,
            original_is_dark,
            axis_x,
            axis_y,
            axis_w,
            axis_h,
        );
        image::imageops::replace(&mut stitched, &axis, axis_x as i64, axis_offset as i64);
    }

    let mut words = run_tesseract(&stitched, "3")?;
    words.retain_mut(|word| {
        if word.y < top_h as i32 {
            return true;
        }
        if info_h > 0 && word.y >= lower_offset as i32 && word.y < (lower_offset + info_h) as i32 {
            word.y += info_y0 as i32 - lower_offset as i32;
            return word.y >= 0;
        }
        if let Some((_, axis_y, _, axis_h)) = axis_region
            && word.y >= axis_offset as i32
            && word.y < (axis_offset + axis_h) as i32
        {
            word.y += axis_y as i32 - axis_offset as i32;
            return word.y >= 0;
        }
        false
    });
    for word in &mut words {
        if word.y < 0 {
            word.y = 0;
        }
    }
    Ok(words)
}

/// Parse TSV output from a recognized LepTess instance into word-level boxes.
#[cfg(feature = "ocr")]
pub fn parse_tsv_words(lt: &mut Tess) -> Result<Vec<OcrWord>, ProcessingError> {
    let tsv = lt
        .get_tsv_text(0)
        .map_err(|e| ProcessingError::Ocr(format!("Read Tesseract TSV output failed: {e}")))?;
    let mut words = Vec::new();

    for line in tsv.lines().skip(1) {
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() >= 12 {
            let text = parts[11].trim().to_string();
            if text.is_empty() {
                continue;
            }
            words.push(OcrWord {
                text,
                x: parts[6].parse().unwrap_or(0),
                y: parts[7].parse().unwrap_or(0),
                w: parts[8].parse().unwrap_or(0),
                h: parts[9].parse().unwrap_or(0),
            });
        }
    }

    Ok(words)
}

#[cfg(any(feature = "ocr", test))]
fn parse_phi_tsv(tsv: &str) -> Vec<PhiWord> {
    let mut words = Vec::new();
    for line in tsv.lines().skip(1) {
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() < 12 {
            continue;
        }
        let text = parts[11].trim().to_string();
        if text.is_empty() {
            continue;
        }
        words.push(PhiWord {
            text,
            x: parts[6].parse().unwrap_or(0),
            y: parts[7].parse().unwrap_or(0),
            w: parts[8].parse().unwrap_or(0),
            h: parts[9].parse().unwrap_or(0),
            conf: parts[10].parse::<f32>().unwrap_or(0.0).round() as i32,
        });
    }
    words
}

/// Run full-page Tesseract OCR for PHI detection — returns every word with
/// bbox + confidence, no character whitelist.
///
/// Used by the WASM PHI pipeline to replace Tesseract.js. The thread-local
/// LepTess instance is shared with `run_tesseract`; this function explicitly
/// clears the digit whitelist so subsequent digit-only calls must re-set it
/// (which `run_tesseract` already does).
#[cfg(feature = "ocr")]
pub fn run_phi_ocr_words(img: &RgbImage) -> Result<Vec<PhiWord>, ProcessingError> {
    with_leptess("3", |lt| {
        // Clear any whitelist a previous digit-only call left behind.
        lt.set_variable(leptess::Variable::TesseditCharWhitelist, "")
            .ok();
        lt.set_rgb_image(img)?;
        ensure_tesseract_recognized(lt.recognize())?;
        let tsv = lt
            .get_tsv_text(0)
            .map_err(|e| ProcessingError::Ocr(format!("Read Tesseract TSV output failed: {e}")))?;

        Ok(parse_phi_tsv(&tsv))
    })
}

/// Sort OCR words in reading order (left-to-right, top-to-bottom).
///
/// Words within `y_tolerance` pixels of each other are considered on the same
/// line and sorted by x only. This prevents 1-2px y jitter from reordering
/// "1h" and "9m" into "9m 1h" when they're visually on the same line.
fn sort_words_reading_order<'a>(words: &mut [&'a OcrWord]) {
    const Y_TOLERANCE: i32 = 8;
    // Rows are assigned ONCE and then sorted on, rather than decided pairwise
    // inside the comparator. "Same row if within 8px" is not transitive — a
    // chain of words each 8px below the last is one row to every neighbour and
    // several rows end to end — and `sort_by` with an intransitive comparator
    // aborts the process on std's total-order check. That is not theoretical:
    // it took down whole-page reads on participant captures.
    words.sort_by_key(|w| (w.y, w.x));
    let mut keyed: Vec<(usize, i32, &'a OcrWord)> = Vec::with_capacity(words.len());
    let mut row = 0usize;
    let mut anchor: Option<i32> = None;
    for word in words.iter() {
        if let Some(y) = anchor
            && (word.y - y).abs() > Y_TOLERANCE
        {
            row += 1;
        }
        // Chain off the LAST word, not the row's first: two words 8px apart are
        // one row, which is exactly what the pairwise comparator this replaced
        // decided. Only the abort is gone; the grouping is the same.
        anchor = Some(word.y);
        keyed.push((row, word.x, word));
    }
    keyed.sort_by_key(|&(row, x, _)| (row, x));
    for (slot, (_, _, word)) in words.iter_mut().zip(keyed) {
        *slot = word;
    }
}

/// Join OCR words into a single normalized string.
///
/// Applies common OCR cleanup (Os→0s, pipe removal), joins with spaces,
/// and normalizes digit confusions.
fn words_to_normalized_text<'a>(words: impl Iterator<Item = &'a OcrWord>) -> String {
    let raw: String = words
        .map(|w| w.text.replace("Os", "0s").replace('|', ""))
        .filter(|s| !s.is_empty())
        .collect::<Vec<_>>()
        .join(" ");
    normalize_ocr_digits(raw.trim())
}

fn is_hour_min_time(text: &str) -> bool {
    let text = normalize_ocr_digits(text);
    RE_HOUR_MIN.is_match(&text)
        // Same search-onward rule as `extract_time_from_text`: a candidate carrying
        // a trailing unit is skipped, not treated as the answer. The two must agree
        // about a string, since this decides which row is ranked as the total.
        || RE_HOUR_MIN_NO_M
            .captures_iter(&text)
            .any(|caps| caps.get(3).is_none())
}

fn extract_daily_total_from_word_rows(words: &[&OcrWord]) -> String {
    if words.is_empty() {
        return String::new();
    }

    let mut sorted = words.to_vec();
    sort_words_reading_order(&mut sorted);

    let mut rows: Vec<Vec<&OcrWord>> = Vec::new();
    for word in sorted {
        let Some(row) = rows.last_mut() else {
            rows.push(vec![word]);
            continue;
        };
        let row_y = row.iter().map(|w| w.y).min().unwrap_or(word.y);
        let row_h = row.iter().map(|w| w.h).max().unwrap_or(word.h).max(word.h);
        let tolerance = 12.max(row_h);
        if (word.y - row_y).abs() <= tolerance {
            row.push(word);
        } else {
            rows.push(vec![word]);
        }
    }

    let mut best: Option<(String, i32, i32, bool)> = None;
    for row in rows {
        let text = words_to_normalized_text(row.iter().copied());
        let total = extract_time_from_text(&text);
        if total.is_empty() {
            continue;
        }
        let max_h = row.iter().map(|w| w.h).max().unwrap_or(0);
        let min_y = row.iter().map(|w| w.y).min().unwrap_or(0);
        let hour_min = is_hour_min_time(&text);
        match &best {
            Some((_, best_h, best_y, best_hour_min))
                if max_h < *best_h
                    || (max_h == *best_h && !hour_min && *best_hour_min)
                    || (max_h == *best_h && hour_min == *best_hour_min && min_y >= *best_y) => {}
            _ => best = Some((total, max_h, min_y, hour_min)),
        }
    }

    best.map(|(total, _, _, _)| total).unwrap_or_default()
}

/// Read a localized duration from the visually largest text row.
///
/// RTL OCR engines expose word boxes in screen order, not necessarily logical
/// language order. Trying both directions is therefore load-bearing: a Hebrew
/// row displayed as `7 שעה 28 דק׳` commonly arrives left-to-right as
/// `דק׳ 28 שעה 7`, which the localized parser cannot associate with its units.
/// Ranking by glyph height keeps category subtotals below the chart from
/// outranking the large header total.
fn extract_localized_total_from_word_rows(words: &[&OcrWord]) -> String {
    let languages = localized_languages();
    if languages.is_empty() || words.is_empty() {
        return String::new();
    }
    let refs: Vec<&str> = languages.iter().map(String::as_str).collect();

    let mut sorted = words.to_vec();
    sort_words_reading_order(&mut sorted);
    let mut rows: Vec<Vec<&OcrWord>> = Vec::new();
    for word in sorted {
        let Some(row) = rows.last_mut() else {
            rows.push(vec![word]);
            continue;
        };
        let row_y = row.iter().map(|w| w.y).min().unwrap_or(word.y);
        let row_h = row.iter().map(|w| w.h).max().unwrap_or(word.h).max(word.h);
        // The date/caption is only ~0.7 of one large-header glyph above the
        // total on iOS. A full-glyph tolerance merges those distinct baselines
        // and lets the date (20..29) become the duration's hour. One third of
        // the tallest glyph still groups antialiasing/segmentation jitter while
        // keeping the caption on its own row.
        if (word.y - row_y).abs() <= 12.max(row_h / 3) {
            row.push(word);
        } else {
            rows.push(vec![word]);
        }
    }

    let mut best: Option<(String, i32, i32)> = None;
    for mut row in rows {
        row.sort_by_key(|w| w.x);
        let is_rtl_row = row.iter().any(|word| {
            word.text
                .chars()
                .any(|ch| matches!(ch as u32, 0x0590..=0x08ff))
        });
        let text = if is_rtl_row {
            words_to_normalized_text(row.iter().rev().copied())
        } else {
            words_to_normalized_text(row.iter().copied())
        };
        let total = crate::localized_total::extract_localized_total(&text, &refs);
        if total.is_empty() {
            continue;
        }
        let max_h = row.iter().map(|w| w.h).max().unwrap_or(0);
        let min_y = row.iter().map(|w| w.y).min().unwrap_or(0);
        match &best {
            Some((_, best_h, best_y))
                if max_h < *best_h || (max_h == *best_h && min_y >= *best_y) => {}
            _ => best = Some((total, max_h, min_y)),
        }
    }
    best.map(|(total, _, _)| total).unwrap_or_default()
}

/// Words in the band where iOS prints the daily total — above the chart.
///
/// The same header band [`total_row_bounds`] already prefers. Measured headers
/// this fallback exists for sit at y=651..709 on 2556-tall captures (0.25..0.28
/// of the height), so the ceiling clears them with room to spare.
fn header_band_words(ocr_data: &[OcrWord], img_h: u32) -> Vec<&OcrWord> {
    let header_band = (img_h as i32) * 2 / 5;
    ocr_data
        .iter()
        .filter(|w| !w.text.is_empty() && w.y < header_band)
        .collect()
}

/// Re-read the header band on its own to recover a total the full-page pass
/// segmented away entirely.
///
/// The last resort, and the only one that does not depend on the page OCR having
/// produced ANY word for the total. Measured on three participant captures: the
/// whole-page pass returned not a single word from the header row, so every
/// reader above — anchored crop, hardcoded band, header-band ranking — had
/// nothing to work with and the largest time on the frame was an app row under
/// the chart. The same pixels cropped to this band read `4h 46m`, `5h 51m` and
/// `9h 23m` at 1x, each within 7 minutes of that capture's own bar sum.
#[cfg(feature = "ocr")]
fn recover_total_from_header_band(img: &RgbImage) -> Option<String> {
    let (img_w, img_h) = img.dimensions();
    let y0 = (img_h as f64 * TOTAL_HEADER_REOCR_TOP_FRAC) as u32;
    let y1 = ((img_h as f64 * TOTAL_HEADER_REOCR_BOTTOM_FRAC) as u32).min(img_h);
    if y1 <= y0 || img_w == 0 {
        return None;
    }
    let band = image::imageops::crop_imm(img, 0, y0, img_w, y1 - y0).to_image();
    let mut best_localized = String::new();
    let mut best_english = String::new();
    let mut localized_reads = Vec::new();
    // PSM 3 preserves the logical Hebrew header row on this layout; PSM 6
    // frequently substitutes one minute digit (39→59, 33→55) or drops the hour
    // entirely. Use PSM 6 only when the auto-layout read found no localized
    // duration at all.
    for psm in ["3", "6"] {
        let Ok(words) = run_tesseract(&band, psm) else {
            continue;
        };
        let mut band_words: Vec<&OcrWord> = words.iter().filter(|w| !w.text.is_empty()).collect();
        sort_words_reading_order(&mut band_words);
        let localized = extract_localized_total_from_word_rows(&band_words);
        if !localized.is_empty() {
            localized_reads.push(localized.clone());
            // A whole-hour or one-digit-minute result can be genuine or a
            // partial read. Let the alternate segmentation mode settle it.
            if crate::localized_total::total_text_minutes(&localized) % 60 >= 10 {
                return Some(localized);
            }
            if best_localized.is_empty() {
                best_localized = localized;
            }
        }
        let total = extract_daily_total_from_word_rows(&band_words);
        if !total.is_empty() {
            // The page pass never read this row — that is why the band was
            // cropped at all — so its words cannot frame the row for a re-read.
            // The band's own words are the only ones that describe this total.
            let owned: Vec<OcrWord> = band_words.into_iter().cloned().collect();
            let healed = heal_missing_hours(&band, &owned, total);
            if crate::localized_total::total_text_minutes(&healed)
                > crate::localized_total::total_text_minutes(&best_english)
            {
                best_english = healed;
            }
        }
    }
    // Emscripten's dark-mode PSM 3 can lose the minutes completely while PSM 6
    // keeps only their final digit. That specific disagreement means the glyphs
    // need separating, not guessing: one slightly stronger contrast pass makes
    // the failing `ו39` readable. Require PSM 3 and 6 to agree before replacing
    // the conservative result, so a real one-digit minute total is unchanged.
    if localized_reads.len() == 2 {
        let first = crate::localized_total::total_text_minutes(&localized_reads[0]);
        let second = crate::localized_total::total_text_minutes(&localized_reads[1]);
        if first % 60 == 0 && (1..=9).contains(&(second % 60)) && first / 60 == second / 60 {
            let stronger = adjust_contrast_brightness(&band, 13.0 / 12.0, 1);
            let mut stronger_reads = Vec::new();
            for psm in ["3", "6"] {
                let Ok(words) = run_tesseract(&stronger, psm) else {
                    continue;
                };
                let refs: Vec<&OcrWord> =
                    words.iter().filter(|word| !word.text.is_empty()).collect();
                let total = extract_localized_total_from_word_rows(&refs);
                if !total.is_empty() {
                    stronger_reads.push(total);
                }
            }
            if stronger_reads.len() == 2 && stronger_reads[0] == stronger_reads[1] {
                let stronger_minutes =
                    crate::localized_total::total_text_minutes(&stronger_reads[0]);
                if stronger_minutes / 60 == first / 60 && stronger_minutes % 60 >= 10 {
                    return stronger_reads.pop();
                }
            }
        }
    }
    if !best_localized.is_empty() {
        Some(best_localized)
    } else if !best_english.is_empty() {
        Some(best_english)
    } else {
        None
    }
}

/// What a re-read of the header row must agree with for it to be believed.
#[derive(Clone, Copy)]
enum HourEvidence {
    /// The page read N minutes; the re-read has to produce the same minutes, so a
    /// value is completed rather than invented.
    Minutes(u32),
    /// The page read a bare `Nh` with no minutes at all — iOS prints exactly that
    /// on a whole-hour day. There are no minutes to agree with, so the trigger
    /// carries the whole burden: this is only ever reached when the hour glyph was
    /// a LETTER, i.e. a digit that was never actually read.
    BareHours,
    /// The page read a bare `Nh` whose hour IS a digit. Either iOS printed a
    /// whole-hour day, or the minutes beside it were never segmented — the page
    /// pass cannot tell those apart, so the row is re-read to settle it.
    WholeHours(u32),
}

/// Minutes of a total the header reader could not put an hour on.
///
/// Two shapes qualify, and both mean the same thing: the hours glyph of a
/// `5h 11m`-style header was not recognised. `"11m"` is what survives when the
/// hour token reads as lowercase `oh` (no digit, so no hour pattern matches);
/// `"0h 24m"` is what survives when it reads as uppercase `Oh`, because
/// [`normalize_ocr_digits`] rewrites `O`-before-a-unit to a zero. iOS never
/// prints a zero hour — it writes `24m` — so a zero here is always a misread,
/// never a real value.
fn total_missing_hours(total: &str) -> Option<u32> {
    let rest = total.strip_prefix("0h ").unwrap_or(total);
    let minutes = rest.strip_suffix('m')?;
    if minutes.is_empty() || !minutes.bytes().all(|b| b.is_ascii_digit()) {
        return None;
    }
    // A seconds component means this is not the header total at all.
    if rest.contains('s') {
        return None;
    }
    minutes.parse().ok()
}

/// The word the header-row re-read is anchored on: the token the page DID read.
///
/// Located from the full-image word list rather than from any one reader's
/// region, so every caller that produced a mangled total can use it.
#[cfg_attr(not(feature = "ocr"), allow(dead_code))]
fn total_row_anchor(ocr_data: &[OcrWord], evidence: HourEvidence, img_h: u32) -> Option<&OcrWord> {
    // The minutes when the page read some, and otherwise the hour token itself
    // (`Sh`, `8h`) — the only thing left on that row.
    let wanted = match evidence {
        HourEvidence::Minutes(minutes) => format!("{minutes}m"),
        HourEvidence::BareHours => String::new(),
        HourEvidence::WholeHours(hours) => format!("{hours}h"),
    };
    let matches = |w: &&OcrWord| match evidence {
        HourEvidence::Minutes(_) | HourEvidence::WholeHours(_) => {
            normalize_ocr_digits(&w.text).trim() == wanted
        }
        HourEvidence::BareHours => {
            let token = w.text.trim();
            RE_LETTER_HOUR.is_match(token) || RE_BARE_HOUR.is_match(token)
        }
    };
    // The header total is the largest text on the upper part of the page, so of
    // the candidates the tallest is the one to re-read. Callers that already
    // cropped to the total region hand us an image where the row is NOT in the
    // top fifth of the frame, so the band is a preference, not a requirement.
    ocr_data
        .iter()
        .filter(|w| w.y < (img_h as i32) * 2 / 5)
        .filter(matches)
        .max_by_key(|w| w.h)
        .or_else(|| ocr_data.iter().filter(matches).max_by_key(|w| w.h))
}

/// Bounding box of the header row holding the anchor, padded for a re-OCR crop.
#[cfg_attr(not(feature = "ocr"), allow(dead_code))]
fn total_row_bounds(
    ocr_data: &[OcrWord],
    evidence: HourEvidence,
    img_w: u32,
    img_h: u32,
) -> Option<(u32, u32, u32, u32)> {
    let anchor = total_row_anchor(ocr_data, evidence, img_h)?;
    let tolerance = 12.max(anchor.h);
    let row: Vec<&OcrWord> = ocr_data
        .iter()
        .filter(|w| !w.text.is_empty() && (w.y - anchor.y).abs() <= tolerance)
        .collect();

    let x0 = row.iter().map(|w| w.x).min()?.saturating_sub(20).max(0);
    let y0 = row.iter().map(|w| w.y).min()?.saturating_sub(14).max(0);
    let x1 = (row.iter().map(|w| w.x + w.w).max()? + 20).min(img_w as i32);
    let y1 = (row.iter().map(|w| w.y + w.h).max()? + 14).min(img_h as i32);
    if x1 <= x0 || y1 <= y0 {
        return None;
    }
    Some((x0 as u32, y0 as u32, (x1 - x0) as u32, (y1 - y0) as u32))
}

/// The anchor's own line, run to both edges of the frame.
///
/// [`total_row_bounds`] lets the row's words set its sides, which is right when
/// they describe the whole row and wrong when they do not: a token the page
/// never read cannot push the right edge out past the minutes being looked for.
/// Nothing else shares the header total's line, so the frame's own edges are a
/// safe substitute — and dropping the neighbouring words from the box also drops
/// the caption above, which starts only 61px up from a 73px-tall total.
#[cfg_attr(not(feature = "ocr"), allow(dead_code))]
fn total_row_strip(
    ocr_data: &[OcrWord],
    evidence: HourEvidence,
    img_w: u32,
    img_h: u32,
) -> Option<(u32, u32, u32, u32)> {
    let anchor = total_row_anchor(ocr_data, evidence, img_h)?;
    let y0 = (anchor.y - 14).max(0);
    let y1 = (anchor.y + anchor.h + 14).min(img_h as i32);
    if img_w == 0 || y1 <= y0 {
        return None;
    }
    Some((0, y0 as u32, img_w, (y1 - y0) as u32))
}

/// Re-read the header row on its own to recover an hours digit the full-page
/// pass lost.
///
/// Measured on a 176-capture participant batch: the whole-page PSM-3/6 pass
/// reads the bold header `5h 41m` as `oh 41m` and `9h 4m` as `Oh 4m` — the
/// minutes survive, the hour does not — on 43 of 157 captures that printed a
/// total, silently turning 5-hour days into 41-minute ones. Handing Tesseract
/// the same pixels cropped to that one row fixes it: `5h 41m`, `5h 11m`,
/// `5h 32m`, `5h 9m` all read correctly at 1×, and the harder `9h 4m` at 2×.
/// The row crop is what matters, not the resolution — this is a page
/// segmentation failure, not a legibility one — but the scale ladder costs one
/// extra pass on an already-rare path and rescues the cases 1× misses.
///
/// The result is accepted ONLY when it agrees with what the page already read —
/// the same minutes when there were minutes, the same hour when the page read a
/// bare `Nh`. A genuinely short day (`47m`) re-reads as `47m`, finds no hour, and
/// keeps its original value. A genuine whole-hour day re-reads as the same bare
/// `Nh`, and that echo is DECLINED rather than accepted: it cannot improve the
/// total, but accepting it would end the search before the full-width
/// `total_row_strip` frame ever ran. The day keeps its `Nh` either way — see
/// [`accept_row_reading`], which holds these rules and is where they are tested.
/// There is no reading of the evidence in which this invents a value that was not
/// on the screen.
#[cfg(feature = "ocr")]
fn recover_total_hours(
    img: &RgbImage,
    ocr_data: &[OcrWord],
    evidence: HourEvidence,
    digits_only: bool,
) -> Option<String> {
    let (img_w, img_h) = img.dimensions();
    // Tesseract's own page analysis is what fails on these headers, and it reacts
    // to the shape of the crop it is handed: the same row reads `9h 4m` framed on
    // its words and `4m` framed on the page's full width. Neither framing wins
    // everywhere, so both are offered and the acceptance test below picks.
    let frames = [
        total_row_bounds(ocr_data, evidence, img_w, img_h),
        total_row_strip(ocr_data, evidence, img_w, img_h),
    ];
    for (x, y, w, h) in frames.into_iter().flatten() {
        let row = image::imageops::crop_imm(img, x, y, w, h).to_image();
        if let Some(recovered) = read_total_row(&row, evidence, digits_only) {
            return Some(recovered);
        }
    }
    None
}

/// Read a duration out of one cropped header row, or nothing it can stand behind.
#[cfg(feature = "ocr")]
fn read_total_row(row: &RgbImage, evidence: HourEvidence, digits_only: bool) -> Option<String> {
    let (w, h) = row.dimensions();
    for scale in [1u32, 2, 3] {
        let region = if scale == 1 {
            row.clone()
        } else {
            crate::image_utils::resize_lanczos3(row, w * scale, h * scale)
        };
        for psm in ["6", "7"] {
            let read = if digits_only {
                run_tesseract_duration(&region, psm)
            } else {
                run_tesseract(&region, psm)
            };
            let Ok(words) = read else {
                continue;
            };
            let mut row_words: Vec<&OcrWord> = words.iter().collect();
            sort_words_reading_order(&mut row_words);
            let text = words_to_normalized_text(row_words.into_iter());
            let Some(recovered) = accept_row_reading(&text, evidence) else {
                continue;
            };
            info!(
                "Recovered lost hours from header row re-OCR (scale {scale}, psm {psm}): '{recovered}'"
            );
            return Some(recovered);
        }
    }
    None
}

/// Decide whether a re-read of the total's row may be believed, and return the
/// duration to adopt if so.
///
/// Split out of [`read_total_row`] because that function is `#[cfg(feature =
/// "ocr")]` — it needs libtesseract to compile — so on a host without it NONE of
/// these acceptance rules were ever built, let alone tested. The rules are pure
/// string logic and belong somewhere they can be exercised directly.
// Used by `read_total_row` (behind `feature = "ocr"`) and by the tests below;
// a build with neither reaches it, which is the situation this split fixes.
#[allow(dead_code)]
fn accept_row_reading(text: &str, evidence: HourEvidence) -> Option<String> {
    let recovered = extract_time_from_text(text);
    let normalized = normalize_ocr_digits(&recovered);
    let hours: u32 = match evidence {
        HourEvidence::Minutes(minutes) => {
            let caps = RE_HOUR_MIN.captures(&normalized)?;
            let read_minutes: u32 = caps[2].parse().unwrap_or(u32::MAX);
            if read_minutes != minutes {
                return None;
            }
            // Agreeing with the page is not proof on its own. The page can have
            // read `5h 15m` as `75m`, and re-reading the same pixels reproduces a
            // misread more often than it corrects one — so without a range check
            // the two agree their way to `9h 75m`, which iOS never prints.
            if read_minutes == 0 || read_minutes > 59 {
                return None;
            }
            caps[1].parse().unwrap_or(0)
        }
        HourEvidence::BareHours => {
            // a re-read that grew minutes is a different row
            let caps = RE_BARE_HOUR.captures(normalized.trim())?;
            caps[1].parse().unwrap_or(0)
        }
        // The hour was read; the question is only whether minutes stood beside it.
        //
        // A re-read that merely repeats the bare `Nh` is DECLINED rather than
        // accepted. It returns the string we already had, so it can never improve
        // the total — but accepting it ends the search, and the remaining scales,
        // PSMs and the full-width `total_row_strip` frame would never run.
        HourEvidence::WholeHours(hours) => {
            // What disqualifies a row is the duration being read not being the
            // FIRST one on it. `8h Daily Average 8h 45m` offers `8h 45m` as its
            // leftmost `Nh Mm`, and that belongs to the average, not to the total
            // whose minutes went missing — `extract_time_from_text` returns the
            // leftmost match, and a bare `Nh` (this arm's own precondition) cannot
            // match `RE_HOUR_MIN` at all, so the leftmost one is the neighbour's.
            //
            // Positional, not a count: counting hour tokens also threw away
            // `4h 30m 1h 12m`, where the leftmost duration IS the total.
            // `RE_HOUR_TOKEN` omits `\b` on purpose — `RE_HOURS_ONLY` cannot see
            // the hour in `4h30m`, and a row must not be judged on whether
            // Tesseract happened to leave a space.
            let first_duration = RE_HOUR_MIN.find(text).map(|m| m.start());
            if first_duration.is_some()
                && first_duration != RE_HOUR_TOKEN.find(text).map(|m| m.start())
            {
                return None;
            }
            let caps = RE_HOUR_MIN.captures(&normalized)?;
            let minutes: u32 = caps[2].parse().unwrap_or(u32::MAX);
            if minutes == 0 || minutes > 59 {
                return None;
            }
            let read: u32 = caps[1].parse().unwrap_or(0);
            if read != hours {
                return None;
            }
            read
        }
    };
    if hours == 0 || hours > 23 {
        return None;
    }
    Some(recovered)
}

/// Hours of a total that were decided by [`normalize_ocr_digits`] rewriting a
/// LETTER, not by reading a digit.
///
/// `Sh 16m` becomes `5h 16m` and `gh 4m` becomes `9h 4m` with equal confidence,
/// and on the bold header glyph that rewrite is a coin flip: measured on this
/// batch, `S` in the hours slot was an `8` every time, so the page reading was
/// three hours short. The letter is the signal that the digit is still unread —
/// a re-read restricted to digits settles it.
fn hours_came_from_a_letter(ocr_data: &[OcrWord]) -> bool {
    ocr_data
        .iter()
        .any(|w| RE_LETTER_HOUR.is_match(w.text.trim()))
}

/// [`recover_total_hours`], applied to a total only when the evidence says the
/// hours digit was never actually read.
///
/// Every reader in [`extract_total_impl`] funnels through here, because the
/// hour can be lost on any of them — the word-row reader, the hardcoded region
/// fallback and the progressive search all parse the same mangled token.
///
/// Three triggers, all narrow:
///   * no hour at all (or a zero hour iOS never prints) → re-read plainly;
///   * an hour that a letter was rewritten into → re-read digits-only;
///   * a bare `Nh`, where the minutes may simply never have been segmented.
///
/// The re-read is accepted only when it agrees with what the page already read:
/// the same minutes when there were minutes, and the same hour when that is what
/// the page read. A value is never invented, only completed.
fn heal_missing_hours(img: &RgbImage, ocr_data: &[OcrWord], total: String) -> String {
    let mut attempts: Vec<(HourEvidence, bool)> = Vec::new();
    match total_missing_hours(&total) {
        Some(minutes) => attempts.push((HourEvidence::Minutes(minutes), false)),
        None => {
            if hours_came_from_a_letter(ocr_data) {
                if let Some(caps) = RE_HOUR_MIN.captures(&total) {
                    attempts.push((HourEvidence::Minutes(caps[2].parse().unwrap_or(0)), true));
                } else if RE_BARE_HOUR.is_match(total.trim()) {
                    // `Sh` normalized to `5h`: a whole-hour day whose only digit
                    // is the one that was never read. Measured on this batch, the
                    // bars under such a header summed to 7h52m against `5h`.
                    attempts.push((HourEvidence::BareHours, true));
                }
            }
            // The same bare `Nh` read a second way: whatever settled its hour, the
            // minutes beside it may simply never have been segmented. This runs
            // after the digits-only pass, so a whole-hour day still confirms
            // itself there and only a row that grew minutes reaches here.
            if let Some(caps) = RE_BARE_HOUR.captures(total.trim()) {
                let hours = caps[1].parse().unwrap_or(0);
                // `read_total_row` refuses hours outside 1..=23, so queueing one
                // would spend the whole scale/PSM ladder on a certain rejection.
                if (1..=23).contains(&hours) {
                    attempts.push((HourEvidence::WholeHours(hours), false));
                }
            }
        }
    }
    #[cfg(feature = "ocr")]
    for (evidence, digits_only) in attempts.iter().copied() {
        if let Some(recovered) = recover_total_hours(img, ocr_data, evidence, digits_only) {
            return recovered;
        }
    }
    #[cfg(not(feature = "ocr"))]
    let _ = (img, ocr_data, &attempts);
    total
}

fn daily_total_crop_rect(screen: &OcrWord, img_w: u32, img_h: u32) -> Option<(u32, u32, u32, u32)> {
    let x = (screen.x - 50).max(0) as u32;
    let y = (screen.y + screen.h + 70).max(0) as u32;
    if x >= img_w || y >= img_h {
        return None;
    }
    let w = ((screen.w * 4).max(1) as u32).min(img_w - x);
    let h = ((screen.h * 8).max(1) as u32).min(img_h - y);
    if w == 0 || h == 0 {
        None
    } else {
        Some((x, y, w, h))
    }
}

#[cfg(feature = "ocr")]
fn extract_daily_total_crop_from_sources(
    original: &RgbImage,
    converted: &RgbImage,
    ocr_data: &[OcrWord],
) -> Result<Option<String>, ProcessingError> {
    let texts: Vec<String> = ocr_data.iter().map(|w| w.text.clone()).collect();
    if !is_daily_total_page(&texts) {
        return Ok(None);
    }

    let Some(screen) = ocr_data
        .iter()
        .rev()
        .find(|w| is_screen_anchor_text(&w.text))
    else {
        return Ok(None);
    };

    let (img_w, img_h) = converted.dimensions();
    let Some((x, y, w, h)) = daily_total_crop_rect(screen, img_w, img_h) else {
        return Ok(None);
    };
    let region = crop_text_ocr_region(original, converted, is_dark_mode(original), x, y, w, h);

    for psm in ["3", "6"] {
        let words = run_tesseract(&region, psm)?;
        let mut region_words: Vec<&OcrWord> = words.iter().collect();
        sort_words_reading_order(&mut region_words);
        let localized = extract_localized_total_from_word_rows(&region_words);
        if !localized.is_empty() {
            info!("Found localized daily total from targeted crop: '{localized}'");
            return Ok(Some(localized));
        }
        let total = extract_daily_total_from_word_rows(&region_words);
        if !total.is_empty() {
            let total = heal_missing_hours(&region, &words, total);
            info!("Found daily total from targeted crop: '{total}'");
            return Ok(Some(total));
        }
    }

    Ok(None)
}

/// Join OCR words into a title string.
/// Only removes OCR artifacts (pipe chars, non-alphabetic garbage).
/// No title corrections or noise word filtering — that belongs in postprocessing.
fn words_to_title_text<'a>(words: impl Iterator<Item = &'a OcrWord>) -> String {
    let raw: String = words
        .map(|w| w.text.replace('|', ""))
        .filter(|s| !s.is_empty())
        .collect::<Vec<_>>()
        .join(" ");
    // Strip outer artifacts. Tesseract often misreads the small app icon
    // sitting to the left of the title as `~`, `*`, `#`, `_`, etc.,
    // which trickles through as a leading garbage glyph; strip these
    // along with whitespace so the title reads cleanly.
    raw.trim()
        .trim_matches(|c: char| {
            c == '#' || c == '_' || c == '~' || c == '*' || c == '`' || c.is_whitespace()
        })
        .to_string()
}

fn words_to_title_row_text<'a>(words: impl Iterator<Item = &'a OcrWord>) -> String {
    let candidates: Vec<&OcrWord> = words
        .filter(|w| !w.text.is_empty() && !is_info_anchor_text(&w.text))
        .collect();
    let row_tol = candidates.iter().map(|w| w.h).max().unwrap_or(12).max(12);
    let mut title_words: Vec<&OcrWord> = candidates
        .iter()
        .copied()
        .filter(|w| {
            w.text.chars().filter(|ch| ch.is_alphabetic()).count() >= 2
                || (w.text.chars().any(|ch| ch.is_alphanumeric())
                    && candidates
                        .iter()
                        .filter(|other| (other.y - w.y).abs() < row_tol)
                        .count()
                        == 1)
        })
        .collect();
    if let Some(min_y) = title_words.iter().map(|w| w.y).min() {
        let row_tol = title_words.iter().map(|w| w.h).max().unwrap_or(12).max(12);
        title_words.retain(|w| w.y < min_y + row_tol);
    }
    if title_words.iter().any(|word| {
        word.text
            .chars()
            .any(|ch| matches!(ch as u32, 0x0590..=0x08ff))
    }) {
        title_words.sort_by_key(|word| std::cmp::Reverse(word.x));
    } else {
        sort_words_reading_order(&mut title_words);
    }
    words_to_title_text(title_words.into_iter())
}

fn is_info_anchor_text(text: &str) -> bool {
    let token = text
        .trim_matches(|c: char| !c.is_ascii_alphanumeric())
        .to_ascii_uppercase();
    token == "INFO" || token == "INF0"
}

fn is_screen_anchor_text(text: &str) -> bool {
    let token = text
        .trim_matches(|c: char| !c.is_ascii_alphanumeric())
        .to_ascii_uppercase();
    token == "SCREEN"
}

/// Extract the screenshot title using pre-computed full-image OCR data.
///
/// Tries spatial filtering of full-image OCR words first (no extra Tesseract call).
/// Falls back to crop+re-OCR only when the spatial pass yields nothing.
fn extract_title(
    img: &RgbImage,
    ocr_data: &[OcrWord],
) -> Result<(String, Option<i32>), ProcessingError> {
    // Check if daily total page
    let texts: Vec<String> = ocr_data.iter().map(|w| w.text.clone()).collect();
    if is_daily_total_page(&texts) {
        return Ok(("Daily Total".to_string(), None));
    }

    // Find LAST standalone "INFO" text position — bottom-most exact header match
    // is more likely to be the actual section header, not random text.
    // Case-INSENSITIVE: iOS renders the section header title-case ("Info"), which
    // Tesseract reads as "Info". Do not use substring matching: category values
    // like "Information & Reading" sit below the title row and would shift the
    // title crop down into "Age Rating".
    let info_word: Option<OcrWord> = ocr_data
        .iter()
        .rev()
        .find(|w| is_info_anchor_text(&w.text))
        .cloned();

    // INFO-RECOVERY: the full-image OCR pass sometimes silently drops the entire
    // INFO card (segmentation), leaving no anchor — and the title would then fall
    // through to the device-name-polluted top nav row (`< 🙈 <App>`, where 🙈 is the
    // iPad's name emoji). Before that, re-OCR a moderate lower band to recover the
    // anchor so the title still comes from the CLEAN INFO card. Only the user's
    // explicit cascade order: lower INFO card → (retries) → top nav title.
    #[cfg(feature = "ocr")]
    let info_word = info_word.or_else(|| recover_info_anchor_lower_reocr(img));

    if let Some(info) = info_word {
        let (img_w, _img_h) = img.dimensions();
        // Title box derived from the "Info" word — multipliers are the shared SSoT
        // (shared/processing_constants.json → generated TITLE_* consts), so Rust and
        // Python can't drift. app_height = info.h * 7: the previous info.h * 4 was a
        // Rust-only deviation that cropped the title row on Pro Max-class displays
        // where the app-name baseline sits ~six INFO-heights below INFO.
        let title_y_start = info.y + info.h;
        let title_x_start = (info.x as f64 + TITLE_X_ORIGIN_INFO_W_MULT * info.w as f64) as i32;
        let title_x_end = (title_x_start + info.w * TITLE_X_END_INFO_W_MULT).min(img_w as i32);
        let title_y_end = title_y_start + info.h * TITLE_APP_HEIGHT_INFO_H_MULT;

        // Canvas always crops the title region + applies 2× contrast + re-OCRs.
        // No spatial fast path — canvas never reuses full-image OCR words for title.
        // Under no-ocr (WASM JS path): fall back to spatial word filtering since
        // JS handles re-OCR externally via findScreenshotTitle().
        #[cfg(not(feature = "ocr"))]
        {
            let mut title_words: Vec<&OcrWord> = ocr_data
                .iter()
                .filter(|w| {
                    !w.text.is_empty()
                        && w.x >= title_x_start
                        && w.x < title_x_end
                        && w.y >= title_y_start
                        && w.y < title_y_end
                        && !is_info_anchor_text(&w.text)
                })
                .collect();
            sort_words_reading_order(&mut title_words);
            let title = words_to_title_row_text(title_words.iter().copied());
            if !title.is_empty() && title.chars().count() <= MAX_TITLE_LENGTH {
                return Ok((title, Some(title_y_end)));
            }
        }

        #[cfg(feature = "ocr")]
        {
            let (img_w, img_h) = img.dimensions();
            let x_origin = title_x_start.max(0) as u32;
            let x_end = (title_x_end as u32).min(img_w);
            let y_start = title_y_start.max(0) as u32;
            let y_end = (title_y_end as u32).min(img_h);

            if x_end > x_origin && y_end > y_start {
                let region = image::imageops::crop_imm(
                    img,
                    x_origin,
                    y_start,
                    x_end - x_origin,
                    y_end - y_start,
                )
                .to_image();
                let region_enhanced = adjust_contrast_brightness(&region, 2.0, 0);
                // Python reference uses PSM 3 (auto layout) for the title
                // re-OCR; Rust used to use PSM 6 (single uniform block),
                // which expects multi-line layout and fails on the
                // single-line title crops produced by tall iPhones. Match
                // Python.
                let words = run_tesseract(&region_enhanced, "3")?;

                let title = words_to_title_row_text(words.iter());

                if title.chars().count() > MAX_TITLE_LENGTH {
                    info!(
                        "Title too long ({} chars), likely OCR garbage",
                        title.chars().count()
                    );
                    return Ok((String::new(), Some(y_end as i32)));
                }

                info!("Found title via crop OCR: '{}' at y={}", title, y_end);
                return Ok((title, Some(y_end as i32)));
            }
        }
    }

    #[cfg(feature = "ocr")]
    {
        let (img_w, img_h) = img.dimensions();
        let x0 = (img_w as f64 * TITLE_FALLBACK_BAND_LEFT_FRAC) as u32;
        let x1 = ((img_w as f64 * TITLE_FALLBACK_BAND_RIGHT_FRAC) as u32).min(img_w);
        let y0 = ((img_h as f64 * 0.045) as u32).min(img_h);
        let y1 = ((img_h as f64 * 0.13) as u32).min(img_h);
        if x1 > x0 && y1 > y0 {
            let nav = image::imageops::crop_imm(img, x0, y0, x1 - x0, y1 - y0).to_image();
            for psm in ["11", "6"] {
                for words in [run_tesseract(&nav, psm), run_tesseract_anchor(&nav, psm)]
                    .into_iter()
                    .flatten()
                {
                    let title = words_to_title_row_text(words.iter().filter(|word| {
                        word.text.chars().filter(|ch| ch.is_alphabetic()).count() >= 2
                    }));
                    if !title.is_empty() && title.chars().count() <= MAX_TITLE_LENGTH {
                        info!("Found title via targeted full-frame nav crop: '{title}'");
                        return Ok((title, Some(y1 as i32)));
                    }
                }
            }
        }
    }

    // Fallback: no "Info" anchor. The app name is the centered nav-bar title at the
    // top of the page, already segmented by the full-image OCR pass. SELECT the
    // top-most centered row from those words — NOT a re-OCR of a fixed strip, which
    // mis-fired on the status bar / "Screen Time" header of cropped and tall
    // captures. Bands are FRACTIONS of WxH (SSoT): the centered x-range drops the
    // left-aligned "Screen Time" header and the corner status glyphs; y>0 skips the
    // status bar yet still reaches a cropped title near the very top; row_tol groups
    // same-row words (multi-word titles) and excludes the header row below the title.
    let (img_w, img_h) = img.dimensions();
    let x_lo = (img_w as f64 * TITLE_FALLBACK_BAND_LEFT_FRAC) as i32;
    let x_hi = (img_w as f64 * TITLE_FALLBACK_BAND_RIGHT_FRAC) as i32;
    let y_lo = (img_h as f64 * TITLE_FALLBACK_BAND_TOP_FRAC) as i32;
    let y_hi = (img_h as f64 * TITLE_FALLBACK_BAND_BOTTOM_FRAC) as i32;
    let row_tol = (img_h as f64 * TITLE_FALLBACK_ROW_TOL_FRAC) as i32;

    let mut band: Vec<&OcrWord> = ocr_data
        .iter()
        .filter(|w| {
            // A title is a real word (>=2 letters). This drops status-bar tokens that
            // sit ABOVE the title on full (un-cropped) screenshots — the clock
            // "10:09", battery "1%", and icon garbage ") a" / "—_))" — so the
            // top-most survivor is the nav title, whether or not a status bar exists.
            w.text.chars().filter(|ch| ch.is_alphabetic()).count() >= 2
                && w.x >= x_lo
                && w.x < x_hi
                && w.y >= y_lo
                && w.y < y_hi
                && !is_info_anchor_text(&w.text)
        })
        .collect();
    if let Some(min_y) = band.iter().map(|w| w.y).min() {
        band.retain(|w| w.y < min_y + row_tol);
        sort_words_reading_order(&mut band);
        let title = words_to_title_text(band.iter().copied());
        if !title.is_empty() && title.chars().count() <= MAX_TITLE_LENGTH {
            return Ok((title, Some(y_hi)));
        }
    }

    debug!("No title found after all extraction strategies (anchor crop, nav-bar row select)");
    Ok((String::new(), None))
}

#[cfg(feature = "ocr")]
fn extract_title_from_sources(
    original: &RgbImage,
    converted: &RgbImage,
    ocr_data: &[OcrWord],
) -> Result<(String, Option<i32>), ProcessingError> {
    let texts: Vec<String> = ocr_data.iter().map(|w| w.text.clone()).collect();
    if is_daily_total_page(&texts) {
        return Ok(("Daily Total".to_string(), None));
    }

    let info_word: Option<OcrWord> = ocr_data
        .iter()
        .rev()
        .find(|w| is_info_anchor_text(&w.text))
        .cloned()
        .or_else(|| recover_info_anchor_lower_reocr_from_sources(original, converted));

    if let Some(info) = info_word {
        let (img_w, img_h) = converted.dimensions();
        let title_y_start = info.y + info.h;
        let title_x_start = (info.x as f64 + TITLE_X_ORIGIN_INFO_W_MULT * info.w as f64) as i32;
        let title_x_end = (title_x_start + info.w * TITLE_X_END_INFO_W_MULT).min(img_w as i32);
        let title_y_end = title_y_start + info.h * TITLE_APP_HEIGHT_INFO_H_MULT;

        let x_origin = title_x_start.max(0) as u32;
        let x_end = (title_x_end as u32).min(img_w);
        let y_start = title_y_start.max(0) as u32;
        let y_end = (title_y_end as u32).min(img_h);

        if x_end > x_origin && y_end > y_start {
            let original_is_dark = is_dark_mode(original);
            let region = crop_text_ocr_region(
                original,
                converted,
                original_is_dark,
                x_origin,
                y_start,
                x_end - x_origin,
                y_end - y_start,
            );
            let region_enhanced = adjust_contrast_brightness(&region, 2.0, 0);
            let words = run_tesseract(&region_enhanced, "3")?;

            let title = words_to_title_row_text(words.iter());

            if title.chars().count() > MAX_TITLE_LENGTH {
                info!(
                    "Title too long ({} chars), likely OCR garbage",
                    title.chars().count()
                );
                return Ok((String::new(), Some(y_end as i32)));
            }

            info!("Found title via crop OCR: '{}' at y={}", title, y_end);
            return Ok((title, Some(y_end as i32)));
        }
    }

    // Localized Screen Time pages translate the lower "Info" anchor, so the
    // anchor cascade above cannot reach the clean duplicate app name. Re-read
    // only the centered navigation-title strip instead. The narrow crop avoids
    // the chart/grid words that a full multi-language page pass frequently
    // promotes to fake light-mode titles (observed as "line", "mm", and
    // "Ite" across the Hebrew corpus).
    let (img_w, img_h) = converted.dimensions();
    let nav_x0 = (img_w as f64 * TITLE_FALLBACK_BAND_LEFT_FRAC) as u32;
    let nav_x1 = ((img_w as f64 * TITLE_FALLBACK_BAND_RIGHT_FRAC) as u32).min(img_w);
    let nav_y0 = ((img_h as f64 * 0.045) as u32).min(img_h);
    let nav_y1 = ((img_h as f64 * 0.13) as u32).min(img_h);
    if nav_x1 > nav_x0 && nav_y1 > nav_y0 {
        let nav = crop_text_ocr_region(
            original,
            converted,
            is_dark_mode(original),
            nav_x0,
            nav_y0,
            nav_x1 - nav_x0,
            nav_y1 - nav_y0,
        );
        for psm in ["11", "6"] {
            for words in [run_tesseract(&nav, psm), run_tesseract_anchor(&nav, psm)]
                .into_iter()
                .flatten()
            {
                let title =
                    words_to_title_row_text(words.iter().filter(|word| {
                        word.text.chars().filter(|ch| ch.is_alphabetic()).count() >= 2
                    }));
                if !title.is_empty() && title.chars().count() <= MAX_TITLE_LENGTH {
                    info!("Found title via targeted nav crop: '{title}'");
                    return Ok((title, Some(nav_y1 as i32)));
                }
            }
        }
    }

    let x_lo = (img_w as f64 * TITLE_FALLBACK_BAND_LEFT_FRAC) as i32;
    let x_hi = (img_w as f64 * TITLE_FALLBACK_BAND_RIGHT_FRAC) as i32;
    let y_lo = (img_h as f64 * TITLE_FALLBACK_BAND_TOP_FRAC) as i32;
    let y_hi = (img_h as f64 * TITLE_FALLBACK_BAND_BOTTOM_FRAC) as i32;
    let row_tol = (img_h as f64 * TITLE_FALLBACK_ROW_TOL_FRAC) as i32;

    let mut band: Vec<&OcrWord> = ocr_data
        .iter()
        .filter(|w| {
            w.text.chars().filter(|ch| ch.is_alphabetic()).count() >= 2
                && w.x >= x_lo
                && w.x < x_hi
                && w.y >= y_lo
                && w.y < y_hi
                && !is_info_anchor_text(&w.text)
        })
        .collect();
    if let Some(min_y) = band.iter().map(|w| w.y).min() {
        band.retain(|w| w.y < min_y + row_tol);
        sort_words_reading_order(&mut band);
        let title = words_to_title_text(band.iter().copied());
        if !title.is_empty() && title.chars().count() <= MAX_TITLE_LENGTH {
            return Ok((title, Some(y_hi)));
        }
    }

    debug!("No title found after all extraction strategies (anchor crop, nav-bar row select)");
    Ok((String::new(), None))
}

/// Recover the "Info" anchor when the full-image OCR pass dropped the INFO card.
///
/// The app name appears twice on an app-detail screenshot: the top nav row
/// (`< 🙈 <App>`, polluted by the iPad's device-name emoji) and the lower INFO
/// card (real app icon + clean name). The full-image pass occasionally
/// segments away the whole INFO card; rather than fall through to the polluted
/// nav row, re-OCR a moderate lower BAND to recover the "Info" anchor, then let
/// the caller run the normal anchor-window logic on it for a clean title.
///
/// The whole lower region (top_frac*H .. H) is too tall and re-drops "Info" in
/// segmentation, so the band is ~30% of the height around the INFO card. The
/// (band, contrast) ladder and fractions are mirrored verbatim in
/// `core/ocr.py::_recover_info_anchor_lower_reocr` for Rust/Python parity; the
/// first "Info" hit wins (this is the user's "multiple retries").
#[cfg(feature = "ocr")]
fn recover_info_anchor_lower_reocr(img: &RgbImage) -> Option<OcrWord> {
    let (img_w, img_h) = img.dimensions();
    let h = img_h as f64;
    // Proven primary band [top..bottom], then a slightly widened retry.
    let bands = [
        (TITLE_INFO_REOCR_TOP_FRAC, TITLE_INFO_REOCR_BOTTOM_FRAC),
        (
            TITLE_INFO_REOCR_TOP_FRAC - 0.05,
            TITLE_INFO_REOCR_BOTTOM_FRAC + 0.05,
        ),
    ];
    for (top_frac, bottom_frac) in bands {
        let y0 = (h * top_frac).max(0.0) as u32;
        let y1 = ((h * bottom_frac) as u32).min(img_h);
        if y1 <= y0 {
            continue;
        }
        let region = image::imageops::crop_imm(img, 0, y0, img_w, y1 - y0).to_image();
        // contrast 1.0 is identity in adjust_contrast_brightness, so always
        // applying it keeps the contrast ladder a single mirrored code path.
        for &contrast in &[1.0_f64, 2.0] {
            let enhanced = adjust_contrast_brightness(&region, contrast, 0);
            let Ok(words) = run_tesseract(&enhanced, "3") else {
                continue;
            };
            if let Some(mut anchor) = words
                .into_iter()
                .rev()
                .find(|w| is_info_anchor_text(&w.text))
            {
                anchor.y += y0 as i32;
                info!(
                    "Recovered Info anchor via lower-band re-OCR (band {top_frac}..{bottom_frac}, contrast {contrast})"
                );
                return Some(anchor);
            }
        }
    }
    None
}

#[cfg(feature = "ocr")]
fn recover_info_anchor_lower_reocr_from_sources(
    original: &RgbImage,
    converted: &RgbImage,
) -> Option<OcrWord> {
    let (img_w, img_h) = converted.dimensions();
    let h = img_h as f64;
    let original_is_dark = is_dark_mode(original);
    let bands = [
        (TITLE_INFO_REOCR_TOP_FRAC, TITLE_INFO_REOCR_BOTTOM_FRAC),
        (
            TITLE_INFO_REOCR_TOP_FRAC - 0.05,
            TITLE_INFO_REOCR_BOTTOM_FRAC + 0.05,
        ),
    ];
    for (top_frac, bottom_frac) in bands {
        let y0 = (h * top_frac).max(0.0) as u32;
        let y1 = ((h * bottom_frac) as u32).min(img_h);
        if y1 <= y0 {
            continue;
        }
        let region =
            crop_text_ocr_region(original, converted, original_is_dark, 0, y0, img_w, y1 - y0);
        for &contrast in &[1.0_f64, 2.0] {
            let enhanced = adjust_contrast_brightness(&region, contrast, 0);
            let Ok(words) = run_tesseract(&enhanced, "3") else {
                continue;
            };
            if let Some(mut anchor) = words
                .into_iter()
                .rev()
                .find(|w| is_info_anchor_text(&w.text))
            {
                anchor.y += y0 as i32;
                info!(
                    "Recovered Info anchor via lower-band re-OCR (band {top_frac}..{bottom_frac}, contrast {contrast})"
                );
                return Some(anchor);
            }
        }
    }
    None
}

/// Extract total screen time using pre-computed full-image OCR data.
///
/// Extracts from spatially-filtered full-image OCR words — no extra Tesseract call.
fn extract_total(img: &RgbImage, ocr_data: &[OcrWord]) -> Result<String, ProcessingError> {
    extract_total_with_source(img, ocr_data, None)
}

/// [`extract_total`] with an optional PRISTINE copy of the frame for the
/// localized reader.
///
/// The contrast/brightness boost the pipeline applies before OCR helps the
/// English readers and hurts Hebrew: on the reference capture the boosted frame
/// clips the header's `7 שע׳ 44 דק׳` while the untouched frame reads it cleanly.
/// Python has always read both and kept the larger total
/// (`image_processor.apply_processing`); this is the same rule on the Rust side,
/// which is the one that actually runs in the offline app.
fn extract_total_with_source(
    img: &RgbImage,
    ocr_data: &[OcrWord],
    pristine: Option<&RgbImage>,
) -> Result<String, ProcessingError> {
    extract_total_impl(img, ocr_data, pristine, true)
}

/// `language_fallbacks` is false for the English-only re-read at the bottom of
/// this function, which must not recurse into itself.
fn extract_total_impl(
    img: &RgbImage,
    ocr_data: &[OcrWord],
    pristine: Option<&RgbImage>,
    language_fallbacks: bool,
) -> Result<String, ProcessingError> {
    let texts: Vec<String> = ocr_data.iter().map(|w| w.text.clone()).collect();
    let is_daily = is_daily_total_page(&texts);

    // On a localized page, isolate the known header band before trusting any
    // whole-page token ordering. The page pass freely mixes the date, category
    // rows and daily-average text into the header row; a bounded re-read keeps
    // those numbers out and works identically for light mode and the plain-
    // inverted dark OCR source.
    #[cfg(feature = "ocr")]
    if language_fallbacks && !localized_languages().is_empty() {
        if let Some(localized) = recover_total_from_header_band(img) {
            info!("Found total from localized header-band re-read: '{localized}'");
            return Ok(localized);
        }
    }

    // Prefer an explicitly enabled localized unit over English-looking OCR
    // confusions. With eng+heb, the Hebrew geresh and glyph fragments are often
    // emitted as `h`/`m`; letting the English reader go first produced plausible
    // but false totals such as 42h for a visible 6h28m header, and sometimes a
    // category subtotal instead of the large daily header. Row geometry plus
    // the user's installed unit catalogue is stronger evidence.
    if language_fallbacks {
        let localized_words: Vec<&OcrWord> = ocr_data
            .iter()
            .filter(|word| !word.text.is_empty())
            .collect();
        let localized = extract_localized_total_from_word_rows(&localized_words);
        if !localized.is_empty() {
            info!("Found total from localized header row: '{localized}'");
            return Ok(localized);
        }
    }

    // Find LAST standalone "SCREEN" word — matches Python's behavior of taking last match.
    // Case-insensitive: some screenshots render the header in title case ("Screen
    // Time") rather than all-caps ("SCREEN TIME"); an exact-uppercase match misses
    // the anchor. Do not use substring matching: app titles like "ScreenZen" can
    // appear lower on the page and would shift the total crop.
    let screen_word = ocr_data
        .iter()
        .rev()
        .find(|w| is_screen_anchor_text(&w.text));

    let (img_w, img_h) = img.dimensions();

    if let Some(screen) = screen_word {
        // Compute the same bounding box that the crop+re-OCR path used
        let (x_start, y_start, x_end_approx, y_end_approx) = if is_daily {
            if let Some((x, y, w, h)) = daily_total_crop_rect(screen, img_w, img_h) {
                (x as i32, y as i32, (x + w) as i32, (y + h) as i32)
            } else {
                (0, 0, 0, 0)
            }
        } else {
            let h = screen.h * 6;
            let y = screen.y + screen.h + 50;
            let x = (screen.x - 20).max(0);
            // Clamp width to img_width / 3 for app pages to avoid picking up
            // unrelated text on the right side of the screen
            let w = (screen.w * 3).min(img_w as i32 / 3);
            (x, y, x + w, y + h)
        };

        // Collect words in the total region from the full-image OCR data
        let mut region_words: Vec<&OcrWord> = ocr_data
            .iter()
            .filter(|w| {
                !w.text.is_empty()
                    && w.x >= x_start
                    && w.x < x_end_approx
                    && w.y >= y_start
                    && w.y < y_end_approx
            })
            .collect();
        sort_words_reading_order(&mut region_words);

        let total_text = words_to_normalized_text(region_words.iter().copied());
        let extracted = if is_daily {
            extract_daily_total_from_word_rows(&region_words)
        } else {
            extract_time_from_text(&total_text)
        };
        if !extracted.is_empty() {
            let extracted = heal_missing_hours(img, ocr_data, extracted);
            info!(
                "Found total from full-image OCR: '{}' (from '{}')",
                extracted, total_text
            );
            return Ok(extracted);
        }
    }

    // Fallback: when "SCREEN" not found, use hardcoded regions matching Python
    let (fb_y_start, fb_y_end) = if is_daily { (325, 425) } else { (250, 350) };

    let mut region_words: Vec<&OcrWord> = ocr_data
        .iter()
        .filter(|w| {
            !w.text.is_empty() && w.y >= fb_y_start && w.y < fb_y_end && w.x < (img_w as i32 / 3)
        })
        .collect();
    sort_words_reading_order(&mut region_words);

    let fb_text = words_to_normalized_text(region_words.iter().copied());
    let extracted = extract_time_from_text(&fb_text);
    if !extracted.is_empty() {
        let extracted = heal_missing_hours(img, ocr_data, extracted);
        info!(
            "Found total via hardcoded region fallback: '{}' (from '{}')",
            extracted, fb_text
        );
        return Ok(extracted);
    }

    // Neither the anchored crop nor the hardcoded band saw a time. On a daily-total
    // page the header total is the LARGEST text on the frame, so ask the whole word
    // list for its biggest time row. This is what reads captures whose header sits
    // below the progressive search's y ceiling: with no "SCREEN" anchor that ceiling
    // is img_h/4, and a taller status/date header pushes the total past it (measured
    // at y=709 on a 2556-tall capture, ceiling 639), leaving it invisible to every
    // reader above and below. Font size is the signal that survives that shift —
    // `extract_daily_total_from_word_rows` already ranks by row height, and it is the
    // same function the anchored crop uses.
    if is_daily {
        // HEADER BAND ONLY. iOS prints the daily total above the chart, and the app
        // list below it is full of times that are not the total. Measured on three
        // captures whose header row the page pass never read at all: the largest
        // time row on the whole page was an app row at y≈0.6·H, so this fallback
        // returned `39m` for a day whose bars sum to about four hours. The ceiling
        // is the same header band `total_row_bounds` already prefers, and it clears
        // every header this fallback was built for by a wide margin (measured at
        // y=651..709 on 2556-tall captures, i.e. 0.25..0.28·H).
        let mut page_words = header_band_words(ocr_data, img_h);
        sort_words_reading_order(&mut page_words);
        let total = extract_daily_total_from_word_rows(&page_words);
        if !total.is_empty() {
            let total = heal_missing_hours(img, ocr_data, total);
            info!("Found total from the largest time row on the page: '{total}'");
            return Ok(total);
        }

        // Nothing in the band at all — not even a mangled one. Re-read those
        // pixels on their own before giving up; the page pass can segment the
        // header away completely.
        #[cfg(feature = "ocr")]
        if let Some(total) = recover_total_from_header_band(img) {
            info!("Found total by re-reading the header band on its own: '{total}'");
            return Ok(total);
        }
    }

    // Progressive search: left 1/3 → left 1/2 → full width.
    // Canvas uses 3 tiers: left-third (avoids "Daily Average"), left-half, full image.
    // "Daily Average" at y~674 must be excluded. Use SCREEN word position
    // if available, otherwise cap at img_h/4.
    let y_limit = screen_word
        .map(|sw| sw.y + sw.h + 200) // ~200px below SCREEN word
        .unwrap_or((img_h as i32) / 4);
    for fraction in &[3, 2, 1] {
        let x_limit = img_w as i32 / fraction;
        let prog_text = words_to_normalized_text(
            ocr_data
                .iter()
                .filter(|w| !w.text.is_empty() && w.x < x_limit && w.y < y_limit),
        );
        let total = extract_time_from_text(&prog_text);
        if !total.is_empty() {
            let total = heal_missing_hours(img, ocr_data, total);
            info!(
                "Found total via progressive search (1/{}): '{}'",
                fraction, total
            );
            return Ok(total);
        }
    }

    // Last resort: a non-English total, which every reader above misses because
    // they all key on the literal letters h/m/s. Runs on the FULL word list —
    // the left-third crops above exist to dodge "Daily Average" on the right,
    // but iOS mirrors the layout in an RTL locale and puts the main total there.
    // `extract_localized_total` does its own disambiguation, preferring the
    // largest candidate, which on a daily-total page is the total by definition.
    //
    // Costs nothing for an English install: `localized_languages()` is empty
    // when no pack is selected, so the call returns immediately.
    let languages = if language_fallbacks {
        localized_languages()
    } else {
        Vec::new()
    };
    if !languages.is_empty() {
        let refs: Vec<&str> = languages.iter().map(String::as_str).collect();

        let read = |text: &str| {
            let total = crate::localized_total::extract_localized_total(text, &refs);
            let minutes = crate::localized_total::total_text_minutes(&total);
            (total, minutes)
        };

        // The supplied word list first — free, since the caller already ran it,
        // and on every capture seen so far it already holds the header total.
        let from_words = words_to_normalized_text(ocr_data.iter().filter(|w| !w.text.is_empty()));
        // Rebound only by the `ocr`-feature fallback below.
        #[cfg_attr(not(feature = "ocr"), allow(unused_mut))]
        let (mut best, mut best_minutes) = read(&from_words);

        // Only if that saw nothing: re-read the whole frame, the way Python's
        // `_find_total_localized` always does. The region-first callers hand us
        // a stitched top-band + INFO-card crop, so a header that falls outside
        // it is invisible to the word list above. `pristine` is the frame before
        // the contrast/brightness boost, which helps the English readers and can
        // clip a small RTL glyph cluster. Both are whole extra OCR passes —
        // hence a fallback, not a routine second opinion.
        #[cfg(feature = "ocr")]
        if best.is_empty() {
            for source in std::iter::once(img).chain(pristine) {
                let Ok(full) = run_tesseract(source, "3") else {
                    continue;
                };
                let (total, minutes) = read(&words_to_normalized_text(
                    full.iter().filter(|w| !w.text.is_empty()),
                ));
                if minutes > best_minutes {
                    best_minutes = minutes;
                    best = total;
                }
            }
        }
        // Both are read only by the `ocr`-feature fallback above.
        let _ = (best_minutes, pristine);

        if !best.is_empty() {
            info!("Found total with localized units: '{best}'");
            return Ok(best);
        }

        // Nothing read in any language. Adding a pack changes what Tesseract
        // makes of ENGLISH text too: on `IMG_0809 Cropped.png` the total "1m"
        // comes back as the Hebrew "חן" once heb joins the language list, so
        // every reader above sees no total on a page that plainly has one.
        // Re-read with the eng-pinned engine — the same one the grid anchors
        // use, and for the same reason — and run the English readers over that.
        // Only reachable when a pack is enabled AND the page read as nothing,
        // so an English install never pays for it.
        #[cfg(feature = "ocr")]
        if let Ok(english) = run_tesseract_anchor(img, "3") {
            let retried = extract_total_impl(img, &english, None, false)?;
            if !retried.is_empty() {
                info!("Found total by re-reading in '{DEFAULT_OCR_LANG}': '{retried}'");
                return Ok(retried);
            }
        }
    }

    Ok(String::new())
}

/// Selected languages other than [`DEFAULT_OCR_LANG`], for the localized total
/// reader. Empty on an English install, which is what keeps that path free.
///
/// Without the `ocr` feature there is no engine and therefore no language state,
/// but `extract_total` itself still compiles (it works over a supplied word
/// list), so this needs a stub rather than being gated away with it.
#[cfg(not(feature = "ocr"))]
fn localized_languages() -> Vec<String> {
    Vec::new()
}

#[cfg(feature = "ocr")]
fn localized_languages() -> Vec<String> {
    ocr_language()
        .split('+')
        .map(str::trim)
        .filter(|c| !c.is_empty() && *c != DEFAULT_OCR_LANG)
        .map(str::to_string)
        .collect()
}

/// Does the user have a right-to-left language enabled?
///
/// The gate on axis-direction detection. An English daily chart's axis reads
/// `12 AM / 6 AM / 12 PM / 6 PM`, whose bare numerals descend across the page
/// and would vote "mirrored" — so direction must only ever be re-examined for
/// users who could actually be looking at a mirrored chart. `direction` comes
/// from the pack catalogue in `shared/language_packs.json`, so adding an RTL
/// locale there is all it takes; nothing here names a specific language.
#[cfg(feature = "ocr")]
pub fn rtl_language_enabled() -> bool {
    let enabled = localized_languages();
    crate::generated_constants::LANGUAGE_PACKS
        .iter()
        .any(|pack| pack.direction == "rtl" && enabled.iter().any(|code| code == pack.code))
}

/// Without the `ocr` feature there is no language state, so no RTL selection.
#[cfg(not(feature = "ocr"))]
pub fn rtl_language_enabled() -> bool {
    false
}

/// Extract both title and total from an image with a SINGLE Tesseract call.
///
/// Runs Tesseract once on the full image, then uses spatial filtering of the
/// resulting word list to extract title and total — no extra Tesseract calls.
/// Daily total pages are detected from the full-image word list; cropping the
/// image would cause markers like "MOST USED" and "CATEGORIES" (which appear
/// in the lower half of daily total pages) to be missed.
///
/// Errors are propagated, not silently swallowed.
#[cfg(feature = "ocr")]
pub fn find_title_and_total(
    img: &RgbImage,
) -> Result<(String, Option<i32>, String), ProcessingError> {
    let (title, title_y, total, _) = find_title_total_and_quality(img, None)?;
    Ok((title, title_y, total))
}

/// Extract title/total and data-quality evidence from the same full-frame OCR
/// word list. `bounds` narrows axis-label detection to the chart edge.
#[cfg(feature = "ocr")]
pub fn find_title_total_and_quality(
    img: &RgbImage,
    bounds: Option<&crate::types::GridBounds>,
) -> Result<(String, Option<i32>, String, AllDevicesSignals), ProcessingError> {
    TITLE_TOTAL_FULL_FRAME_CALLS.fetch_add(1, Ordering::Relaxed);
    // Run Tesseract ONCE on the full image. PSM 3 (auto layout) matches
    // the Python reference (`pytesseract.image_to_data(img, config="--psm 3")`)
    // and is what reliably segments the page into label words like INFO
    // and SCREEN that the spatial filter downstream depends on. PSM 6
    // (single uniform block) treats the whole header as one paragraph and
    // can drop those anchor words on tall displays.
    let ocr_data = run_tesseract(img, "3")?;

    // Extract title and total using the cached OCR data.
    // Pass the full image for the title crop fallback (needs full-res pixels).
    let (title, title_y) = extract_title(img, &ocr_data)?;
    let total = extract_total(img, &ocr_data)?;
    let quality = detect_all_devices_signals(&ocr_data, img.width(), img.height(), bounds);

    Ok((title, title_y, total, quality))
}

/// Extract title and total from bounded OCR regions without first materializing
/// a full-frame text-OCR image.
///
/// Light mode reads the regions from `converted` (which is equal to original
/// after a no-op `convert_dark_mode`); dark mode reads the same regions from
/// `original` and plain-inverts only those crops. A full-frame OCR source is
/// built only for the fallback path when the region pass cannot recover both
/// fields.
#[cfg(feature = "ocr")]
pub fn find_title_and_total_region_first_from_sources(
    original: &RgbImage,
    converted: &RgbImage,
) -> Result<(String, Option<i32>, String), ProcessingError> {
    let (title, title_y, total, _) =
        find_title_total_and_quality_region_first_from_sources(original, converted, None)?;
    Ok((title, title_y, total))
}

/// Region-first title/total OCR plus All Devices evidence, sharing the same OCR
/// words so quality screening adds no second Tesseract pass.
#[cfg(feature = "ocr")]
pub fn find_title_total_and_quality_region_first_from_sources(
    original: &RgbImage,
    converted: &RgbImage,
    bounds: Option<&crate::types::GridBounds>,
) -> Result<(String, Option<i32>, String, AllDevicesSignals), ProcessingError> {
    let ocr_data = run_title_total_region_ocr_from_sources(original, converted, bounds)?;
    let (title, title_y) = extract_title_from_sources(original, converted, &ocr_data)?;
    let daily_crop_total = extract_daily_total_crop_from_sources(original, converted, &ocr_data)?;
    let total = match daily_crop_total {
        Some(total) => total,
        None => extract_total_with_source(converted, &ocr_data, Some(original))?,
    };

    if title.is_empty() || total.is_empty() {
        debug!(
            "Region OCR incomplete (title_empty={}, total_empty={}); falling back to full-frame OCR",
            title.is_empty(),
            total.is_empty()
        );
        let ocr_src = text_ocr_image(original, converted);
        return find_title_total_and_quality(&ocr_src, bounds);
    }

    let quality =
        detect_all_devices_signals(&ocr_data, converted.width(), converted.height(), bounds);
    Ok((title, title_y, total, quality))
}

/// Run quality-only OCR over the full prepared image.
///
/// This is reserved for the grid-failure path. Without usable bounds there is
/// no safe right-axis crop, so the full frame is required to retain both the
/// device selector and any >1-hour chart-axis label. OCR errors are returned to
/// the caller so it can keep the grid failure while documenting the secondary
/// screening failure.
#[cfg(feature = "ocr")]
pub fn find_all_devices_quality_from_sources(
    original: &RgbImage,
    converted: &RgbImage,
) -> Result<AllDevicesSignals, ProcessingError> {
    let ocr_src = text_ocr_image(original, converted);
    let words = run_tesseract(&ocr_src, "3")?;
    Ok(detect_all_devices_signals(
        &words,
        converted.width(),
        converted.height(),
        None,
    ))
}

/// Extract title and total from an externally-provided word list (e.g. Tesseract.js).
///
/// Used by the WASM module: the caller provides words from the JS OCR engine,
/// and this function applies Rust's spatial filtering and text normalization.
/// `img_width` and `img_height` must match the source image for correct spatial math.
pub fn extract_from_words(
    words: &[OcrWord],
    img_width: u32,
    img_height: u32,
) -> (String, Option<i32>, String) {
    let stub = image::RgbImage::new(img_width, img_height);
    let texts: Vec<String> = words.iter().map(|w| w.text.clone()).collect();
    let is_daily = is_daily_total_page(&texts);
    let (raw_title, title_y) = extract_title(&stub, words).unwrap_or((String::new(), None));
    let title = if is_daily {
        "Daily Total".to_string()
    } else {
        raw_title
    };
    let total = extract_total(&stub, words).unwrap_or_default();
    (title, title_y, total)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn review_decimal_tsv_confidence_preserves_integer_contract() {
        let words = parse_phi_tsv("header\n5\t1\t1\t1\t1\t1\t10\t20\t30\t40\t96.734261\tAlice\n");
        assert_eq!(words.len(), 1);
        assert_eq!(words[0].conf, 97);
        assert_eq!(
            serde_json::json!({"conf": words[0].conf}),
            serde_json::json!({"conf": 97})
        );
    }

    #[test]
    fn review_paired_duration_skips_invalid_components() {
        for text in [
            "1h 75m 2h 15m",
            "1h 75 2h 15",
            "5m 75s 3m 15s",
            "75m 5s 3m 15s",
        ] {
            let expected = if text.contains('h') {
                "2h 15m"
            } else {
                "3m 15s"
            };
            assert_eq!(extract_time_from_text(text), expected, "{text}");
        }
        assert_eq!(extract_time_from_text("1h 59m"), "1h 59m");
        assert_eq!(extract_time_from_text("59m 59s"), "59m 59s");
        assert_eq!(extract_time_from_text("75m"), "75m");
    }

    #[test]
    fn review_title_row_keeps_single_short_or_numeric_token() {
        for text in ["X", "2048"] {
            let words = [
                word(text, 20, 100, 40, 30),
                word("Category", 20, 150, 100, 30),
            ];
            assert_eq!(words_to_title_row_text(words.iter()), text);
        }
        let words = [word("X", 20, 100, 40, 30), word("Roblox", 80, 100, 100, 30)];
        assert_eq!(words_to_title_row_text(words.iter()), "Roblox");
    }

    #[cfg(not(feature = "ocr"))]
    #[test]
    fn review_title_length_counts_unicode_characters() {
        let img = RgbImage::new(1170, 2532);
        let title = "日本語".repeat(6);
        let words = [
            word("Info", 101, 1367, 84, 38),
            word(&title, 283, 1507, 157, 39),
        ];
        assert_eq!(extract_title(&img, &words).unwrap().0, title);
    }

    #[cfg(feature = "ocr")]
    #[test]
    fn localized_row_reader_prefers_large_rtl_header_over_category_subtotal() {
        set_ocr_language("eng+heb");
        // Bounding boxes are in visual LTR order: minute unit, minutes, hour
        // unit, hours. The reader must reverse that row for logical Hebrew.
        let words = vec![
            word("דק׳", 40, 650, 40, 80),
            word("28", 100, 650, 60, 80),
            word("שע׳", 180, 650, 55, 80),
            word("6", 250, 650, 35, 80),
            word("דק׳", 40, 1450, 30, 30),
            word("42", 80, 1450, 35, 30),
            word("שע׳", 130, 1450, 40, 30),
            word("4", 180, 1450, 20, 30),
        ];
        let refs: Vec<&OcrWord> = words.iter().collect();
        assert_eq!(extract_localized_total_from_word_rows(&refs), "6h 28m");
        set_ocr_language("eng");
    }

    #[cfg(feature = "ocr")]
    #[test]
    fn localized_row_reader_handles_real_dark_header_word_boxes() {
        set_ocr_language("eng+heb");
        let words = vec![
            word("7", 1030, 349, 47, 72),
            word("'ו28", 681, 348, 132, 74),
            word("דק", 534, 361, 114, 78),
        ];
        let refs: Vec<&OcrWord> = words.iter().collect();
        assert_eq!(extract_localized_total_from_word_rows(&refs), "7h 28m");
        set_ocr_language("eng");
    }

    #[test]
    fn title_row_preserves_rtl_reading_order() {
        let words = [
            word("משתמש/ת", 40, 100, 80, 30),
            word("אימות", 140, 100, 60, 30),
        ];
        assert_eq!(words_to_title_row_text(words.iter()), "אימות משתמש/ת");
    }

    /// The cut has to leave a line of text alone. These build a frame whose only
    /// ink inside the search window is one 87-px band — the height iOS prints the
    /// daily total at — and check the boundary lands clear of it rather than
    /// through it. Reachable on the host only because `header_crop_bottom` is
    /// deliberately not behind `#[cfg(feature = "ocr")]`; gated, none of this
    /// would compile here, let alone run.
    #[test]
    fn the_header_cut_slides_off_a_line_of_text() {
        // 2556 tall: flat cut at 767, search window ends at 921.
        let h = 2556u32;
        let w = 1179u32;
        let mut img = RgbImage::from_pixel(w, h, image::Rgb([255, 255, 255]));
        // A total row straddling the flat cut, exactly as measured: y 700..787.
        for y in 700..787 {
            for x in 100..600 {
                img.put_pixel(x, y, image::Rgb([0, 0, 0]));
            }
        }
        let cut = header_crop_bottom(&img);
        assert!(cut >= 787, "cut at {cut} still runs through the total row");
        assert!(cut < 921, "cut at {cut} slid past the search window");

        // Nothing in the way: the flat cut stands, unmoved.
        let clear = RgbImage::from_pixel(w, h, image::Rgb([255, 255, 255]));
        assert_eq!(header_crop_bottom(&clear), 767);

        // Ink on every row of the window — no blank line to find. The flat cut is
        // the documented fallback, NOT a slide to the bottom of the window.
        let mut solid = RgbImage::from_pixel(w, h, image::Rgb([255, 255, 255]));
        for y in 760..930 {
            for x in 0..w {
                solid.put_pixel(x, y, image::Rgb([0, 0, 0]));
            }
        }
        assert_eq!(header_crop_bottom(&solid), 767);

        // A few antialiased specks are not a line of text: tolerance is w/200.
        let mut speckled = RgbImage::from_pixel(w, h, image::Rgb([255, 255, 255]));
        for y in 767..800 {
            for x in 0..(w / 200) {
                speckled.put_pixel(x, y, image::Rgb([0, 0, 0]));
            }
        }
        assert_eq!(header_crop_bottom(&speckled), 767);
    }

    /// It reads the image it is given, so a degenerate one must not walk off the
    /// end. `clamp(1, img_h)` panics when `img_h` is 0, and `get_pixel` panics
    /// past the last row — taking the height from the image rather than from a
    /// parameter is what makes both unreachable.
    #[test]
    fn the_header_cut_survives_a_degenerate_frame() {
        assert_eq!(header_crop_bottom(&RgbImage::new(0, 0)), 0);
        assert_eq!(header_crop_bottom(&RgbImage::new(10, 0)), 0);
        // 1 row tall: flat == limit == 1, the loop never runs.
        assert_eq!(
            header_crop_bottom(&RgbImage::from_pixel(10, 1, image::Rgb([255, 255, 255]))),
            1
        );
        // Narrower than the tolerance divisor — w/200 is 0, and .max(1) saves it.
        let narrow = RgbImage::from_pixel(4, 2556, image::Rgb([255, 255, 255]));
        assert_eq!(header_crop_bottom(&narrow), 767);
    }

    #[test]
    fn tesseract_recognition_status_is_not_silently_ignored() {
        assert!(ensure_tesseract_recognized(0).is_ok());

        let error =
            ensure_tesseract_recognized(-1).expect_err("nonzero status must be an OCR failure");
        assert!(matches!(error, ProcessingError::Ocr(message) if message.contains("status -1")));
    }

    // --- lost-hours recovery ---

    fn word(text: &str, x: i32, y: i32, w: i32, h: i32) -> OcrWord {
        OcrWord {
            text: text.to_string(),
            x,
            y,
            w,
            h,
        }
    }

    #[test]
    fn total_missing_hours_spots_both_shapes_of_a_lost_hour() {
        // Lowercase `oh` leaves no hour pattern at all.
        assert_eq!(total_missing_hours("11m"), Some(11));
        // Uppercase `Oh` survives normalization as a zero hour, which iOS never
        // prints — it writes `24m`.
        assert_eq!(total_missing_hours("0h 24m"), Some(24));
    }

    #[test]
    fn total_missing_hours_leaves_well_formed_totals_alone() {
        assert_eq!(total_missing_hours("5h 11m"), None);
        assert_eq!(total_missing_hours("7h"), None);
        assert_eq!(total_missing_hours(""), None);
        // A minutes/seconds reading is an app page's total, not the header.
        assert_eq!(total_missing_hours("4m 20s"), None);
    }

    #[test]
    fn the_app_list_below_the_chart_cannot_supply_the_total() {
        // A capture whose header row the page pass never read: every time on the
        // frame belongs to the app list under the chart. Ranking those by size
        // returned `39m` for a day whose bars summed to about four hours, so the
        // band has to exclude them — better no total than someone else's.
        let words = vec![
            word("Daily", 102, 430, 120, 33),
            word("Total", 240, 430, 120, 33),
            word("2h", 102, 1535, 60, 33),
            word("38m", 180, 1535, 90, 33),
            word("39m", 102, 1656, 90, 33),
        ];
        let band = header_band_words(&words, 2556);
        assert_eq!(
            band.iter().map(|w| w.text.as_str()).collect::<Vec<_>>(),
            ["Daily", "Total"]
        );
        assert!(extract_daily_total_from_word_rows(&band).is_empty());

        // A header the fallback WAS built for still clears the band.
        let header = vec![word("9h", 103, 709, 87, 95), word("30m", 267, 709, 87, 95)];
        let band = header_band_words(&header, 2556);
        assert_eq!(extract_daily_total_from_word_rows(&band), "9h 30m");
    }

    #[test]
    fn reading_order_survives_a_staircase_of_words() {
        // Each word sits exactly Y_TOLERANCE below the last, so "same row?" is
        // true for every adjacent pair and false end to end. Deciding that
        // pairwise inside a comparator is intransitive and aborts the process;
        // a whole-page read on a real capture is exactly this shape. Left-most
        // x goes with the LAST word so an x-only order would be visible.
        let staircase: Vec<OcrWord> = (0..40)
            .map(|i| word("w", 500 - i * 10, 100 + i * 8, 30, 20))
            .collect();
        let mut words: Vec<&OcrWord> = staircase.iter().collect();
        sort_words_reading_order(&mut words);
        assert_eq!(words.len(), 40);
        // Chained, the staircase is ONE row, so it comes out purely left to right.
        assert!(words.windows(2).all(|p| p[0].x <= p[1].x));

        // Words that really are on one line still come out left to right.
        let line = [
            word("25m", 255, 704, 149, 72),
            word("Yesterday,", 102, 700, 180, 40),
            word("8h", 102, 702, 104, 73),
        ];
        let mut words: Vec<&OcrWord> = line.iter().collect();
        sort_words_reading_order(&mut words);
        assert_eq!(
            words.iter().map(|w| w.text.as_str()).collect::<Vec<_>>(),
            ["Yesterday,", "8h", "25m"]
        );
    }

    #[test]
    fn total_row_bounds_frames_the_whole_header_row() {
        // The date line shares the row band with the total on a real capture.
        let words = vec![
            word("Yesterday,", 102, 705, 180, 40),
            word("April", 300, 705, 90, 40),
            word("24", 400, 705, 48, 40),
            word("oh", 102, 785, 104, 73),
            word("11m", 255, 785, 149, 72),
        ];
        let (x, y, w, h) =
            total_row_bounds(&words, HourEvidence::Minutes(11), 1179, 2556).expect("row found");
        // Padded 20px horizontally, 14px vertically, around the `oh 11m` row.
        assert_eq!((x, y), (82, 771));
        assert_eq!(x + w, 424);
        assert_eq!(y + h, 872);

        // The same row offered as a full-width strip: the second framing the
        // re-read falls back to when the words cannot describe their own row.
        let (x, y, w, h) =
            total_row_strip(&words, HourEvidence::Minutes(11), 1179, 2556).expect("strip found");
        assert_eq!((x, y), (0, 771));
        assert_eq!((x + w, y + h), (1179, 871));
    }

    #[test]
    fn total_row_bounds_picks_the_largest_matching_token() {
        // A category row further down prints the same duration in small type.
        let words = vec![
            word("11m", 255, 785, 149, 72),
            word("11m", 900, 1400, 40, 20),
        ];
        let (_, y, _, h) =
            total_row_bounds(&words, HourEvidence::Minutes(11), 1179, 2556).expect("row found");
        assert!(
            y < 800 && y + h < 900,
            "must anchor on the header, got y={y} h={h}"
        );
    }

    // A row whose minutes were never segmented has no right-hand word to bound
    // it: the `4h` bbox stops 200px short of the `46m` beside it. The strip has
    // to run to the edge of the frame or the re-read cannot see what it is for.
    // The caption above the header total sits 61px up from a 73px-tall total. A
    // strip that swallows it reads as two lines and comes back empty.
    #[test]
    fn the_caption_above_the_total_is_not_part_of_its_row() {
        let words = vec![
            word("SCREEN", 108, 520, 200, 32),
            word("TIME", 330, 520, 130, 32),
            word("4h", 100, 581, 120, 73),
        ];
        let (_, y, _, h) =
            total_row_strip(&words, HourEvidence::WholeHours(4), 1170, 2532).expect("strip found");
        assert_eq!(y, 567, "the strip starts at the total, not at the caption");
        assert_eq!(y + h, 668);
    }

    #[test]
    fn a_row_with_unread_minutes_is_framed_to_the_edge_of_the_page() {
        let words = vec![
            word("Yesterday,", 374, 383, 229, 48),
            word("4h", 100, 581, 120, 73),
        ];
        let (x, y, w, h) =
            total_row_strip(&words, HourEvidence::WholeHours(4), 1170, 2532).expect("strip found");
        assert_eq!((x, y), (0, 567));
        assert_eq!(x + w, 1170, "strip must reach the right edge");
        assert_eq!(y + h, 668);
        // The words alone stop 700px short of the minutes being looked for.
        let (_, _, narrow, _) =
            total_row_bounds(&words, HourEvidence::WholeHours(4), 1170, 2532).expect("row found");
        assert!(narrow < w, "the word-framed box cannot reach them");
    }

    #[test]
    fn total_row_bounds_accepts_a_row_below_the_header_band_in_a_crop() {
        // Callers that already cropped to the total region hand us an image
        // where the row sits well below the top fifth of the frame.
        let words = vec![word("9m", 20, 160, 120, 70)];
        assert!(total_row_bounds(&words, HourEvidence::Minutes(9), 400, 260).is_some());
    }

    #[test]
    fn a_letter_in_the_hours_slot_is_treated_as_an_unread_digit() {
        // `Sh` normalizes to `5h` with full confidence; on this batch's bold
        // header glyph it was an 8 every time.
        assert!(hours_came_from_a_letter(&[word("Sh", 0, 0, 10, 10)]));
        assert!(hours_came_from_a_letter(&[word("oh", 0, 0, 10, 10)]));
        // A digit that was actually read is not a candidate, and neither is a
        // longer token that merely contains an h.
        assert!(!hours_came_from_a_letter(&[word("8h", 0, 0, 10, 10)]));
        assert!(!hours_came_from_a_letter(&[word("Health", 0, 0, 10, 10)]));
    }

    #[test]
    fn heal_missing_hours_is_a_no_op_without_a_lost_hour() {
        let img = RgbImage::new(4, 4);
        let words = vec![word("5h", 0, 0, 10, 10), word("11m", 20, 0, 10, 10)];
        assert_eq!(
            heal_missing_hours(&img, &words, "5h 11m".to_string()),
            "5h 11m"
        );
        // A genuinely short day keeps its value when no hour can be recovered.
        assert_eq!(heal_missing_hours(&img, &words, "47m".to_string()), "47m");
    }

    // --- normalize_ocr_digits ---

    #[test]
    fn test_normalize_i_to_1() {
        assert_eq!(normalize_ocr_digits("I h"), "1 h");
        assert_eq!(normalize_ocr_digits("3I h"), "31 h");
        assert_eq!(normalize_ocr_digits("I2"), "12");
    }

    #[test]
    fn test_normalize_o_to_0() {
        assert_eq!(normalize_ocr_digits("O h"), "0 h");
        assert_eq!(normalize_ocr_digits("1O h"), "10 h");
        assert_eq!(normalize_ocr_digits("O5"), "05");
        assert_eq!(normalize_ocr_digits("1O2"), "102");
    }

    #[test]
    fn test_normalize_s_to_5() {
        assert_eq!(normalize_ocr_digits("S h"), "5 h");
        assert_eq!(normalize_ocr_digits("3S h"), "35 h");
    }

    #[test]
    fn test_normalize_a_to_4() {
        assert_eq!(normalize_ocr_digits("A h"), "4 h");
        assert_eq!(normalize_ocr_digits("1A h"), "14 h");
    }

    #[test]
    fn test_normalize_preserves_normal_text() {
        assert_eq!(normalize_ocr_digits("hello world"), "hello world");
        assert_eq!(normalize_ocr_digits("3h 45m"), "3h 45m");
    }

    // --- extract_time_from_text ---

    #[test]
    fn test_extract_hour_min() {
        assert_eq!(extract_time_from_text("4h 36m"), "4h 36m");
        assert_eq!(extract_time_from_text("12h 5m"), "12h 5m");
        assert_eq!(
            extract_time_from_text("some text 2h 30m more text"),
            "2h 30m"
        );
    }

    #[test]
    fn test_extract_hour_min_no_m() {
        assert_eq!(extract_time_from_text("4h 36"), "4h 36m");
    }

    #[test]
    fn test_extract_min_sec() {
        assert_eq!(extract_time_from_text("45m 30s"), "45m 30s");
        assert_eq!(extract_time_from_text("5m Os"), "5m 0s");
    }

    #[test]
    fn test_extract_hours_only() {
        assert_eq!(extract_time_from_text("3h"), "3h");
    }

    #[test]
    fn test_daily_total_rows_prefer_large_visible_total_over_chart_tick() {
        let words = vec![
            OcrWord {
                text: "4h".to_string(),
                x: 360,
                y: 40,
                w: 28,
                h: 14,
            },
            OcrWord {
                text: "6h".to_string(),
                x: 20,
                y: 70,
                w: 54,
                h: 34,
            },
            OcrWord {
                text: "36m".to_string(),
                x: 84,
                y: 70,
                w: 86,
                h: 34,
            },
        ];
        let refs: Vec<&OcrWord> = words.iter().collect();
        assert_eq!(extract_daily_total_from_word_rows(&refs), "6h 36m");
    }

    #[test]
    fn test_extract_min_only() {
        assert_eq!(extract_time_from_text("45m"), "45m");
    }

    #[test]
    fn test_extract_sec_only() {
        assert_eq!(extract_time_from_text("30s"), "30s");
    }

    #[test]
    fn test_extract_no_time() {
        assert_eq!(extract_time_from_text("no time here"), "");
        assert_eq!(extract_time_from_text(""), "");
    }

    #[test]
    fn test_extract_with_ocr_errors() {
        // I should become 1, O should become 0
        assert_eq!(extract_time_from_text("Ih 3Om"), "1h 30m");
    }

    // --- is_daily_total_page ---

    #[test]
    fn test_daily_total_page() {
        let texts: Vec<String> = vec![
            "SCREEN".to_string(),
            "TIME".to_string(),
            "MOST".to_string(),
            "USED".to_string(),
            "TODAY".to_string(),
            "CATEGORIES".to_string(),
        ];
        assert!(is_daily_total_page(&texts));
    }

    #[test]
    fn test_app_usage_page() {
        let texts: Vec<String> = vec![
            "Instagram".to_string(),
            "INFO".to_string(),
            "DEVELOPER".to_string(),
            "RATING".to_string(),
            "LIMIT".to_string(),
        ];
        assert!(!is_daily_total_page(&texts));
    }

    #[test]
    fn test_has_time_pattern() {
        assert!(has_time_pattern("4h 36m"));
        assert!(has_time_pattern("45m"));
        assert!(has_time_pattern("30s"));
        assert!(!has_time_pattern("hello world"));
    }

    #[test]
    fn test_info_anchor_is_standalone_token_not_information() {
        assert!(is_info_anchor_text("Info"));
        assert!(is_info_anchor_text("INFO:"));
        assert!(is_info_anchor_text("Inf0"));
        assert!(!is_info_anchor_text("Information"));
        assert!(!is_info_anchor_text("Information & Reading"));
        assert!(!is_info_anchor_text("Rating"));
    }

    #[test]
    fn test_screen_anchor_is_standalone_token_not_app_title() {
        assert!(is_screen_anchor_text("Screen"));
        assert!(is_screen_anchor_text("SCREEN:"));
        assert!(!is_screen_anchor_text("ScreenZen"));
        assert!(!is_screen_anchor_text("Screen Time"));
    }

    // Regression: iOS renders the Info section header title-case ("Info"), which
    // Tesseract reads as "Info". A case-sensitive `contains("INFO")` anchor missed
    // it on every app-detail page and blanked the title (real Roblox 1170x2532
    // screenshot returned null). The anchor must match "Info" case-insensitively.
    // Gated to the no-ocr spatial path (the ocr path crops + re-OCRs real pixels).
    #[cfg(not(feature = "ocr"))]
    #[test]
    fn test_extract_title_info_anchor_is_case_insensitive() {
        let img = RgbImage::new(1170, 2532);
        // Coordinates from the real Roblox screenshot OCR: Info @ (101,1367,84,38),
        // app-name "Roblox" @ (283,1507) sits inside the computed title window
        // x[227,1170] y[1405,1671]; "Category" below it must be excluded.
        let words = vec![
            OcrWord {
                text: "Info".to_string(),
                x: 101,
                y: 1367,
                w: 84,
                h: 38,
            },
            OcrWord {
                text: "Roblox".to_string(),
                x: 283,
                y: 1507,
                w: 157,
                h: 39,
            },
            OcrWord {
                text: "Category".to_string(),
                x: 99,
                y: 1679,
                w: 206,
                h: 47,
            },
        ];
        let (title, _y) = extract_title(&img, &words).unwrap();
        assert_eq!(title, "Roblox");
    }

    #[cfg(not(feature = "ocr"))]
    #[test]
    fn test_extract_title_ignores_information_category_as_info_anchor() {
        let img = RgbImage::new(393, 873);
        let words = vec![
            OcrWord {
                text: "Info".to_string(),
                x: 32,
                y: 340,
                w: 28,
                h: 14,
            },
            OcrWord {
                text: "Weather".to_string(),
                x: 86,
                y: 386,
                w: 70,
                h: 15,
            },
            OcrWord {
                text: "Information".to_string(),
                x: 218,
                y: 431,
                w: 91,
                h: 15,
            },
            OcrWord {
                text: "Rating".to_string(),
                x: 48,
                y: 468,
                w: 42,
                h: 15,
            },
        ];
        let (title, _y) = extract_title(&img, &words).unwrap();
        assert_eq!(title, "Weather");
    }

    // The proportional nav-bar fallback: when no "Info" anchor exists, the app name
    // is recovered from the centered nav-bar title band (fractions of WxH), NOT the
    // old absolute [40,300,120,2000] strip that hit the status bar on tall displays.
    // Band for 1170x2532 ≈ y[113,303] x[175,994]: the title is inside; the status-bar
    // clock above and the back chevron to the left are excluded.
    #[cfg(not(feature = "ocr"))]
    #[test]
    fn test_extract_title_nav_band_fallback_no_info_anchor() {
        let img = RgbImage::new(1170, 2532);
        let words = vec![
            OcrWord {
                text: "10:09".to_string(),
                x: 150,
                y: 60,
                w: 120,
                h: 38,
            },
            OcrWord {
                text: "<".to_string(),
                x: 90,
                y: 188,
                w: 40,
                h: 40,
            },
            OcrWord {
                text: "Roblox".to_string(),
                x: 507,
                y: 188,
                w: 157,
                h: 39,
            },
            OcrWord {
                text: "Screen".to_string(),
                x: 99,
                y: 379,
                w: 161,
                h: 38,
            },
        ];
        let (title, _y) = extract_title(&img, &words).unwrap();
        assert_eq!(title, "Roblox");
    }

    // Parity: T before unit → 7 (canvas confuses 7 and T in OCR output)
    #[test]
    fn parity_normalize_t_to_7() {
        assert_eq!(normalize_ocr_digits("T h"), "7 h");
        assert_eq!(normalize_ocr_digits("3T h"), "37 h");
    }

    // Parity: G and b before unit → 6 (canvas OCR confusion)
    #[test]
    fn parity_normalize_g_b_to_6() {
        assert_eq!(normalize_ocr_digits("G h"), "6 h");
        assert_eq!(normalize_ocr_digits("b h"), "6 h");
        assert_eq!(normalize_ocr_digits("3G m"), "36 m");
    }

    // Parity: B before unit → 8
    #[test]
    fn parity_normalize_b_to_8() {
        assert_eq!(normalize_ocr_digits("B h"), "8 h");
        assert_eq!(normalize_ocr_digits("3B m"), "38 m");
    }

    // Parity: S before digit → 5 (RE_5_BEFORE_DIGIT covers digit-after-S context)
    #[test]
    fn parity_normalize_s_before_digit() {
        assert_eq!(normalize_ocr_digits("S5"), "55");
        assert_eq!(normalize_ocr_digits("S3"), "53");
    }

    // Parity: 's' unit itself must NOT be corrupted — only capital S before h/m is normalized.
    // Canvas RE_5_BEFORE_UNIT only covers [hm], not 's'. "30s" has no capital S → unchanged.
    #[test]
    fn parity_normalize_s_unit_unchanged() {
        assert_eq!(normalize_ocr_digits("30s"), "30s");
        assert_eq!(normalize_ocr_digits("5m 30s"), "5m 30s");
    }

    // Parity: g, q before unit → 9
    #[test]
    fn parity_normalize_g_q_to_9() {
        assert_eq!(normalize_ocr_digits("g h"), "9 h");
        assert_eq!(normalize_ocr_digits("q m"), "9 m");
        assert_eq!(normalize_ocr_digits("1g h"), "19 h");
    }

    // Parity: Z before unit → 2
    #[test]
    fn parity_normalize_z_to_2() {
        assert_eq!(normalize_ocr_digits("Z h"), "2 h");
        assert_eq!(normalize_ocr_digits("3Z m"), "32 m");
    }

    // The 7 in a printed total is a bare diagonal with a thin top bar. When the bar
    // fades, leptess returns the stroke alone (`2/m`); when it is read as its own
    // glyph, the digit is doubled (`2/7m`). Both are the same 27.
    #[test]
    fn a_slash_where_a_seven_belongs_is_a_seven() {
        assert_eq!(extract_time_from_text("8h 2/m"), "8h 27m");
        assert_eq!(extract_time_from_text("8h 2/7m"), "8h 27m");
    }

    // A slash with no digit beside it is a real slash. Rewriting it as a 7
    // invents a duration on a row that never carried one.
    #[test]
    fn a_slash_without_a_digit_beside_it_is_not_a_seven() {
        assert_eq!(normalize_ocr_digits("km/h"), "km/h");
        assert_eq!(extract_time_from_text("km/h"), "");
        assert_eq!(extract_time_from_text("w/ m"), "");
    }

    /// Six shipped language packs print the hour as `h`, so the letter beside the
    /// stroke is often outside ASCII. Excluding `[A-Za-z]` read all of these as
    /// seven hours; naming the legal left contexts does not.
    #[test]
    fn a_slash_after_a_non_ascii_letter_is_also_a_real_slash() {
        assert_eq!(normalize_ocr_digits("é/h 15m"), "é/h 15m");
        assert_eq!(normalize_ocr_digits("Км/h"), "Км/h");
    }

    /// A stray mark or a lost space beside a faded 7 is the normal case, not a
    /// reason to refuse it. Naming the legal left contexts rejected all of these
    /// and dropped seven hours from each.
    #[test]
    fn a_speck_beside_the_stroke_does_not_disqualify_it() {
        for prefix in [".", ":", ")", "'", "·", ","] {
            assert_eq!(
                extract_time_from_text(&format!("{prefix}/h 15m")),
                "7h 15m",
                "prefix {prefix}"
            );
        }
    }

    /// The unit has to sit flush against the stroke; a slash belonging to nothing
    /// is not a seven.
    #[test]
    fn a_free_standing_slash_is_not_a_seven() {
        assert_eq!(extract_time_from_text("5 / h"), "");
    }

    /// `8h 4/5m` is `8h 45m`. Left un-collapsed the leading digit is DROPPED —
    /// `Xh Y` reads `8h 4` and reports a total 41 minutes short.
    #[test]
    fn a_stroke_splitting_the_minutes_is_repaired_not_truncated() {
        assert_eq!(extract_time_from_text("8h 4/5m"), "8h 45m");
        assert_eq!(extract_time_from_text("8h 1/5m"), "8h 15m");
        // ...but with no hour to its left it is a fraction, not a split digit.
        assert_eq!(extract_time_from_text("1/2 h"), "2h");
    }

    /// A confused glyph is the FIRST character of its token. A letter with another
    /// letter before it is just a word — and every one of these was being read as
    /// a duration, `Settings` loudest of all, since it is the back-chevron label on
    /// any capture reached through the Settings app and sits in the header band the
    /// fallback readers scan.
    #[test]
    fn a_letter_inside_a_word_is_not_a_misread_digit() {
        for word in [
            "Settings", "Songs", "Tabs", "Jobs", "High", "Although", "Film", "Anselm", "Meetings",
            "USBs", "Enough", "Maps", "Photos",
        ] {
            assert_eq!(normalize_ocr_digits(word), word, "{word}");
            assert_eq!(extract_time_from_text(word), "", "{word}");
        }
    }

    /// ...but the glyph at the start of its token still is one, and a speck or a
    /// lost space beside it must not disqualify it — refusing those drops the hour
    /// and reports the minutes alone.
    #[test]
    fn a_confused_glyph_starting_its_token_is_still_a_digit() {
        assert_eq!(extract_time_from_text("Sh 16m"), "5h 16m");
        assert_eq!(extract_time_from_text("gh 4m"), "9h 4m");
        assert_eq!(extract_time_from_text("Bh"), "8h");
        assert_eq!(extract_time_from_text(".Sh 15m"), "5h 15m");
        assert_eq!(extract_time_from_text(":Bh 14m"), "8h 14m");
        assert_eq!(extract_time_from_text("'gh 4m"), "9h 4m");
    }

    /// A day cannot hold more than 24 hours, so an hours figure above that is
    /// not a reading — it is damage. This matters because the page-wide total
    /// takes the LARGEST time on the frame and the digit-repair passes can turn
    /// a garbage word into a large hour value: `Screen Time Agh` normalizes to
    /// `Screen Time 49h` (the `g`->`9` rule fires first, then the chain takes
    /// the `A`), which would outrank the real header row. An inflated total is
    /// also the one direction the bars cannot refute — they may only undershoot
    /// what is printed — so it has to be rejected here.
    #[test]
    fn an_impossible_hour_is_skipped_and_the_search_continues() {
        // The impossible candidate is passed over, not fatal: the real reading
        // later in the same text still wins.
        assert_eq!(extract_time_from_text("Screen Time Agh 5h 41m"), "5h 41m");
        assert_eq!(extract_time_from_text("Mail BTh today 2h"), "2h");
        // With nothing plausible left, the tier yields rather than inventing one.
        assert_eq!(extract_time_from_text("Screen Time Agh"), "");
        // 24h itself is attainable and stays.
        assert_eq!(extract_time_from_text("24h"), "24h");
        assert_eq!(extract_time_from_text("24h 0m"), "24h 0m");
        assert_eq!(extract_time_from_text("25h"), "");
    }

    /// Confusions arrive in pairs, and each rule repairs only the glyph it names.
    /// A guard that demands a non-letter immediately to the left therefore makes the
    /// SECOND repair unreachable and halves the reading: `SOm` needs `O`->`0` before
    /// `S`->`5` can see a digit, but `S` is the letter standing to the `O`'s left.
    /// Letting the guard skip a run of *confusable* letters is what keeps a chain
    /// whole — while `USBs` and `Settings`, which have a plain letter before the
    /// glyph, stay words.
    #[test]
    fn a_chain_of_confusions_is_repaired_end_to_end() {
        assert_eq!(normalize_ocr_digits("SOm"), "50m");
        assert_eq!(normalize_ocr_digits("SOh"), "50h");
        assert_eq!(normalize_ocr_digits("SOs"), "50s");
        // Glyph repair is the normalizer's job and it does the whole chain; the
        // EXTRACTOR then refuses the result, because no day holds 50 hours, and
        // reports the part that is possible. Splitting the assertion this way is
        // the point: a repaired chain is not automatically a reading.
        assert_eq!(normalize_ocr_digits("SOh 15m"), "50h 15m");
        assert_eq!(extract_time_from_text("SOh 15m"), "15m");
        assert_eq!(extract_time_from_text("2h SOm"), "2h 50m");
        // The run admits confusables only; a plain letter still ends the chain.
        assert_eq!(normalize_ocr_digits("USBs"), "USBs");
        assert_eq!(normalize_ocr_digits("Settings"), "Settings");

        // The LEADING glyph of a pair: visited before its partner became a digit,
        // it needs the deferred chain pass. Without it these shipped as `0m` — a
        // confident wrong number that suppressed the empty-total re-read.
        assert_eq!(normalize_ocr_digits("IOm"), "10m");
        assert_eq!(normalize_ocr_digits("BOm"), "80m");
        assert_eq!(normalize_ocr_digits("TOm"), "70m");
        assert_eq!(normalize_ocr_digits("ZOm"), "20m");
        assert_eq!(normalize_ocr_digits("lSm"), "15m");
        assert_eq!(extract_time_from_text("IOh 3lm"), "10h 31m");
        // Iterated: each round exposes the next glyph of a longer chain.
        assert_eq!(normalize_ocr_digits("lIOm"), "110m");
        // The unit anchor is the safety: no unit, no rewrite.
        assert_eq!(normalize_ocr_digits("B12"), "B12");
        assert_eq!(normalize_ocr_digits("A4"), "A4");
        assert_eq!(normalize_ocr_digits("Z3"), "Z3");
        assert_eq!(normalize_ocr_digits("T20"), "T20");
    }

    /// `shared/ocr_patterns.json` is the declared source of truth for these rules,
    /// but its vectors were only ever asserted against the Python mirror. Rust is
    /// what the WASM app and the PyO3 wheel actually run, so the declaration has to
    /// bind THIS implementation or it is documentation, not a contract.
    #[test]
    fn the_declared_vectors_hold_against_this_implementation() {
        let raw = include_str!("../../../shared/ocr_patterns.json");
        let doc: serde_json::Value = serde_json::from_str(raw).expect("ocr_patterns.json parses");
        let vectors = &doc["test_vectors"];

        let normalize = vectors["normalize_ocr_digits"]
            .as_array()
            .expect("normalize_ocr_digits vectors");
        assert!(normalize.len() >= 10, "vector set went missing");
        for pair in normalize {
            let input = pair[0].as_str().expect("input");
            let expected = pair[1].as_str().expect("expected");
            assert_eq!(normalize_ocr_digits(input), expected, "normalize {input:?}");
        }

        let extract = vectors["extract_time_from_text"]
            .as_array()
            .expect("extract_time_from_text vectors");
        assert!(extract.len() >= 10, "vector set went missing");
        for pair in extract {
            let input = pair[0].as_str().expect("input");
            let expected = pair[1].as_str().expect("expected");
            assert_eq!(extract_time_from_text(input), expected, "extract {input:?}");
        }
    }

    /// These rules live inside a `#[cfg(feature = "ocr")]` function, so before
    /// they were split out NOTHING on the host compiled them, let alone ran them.
    #[test]
    fn a_re_read_is_believed_only_when_it_completes_the_page_reading() {
        use HourEvidence::{BareHours, Minutes, WholeHours};

        // The minutes the page read are the anchor; the hour comes back with them.
        assert_eq!(
            accept_row_reading("5h 41m", Minutes(41)).as_deref(),
            Some("5h 41m")
        );
        // A caption on the row does not disturb that.
        assert_eq!(
            accept_row_reading("SCREEN TIME 5h 41m DAILY AVERAGE", Minutes(41)).as_deref(),
            Some("5h 41m")
        );
        // Different minutes: a different row, or a different reading. Declined.
        assert_eq!(accept_row_reading("5h 42m", Minutes(41)), None);

        // A bare `Nh` re-read must stay bare for the BareHours evidence.
        assert_eq!(accept_row_reading("8h", BareHours).as_deref(), Some("8h"));
        assert_eq!(accept_row_reading("8h 15m", BareHours), None);

        // The page read `5h`; minutes standing beside it complete the total.
        assert_eq!(
            accept_row_reading("5h 41m", WholeHours(5)).as_deref(),
            Some("5h 41m")
        );
        // An echo of the bare hour ends the search without improving anything.
        assert_eq!(accept_row_reading("5h", WholeHours(5)), None);
        // A re-read disagreeing about the hour is a different row.
        assert_eq!(accept_row_reading("6h 41m", WholeHours(5)), None);
    }

    /// The duration adopted has to be the FIRST one on the row. A neighbour's
    /// value is a fully-formed, plausible total that was never the day's.
    #[test]
    fn a_duration_that_is_not_the_rows_first_is_declined() {
        use HourEvidence::WholeHours;

        assert_eq!(
            accept_row_reading("8h Daily Average 8h 45m", WholeHours(8)),
            None
        );
        assert_eq!(
            accept_row_reading("SCREEN TIME DAILY AVERAGE 5h 5h 23m", WholeHours(5)),
            None
        );
        // ...but a second duration further right does not condemn the first.
        assert_eq!(
            accept_row_reading("4h 30m 1h 12m", WholeHours(4)).as_deref(),
            Some("4h 30m")
        );
        // ...and the judgement must not turn on whether Tesseract left a space.
        assert_eq!(
            accept_row_reading("4h30m 1h 12m", WholeHours(4)).as_deref(),
            Some("4h 30m")
        );
    }

    /// Agreeing with the page is not proof: re-reading the same pixels reproduces
    /// a misread more often than it corrects one.
    #[test]
    fn minutes_outside_the_clock_are_declined_even_when_both_readings_agree() {
        use HourEvidence::{Minutes, WholeHours};

        assert_eq!(accept_row_reading("9h 75m", Minutes(75)), None);
        assert_eq!(accept_row_reading("9h 60m", Minutes(60)), None);
        assert_eq!(accept_row_reading("9h 75m", WholeHours(9)), None);
        // An hour outside the day is declined on every evidence.
        assert_eq!(accept_row_reading("25h 30m", Minutes(30)), None);
    }

    /// A candidate carrying a trailing unit is skipped and the search CONTINUES.
    #[test]
    fn a_disqualified_bare_number_does_not_abandon_the_search() {
        assert_eq!(extract_time_from_text("5h 30s"), "5h");
        assert_eq!(extract_time_from_text("5h 30"), "5h 30m");
    }

    /// A trailing unit disqualifies the whole number. Python used a lookahead
    /// here, which backtracks to a shorter number instead of giving up and
    /// reported `5h 3m` for `5h 30s`; both sides now reject on the captured group.
    #[test]
    fn a_bare_number_carrying_a_trailing_unit_is_rejected_whole() {
        assert_eq!(extract_time_from_text("5h 30"), "5h 30m");
        assert_eq!(extract_time_from_text("5h 30s"), "5h");
        assert_eq!(extract_time_from_text("8h 15s"), "8h");
        assert_eq!(extract_time_from_text("12h 30s"), "12h");
    }

    // ...but a slash with nothing alphabetic to its left IS the 7 whose top bar
    // faded, and the hours digit of a header total has nothing to its left.
    #[test]
    fn a_leading_slash_is_still_a_seven() {
        assert_eq!(extract_time_from_text("/h 15m"), "7h 15m");
        assert_eq!(extract_time_from_text("8h /m"), "8h 7m");
    }

    // `1/2 h` is a fraction, not a twelve-hour day: only a doubled *seven*
    // collapses across the stroke.
    #[test]
    fn a_fraction_is_not_a_two_digit_hour() {
        assert_eq!(normalize_ocr_digits("1/2 h"), "1/2 h");
        assert_eq!(normalize_ocr_digits("3/4h"), "3/4h");
        assert_eq!(normalize_ocr_digits("9/11m"), "9/11m");
    }

    // A slash that is not part of a duration is left alone — a date is not a time.
    #[test]
    fn a_slash_between_plain_numbers_is_left_alone() {
        assert_eq!(normalize_ocr_digits("4/23"), "4/23");
    }

    // Parity: "Xh Y h" and "Xh Y s" must fall through RE_HOUR_MIN_NO_M (group 3 present)
    // and match RE_HOURS_ONLY → return "Xh".
    // Canvas: same pattern — trailing unit after digit means it's not a bare minute count.
    #[test]
    fn parity_extract_time_rejects_ambiguous_hour_digit_with_unit() {
        assert_eq!(
            extract_time_from_text("4h 36 h"),
            "4h",
            "'4h 36 h' — trailing 'h' makes group3 present → skip Xh Y path → hours only"
        );
        assert_eq!(
            extract_time_from_text("4h 36 s"),
            "4h",
            "'4h 36 s' — trailing 's' makes group3 present → skip Xh Y path → hours only"
        );
    }

    // Parity: "Xm Os" — 'O' in seconds position normalized to '0'.
    // Canvas: replaces 'O' with '0'; parses as integer → no leading-zero padding.
    #[test]
    fn parity_extract_time_min_sec_o_as_zero() {
        assert_eq!(extract_time_from_text("5m Os"), "5m 0s");
        // "12m O5s" → normalize O→0 → "12m 05s" → parse 05 as u32=5 → "12m 5s"
        assert_eq!(extract_time_from_text("12m O5s"), "12m 5s");
    }

    // Parity: is_daily_total_page uses daily_count > app_count (strictly greater).
    // A tie (equal counts) → false.
    #[test]
    fn parity_is_daily_total_page_tie_returns_false() {
        let texts: Vec<String> = vec![
            "TODAY".to_string(), // daily marker
            "DAILY".to_string(), // app marker
        ];
        assert!(
            !is_daily_total_page(&texts),
            "tied daily vs app count must return false"
        );
    }

    // Parity: is_daily_total_page ignores case (uses to_uppercase internally).
    #[test]
    fn parity_is_daily_total_page_case_insensitive() {
        let texts: Vec<String> = vec!["Most".to_string(), "Used".to_string(), "today".to_string()];
        assert!(
            is_daily_total_page(&texts),
            "lowercase markers must still match via to_uppercase"
        );
    }

    #[test]
    fn all_devices_signal_detects_explicit_text() {
        let words = vec![
            OcrWord {
                text: "All".into(),
                x: 40,
                y: 100,
                w: 30,
                h: 12,
            },
            OcrWord {
                text: "Devices⌄".into(),
                x: 75,
                y: 100,
                w: 55,
                h: 12,
            },
        ];
        let result = detect_all_devices_signals(&words, 400, 800, None);
        assert!(result.suspected);
        assert!(
            result
                .reasons
                .iter()
                .any(|reason| reason.contains("All Devices"))
        );
    }

    #[test]
    fn all_devices_signal_detects_two_hour_chart_axis() {
        let bounds = crate::types::GridBounds::new(40, 180, 340, 360);
        let words = vec![
            OcrWord {
                text: "2".into(),
                x: 350,
                y: 175,
                w: 10,
                h: 12,
            },
            OcrWord {
                text: "hr".into(),
                x: 363,
                y: 175,
                w: 18,
                h: 12,
            },
        ];
        let result = detect_all_devices_signals(&words, 400, 800, Some(&bounds));
        assert!(result.suspected);
        assert_eq!(result.axis_max_minutes, Some(120));
    }

    #[test]
    fn all_devices_signal_omits_the_ordinary_one_hour_axis() {
        let bounds = crate::types::GridBounds::new(40, 180, 340, 360);
        let words = vec![OcrWord {
            text: "1h".into(),
            x: 350,
            y: 175,
            w: 24,
            h: 12,
        }];
        let result = detect_all_devices_signals(&words, 400, 800, Some(&bounds));
        assert!(!result.suspected);
        assert_eq!(result.axis_max_minutes, None);
    }

    #[test]
    fn all_devices_axis_parser_handles_mixed_fractional_and_ocr_confused_hours() {
        assert_eq!(parse_axis_minutes("1h 30m"), Some(90));
        assert_eq!(parse_axis_minutes("1.5 hr"), Some(90));
        assert_eq!(parse_axis_minutes("Z hr"), Some(120));
        assert_eq!(parse_axis_minutes("120 min"), Some(120));
        assert_eq!(parse_axis_minutes("2 hours"), Some(120));
        assert_eq!(parse_axis_minutes("daily 1.5h total"), None);
    }

    #[test]
    fn all_devices_signal_does_not_join_distant_words() {
        let words = vec![
            OcrWord {
                text: "All".into(),
                x: 20,
                y: 80,
                w: 20,
                h: 12,
            },
            OcrWord {
                text: "Devices".into(),
                x: 300,
                y: 180,
                w: 55,
                h: 12,
            },
        ];
        let result = detect_all_devices_signals(&words, 400, 800, None);
        assert!(!result.suspected);
    }

    #[test]
    fn all_devices_signal_ignores_selector_text_below_chart_top() {
        let bounds = crate::types::GridBounds::new(40, 180, 340, 360);
        let words = vec![OcrWord {
            text: "All Devices".into(),
            x: 40,
            y: 250,
            w: 90,
            h: 12,
        }];
        let result = detect_all_devices_signals(&words, 400, 800, Some(&bounds));
        assert!(!result.suspected);
    }

    #[test]
    fn all_devices_signal_detects_four_word_mixed_axis_label() {
        let bounds = crate::types::GridBounds::new(40, 180, 340, 360);
        let words = ["1", "hr", "30", "min"]
            .iter()
            .enumerate()
            .map(|(index, text)| OcrWord {
                text: (*text).into(),
                x: 345 + index as i32 * 14,
                y: 175,
                w: 12,
                h: 12,
            })
            .collect::<Vec<_>>();
        let result = detect_all_devices_signals(&words, 420, 800, Some(&bounds));
        assert!(result.suspected);
        assert_eq!(result.axis_max_minutes, Some(90));
    }

    #[test]
    fn all_devices_signal_ignores_large_total_left_of_chart() {
        let bounds = crate::types::GridBounds::new(40, 180, 340, 360);
        let words = vec![OcrWord {
            text: "4h".into(),
            x: 25,
            y: 80,
            w: 28,
            h: 16,
        }];
        let result = detect_all_devices_signals(&words, 400, 800, Some(&bounds));
        assert!(!result.suspected);
        assert_eq!(result.axis_max_minutes, None);
    }
}
