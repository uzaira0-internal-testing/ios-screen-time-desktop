//! Per-hour bar fill ratios measured straight off the cropped graph.
//!
//! The annotation view flags bars whose visible height disagrees with the
//! stored value (`barConfidence.ts`). The measurement used to run on a browser
//! canvas, so Chromium, WebKit and WebView2 each resampled the crop their own
//! way and could disagree about which bars to flag. It runs here instead, so
//! every engine gets the same 24 ratios.
//!
//! The shrink to 240x120 reproduces what Chromium's canvas `drawImage` did at
//! the default `imageSmoothingQuality` (Skia linear filtering from the nearest
//! mip level below the shrink factor). Over the 36 fixtures in
//! `tests/fixtures/images` with a detected grid, 815 of 864 columns match the
//! headless-Chromium canvas exactly, none differ by more than 2 of 120 rows,
//! and no review flag changes. A plain bilinear shrink matched 152 columns and
//! a box (area) average 190.

use image::RgbImage;

/// Downscaled sampling size: 10 px per hour column.
pub const FILL_SAMPLE_W: u32 = 240;
pub const FILL_SAMPLE_H: u32 = 120;

/// Colour distance (Euclidean RGB) above which a pixel counts as "bar" rather
/// than background. Measured on 140 participant captures with accurate grids:
/// the dark-mode "Other" category segment is rgb(58,58,59) on a rgb(32,31,31)
/// background — distance ≈ 46 — so 48 read every gray segment as empty and
/// under-measured correct bars by 10-25 minutes. Below ~30 the downscaled
/// gridlines start to count as bar (flags rise again at 28). 32 sits in the
/// flat minimum.
const BAR_COLOUR_DIST: f64 = 32.0;

/// Fill ratios (0..1) for the 24 hourly columns of the `w` x `h` graph at
/// `x,y` in an RGBA image. A crop that overhangs the image is clipped to it.
/// `None` when the crop is empty or falls outside the image, or the buffer
/// does not match `width` x `height`.
pub fn column_fills_rgba(
    rgba: &[u8],
    width: u32,
    height: u32,
    x: i32,
    y: i32,
    w: i32,
    h: i32,
) -> Option<[f64; 24]> {
    if width == 0 || height == 0 || rgba.len() != (width as usize) * (height as usize) * 4 {
        return None;
    }
    let x0 = x.max(0);
    let y0 = y.max(0);
    let x1 = x.saturating_add(w).min(width as i32);
    let y1 = y.saturating_add(h).min(height as i32);
    if x1 <= x0 || y1 <= y0 {
        return None;
    }
    let image = RgbImage::from_fn(width, height, |px, py| {
        let o = ((py * width + px) * 4) as usize;
        image::Rgb([rgba[o], rgba[o + 1], rgba[o + 2]])
    });
    let small = shrink(
        image,
        x0 as u32,
        y0 as u32,
        (x1 - x0) as u32,
        (y1 - y0) as u32,
    );
    Some(fills_from_pixels(&small))
}

/// Mip level Skia samples from: the shrink factor's log2 on the less-shrunk
/// axis, rounded down (round-to-nearest after Skia's -0.5 sharpening bias).
fn mip_level(cw: u32, ch: u32) -> u32 {
    let scale = (cw as f64 / FILL_SAMPLE_W as f64).min(ch as f64 / FILL_SAMPLE_H as f64);
    if scale <= 1.0 {
        0
    } else {
        scale.log2().floor() as u32
    }
}

/// One Skia mip step: halve each dimension (floor), with a 1-1 box on an even
/// source axis and 1-2-1 on an odd one, integer sums truncated.
fn mip_down(src: &RgbImage) -> RgbImage {
    let (sw, sh) = (src.width(), src.height());
    let taps = |len: u32| -> &'static [(u32, u32)] {
        if len > 1 && len % 2 == 1 {
            &[(0, 1), (1, 2), (2, 1)]
        } else {
            &[(0, 1), (1, 1)]
        }
    };
    let (tx, ty) = (taps(sw), taps(sh));
    let norm: u32 = tx.iter().map(|t| t.1).sum::<u32>() * ty.iter().map(|t| t.1).sum::<u32>();
    RgbImage::from_fn((sw / 2).max(1), (sh / 2).max(1), |ox, oy| {
        let mut acc = [0u32; 3];
        for &(dy, wy) in ty {
            for &(dx, wx) in tx {
                let p = src
                    .get_pixel((2 * ox + dx).min(sw - 1), (2 * oy + dy).min(sh - 1))
                    .0;
                for (a, v) in acc.iter_mut().zip(p) {
                    *a += v as u32 * wx * wy;
                }
            }
        }
        image::Rgb(acc.map(|a| (a / norm) as u8))
    })
}

/// Shrink the `cw` x `ch` crop at `x0,y0` to `FILL_SAMPLE_W` x `FILL_SAMPLE_H`:
/// build the whole image's mip pyramid down to `mip_level`, then sample each
/// output pixel centre bilinearly from that level.
fn shrink(mut image: RgbImage, x0: u32, y0: u32, cw: u32, ch: u32) -> RgbImage {
    let (full_w, full_h) = (image.width() as f64, image.height() as f64);
    for _ in 0..mip_level(cw, ch) {
        image = mip_down(&image);
    }
    let (lw, lh) = (image.width(), image.height());
    let kx = lw as f64 / full_w;
    let ky = lh as f64 / full_h;
    let sx = cw as f64 / FILL_SAMPLE_W as f64;
    let sy = ch as f64 / FILL_SAMPLE_H as f64;
    RgbImage::from_fn(FILL_SAMPLE_W, FILL_SAMPLE_H, |ox, oy| {
        let u = (((ox as f64 + 0.5) * sx + x0 as f64) * kx - 0.5).clamp(0.0, (lw - 1) as f64);
        let v = (((oy as f64 + 0.5) * sy + y0 as f64) * ky - 0.5).clamp(0.0, (lh - 1) as f64);
        let (ax, ay) = (u.floor() as u32, v.floor() as u32);
        let (bx, by) = ((ax + 1).min(lw - 1), (ay + 1).min(lh - 1));
        let (fx, fy) = (u - ax as f64, v - ay as f64);
        let (p00, p10) = (image.get_pixel(ax, ay).0, image.get_pixel(bx, ay).0);
        let (p01, p11) = (image.get_pixel(ax, by).0, image.get_pixel(bx, by).0);
        image::Rgb(std::array::from_fn(|c| {
            let top = p00[c] as f64 + (p10[c] as f64 - p00[c] as f64) * fx;
            let bottom = p01[c] as f64 + (p11[c] as f64 - p01[c] as f64) * fx;
            (top + (bottom - top) * fy).round() as u8
        }))
    })
}

fn median(values: &mut [f64]) -> f64 {
    values.sort_by(|a, b| a.total_cmp(b));
    let m = values.len() / 2;
    if values.len() % 2 == 1 {
        values[m]
    } else {
        (values[m - 1] + values[m]) / 2.0
    }
}

/// Fill ratios from an already-downscaled graph.
///
/// Background reference = per-channel median of the inter-bar gutters (the
/// outermost pixel on each side of every hour column) over the top 10% strip.
/// iOS bars span ~58% of their column, centred, so the gutters are background
/// however many bars reach the 60 line — a mean or median over the whole strip
/// is pulled to the bar colour on a busy day (15+ full bars), after which every
/// empty row reads as filled. The few gutter pixels a gridline touches are a
/// minority the median ignores.
pub fn fills_from_pixels(img: &RgbImage) -> [f64; 24] {
    let (w, h) = (img.width(), img.height());
    let col_w = w as f64 / 24.0;
    let bg_rows = ((h as f64 * 0.1).round() as u32).max(2).min(h);
    let (mut rs, mut gs, mut bs) = (Vec::new(), Vec::new(), Vec::new());
    for y in 0..bg_rows {
        for i in 0..24 {
            for x in [
                (i as f64 * col_w).floor() as u32,
                (((i + 1) as f64 * col_w).ceil() as u32).saturating_sub(1),
            ] {
                let p = img.get_pixel(x.min(w - 1), y).0;
                rs.push(p[0] as f64);
                gs.push(p[1] as f64);
                bs.push(p[2] as f64);
            }
        }
    }
    let (br, bg, bb) = (median(&mut rs), median(&mut gs), median(&mut bs));

    let mut fills = [0.0; 24];
    for (i, fill) in fills.iter_mut().enumerate() {
        // Sample the centre 50% of the column to avoid inter-bar gridlines.
        let x0 = (i as f64 * col_w + col_w * 0.25).floor() as u32;
        let x1 = (x0 + 1).max((i as f64 * col_w + col_w * 0.75).ceil() as u32);
        let mut filled = 0u32;
        for y in 0..h {
            let (mut r, mut g, mut b, mut cnt) = (0.0, 0.0, 0.0, 0.0);
            for x in x0..x1.min(w) {
                let p = img.get_pixel(x, y).0;
                r += p[0] as f64;
                g += p[1] as f64;
                b += p[2] as f64;
                cnt += 1.0;
            }
            if cnt == 0.0 {
                continue;
            }
            let dist =
                ((r / cnt - br).powi(2) + (g / cnt - bg).powi(2) + (b / cnt - bb).powi(2)).sqrt();
            if dist > BAR_COLOUR_DIST {
                filled += 1;
            }
        }
        *fill = filled as f64 / h as f64;
    }
    fills
}

#[cfg(test)]
mod tests {
    use super::*;

    const BG: [u8; 3] = [255, 255, 255];
    const BAR: [u8; 3] = [0, 122, 255];

    /// A 240x120 graph where hour `i` has a centred bar `heights[i]` rows tall.
    fn graph(heights: &[u32; 24], bg: [u8; 3], bar: [u8; 3]) -> RgbImage {
        RgbImage::from_fn(FILL_SAMPLE_W, FILL_SAMPLE_H, |x, y| {
            let i = (x / 10) as usize;
            let in_bar = (x % 10) >= 2 && (x % 10) < 8 && y >= FILL_SAMPLE_H - heights[i];
            image::Rgb(if in_bar { bar } else { bg })
        })
    }

    /// `graph` scaled up `k` times (nearest) and placed at `ox,oy` on a
    /// background-coloured `width` x `height` RGBA canvas.
    fn placed(graph: &RgbImage, k: u32, ox: u32, oy: u32, width: u32, height: u32) -> Vec<u8> {
        let bg = graph.get_pixel(0, 0).0;
        let mut rgba = Vec::with_capacity((width * height * 4) as usize);
        for y in 0..height {
            for x in 0..width {
                let inside =
                    x >= ox && y >= oy && x < ox + graph.width() * k && y < oy + graph.height() * k;
                let p = if inside {
                    graph.get_pixel((x - ox) / k, (y - oy) / k).0
                } else {
                    bg
                };
                rgba.extend_from_slice(&[p[0], p[1], p[2], 255]);
            }
        }
        rgba
    }

    #[test]
    fn empty_graph_reads_zero() {
        assert_eq!(fills_from_pixels(&graph(&[0; 24], BG, BAR)), [0.0; 24]);
    }

    #[test]
    fn bar_heights_read_back_as_ratios() {
        let mut heights = [0u32; 24];
        heights[3] = 60;
        heights[12] = 120;
        heights[20] = 30;
        let fills = fills_from_pixels(&graph(&heights, BG, BAR));
        assert_eq!(fills[3], 0.5);
        assert_eq!(fills[12], 1.0);
        assert_eq!(fills[20], 0.25);
        assert_eq!(fills[0], 0.0);
    }

    #[test]
    fn busy_day_keeps_the_gutter_background() {
        // 20 bars reach the top: a whole-strip median would pick the bar colour
        // and read every empty row as filled. The gutters stay background.
        let mut heights = [120u32; 24];
        heights[..4].copy_from_slice(&[0, 0, 0, 0]);
        let fills = fills_from_pixels(&graph(&heights, BG, BAR));
        assert_eq!(&fills[..4], &[0.0; 4]);
        assert!(fills[4..].iter().all(|&f| f == 1.0));
    }

    #[test]
    fn every_bar_full_still_reads_full() {
        // Bar pixels are the majority of the top strip, so any whole-strip
        // statistic would pick the bar colour and read every full bar as empty.
        let fills = fills_from_pixels(&graph(&[120; 24], BG, BAR));
        assert_eq!(fills, [1.0; 24]);
    }

    #[test]
    fn dark_mode_gray_segment_counts_as_bar() {
        // rgb(58,58,59) on rgb(32,31,31) is ~46 apart: above the 32 threshold.
        let mut heights = [0u32; 24];
        heights[8] = 90;
        let fills = fills_from_pixels(&graph(&heights, [32, 31, 31], [58, 58, 59]));
        assert_eq!(fills[8], 0.75);
    }

    #[test]
    fn mip_level_rounds_the_shorter_shrink_down() {
        assert_eq!(mip_level(240, 120), 0);
        assert_eq!(mip_level(638, 180), 0); // y shrinks 1.5x
        assert_eq!(mip_level(891, 270), 1); // y shrinks 2.25x
        assert_eq!(mip_level(2400, 1200), 3);
        assert_eq!(mip_level(100, 50), 0);
    }

    #[test]
    fn mip_down_box_filters_even_and_odd_axes() {
        // Even width: plain 2x2 average, truncated.
        let even = RgbImage::from_fn(2, 2, |x, y| image::Rgb([(x + 2 * y) as u8 * 10 + 1; 3]));
        assert_eq!(mip_down(&even).get_pixel(0, 0).0, [16; 3]); // (1+11+21+31)/4 = 16
        // Odd width and height: 1-2-1 taps on both axes.
        let odd = RgbImage::from_fn(3, 3, |x, y| {
            image::Rgb([if x == 1 && y == 1 { 160 } else { 0 }; 3])
        });
        let down = mip_down(&odd);
        assert_eq!((down.width(), down.height()), (1, 1));
        assert_eq!(down.get_pixel(0, 0).0, [40; 3]); // 160 * 4 / 16
    }

    #[test]
    fn crop_outside_the_image_is_unmeasurable() {
        let rgba = vec![255u8; 100 * 100 * 4];
        assert!(column_fills_rgba(&rgba, 100, 100, 200, 0, 50, 50).is_none());
        assert!(column_fills_rgba(&rgba, 100, 100, 0, 0, 0, 50).is_none());
        assert!(column_fills_rgba(&rgba, 100, 99, 0, 0, 50, 50).is_none());
        assert!(column_fills_rgba(&[], 0, 0, 0, 0, 50, 50).is_none());
    }

    #[test]
    fn upscaled_graph_at_an_offset_measures_the_same() {
        let mut heights = [0u32; 24];
        heights[5] = 60;
        heights[17] = 96;
        let small = graph(&heights, BG, BAR);
        // 10x up (mip level 3), offset so the crop is not pyramid-aligned.
        let rgba = placed(&small, 10, 37, 51, 2500, 1300);
        let fills = column_fills_rgba(&rgba, 2500, 1300, 37, 51, 2400, 1200).unwrap();
        assert!((fills[5] - 0.5).abs() <= 2.0 / 120.0, "{}", fills[5]);
        assert!((fills[17] - 0.8).abs() <= 2.0 / 120.0, "{}", fills[17]);
        assert_eq!(fills[0], 0.0);
    }

    #[test]
    fn same_size_crop_reads_exactly() {
        let mut heights = [0u32; 24];
        heights[9] = 42;
        let small = graph(&heights, [32, 31, 31], [58, 58, 59]);
        let rgba = placed(&small, 1, 0, 0, 240, 120);
        let fills = column_fills_rgba(&rgba, 240, 120, 0, 0, 240, 120).unwrap();
        assert_eq!(fills, fills_from_pixels(&small));
        assert_eq!(fills[9], 42.0 / 120.0);
    }
}
