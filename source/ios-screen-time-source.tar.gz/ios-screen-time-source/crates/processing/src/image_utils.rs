//! Image utility functions — Rust port of Python image_utils.py.
//!
//! All functions operate on `image::RgbImage` (RGB format).
//! Python/OpenCV uses BGR; we convert at load boundaries only.
//!
//! Optimizations: raw buffer access, fused passes, LUT-based transforms,
//! sampling for large-image pixel statistics.

use std::{
    collections::{HashMap, hash_map::Entry},
    hash::{BuildHasherDefault, Hasher},
};

#[cfg(test)]
use image::Rgb;
use image::RgbImage;

/// Hasher for a packed 24-bit colour key (`get_pixel`'s index): one multiply,
/// with the high bits folded down so the table's low-bit bucket index mixes all
/// three channels.
#[derive(Default)]
struct ColourHasher(u64);

impl Hasher for ColourHasher {
    fn finish(&self) -> u64 {
        self.0 ^ (self.0 >> 32)
    }
    fn write(&mut self, _: &[u8]) {
        unreachable!("ColourHasher only hashes u32 keys")
    }
    fn write_u32(&mut self, v: u32) {
        self.0 = u64::from(v).wrapping_mul(0x9E37_79B9_7F4A_7C15);
    }
}

use crate::generated_constants::{
    DARK_MODE_THRESHOLD, DARKEN_NON_WHITE_LUMA_COEFFS, DARKEN_NON_WHITE_LUMA_SHIFT,
    DARKEN_NON_WHITE_LUMA_THRESHOLD,
};

/// Convert an RGBA boundary buffer into the RGB representation used by the
/// processing core. All WASM front ends share this checked length contract so
/// large dimensions cannot overflow before validation.
pub fn rgba_to_rgb_image(rgba: &[u8], width: u32, height: u32) -> Option<RgbImage> {
    let pixels = (width as usize).checked_mul(height as usize)?;
    let expected_rgba = pixels.checked_mul(4)?;
    if rgba.len() != expected_rgba {
        return None;
    }
    let expected_rgb = pixels.checked_mul(3)?;
    let mut rgb = Vec::with_capacity(expected_rgb);
    for pixel in rgba.chunks_exact(4) {
        rgb.extend_from_slice(&pixel[..3]);
    }
    RgbImage::from_raw(width, height, rgb)
}

/// Check if an image is in dark mode based on average brightness.
/// Threshold is the shared SSoT (`shared/processing_constants.json` →
/// `generated_constants::DARK_MODE_THRESHOLD`).
pub fn is_dark_mode(img: &RgbImage) -> bool {
    image_mean_fast(img) < DARK_MODE_THRESHOLD
}

/// Detect and convert dark mode screenshots to light mode.
///
/// If the mean pixel value is below threshold, inverts all pixels
/// and applies contrast=3.0, brightness=10 in a SINGLE fused pass
/// (invert + contrast/brightness via a combined LUT).
pub fn convert_dark_mode(img: &mut RgbImage) -> bool {
    if !is_dark_mode(img) {
        return false;
    }
    // Build a fused LUT: invert(x) then apply contrast=3.0, brightness=10
    // invert: x -> 255 - x
    // contrast/brightness: x -> clamp(x * contrast + adjusted_brightness)
    // adjusted_brightness = brightness + round(255 * (1 - contrast) / 2)
    //                     = 10 + round(255 * (1 - 3.0) / 2) = 10 + (-255) = -245
    // combined: x -> clamp((255 - x) * 3.0 + (-245))
    let adjusted_brightness: f64 = 10.0 + (255.0_f64 * (1.0 - 3.0) / 2.0).round(); // -245
    let mut lut = [0u8; 256];
    for i in 0..256 {
        let inverted = 255 - i;
        let val = (inverted as f64 * 3.0 + adjusted_brightness).round();
        lut[i as usize] = val.clamp(0.0, 255.0) as u8;
    }
    // keep-dark-gray: invert turns the iOS "Other" category GRAY bars into
    // ~[197,197,195]; map those to black BEFORE the contrast LUT so they survive
    // darken_non_white instead of being clipped to white (a uniform mid-gray
    // would otherwise pass the white threshold; colored bars survive because one
    // channel stays low). Non-gray pixels take the fused invert+contrast LUT as
    // before. Mirrors Python convert_dark_mode bit-for-bit (Python<->Rust parity
    // gate). Ported from Arcascope/screen-scrape "keep-dark-gray-on-dark-mode".
    const GRAY: [i32; 3] = [197, 197, 195];
    const THRESH_SQ: i32 = 30 * 30;
    let raw = img.as_mut();
    for px in raw.chunks_exact_mut(3) {
        let (r, g, b) = (px[0], px[1], px[2]);
        let dr = (255 - r as i32) - GRAY[0];
        let dg = (255 - g as i32) - GRAY[1];
        let db = (255 - b as i32) - GRAY[2];
        if dr * dr + dg * dg + db * db <= THRESH_SQ {
            px[0] = 0;
            px[1] = 0;
            px[2] = 0;
        } else {
            px[0] = lut[r as usize];
            px[1] = lut[g as usize];
            px[2] = lut[b as usize];
        }
    }
    true
}

/// Convert dark mode image using adaptive thresholding optimized for OCR.
///
/// The standard convert_dark_mode uses contrast=3.0 which clips faint gray text
/// (e.g., "12 AM", "60" labels) to near-white, destroying contrast for Tesseract.
/// This function uses adaptive thresholding to preserve text readability.
pub fn convert_dark_mode_for_ocr(img: &RgbImage) -> RgbImage {
    if !is_dark_mode(img) {
        return img.clone();
    }

    let (w, h) = img.dimensions();
    let block_size: usize = 31;
    let c_offset: i32 = 10;

    // Step 1: Invert and convert to grayscale
    let raw = img.as_raw();
    let len = raw.len();
    let mut gray = vec![0u8; (w * h) as usize];
    let mut i = 0;
    let mut pi = 0;
    while i + 2 < len {
        // Invert then convert to BT.601 grayscale matching canvas cvtColorToGray:
        // Math.round(R*0.299 + G*0.587 + B*0.114) via high-precision integer coefficients.
        let r = (255 - raw[i]) as u32;
        let g = (255 - raw[i + 1]) as u32;
        let b = (255 - raw[i + 2]) as u32;
        gray[pi] = ((r * 19595 + g * 38469 + b * 7472 + 32768) >> 16) as u8;
        pi += 1;
        i += 3;
    }

    // Step 2: Adaptive Gaussian thresholding
    // For each pixel, threshold = mean of block_size×block_size neighborhood - c_offset
    let half = block_size / 2;
    let w_usize = w as usize;
    let h_usize = h as usize;

    // Compute integral image for fast mean calculation
    let mut integral = vec![0i64; (w_usize + 1) * (h_usize + 1)];
    let iw = w_usize + 1;
    for y in 0..h_usize {
        let mut row_sum: i64 = 0;
        for x in 0..w_usize {
            row_sum += gray[y * w_usize + x] as i64;
            integral[(y + 1) * iw + (x + 1)] = row_sum + integral[y * iw + (x + 1)];
        }
    }

    // Apply threshold
    let mut result = RgbImage::new(w, h);
    let out_raw = result.as_mut();
    for y in 0..h_usize {
        for x in 0..w_usize {
            let y0 = y.saturating_sub(half);
            let y1 = (y + half + 1).min(h_usize);
            let x0 = x.saturating_sub(half);
            let x1 = (x + half + 1).min(w_usize);
            let area = ((y1 - y0) * (x1 - x0)) as i64;
            let sum = integral[y1 * iw + x1] - integral[y0 * iw + x1] - integral[y1 * iw + x0]
                + integral[y0 * iw + x0];
            // gray > floor(sum / area) - c  <=>  sum < (gray + c) * area, exactly
            // (for an integer k, floor(q) < k iff q < k), without an i64 divide
            // per pixel.
            let k = gray[y * w_usize + x] as i64 + c_offset as i64;
            let val = if sum < k * area { 255u8 } else { 0u8 };
            let idx = (y * w_usize + x) * 3;
            out_raw[idx] = val;
            out_raw[idx + 1] = val;
            out_raw[idx + 2] = val;
        }
    }

    result
}

/// Plain per-channel inversion (`x -> 255 - x`).
///
/// Used for OCR of the title and total time on dark-mode screenshots. The full
/// `convert_dark_mode` applies contrast=3.0 on top of the invert, which thickens
/// and merges adjacent digit strokes — Tesseract then reads the large bold total
/// "11h 24m" as "Mh 24m" (the "11" collapses to "M"), so the hours are dropped and
/// only "24m" survives, or the total is missed entirely. A plain invert keeps the
/// strokes separated and reads the total correctly, while bar extraction continues
/// to use the high-contrast `convert_dark_mode` output it needs.
pub fn invert_image(img: &RgbImage) -> RgbImage {
    let mut out = img.clone();
    for b in out.as_mut() {
        *b = 255 - *b;
    }
    out
}

/// Pick the image to OCR title/total *text* from, given the pristine `original`
/// and the high-contrast `converted` (post-`convert_dark_mode`) image.
///
/// Dark mode → [`invert_image`] of the original plus the gentle stretch in
/// [`dark_text_contrast`]. Light mode → `converted` as-is (where it equals the
/// original, since `convert_dark_mode` is a no-op on light images).
/// Bar extraction always uses `converted`; only text OCR uses this.
pub fn text_ocr_image(original: &RgbImage, converted: &RgbImage) -> RgbImage {
    if is_dark_mode(original) {
        dark_text_contrast(&invert_image(original))
    } else {
        converted.clone()
    }
}

/// Lift an inverted dark-mode capture just enough for Tesseract to keep the
/// strokes of the large bold total apart.
///
/// A plain invert leaves that total grey-on-white with soft edges, and the
/// engine loses a stroke: on `tests/fixtures/images/ios26_dark/IMG_7869.PNG` —
/// the dark twin of `ios26_light/IMG_7880.PNG`, both printing `8h 14m` — it read
/// the hours as `5`, silently turning an 8h day into a 5h one. Measured through
/// the same PSM-3 engine settings the total path uses, the inverted crop yields
/// `["14m", "61D", "14h"]` untouched and `["8h", "14m"]` after this stretch.
///
/// `alpha` is deliberately mild. `convert_dark_mode`'s 3.0 is far too strong
/// here: it clips the bold digits into each other and turns `11h 24m` into
/// `Mh 24m`, which is the regression this function must not reintroduce.
pub fn dark_text_contrast(img: &RgbImage) -> RgbImage {
    adjust_contrast_brightness(img, DARK_TEXT_ALPHA, DARK_TEXT_BETA)
}

/// Contrast gain applied to inverted dark-mode text before OCR.
const DARK_TEXT_ALPHA: f64 = 1.2;
/// Brightness argument paired with [`DARK_TEXT_ALPHA`].
///
/// [`adjust_contrast_brightness`] folds a midpoint correction of
/// `round(255·(1−contrast)/2)` — here −64 — into whatever is passed, so +24
/// lands the effective offset on the −40 the measurement above was taken at.
const DARK_TEXT_BETA: i32 = 6;

/// Mean pixel brightness using raw buffer.
///
/// Computes (R+G+B)/3 per pixel, consistent with Python's cv2.mean() which
/// returns per-channel means. For a dark-mode brightness threshold this is
/// equivalent — the check is `avg < 100` so per-channel vs per-byte makes
/// no practical difference.
///
/// Samples every 4th pixel for images > 100K pixels (step=12 bytes) to keep
/// this O(pixels/4) on large screenshots. Accuracy loss is negligible for a
/// brightness threshold check.
fn image_mean_fast(img: &RgbImage) -> f64 {
    let raw = img.as_raw();
    let len = raw.len();
    if len == 0 {
        return 0.0;
    }
    // Sample every 4th pixel (12 bytes) for large images
    let step = if len > 300_000 { 12 } else { 3 };
    let mut sum = 0u64;
    let mut count = 0u64;
    let mut i = 0;
    while i + 2 < len {
        // Per-pixel mean: (R+G+B)/3
        sum += (raw[i] as u64 + raw[i + 1] as u64 + raw[i + 2] as u64) / 3;
        count += 1;
        i += step;
    }
    if count == 0 {
        0.0
    } else {
        sum as f64 / count as f64
    }
}

/// Adjust contrast and brightness, returning a NEW image.
///
/// Uses a pre-computed LUT (no float math per pixel).
pub fn adjust_contrast_brightness(img: &RgbImage, contrast: f64, brightness: i32) -> RgbImage {
    let adjusted_brightness = brightness as f64 + (255.0 * (1.0 - contrast) / 2.0).round();
    let mut lut = [0u8; 256];
    for (i, slot) in lut.iter_mut().enumerate() {
        let val = (i as f64 * contrast + adjusted_brightness).round();
        *slot = val.clamp(0.0, 255.0) as u8;
    }
    let mut out = img.clone();
    for byte in out.as_mut().iter_mut() {
        *byte = lut[*byte as usize];
    }
    out
}

/// Build a color quantization LUT and apply it in-place.
pub fn reduce_color_count(img: &mut RgbImage, num_colors: u32) {
    let mut lut = [0u8; 256];
    let nc = num_colors as f64;
    for i in 0..256u32 {
        let bin = ((i as f64 * nc / 255.0) as u32).min(num_colors - 1);
        lut[i as usize] = (bin * 255 / (num_colors - 1)) as u8;
    }
    for byte in img.as_mut().iter_mut() {
        *byte = lut[*byte as usize];
    }
}

/// Keep only pixels matching `color` within `threshold` (squared L2 distance).
/// Matching → black, non-matching → white.
pub fn remove_all_but(img: &mut RgbImage, color: [u8; 3], threshold: i32) {
    let threshold_sq = threshold * threshold;
    let cr = color[0] as i32;
    let cg = color[1] as i32;
    let cb = color[2] as i32;
    let raw = img.as_mut();
    let len = raw.len();
    let mut i = 0;
    while i + 2 < len {
        let dr = raw[i] as i32 - cr;
        let dg = raw[i + 1] as i32 - cg;
        let db = raw[i + 2] as i32 - cb;
        if dr * dr + dg * dg + db * db <= threshold_sq {
            raw[i] = 0;
            raw[i + 1] = 0;
            raw[i + 2] = 0;
        } else {
            raw[i] = 255;
            raw[i + 1] = 255;
            raw[i + 2] = 255;
        }
        i += 3;
    }
}

/// Zero out all non-white pixels (BT.601 luma ≤ 240 → black).
/// Uses BT.601 grayscale to match canvas `darkenNonWhite` behavior.
pub fn darken_non_white(img: &mut RgbImage) {
    let raw = img.as_mut();
    let len = raw.len();
    let mut i = 0;
    let [c0, c1, c2] = DARKEN_NON_WHITE_LUMA_COEFFS;
    let shift = DARKEN_NON_WHITE_LUMA_SHIFT;
    let threshold = DARKEN_NON_WHITE_LUMA_THRESHOLD;
    while i + 2 < len {
        let luma = (raw[i] as u32 * c0 + raw[i + 1] as u32 * c1 + raw[i + 2] as u32 * c2) >> shift;
        if luma <= threshold {
            raw[i] = 0;
            raw[i + 1] = 0;
            raw[i + 2] = 0;
        }
        i += 3;
    }
}

/// Fused darken_non_white + reduce_color_count(2) in a single pass.
///
/// This is the hot path in `slice_image` — combining two passes into one
/// halves the memory bandwidth.
pub fn darken_and_binarize(img: &mut RgbImage) {
    // reduce_color_count(2) LUT
    let mut lut = [0u8; 256];
    let nc = 2.0f64;
    for i in 0..256u32 {
        let bin = ((i as f64 * nc / 255.0) as u32).min(1);
        lut[i as usize] = (bin * 255) as u8;
    }

    let raw = img.as_mut();
    let len = raw.len();
    let mut i = 0;
    let [c0, c1, c2] = DARKEN_NON_WHITE_LUMA_COEFFS;
    let shift = DARKEN_NON_WHITE_LUMA_SHIFT;
    let threshold = DARKEN_NON_WHITE_LUMA_THRESHOLD;
    while i + 2 < len {
        let luma = (raw[i] as u32 * c0 + raw[i + 1] as u32 * c1 + raw[i + 2] as u32 * c2) >> shift;
        if luma <= threshold {
            raw[i] = 0;
            raw[i + 1] = 0;
            raw[i + 2] = 0;
        } else {
            raw[i] = lut[raw[i] as usize];
            raw[i + 1] = lut[raw[i + 1] as usize];
            raw[i + 2] = lut[raw[i + 2] as usize];
        }
        i += 3;
    }
}

/// Find the Nth most common pixel value in an image region.
///
/// arg=1: most common pixel. arg=-2: second most common.
/// Uses exact counting (no sampling) for consistency with Python's np.unique.
pub fn get_pixel(img: &RgbImage, arg: i32) -> Option<[u8; 3]> {
    let raw = img.as_raw();
    let len = raw.len();
    if len < 6 {
        return None;
    } // need at least 2 pixels

    // Small inline frequency table (most quantized images have ≤16 unique colors).
    // After reduce_color_count(2), images typically have exactly 2 colors, so we
    // track whether counting is "settled" to enable an early-exit optimisation:
    // once we've seen 2+ unique colors AND processed enough pixels for stable
    // ranking, skip the rest of the image.
    let pixel_count = len / 3;
    let mut table: Vec<([u8; 3], u32)> = Vec::with_capacity(16);
    let settle_threshold = (pixel_count / 4).max(256); // 25% of pixels or 256
    let mut settled_at: Option<usize> = None;
    // Runs of one colour are the norm, so the entry that matched last is tried
    // first; the counts (and so the ranking) are the same as a plain scan.
    let mut last = 0usize;
    // colour -> position in `table`. `table` keeps first-seen order (which breaks
    // ties), so this only replaces the linear search: a JPEG crop has thousands of
    // colours, and searching the table on every colour change was quadratic.
    let mut index: HashMap<u32, usize, BuildHasherDefault<ColourHasher>> = HashMap::default();
    for (pi, px) in raw.chunks_exact(3).enumerate() {
        let color = [px[0], px[1], px[2]];
        if last < table.len() && table[last].0 == color {
            table[last].1 += 1;
        } else {
            match index.entry(u32::from_le_bytes([px[0], px[1], px[2], 0])) {
                Entry::Occupied(e) => {
                    last = *e.get();
                    table[last].1 += 1;
                }
                Entry::Vacant(e) => {
                    e.insert(table.len());
                    table.push((color, 1));
                    last = table.len() - 1;
                    // For binarized images (2 colors), record when we first see both
                    if table.len() == 2 {
                        settled_at = Some(pi);
                    }
                }
            }
        }
        // Early exit: if we've found exactly 2 colors (common after reduce_color_count(2))
        // and have counted enough pixels, the ranking is stable.
        if let Some(start) = settled_at
            && table.len() == 2
            && (pi + 1 - start) >= settle_threshold
        {
            break;
        }
    }

    if table.len() <= 1 {
        return None;
    }

    // Find top-2 by count
    let mut top1 = ([0u8; 3], 0u32);
    let mut top2 = ([0u8; 3], 0u32);
    for &(color, count) in &table {
        if count > top1.1 {
            top2 = top1;
            top1 = (color, count);
        } else if count > top2.1 {
            top2 = (color, count);
        }
    }

    match arg {
        1 => Some(top1.0),
        -2 => Some(top2.0),
        _ => {
            // General case: sort and index
            table.sort_by_key(|&(_, c)| c);
            let idx = if arg < 0 {
                let abs_idx = (-arg) as usize;
                if abs_idx > table.len() {
                    0
                } else {
                    table.len() - abs_idx
                }
            } else {
                (arg as usize).min(table.len() - 1)
            };
            Some(table[idx].0)
        }
    }
}

/// `image::imageops::resize(img, nw, nh, FilterType::Lanczos3)` for an RGB
/// image, bit-identical and several times faster.
///
/// It repeats the crate's arithmetic step for step: the same tap windows and
/// normalised f32 weights, a vertical pass into f32 then a horizontal pass, each
/// output summed from zero in tap order, then clamped and rounded. What it drops
/// is the overhead: per-pixel bounds-checked access, the unused fourth channel
/// and an intermediate RGBA image. `resize_lanczos3_matches_the_image_crate`
/// pins the equality.
pub fn resize_lanczos3(img: &RgbImage, nw: u32, nh: u32) -> RgbImage {
    let (w, h) = img.dimensions();
    if w == 0 || h == 0 || nw == 0 || nh == 0 || (nw, nh) == (w, h) {
        return image::imageops::resize(img, nw, nh, image::imageops::FilterType::Lanczos3);
    }
    fn sinc(t: f32) -> f32 {
        let a = t * std::f32::consts::PI;
        if t == 0.0 { 1.0 } else { a.sin() / a }
    }
    fn lanczos3(x: f32) -> f32 {
        if x.abs() < 3.0 {
            sinc(x) * sinc(x / 3.0)
        } else {
            0.0
        }
    }
    // (first source index, normalised weights) for each output index.
    fn taps(len: u32, new_len: u32) -> Vec<(usize, Vec<f32>)> {
        let ratio = len as f32 / new_len as f32;
        let sratio = if ratio < 1.0 { 1.0 } else { ratio };
        let src_support = 3.0 * sratio;
        (0..new_len)
            .map(|out| {
                let input = (out as f32 + 0.5) * ratio;
                let left = ((input - src_support).floor() as i64).clamp(0, len as i64 - 1);
                let right = ((input + src_support).ceil() as i64).clamp(left + 1, len as i64);
                let input = input - 0.5;
                let mut ws: Vec<f32> = (left..right)
                    .map(|i| lanczos3((i as f32 - input) / sratio))
                    .collect();
                let sum = ws.iter().fold(0.0f32, |acc, w| acc + w);
                for wt in ws.iter_mut() {
                    *wt /= sum;
                }
                (left as usize, ws)
            })
            .collect()
    }
    let (wu, nwu) = (w as usize, nw as usize);
    let src = img.as_raw();
    // Vertical pass: w x h -> w x nh, f32. Accumulating whole rows tap by tap
    // adds each output's terms in the same order as the crate's per-pixel loop.
    let mut mid = vec![0f32; wu * nh as usize * 3];
    for (oy, (left, ws)) in taps(h, nh).iter().enumerate() {
        let out = &mut mid[oy * wu * 3..(oy + 1) * wu * 3];
        for (i, &wt) in ws.iter().enumerate() {
            let row = &src[(left + i) * wu * 3..(left + i + 1) * wu * 3];
            for (o, &v) in out.iter_mut().zip(row) {
                *o += v as f32 * wt;
            }
        }
    }
    // Horizontal pass: w x nh -> nw x nh, clamped and rounded to u8.
    let htaps = taps(w, nw);
    let mut out = RgbImage::new(nw, nh);
    let dst = out.as_mut();
    for y in 0..nh as usize {
        let row = &mid[y * wu * 3..(y + 1) * wu * 3];
        let drow = &mut dst[y * nwu * 3..(y + 1) * nwu * 3];
        for (ox, (left, ws)) in htaps.iter().enumerate() {
            let mut t = [0.0f32; 3];
            for (i, &wt) in ws.iter().enumerate() {
                let p = (left + i) * 3;
                t[0] += row[p] * wt;
                t[1] += row[p + 1] * wt;
                t[2] += row[p + 2] * wt;
            }
            for c in 0..3 {
                drow[ox * 3 + c] = t[c].clamp(0.0, 255.0).round() as u8;
            }
        }
    }
    out
}

/// Check if two pixels are close (L1 distance ≤ thresh * 3).
#[inline(always)]
pub fn is_close(p1: &[u8; 3], p2: &[u8; 3], thresh: i32) -> bool {
    (p1[0] as i32 - p2[0] as i32).abs()
        + (p1[1] as i32 - p2[1] as i32).abs()
        + (p1[2] as i32 - p2[2] as i32).abs()
        <= thresh * 3
}

/// Extract line position from a subregion.
///
/// Returns the first row (horizontal) or column (vertical) where the
/// 2nd-most-common pixel dominates. Uses raw buffer access.
pub fn extract_line(img: &RgbImage, x0: u32, x1: u32, y0: u32, y1: u32, horizontal: bool) -> u32 {
    let w = x1.saturating_sub(x0);
    let h = y1.saturating_sub(y0);
    if w == 0 || h == 0 {
        return 0;
    }

    let mut sub = image::imageops::crop_imm(img, x0, y0, w, h).to_image();
    reduce_color_count(&mut sub, 2);

    let pixel_value = match get_pixel(&sub, -2) {
        Some(p) => p,
        None => return 0,
    };

    let (sw, sh) = sub.dimensions();
    let raw = sub.as_raw();
    let stride = sw as usize * 3;
    let pr = pixel_value[0] as i32;
    let pg = pixel_value[1] as i32;
    let pb = pixel_value[2] as i32;

    if horizontal {
        for y in 0..sh {
            let row_off = y as usize * stride;
            let mut count = 0u32;
            for x in 0..sw as usize {
                let idx = row_off + x * 3;
                let dist = (raw[idx] as i32 - pr).abs()
                    + (raw[idx + 1] as i32 - pg).abs()
                    + (raw[idx + 2] as i32 - pb).abs();
                if dist <= 3 {
                    count += 1;
                }
            }
            if count > sw / 2 {
                return y;
            }
        }
    } else {
        for x in 0..sw {
            let mut count = 0u32;
            for y in 0..sh as usize {
                let idx = y * stride + x as usize * 3;
                let dist = (raw[idx] as i32 - pr).abs()
                    + (raw[idx + 1] as i32 - pg).abs()
                    + (raw[idx + 2] as i32 - pb).abs();
                if dist <= 3 {
                    count += 1;
                }
            }
            if count > sh / 4 {
                return x;
            }
        }
    }
    0
}

/// Convert RGB to HSV (OpenCV convention: H 0-180, S 0-255, V 0-255).
#[inline(always)]
pub fn rgb_to_hsv(r: u8, g: u8, b: u8) -> (u8, u8, u8) {
    let rf = r as f64 / 255.0;
    let gf = g as f64 / 255.0;
    let bf = b as f64 / 255.0;
    let max = rf.max(gf).max(bf);
    let min = rf.min(gf).min(bf);
    let diff = max - min;

    let h = if diff == 0.0 {
        0.0
    } else if max == rf {
        60.0 * (((gf - bf) / diff) % 6.0)
    } else if max == gf {
        60.0 * ((bf - rf) / diff + 2.0)
    } else {
        60.0 * ((rf - gf) / diff + 4.0)
    };
    let h = if h < 0.0 { h + 360.0 } else { h };
    let h = (h / 2.0) as u8;
    let s = if max == 0.0 {
        0.0
    } else {
        (diff / max) * 255.0
    };
    let v = max * 255.0;
    (h, s as u8, v as u8)
}

#[cfg(test)]
mod tests {
    #[test]
    fn resize_lanczos3_matches_the_image_crate() {
        for (w, h, nw, nh) in [
            (7, 5, 21, 15),
            (40, 9, 80, 18),
            (33, 17, 99, 51),
            (64, 48, 17, 13),
            (5, 3, 5, 9),
            (1, 4, 3, 8),
        ] {
            let img = RgbImage::from_fn(w, h, |x, y| {
                let v = x.wrapping_mul(2654435761).wrapping_add(y.wrapping_mul(97)) >> 7;
                Rgb([
                    v as u8,
                    (v >> 8) as u8,
                    (v >> 3) as u8 | (x as u8 & 1) * 255,
                ])
            });
            let want = image::imageops::resize(&img, nw, nh, image::imageops::FilterType::Lanczos3);
            assert_eq!(resize_lanczos3(&img, nw, nh), want, "{w}x{h} -> {nw}x{nh}");
        }
    }

    use super::*;

    #[test]
    fn test_darken_non_white() {
        let mut img = RgbImage::new(3, 1);
        img.put_pixel(0, 0, Rgb([255, 255, 255]));
        img.put_pixel(1, 0, Rgb([100, 100, 100]));
        img.put_pixel(2, 0, Rgb([250, 250, 250]));
        darken_non_white(&mut img);
        assert_eq!(img.get_pixel(0, 0), &Rgb([255, 255, 255]));
        assert_eq!(img.get_pixel(1, 0), &Rgb([0, 0, 0]));
        assert_eq!(img.get_pixel(2, 0), &Rgb([250, 250, 250]));
    }

    // Parity: darken_non_white uses canvas cvtColorToGray formula: (R*77+G*150+B*29)>>8.
    // Canvas: cvtColorToGray → threshold(gray, 240, 255) → if gray <= 240, black.
    // The high-precision formula (R*19595+G*38469+B*7472+32768)>>16 can diverge from canvas
    // for non-gray pixels near the 240 boundary. Use the exact canvas formula.
    #[test]
    fn parity_darken_non_white_canvas_luma_formula() {
        let mut img = RgbImage::new(2, 1);
        // (100, 200, 50): canvas luma = (100*77+200*150+50*29)>>8 = 39150>>8 = 152 ≤ 240 → black
        // high-precision: (100*19595+200*38469+50*7472+32768)>>16 = 153 > 240? No, 153 ≤ 240 → same here
        // But the formula is now exactly canvas to avoid divergence near threshold.
        img.put_pixel(0, 0, Rgb([100, 200, 50]));
        // (250, 245, 215): canvas luma = (250*77+245*150+215*29)>>8 = 62235>>8 = 243 > 240 → keep
        img.put_pixel(1, 0, Rgb([250, 245, 215]));
        darken_non_white(&mut img);
        assert_eq!(
            img.get_pixel(0, 0),
            &Rgb([0, 0, 0]),
            "canvas luma=152 ≤ 240 must darken"
        );
        assert_eq!(
            img.get_pixel(1, 0),
            &Rgb([250, 245, 215]),
            "canvas luma=243 > 240 must keep"
        );
    }

    // Parity: darken_non_white uses BT.601 luma, not simple (R+G+B)/3.
    // Canvas: cvtColorToGray → threshold(gray, 240, 255) → if gray <= 240, black.
    // The old simple-average formula would INCORRECTLY darken these non-gray pixels.
    #[test]
    fn parity_darken_non_white_bt601_threshold() {
        let mut img = RgbImage::new(2, 1);
        // (250, 245, 215): canvas (R*77+G*150+B*29)>>8 = 243 > 240 → keep
        // simple avg: (250+245+215)/3 = 236 ≤ 240 → old code wrongly zeroed this
        img.put_pixel(0, 0, Rgb([250, 245, 215]));
        // (241, 241, 241): canvas luma = 241 > 240 → keep
        img.put_pixel(1, 0, Rgb([241, 241, 241]));
        darken_non_white(&mut img);
        assert_eq!(
            img.get_pixel(0, 0),
            &Rgb([250, 245, 215]),
            "BT.601>240 must keep non-gray near-white pixel"
        );
        assert_eq!(img.get_pixel(1, 0), &Rgb([241, 241, 241]));
    }

    #[test]
    fn test_reduce_color_count_binary() {
        let mut img = RgbImage::new(4, 1);
        img.put_pixel(0, 0, Rgb([0, 0, 0]));
        img.put_pixel(1, 0, Rgb([50, 50, 50]));
        img.put_pixel(2, 0, Rgb([200, 200, 200]));
        img.put_pixel(3, 0, Rgb([255, 255, 255]));
        reduce_color_count(&mut img, 2);
        assert_eq!(img.get_pixel(0, 0)[0], 0);
        assert_eq!(img.get_pixel(3, 0)[0], 255);
    }

    #[test]
    fn test_remove_all_but() {
        let mut img = RgbImage::new(3, 1);
        img.put_pixel(0, 0, Rgb([255, 121, 0]));
        img.put_pixel(1, 0, Rgb([255, 120, 1]));
        img.put_pixel(2, 0, Rgb([0, 0, 255]));
        remove_all_but(&mut img, [255, 121, 0], 30);
        assert_eq!(img.get_pixel(0, 0), &Rgb([0, 0, 0]));
        assert_eq!(img.get_pixel(1, 0), &Rgb([0, 0, 0]));
        assert_eq!(img.get_pixel(2, 0), &Rgb([255, 255, 255]));
    }

    #[test]
    fn test_adjust_contrast_brightness() {
        let mut img = RgbImage::new(1, 1);
        img.put_pixel(0, 0, Rgb([128, 128, 128]));
        let result = adjust_contrast_brightness(&img, 2.0, 0);
        assert_eq!(result.get_pixel(0, 0)[0], 128);
    }

    #[test]
    fn test_convert_dark_mode_detects_dark() {
        let mut img = RgbImage::from_fn(10, 10, |_, _| Rgb([30, 30, 30]));
        let was_dark = convert_dark_mode(&mut img);
        assert!(was_dark);
        let mean = image_mean_fast(&img);
        assert!(mean > 100.0);
    }

    #[test]
    fn test_convert_dark_mode_ignores_light() {
        let mut img = RgbImage::from_fn(10, 10, |_, _| Rgb([200, 200, 200]));
        assert!(!convert_dark_mode(&mut img));
    }

    #[test]
    fn test_convert_dark_mode_preserves_gray_bars() {
        // Dark-mode screenshot: dark background + a gray "Other" category bar.
        // The bar value [58,58,60] inverts to [197,197,195] (the iOS gray).
        // BEFORE keep-dark-gray it would invert+contrast to white (clamp(197*3
        // -245)=255) and be DROPPED by darken_non_white; the fix maps it to black
        // so the bar is still counted. The dark background inverts to ~235 and
        // contrasts to white (not a bar) as before.
        let mut img = RgbImage::from_fn(10, 10, |x, _| {
            if x < 3 {
                Rgb([58, 58, 60]) // gray bar columns
            } else {
                Rgb([20, 20, 20]) // dark background
            }
        });
        assert!(convert_dark_mode(&mut img));
        // Gray bar -> BLACK (preserved as a countable bar)
        assert_eq!(img.get_pixel(0, 0).0, [0, 0, 0]);
        assert_eq!(img.get_pixel(2, 5).0, [0, 0, 0]);
        // Dark background -> WHITE (not a bar)
        assert_eq!(img.get_pixel(5, 5).0, [255, 255, 255]);
    }

    #[test]
    fn test_is_close() {
        assert!(is_close(&[100, 100, 100], &[101, 101, 101], 1));
        assert!(!is_close(&[100, 100, 100], &[110, 110, 110], 1));
    }

    #[test]
    fn test_rgb_to_hsv_blue() {
        let (h, s, v) = rgb_to_hsv(0, 0, 255);
        assert!(h >= 115 && h <= 125, "H={h}");
        assert_eq!(s, 255);
        assert_eq!(v, 255);
    }

    #[test]
    fn test_darken_and_binarize() {
        let mut img = RgbImage::new(3, 1);
        img.put_pixel(0, 0, Rgb([255, 255, 255])); // white → keep + quantize
        img.put_pixel(1, 0, Rgb([100, 100, 100])); // gray → darken to black
        img.put_pixel(2, 0, Rgb([0, 0, 0])); // black → stays black
        darken_and_binarize(&mut img);
        assert_eq!(img.get_pixel(0, 0), &Rgb([255, 255, 255]));
        assert_eq!(img.get_pixel(1, 0), &Rgb([0, 0, 0]));
        assert_eq!(img.get_pixel(2, 0), &Rgb([0, 0, 0]));
    }

    // Parity: darken_and_binarize uses BT.601 luma for white detection, matching canvas.
    // Canvas darkenNonWhite: cvtColorToGray (BT.601) then threshold at 240.
    #[test]
    fn parity_darken_and_binarize_bt601_threshold() {
        let mut img = RgbImage::new(2, 1);
        // (250, 245, 215): BT.601 luma = 243 > 240 → white path (keep + quantize to 255)
        // simple avg: 236 ≤ 240 → old code wrongly sent this to the black path
        img.put_pixel(0, 0, Rgb([250, 245, 215]));
        // (240, 240, 240): BT.601 = 240 ≤ 240 → non-white → black
        img.put_pixel(1, 0, Rgb([240, 240, 240]));
        darken_and_binarize(&mut img);
        assert_eq!(
            img.get_pixel(0, 0),
            &Rgb([255, 255, 255]),
            "BT.601>240 non-gray near-white must stay white"
        );
        assert_eq!(
            img.get_pixel(1, 0),
            &Rgb([0, 0, 0]),
            "BT.601=240 must darken to black"
        );
    }

    // Parity: rgb_to_hsv red — H=0 in OpenCV 0-180 convention
    #[test]
    fn parity_rgb_to_hsv_red() {
        let (h, s, v) = rgb_to_hsv(255, 0, 0);
        assert_eq!(h, 0, "pure red H must be 0");
        assert_eq!(s, 255);
        assert_eq!(v, 255);
    }

    // Parity: rgb_to_hsv green — H=60 in OpenCV 0-180 convention (120° / 2)
    #[test]
    fn parity_rgb_to_hsv_green() {
        let (h, s, v) = rgb_to_hsv(0, 255, 0);
        assert_eq!(h, 60, "pure green H must be 60 in OpenCV convention");
        assert_eq!(s, 255);
        assert_eq!(v, 255);
    }

    // Parity: gray pixels must have S=0 regardless of brightness
    #[test]
    fn parity_rgb_to_hsv_gray_saturation_zero() {
        let (_, s, _) = rgb_to_hsv(128, 128, 128);
        assert_eq!(s, 0, "gray pixel must have S=0");
        let (_, s2, _) = rgb_to_hsv(0, 0, 0);
        assert_eq!(s2, 0, "black must have S=0");
    }

    // Parity: is_close uses L1 ≤ thresh*3 (inclusive boundary).
    // Canvas: Math.abs(r1-r2)+Math.abs(g1-g2)+Math.abs(b1-b2) <= thresh*3
    #[test]
    fn parity_is_close_boundary() {
        // L1 = 5+5+5 = 15 = thresh*3 → true (inclusive)
        assert!(
            is_close(&[0, 0, 0], &[5, 5, 5], 5),
            "L1==thresh*3 must be close"
        );
        // L1 = 5+5+6 = 16 > 15 → false
        assert!(
            !is_close(&[0, 0, 0], &[5, 5, 6], 5),
            "L1==thresh*3+1 must not be close"
        );
    }

    // get_pixel's hash index must not change any answer: compare with the plain
    // linear-scan version it replaced, on many-colour images with runs and ties,
    // and on a two-colour image that takes the early exit.
    #[test]
    fn get_pixel_matches_the_linear_scan() {
        fn linear(img: &RgbImage, arg: i32) -> Option<[u8; 3]> {
            let raw = img.as_raw();
            if raw.len() < 6 {
                return None;
            }
            let pixel_count = raw.len() / 3;
            let mut table: Vec<([u8; 3], u32)> = Vec::new();
            let settle_threshold = (pixel_count / 4).max(256);
            let mut settled_at: Option<usize> = None;
            for (pi, px) in raw.chunks_exact(3).enumerate() {
                let color = [px[0], px[1], px[2]];
                if let Some(k) = table.iter().position(|e| e.0 == color) {
                    table[k].1 += 1;
                } else {
                    table.push((color, 1));
                    if table.len() == 2 {
                        settled_at = Some(pi);
                    }
                }
                if let Some(start) = settled_at
                    && table.len() == 2
                    && (pi + 1 - start) >= settle_threshold
                {
                    break;
                }
            }
            if table.len() <= 1 {
                return None;
            }
            let (mut top1, mut top2) = (([0u8; 3], 0u32), ([0u8; 3], 0u32));
            for &(color, count) in &table {
                if count > top1.1 {
                    top2 = top1;
                    top1 = (color, count);
                } else if count > top2.1 {
                    top2 = (color, count);
                }
            }
            match arg {
                1 => Some(top1.0),
                -2 => Some(top2.0),
                _ => {
                    table.sort_by_key(|&(_, c)| c);
                    let idx = if arg < 0 {
                        let a = (-arg) as usize;
                        if a > table.len() { 0 } else { table.len() - a }
                    } else {
                        (arg as usize).min(table.len() - 1)
                    };
                    Some(table[idx].0)
                }
            }
        }
        let mut seed = 7u32;
        let mut next = move || {
            seed = seed.wrapping_mul(1_103_515_245).wrapping_add(12_345);
            (seed >> 16) as u8
        };
        for (w, h, palette) in [(97, 61, 40u8), (200, 150, 255), (64, 64, 3), (31, 7, 2)] {
            let mut img = RgbImage::new(w, h);
            let mut run = [0u8; 3];
            for (i, p) in img.pixels_mut().enumerate() {
                if i % 5 == 0 {
                    run = [next() % palette, next() % palette, next() % palette];
                }
                *p = Rgb(run);
            }
            for arg in [1, -2, -3, 0, 2, 5, -500] {
                assert_eq!(
                    get_pixel(&img, arg),
                    linear(&img, arg),
                    "{w}x{h} palette {palette} arg {arg}"
                );
            }
        }
        let two = RgbImage::from_fn(300, 300, |x, y| {
            Rgb(if (x + y) % 3 == 0 {
                [0, 0, 0]
            } else {
                [255; 3]
            })
        });
        for arg in [1, -2] {
            assert_eq!(get_pixel(&two, arg), linear(&two, arg));
        }
    }

    // Parity: get_pixel arg=1 returns most common; arg=-2 returns second most common.
    // Canvas uses numpy unique (equivalent behavior for binarized images).
    #[test]
    fn parity_get_pixel_arg1_and_neg2() {
        let mut img = RgbImage::new(4, 1);
        img.put_pixel(0, 0, Rgb([255, 255, 255]));
        img.put_pixel(1, 0, Rgb([255, 255, 255]));
        img.put_pixel(2, 0, Rgb([255, 255, 255]));
        img.put_pixel(3, 0, Rgb([0, 0, 0]));
        assert_eq!(
            get_pixel(&img, 1),
            Some([255, 255, 255]),
            "arg=1 must return most common"
        );
        assert_eq!(
            get_pixel(&img, -2),
            Some([0, 0, 0]),
            "arg=-2 must return 2nd most common"
        );
    }

    // Parity: remove_all_but uses squared L2 distance, boundary dist_sq==threshold^2 → matches.
    // Canvas: dr*dr+dg*dg+db*db <= threshold*threshold
    #[test]
    fn parity_remove_all_but_boundary() {
        // threshold=30, threshold_sq=900
        // pixel [255, 151, 0] vs target [255, 121, 0]: dg=30, dist_sq=900 ≤ 900 → black
        // pixel [255, 152, 0] vs target [255, 121, 0]: dg=31, dist_sq=961 > 900 → white
        let mut img = RgbImage::new(2, 1);
        img.put_pixel(0, 0, Rgb([255, 151, 0]));
        img.put_pixel(1, 0, Rgb([255, 152, 0]));
        remove_all_but(&mut img, [255, 121, 0], 30);
        assert_eq!(
            img.get_pixel(0, 0),
            &Rgb([0, 0, 0]),
            "exact threshold dist must match → black"
        );
        assert_eq!(
            img.get_pixel(1, 0),
            &Rgb([255, 255, 255]),
            "dist>threshold must not match → white"
        );
    }

    // Parity: adjust_contrast_brightness clamps output at 0.
    // Canvas: Math.max(0, Math.min(255, v * contrast + adjusted))
    #[test]
    fn parity_adjust_contrast_brightness_clamps_at_zero() {
        let mut img = RgbImage::new(1, 1);
        img.put_pixel(0, 0, Rgb([0, 0, 0]));
        // contrast=1.0, brightness=-50: adjusted=-50+(255*(1-1)/2).round()=-50; val=0-50 → clamp=0
        let result = adjust_contrast_brightness(&img, 1.0, -50);
        assert_eq!(
            result.get_pixel(0, 0)[0],
            0,
            "output must clamp at 0, not go negative"
        );
    }

    // Parity: convert_dark_mode fused LUT maps black→255 and white→0.
    // Canvas: invert then contrast=3.0, brightness=10 → adjusted=-245.
    // LUT[0]  = clamp((255-0)*3+(-245)) = clamp(520) = 255
    // LUT[255] = clamp((255-255)*3+(-245)) = clamp(-245) = 0
    #[test]
    fn parity_convert_dark_mode_extreme_lut_values() {
        // Build a dark image (mean < 100) with two extreme pixels
        let mut img = RgbImage::from_fn(10, 10, |x, _| {
            if x == 9 {
                Rgb([0, 0, 0])
            } else {
                Rgb([10, 10, 10])
            }
        });
        // Add one near-white pixel in dark image to test white→0 mapping
        img.put_pixel(9, 9, Rgb([255, 255, 255]));
        convert_dark_mode(&mut img);
        assert_eq!(
            img.get_pixel(9, 0)[0],
            255,
            "pure black in dark image → white after conversion"
        );
        assert_eq!(
            img.get_pixel(9, 9)[0],
            0,
            "pure white in dark image → black after conversion"
        );
    }

    // Parity: extract_line horizontal uses count > sw/2 threshold (strictly greater).
    // Canvas: if (count / width > 0.5) — equivalently count > width/2.
    #[test]
    fn parity_extract_line_horizontal_threshold() {
        // 10×10 white image, row 3 is fully black.
        // After reduce_color_count(2): black(0,0,0)=10px, white=90px → 2nd most common=black.
        // Row 3: 10 black pixels; count=10 > sw/2=5 → detected at y=3.
        let mut img = RgbImage::from_fn(10, 10, |_, _| image::Rgb([255, 255, 255]));
        for x in 0..10 {
            img.put_pixel(x, 3, image::Rgb([0, 0, 0]));
        }
        let y = extract_line(&img, 0, 10, 0, 10, true);
        assert_eq!(y, 3, "horizontal line at row 3 must be detected");
    }

    // Parity: extract_line vertical uses count > sh/4 threshold (strictly greater).
    // Canvas: if (count / height > 0.25) — equivalently count > height/4.
    #[test]
    fn parity_extract_line_vertical_threshold() {
        // 10×10 white image, column 5 has 3 black pixels (3/10=30% > 25%).
        // After reduce_color_count(2): black=3px, white=97px → 2nd most common=black.
        // Column 5: count=3 > sh/4=2 → detected at x=5.
        let mut img = RgbImage::from_fn(10, 10, |_, _| image::Rgb([255, 255, 255]));
        img.put_pixel(5, 0, image::Rgb([0, 0, 0]));
        img.put_pixel(5, 1, image::Rgb([0, 0, 0]));
        img.put_pixel(5, 2, image::Rgb([0, 0, 0]));
        let x = extract_line(&img, 0, 10, 0, 10, false);
        assert_eq!(x, 5, "vertical line at col 5 must be detected");
    }
}
