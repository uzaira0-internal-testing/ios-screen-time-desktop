//! Read a non-English total-usage string ("7 שע׳ 44 דק׳") into canonical form.
//!
//! Port of Python `core/localized_total.py`; the two must agree, because the
//! offline app runs this crate compiled to WASM while the server runs the
//! Python fallback, and a total that differs between them changes the extracted
//! bars — apportionment reconciles the 24 values against it.
//!
//! The English reader (`boundary_optimizer::parse_ocr_total` and friends) keys
//! on the literal letters `h`/`m`/`s`. That covers Latin-abbreviation locales by
//! accident and nothing else: a Hebrew capture yields `"7ע' ו44 דק'"` and falls
//! straight through, leaving the screenshot with no total at all.
//!
//! Deliberately a SEPARATE fallback rather than extra branches in the English
//! reader, which is the Rust half of a gated parity contract driven by fixed
//! vectors in `shared/ocr_patterns.json`. Running only after that reader has
//! declined keeps every existing behaviour byte-identical.

use crate::generated_constants::LANGUAGE_PACKS;

/// Longest plausible daily total. A screenshot aggregating several devices can
/// exceed 24 hours, so this is a sanity bound, not the clock.
pub const MAX_TOTAL_HOURS: u32 = 48;

/// Shortest CLIPPED unit-token form accepted, in characters. A one-character
/// remnant is too weak to be evidence — the catalogue's Latin abbreviations are
/// single letters ("h", "t", "j") that occur constantly in ordinary page text.
const MIN_UNIT_PREFIX: usize = 2;

/// How much junk may sit between a number and the thing it belongs to. OCR
/// sprinkles stray marks into RTL runs — the reference capture reads "7 ו44" for
/// "7 שע׳ 44" — but a wider gap means real words, i.e. a different phrase.
const MAX_ADJACENCY_GAP: usize = 4;

/// Widest a whole total may be, in characters, from the start of the hour number
/// to the start of the minute number. "7 שע׳ 44 דק׳" spans 6; a page that
/// repeats the hour word in an unrelated row is far wider.
const MAX_TOTAL_SPAN: usize = 12;

/// Characters that all render as an apostrophe-like tick. The catalogue spells
/// Hebrew "דק׳" with U+05F3 HEBREW PUNCTUATION GERESH; Tesseract reads the same
/// glyph back as a plain ASCII apostrophe, so an un-normalized comparison never
/// matches and Hebrew totals silently stay unreadable.
const TICKS: [char; 8] = [
    '\u{05f3}', '\u{05f4}', '\u{2018}', '\u{2019}', '\u{201b}', '\u{02bc}', '\u{00b4}', '`',
];

/// Bidi control marks Tesseract emits around RTL runs. They carry no glyph and
/// would otherwise sit between a number and its unit, breaking adjacency.
const BIDI: [char; 10] = [
    '\u{200e}', '\u{200f}', '\u{202a}', '\u{202b}', '\u{202c}', '\u{2066}', '\u{2067}', '\u{2068}',
    '\u{2069}', '\u{200b}',
];

/// Fold tick variants together and drop bidi marks, so catalogue tokens and OCR
/// output can be compared literally.
fn normalize(text: &str) -> String {
    text.chars()
        .filter(|c| !BIDI.contains(c))
        .map(|c| if TICKS.contains(&c) { '\'' } else { c })
        .collect()
}

/// A number found in the text: its value and its start offset in `chars`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Number {
    value: u32,
    start: usize,
    end: usize,
}

/// Every 1-3 digit run, positioned by CHARACTER index.
///
/// Character indices, not byte offsets: the adjacency and span limits below are
/// counts of glyphs, and Hebrew, Arabic and CJK are all multi-byte, so byte
/// distances would scale with the script and make the limits meaningless.
fn numbers(chars: &[char]) -> Vec<Number> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < chars.len() {
        if !chars[i].is_ascii_digit() {
            i += 1;
            continue;
        }
        let start = i;
        while i < chars.len() && chars[i].is_ascii_digit() {
            i += 1;
        }
        // A run longer than 3 digits is not an hour or minute count; skip it
        // whole rather than reading a prefix of it.
        if i - start <= 3 {
            let value: u32 = chars[start..i]
                .iter()
                .collect::<String>()
                .parse()
                .unwrap_or(0);
            out.push(Number {
                value,
                start,
                end: i,
            });
        }
    }
    out
}

/// Hour and minute tokens for the given language codes, longest-first.
///
/// Longest-first matters: Hebrew's minute tokens include both "דק׳" and "דקה",
/// and matching the longer first avoids reporting a shorter prefix hit for text
/// that in fact spelled the word out.
fn unit_tokens(languages: &[&str]) -> (Vec<String>, Vec<String>) {
    let mut hours: Vec<String> = Vec::new();
    let mut minutes: Vec<String> = Vec::new();
    for pack in LANGUAGE_PACKS.iter() {
        if !languages.contains(&pack.code) {
            continue;
        }
        hours.extend(pack.unit_hour.iter().map(|t| (*t).to_string()));
        minutes.extend(pack.unit_minute.iter().map(|t| (*t).to_string()));
    }
    hours.sort_by_key(|t| std::cmp::Reverse(t.chars().count()));
    minutes.sort_by_key(|t| std::cmp::Reverse(t.chars().count()));
    (hours, minutes)
}

/// Progressively clipped forms of a unit token, longest first.
///
/// OCR damages a small glyph cluster at EITHER end, so both ends are clipped:
/// leading, because the reference Hebrew screenshot reads "ע'" where it says
/// "שע'"; and trailing, because the same header decoded by Chromium reads "דקי'"
/// for "דק'" — an inserted yod that no trailing substring of the token can
/// match, only the leading substring "דק".
///
/// The full token always counts, however short. CJK and Hangul units are single
/// highly-specific glyphs ("分", "분", "時間"); refusing them because of a length
/// rule aimed at Latin single letters would leave those locales unreadable. Only
/// the CLIPPED remnants have to clear [`MIN_UNIT_PREFIX`].
/// Each form is `(chars, tail_clipped)`. `tail_clipped` says the form is a
/// LEADING substring of the token, so it is allowed to butt up against more
/// letters — that is exactly the "דקי׳ for דק׳" case it exists to catch. Every
/// other form must end at a word boundary.
fn prefixes(token: &str) -> Vec<(Vec<char>, bool)> {
    let chars: Vec<char> = normalize(token).trim().chars().collect();
    if chars.is_empty() {
        return Vec::new();
    }
    let mut forms = vec![(chars.clone(), false)];
    let mut i = 1;
    while chars.len() - i >= MIN_UNIT_PREFIX {
        forms.push((chars[i..].to_vec(), false));
        i += 1;
    }
    let mut j = chars.len() - 1;
    while j >= MIN_UNIT_PREFIX {
        forms.push((chars[..j].to_vec(), true));
        j -= 1;
    }
    forms
}

/// Is a match at `at` a standalone unit token rather than part of a word?
///
/// Without this, the catalogue's one-letter Latin units match inside ordinary
/// page text and INVENT totals. Measured on the real OCR of
/// `tests/fixtures/images/IMG_0809 Cropped.png`: with the Dutch pack enabled
/// (`u`, `m`) that English page reads "1h 15m", and with Norwegian (`t`) it
/// reads "15h 0m" — a fabricated total that then drives apportionment across
/// all 24 bars. A unit must therefore start where a word starts, and (unless it
/// was clipped from the tail) end where a word ends. Digits are not letters, so
/// "1m" still matches.
fn is_standalone(chars: &[char], at: usize, len: usize, tail_clipped: bool) -> bool {
    if at > 0 && chars[at - 1].is_alphabetic() {
        return false;
    }
    if tail_clipped {
        return true;
    }
    let end = at + len;
    end >= chars.len() || !chars[end].is_alphabetic()
}

/// Character-index positions where `needle` occurs in `haystack`.
fn find_all(haystack: &[char], needle: &[char]) -> Vec<usize> {
    if needle.is_empty() || needle.len() > haystack.len() {
        return Vec::new();
    }
    (0..=haystack.len() - needle.len())
        .filter(|&i| haystack[i..i + needle.len()] == needle[..])
        .collect()
}

/// Every `(value, value_start)` where a number is attached to a unit token.
///
/// All of them, not the first: a daily-total page repeats the hour and minute
/// words in its category rows ("4 שע׳ 8 דק׳"), and which one is reached first
/// depends on OCR ordering that shifts between crops and engine versions.
/// Collecting the lot lets the caller choose on evidence instead of luck.
fn all_unit_hits(chars: &[char], nums: &[Number], tokens: &[String]) -> Vec<(u32, usize)> {
    let mut hits: Vec<(u32, usize)> = Vec::new();
    for token in tokens {
        for (form, tail_clipped) in prefixes(token) {
            for at in find_all(chars, &form) {
                if !is_standalone(chars, at, form.len(), tail_clipped) {
                    continue;
                }
                let Some(last) = nums.iter().rfind(|n| n.end <= at) else {
                    continue;
                };
                // Reject a number that is not actually attached to this unit.
                if at - last.end > MAX_ADJACENCY_GAP {
                    continue;
                }
                if hits.iter().any(|(_, start)| *start == last.start) {
                    continue;
                }
                hits.push((last.value, last.start));
            }
        }
    }
    hits.sort_by_key(|(_, start)| *start);
    hits
}

/// Unit-token positions independent of whether OCR retained their number.
fn all_unit_positions(chars: &[char], tokens: &[String]) -> Vec<(usize, u32)> {
    let mut positions = Vec::new();
    for token in tokens {
        for (form, tail_clipped) in prefixes(token) {
            for at in find_all(chars, &form) {
                if is_standalone(chars, at, form.len(), tail_clipped)
                    && !positions.iter().any(|(pos, _)| *pos == at)
                {
                    let quantity = if token == "שעתיים" && form.len() == token.chars().count()
                    {
                        2
                    } else {
                        1
                    };
                    positions.push((at, quantity));
                }
            }
        }
    }
    positions.sort_by_key(|(at, _)| *at);
    positions
}

/// Repair the Hebrew conjunction glyph appended to a minute number.
///
/// In large iOS headers `10 ו דק׳`, `19 ו דק׳`, and `28 ו דק׳` are repeatedly
/// segmented as the three-digit runs `101`, `191`, and `281`. Those values are
/// impossible minutes; dropping the final 1 recovers the printed number without
/// weakening the ordinary 0..59 range check.
fn normalized_minutes(value: u32) -> u32 {
    if (100..=591).contains(&value) && value % 10 == 1 && value / 10 < 60 {
        value / 10
    } else {
        value
    }
}

/// Number ending just before `index`, if close enough to be the same phrase.
///
/// Recovers the hours when only the minute unit survived OCR — the common
/// Hebrew case, where "7 שע׳ 44 דק׳" reads as "7 ו44 דק׳". Scanning for
/// "exactly two numbers" cannot do this job: the date line above the total
/// contributes its own numerals.
fn value_adjacent_before(nums: &[Number], index: usize) -> Option<u32> {
    let last = nums.iter().rfind(|n| n.end <= index)?;
    if index - last.end > MAX_ADJACENCY_GAP {
        return None;
    }
    Some(last.value)
}

/// Canonical `"Xh Ym"` for a non-English total string, or `""`.
///
/// `languages` is the user's active Tesseract language list. Codes with no
/// catalogue entry contribute nothing, so passing extras is harmless.
///
/// When several candidates survive, the LARGEST wins. On a daily-total page the
/// total is the sum of the category rows printed below it, so it is the largest
/// duration on the page by construction; on an app page there is only one.
pub fn extract_localized_total(text: &str, languages: &[&str]) -> String {
    if text.trim().is_empty() {
        return String::new();
    }

    let chars: Vec<char> = normalize(text).chars().collect();
    let nums = numbers(&chars);
    let (hour_tokens, minute_tokens) = unit_tokens(languages);

    let hour_hits = all_unit_hits(&chars, &nums, &hour_tokens);
    let minute_hits = all_unit_hits(&chars, &nums, &minute_tokens);
    let hour_positions = all_unit_positions(&chars, &hour_tokens);

    let mut totals: Vec<u32> = Vec::new();

    // A minute hit anchors each candidate: the minute word survives OCR far more
    // reliably than the hour word on the captures seen so far.
    for &(raw_minutes, m_at) in &minute_hits {
        let minutes = normalized_minutes(raw_minutes);
        if minutes >= 60 {
            continue;
        }
        let hours = hour_hits
            .iter()
            .rfind(|(_, h_at)| m_at > *h_at && m_at - h_at <= MAX_TOTAL_SPAN)
            .map(|(h, _)| *h)
            // Several locales omit the numeral for singular one hour. Hebrew
            // iOS writes `שעה ו11 דק׳`; the standalone hour unit is sufficient
            // evidence for 1 when it sits on this same short duration row.
            .or_else(|| {
                hour_positions
                    .iter()
                    .rev()
                    .find(|&&(h_at, _)| m_at > h_at && m_at - h_at <= MAX_TOTAL_SPAN)
                    .map(|&(_, quantity)| quantity)
            })
            // If the unit glyph itself was destroyed, an isolated duration row
            // can still be unambiguous: exactly two nearby numbers, with the
            // latter attached to the minute unit. This is the dark-mode
            // `7 'שע 101 דק׳` reading after 101 is repaired to 10.
            .or_else(|| {
                if nums.len() == 2 && nums[0].start < m_at && m_at - nums[0].start <= MAX_TOTAL_SPAN
                {
                    Some(nums[0].value)
                } else {
                    None
                }
            })
            .or_else(|| value_adjacent_before(&nums, m_at))
            .unwrap_or(0);
        if hours <= MAX_TOTAL_HOURS {
            totals.push(hours * 60 + minutes);
        }
    }

    // Sometimes the minute UNIT disappears while its number survives. An
    // explicit hour hit plus exactly one later, nearby minute number is still
    // unambiguous on the isolated duration row. This also covers the RTL
    // conjunction fusing to the number (`5 שע׳ 331` for 5h33m).
    if minute_hits.is_empty() {
        for &(hours, h_at) in &hour_hits {
            for minute in nums.iter().filter(|number| number.start > h_at) {
                let repaired = normalized_minutes(minute.value);
                if repaired < 60
                    && minute.start - h_at <= MAX_TOTAL_SPAN
                    && hours <= MAX_TOTAL_HOURS
                    && (repaired != minute.value || nums.len() == 2)
                {
                    totals.push(hours * 60 + repaired);
                }
            }
        }
    }

    // An hours-only total ("2 שע׳" with no minutes shown) still counts.
    for &(hours, h_at) in &hour_hits {
        if hours > MAX_TOTAL_HOURS {
            continue;
        }
        if minute_hits
            .iter()
            .any(|(_, m_at)| *m_at > h_at && m_at - h_at <= MAX_TOTAL_SPAN)
        {
            continue;
        }
        totals.push(hours * 60);
    }

    if totals.is_empty() {
        // No unit text survived at all. A bare pair is only unambiguous when the
        // text holds exactly two numbers and nothing else to confuse them with.
        if nums.len() != 2
            || chars
                .iter()
                .any(|c| matches!(c, '月' | '日' | '/' | '.' | '／' | '．'))
        {
            return String::new();
        }
        let (hours, minutes) = (nums[0].value, nums[1].value);
        if hours > MAX_TOTAL_HOURS || minutes >= 60 {
            return String::new();
        }
        // The two halves of a total sit next to each other ("7 44", "7 ו44").
        // Without this, any two numbers on the page become a total: a clock
        // reading "4:52 PM" is exactly two numbers with a plausible hour and
        // minute, and was being reported as a 4h 52m day.
        let between: String = chars[nums[0].end..nums[1].start].iter().collect();
        if nums[1].start - nums[0].end > MAX_ADJACENCY_GAP || between.contains(':') {
            return String::new();
        }
        totals.push(hours * 60 + minutes);
    }

    let best = totals.into_iter().max().unwrap_or(0);
    if best == 0 {
        return String::new();
    }
    format!("{}h {}m", best / 60, best % 60)
}

/// Minutes encoded in a `"7h 44m"` string produced by
/// [`extract_localized_total`], or 0 if it is empty / not that shape.
///
/// Callers compare candidates from several reads of the same page and keep the
/// largest, which needs the value back out of the formatted string.
pub fn total_text_minutes(total: &str) -> u32 {
    let mut hours = 0;
    let mut minutes = 0;
    let mut digits = String::new();
    for ch in total.chars() {
        if ch.is_ascii_digit() {
            digits.push(ch);
            continue;
        }
        let value: u32 = digits.parse().unwrap_or(0);
        digits.clear();
        match ch {
            'h' => hours = value,
            'm' => minutes = value,
            _ => {}
        }
    }
    hours * 60 + minutes
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn review_hebrew_dual_hour_has_implicit_quantity_two() {
        assert_eq!(
            extract_localized_total("שעתיים ו11 דק׳", &["heb"]),
            "2h 11m"
        );
        assert_eq!(extract_localized_total("שעה ו11 דק׳", &["heb"]), "1h 11m");
        assert_eq!(extract_localized_total("3 שע׳ 11 דק׳", &["heb"]), "3h 11m");
    }

    #[test]
    fn review_unitless_total_rejects_date_rows() {
        for text in ["9月30日", "9/30", "9.30", "9／30", "9．30"] {
            assert_eq!(extract_localized_total(text, &["jpn"]), "", "{text}");
        }
        assert_eq!(extract_localized_total("9 30", &["jpn"]), "9h 30m");
        assert_eq!(
            extract_localized_total("9月30日 2時間 11分", &["jpn"]),
            "2h 11m"
        );
    }

    #[test]
    fn total_text_minutes_round_trips_the_formatted_form() {
        assert_eq!(total_text_minutes("7h 44m"), 464);
        assert_eq!(total_text_minutes("0h 8m"), 8);
        assert_eq!(total_text_minutes("13h 0m"), 780);
        assert_eq!(total_text_minutes(""), 0);
        assert_eq!(total_text_minutes("not a total"), 0);
    }

    /// Verbatim engine output for the whole reference frame
    /// (`tests/fixtures/images/hebrew_rtl_daily_16pro_downscaled.jpeg`). The
    /// category rows below the chart repeat both unit words, which is what makes
    /// naive first-match extraction read 4h 44m or 0h 8m.
    const REFERENCE_PAGE: &str = "(> be N 21:08 iPhone > or שבוע זמן מסך היום, 5 באוגוסט 7 ו44 דק' | || \
Sie Bats pies 6 ד' . ₪ Tan תיירות אחרים 4 שע' ו8 'TT 1 דק' 4 דק' \
עודכן היום, 21:07 בשימוש הנפוץ ביותר הצגת קטגוריות WhatsApp Waze Safari";

    #[test]
    fn reads_the_real_total_off_the_whole_page() {
        assert_eq!(extract_localized_total(REFERENCE_PAGE, &["heb"]), "7h 44m");
    }

    #[test]
    fn recovers_hours_when_the_hour_word_did_not_survive() {
        assert_eq!(extract_localized_total("7 ו44 דק'", &["heb"]), "7h 44m");
    }

    #[test]
    fn is_not_fooled_by_the_date_line_above_the_total() {
        assert_eq!(
            extract_localized_total("זמן מסך היום, 5 באוגוסט 7 ו44 דק'", &["heb"]),
            "7h 44m"
        );
    }

    /// Chromium's decode of the reference capture reads the minute word with an
    /// extra yod. Nothing else about the header changes, so the total has to
    /// survive it — otherwise only the category rows match and the page reads
    /// 4h 8m, which is what the browser did before the token clipping was made
    /// symmetric.
    #[test]
    fn survives_an_inserted_letter_in_the_unit_word() {
        assert_eq!(
            extract_localized_total("זמן מסך היום, 5 באוגוסט 7 ' 44 דקי'", &["heb"]),
            "7h 44m"
        );
    }

    /// Verbatim OCR of `tests/fixtures/images/IMG_0809 Cropped.png`, whose real
    /// total is "1m".
    const REAL_ENGLISH_PAGE: &str = "fQ Colorscapes SCREEN TIME 1m Daily Average Updated today \
at 4:52 PM INFO Sa Colorscapes Ww Category Age Rating Developer LIMITS Add Limit 1% 15s Games \
12+ Playflux";

    /// A pack must never turn "no total" into a confident wrong one. The
    /// catalogue ships one-letter units for about a third of its locales, and
    /// unanchored matching found those letters inside ordinary English words —
    /// measured on this page, nld read "1h 15m" and nor "15h 0m".
    #[test]
    fn does_not_invent_totals_from_an_english_page() {
        for code in [
            "fra", "spa", "ita", "por", "ron", "ces", "nor", "fin", "hun",
        ] {
            assert_eq!(
                extract_localized_total(REAL_ENGLISH_PAGE, &[code]),
                "",
                "for {code}"
            );
        }
        // The page's own "1m" is a genuine minute unit, digit-adjacent.
        assert_eq!(
            extract_localized_total(REAL_ENGLISH_PAGE, &["nld"]),
            "0h 1m"
        );
    }

    #[test]
    fn a_unit_letter_inside_a_word_is_not_a_unit() {
        assert_eq!(extract_localized_total("8 Chat", &["ita"]), "");
        assert_eq!(extract_localized_total("Today 7 memories", &["nld"]), "");
    }

    #[test]
    fn a_clock_reading_is_not_a_total() {
        assert_eq!(
            extract_localized_total("Updated today at 4:52 PM", &["spa"]),
            ""
        );
        assert_eq!(extract_localized_total("Today 21:08 Notes", &["hun"]), "");
        assert_eq!(extract_localized_total("15s Games 12+", &["nld"]), "");
    }

    #[test]
    fn matches_across_apostrophe_variants() {
        assert_eq!(extract_localized_total("3 שע׳ 15 דק׳", &["heb"]), "3h 15m");
        assert_eq!(extract_localized_total("3 שע' 15 דק'", &["heb"]), "3h 15m");
    }

    #[test]
    fn repairs_rtl_conjunction_fused_to_minutes() {
        assert_eq!(extract_localized_total("7 101 דק׳", &["heb"]), "7h 10m");
        assert_eq!(extract_localized_total("7 xyz 101 דק׳", &["heb"]), "7h 10m");
        assert_eq!(extract_localized_total("4 191 דק׳", &["heb"]), "4h 19m");
        assert_eq!(extract_localized_total("7 281 דק׳", &["heb"]), "7h 28m");
        assert_eq!(extract_localized_total("5 שע׳ 331 TT", &["heb"]), "5h 33m");
    }

    #[test]
    fn reads_minutes_when_only_their_unit_is_lost() {
        assert_eq!(extract_localized_total("5 שע׳ ו39 TT", &["heb"]), "5h 39m");
    }

    #[test]
    fn singular_hour_unit_implies_one() {
        assert_eq!(extract_localized_total("שעה ו11 דק׳", &["heb"]), "1h 11m");
        assert_eq!(extract_localized_total("ساعة 15 دقيقة", &["ara"]), "1h 15m");
    }

    #[test]
    fn reads_other_locales() {
        assert_eq!(
            extract_localized_total("2 ساعات 15 دقيقة", &["ara"]),
            "2h 15m"
        );
        assert_eq!(
            extract_localized_total("3 Std. 20 Min.", &["deu"]),
            "3h 20m"
        );
        assert_eq!(
            extract_localized_total("2 tuntia 30 min", &["fin"]),
            "2h 30m"
        );
        assert_eq!(extract_localized_total("4 часа 25 мин", &["rus"]), "4h 25m");
        // Single-glyph CJK/Hangul units must survive the length rule aimed at
        // stray Latin letters.
        assert_eq!(extract_localized_total("5 시간 12 분", &["kor"]), "5h 12m");
        assert_eq!(
            extract_localized_total("1 小时 30 分钟", &["chi_sim"]),
            "1h 30m"
        );
        assert_eq!(extract_localized_total("4 時間 5 分", &["jpn"]), "4h 5m");
    }

    #[test]
    fn hours_only_total() {
        assert_eq!(extract_localized_total("2 שע'", &["heb"]), "2h 0m");
    }

    #[test]
    fn declines_rather_than_inventing() {
        for text in [
            "",
            "   ",
            "Today, August 5",
            "21:08 5 71 4Al 7 5 24",
            "99 שע 99 דק",
            "0 שע' 0 דק'",
        ] {
            assert_eq!(extract_localized_total(text, &["heb"]), "", "for {text:?}");
        }
        assert_eq!(extract_localized_total("49 שע' 10 דק'", &["heb"]), "");
    }

    #[test]
    fn bare_pair_only_when_unambiguous() {
        assert_eq!(extract_localized_total("7 44", &["heb"]), "7h 44m");
        assert_eq!(extract_localized_total("7 44 12", &["heb"]), "");
    }

    #[test]
    fn unselected_and_unknown_languages_are_harmless() {
        assert_eq!(extract_localized_total(REFERENCE_PAGE, &["ara"]), "");
        assert_eq!(extract_localized_total("7 44", &["klingon"]), "7h 44m");
        assert_eq!(extract_localized_total(REFERENCE_PAGE, &["klingon"]), "");
    }
}
