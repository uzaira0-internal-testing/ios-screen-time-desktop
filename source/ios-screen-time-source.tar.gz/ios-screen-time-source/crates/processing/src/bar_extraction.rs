//! Bar graph value extraction from ROI regions.
//!
//! Port of Python bar_extraction.py — extracts 24 hourly usage values
//! by analyzing pixel colors and measuring bar heights.

use std::cmp::Ordering;

use image::RgbImage;

use super::{
    generated_constants::{
        APPORTION_MAX_MINUTES, APPORTION_MAX_PERCENT, APPORTION_MIN_REGISTRATION,
        BAR_GAP_TOLERANCE_PX, GRID_REG_DEADBAND, GRID_REG_TOL,
    },
    image_utils::darken_and_binarize,
    types::GridBounds,
};

/// Number of hourly slices in the bar graph.
const NUM_SLICES: usize = 24;

/// Map the 24 left-to-right slices onto clock hours 0..23.
///
/// `slice_image` always scans the ROI left-to-right, which equals hours 0..23
/// only when the chart's time axis reads that way. RTL locales (Hebrew, Arabic)
/// mirror the chart, putting hour 0 at the right edge, so the slices must be
/// reversed. Any trailing element (callers append a total) stays in place —
/// only the 24 hour cells move.
///
/// This is the single point where slices become hours; mirrors Python
/// `bar_extraction.py::orient_hours`.
pub fn orient_hours(row: &mut [f64], axis_direction: crate::types::AxisDirection) {
    if axis_direction.reverses_hours() {
        let n = NUM_SLICES.min(row.len());
        row[..n].reverse();
    }
}
/// Maximum minutes per hour (y-axis ceiling).
const MAX_Y: f64 = 60.0;
/// Largest y-axis ceiling that can be believed, in minutes. A single hourly bar
/// cannot exceed 60 minutes of real usage, but an "All Devices" chart sums
/// several devices into one hour, so the axis legitimately runs past 60 — iOS
/// picks a round `Nh` label above the busiest hour. 24h is the ceiling of what
/// any label could mean; a larger parse is a misread, not a chart.
const MAX_AXIS_MINUTES: f64 = 24.0 * 60.0;
/// Pixels to exclude at the bottom of the ROI (grid line buffer).
const LOWER_GRID_BUFFER: usize = 2;

/// Row at which a column's bar begins: one past the bottom of the lowest white
/// run LONGER than `gap_tol` rows within `0..reset_limit`, or 0 when the column
/// has no such run (the bar reaches the top of the ROI).
///
/// This is the anchor every bar measurement shares. It used to be "the lowest
/// white pixel", which is wrong for a stacked bar: iOS separates the category
/// segments with a 1-px hairline of background (and in dark mode the horizontal
/// gridlines bleed through a bar the same way), so after binarization one white
/// row sits INSIDE the bar and only the segment below it was counted. On real
/// participant captures that read single bars 11-36 minutes short, exactly the
/// printed-total shortfall, and no grid adjustment could fix it because the cut
/// is inside the bar. `gap_tol` is `BAR_GAP_TOLERANCE_PX` in the caller's pixel
/// space (×4 on the 4x-scaled paths). With `gap_tol == 0` this is the old rule.
///
/// Mirrors Python `bar_extraction.py::_bar_start_rows` bit-for-bit.
fn bar_start_row(is_white: impl Fn(usize) -> bool, reset_limit: usize, gap_tol: usize) -> usize {
    let mut white_run = 0usize;
    for y in (0..reset_limit).rev() {
        if is_white(y) {
            white_run += 1;
            if white_run > gap_tol {
                // The run spans y..=y+white_run-1; the bar starts just below it.
                return y + white_run;
            }
        } else {
            white_run = 0;
        }
    }
    // Every scanned row was white but the column is shorter than the tolerance:
    // still "no bar" (start at reset_limit), never "bar from the top".
    if white_run == reset_limit {
        reset_limit
    } else {
        0
    }
}

/// Rows a bar occupies at or below `start_after`: the span from its first black
/// row to its last, so a hairline bridged by [`bar_start_row`] counts as bar.
///
/// The hairline between stacked category segments is drawn INSIDE the bar's
/// height. Counting only black rows found the right top and then lost one row
/// per hairline: measured on 170 participant captures, exact printed-total
/// matches went 156 -> 167 with this span, no capture overshot, and no bar moved
/// by more than one minute. Every white run in the span is within the tolerance
/// by construction (`start_after` sits below the lowest longer one).
fn bar_span(is_black: impl Fn(usize) -> bool, start_after: usize, h: usize) -> u32 {
    // ponytail: a dark speck on the sampled column within the gap tolerance above a
    // bar reads as the bar's top (at most +tolerance rows, under half a minute on a
    // real chart). A real one-row bar top above a two-row dark-mode gridline has the
    // same column profile (darkmode_daily_02), so the column alone cannot tell them
    // apart; check the row's width here if specks ever show up in captures.
    let first = (start_after..h).find(|&y| is_black(y));
    let last = (start_after..h).rev().find(|&y| is_black(y));
    match (first, last) {
        (Some(f), Some(l)) => (l - f + 1) as u32,
        _ => 0,
    }
}
/// Mean hourly displacement (in hours) at which the positional alignment term
/// saturates to 0. Tuned so a 1-hour mean shift lands on the 0.5 warning line and
/// a ≥2-hour shift reads as "poor" — significant misalignment for this use case.
const POS_SATURATION_HOURS: f64 = 2.0;

// ── Grid-registration (structural) constants ─────────────────────────────────
// `compute_grid_registration_score` is a *value-independent* cross-check: it asks
// "is this ROI framed on the chart correctly?" by locating the horizontal
// gridlines and testing them against the expected lattice — orthogonal to the
// value-vs-remeasurement alignment score above.
/// A row counts as a horizontal gridline when at least this percent of its width
/// is black after binarization. Bars (≤~60% of a slice, with inter-bar gaps) never
/// span the full width, so this cleanly separates gridlines from bar mass.
const GRIDLINE_COVERAGE_PCT: u32 = 90;
/// Expected gridline positions as fractions of ROI height: the top border / "60"
/// line plus the evenly-spaced quarter lines. The 0-baseline at the very bottom is
/// NOT a rendered full-width line (it sits under the hour-label band), so the
/// pattern anchors on {0, ¼, ½, ¾} — empirically where every supported layout lands.
const EXPECTED_GRIDLINE_FRACS: [f64; 4] = [0.0, 0.25, 0.5, 0.75];
// `GRID_REG_DEADBAND` (framing offset, as a height fraction, treated as perfect) and
// `GRID_REG_TOL` (offset at which a registration term saturates to 0) are the
// sensitivity knobs and live in shared/processing_constants.json → generated_constants
// (imported above), so server/WASM/UI stay in lock-step. Relaxed to deadband 0.03 /
// tol 0.10 so a harmless ~2-3% framing offset no longer warns; a ≥10% offset still
// reads "poor". They (and the apportionment knobs) are now *user-adjustable* in the
// Settings UI and threaded into the pipeline as a `ScoringConfig`; the generated
// constants remain the canonical defaults.

/// Runtime overrides for the apportionment + grid-registration scoring knobs.
///
/// Defaults come from the SSoT generated constants; the Settings UI can override
/// any of them per device. Threaded into [`crate::pipeline::extract_and_score`]
/// (server) and `pipeline_process` (WASM). Built with [`ScoringConfig::from_overrides`]
/// at the C-ABI / PyO3 boundary, where a *negative* value is the "use the compiled
/// default" sentinel (so a legitimate `apportion_max_minutes = 0` — apportionment off
/// — and `grid_reg_deadband = 0` are still honoured).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ScoringConfig {
    pub apportion_max_minutes: i32,
    /// When > 0, this percent of the OCR total is ONE of the apportionment caps.
    /// It is not exclusive with `apportion_max_minutes`: the configured cap is the
    /// LARGER of the two, so apportionment is disabled only when BOTH are ≤ 0. A
    /// percentage alone shrinks to nothing on short days (2% of a printed `9m`
    /// rounds to 0), which is why the absolute floor still applies alongside it.
    /// See [`apportion_to_total_cfg`].
    pub apportion_max_percent: f64,
    pub apportion_min_registration: f64,
    pub grid_reg_deadband: f64,
    pub grid_reg_tol: f64,
}

impl Default for ScoringConfig {
    fn default() -> Self {
        Self {
            apportion_max_minutes: APPORTION_MAX_MINUTES,
            apportion_max_percent: APPORTION_MAX_PERCENT,
            apportion_min_registration: APPORTION_MIN_REGISTRATION,
            grid_reg_deadband: GRID_REG_DEADBAND,
            grid_reg_tol: GRID_REG_TOL,
        }
    }
}

impl ScoringConfig {
    /// Build from raw overrides; any sentinel (negative) field falls back to the
    /// compiled SSoT default. `grid_reg_tol` additionally falls back when ≤ 0
    /// because it is a divisor in the scorer (a 0 tolerance would divide by zero).
    pub fn from_overrides(
        apportion_max_minutes: i32,
        apportion_max_percent: f64,
        apportion_min_registration: f64,
        grid_reg_deadband: f64,
        grid_reg_tol: f64,
    ) -> Self {
        let d = Self::default();
        Self {
            apportion_max_minutes: if apportion_max_minutes < 0 {
                d.apportion_max_minutes
            } else {
                apportion_max_minutes
            },
            apportion_max_percent: if apportion_max_percent < 0.0 {
                d.apportion_max_percent
            } else {
                apportion_max_percent
            },
            apportion_min_registration: if apportion_min_registration < 0.0 {
                d.apportion_min_registration
            } else {
                apportion_min_registration
            },
            grid_reg_deadband: if grid_reg_deadband < 0.0 {
                d.grid_reg_deadband
            } else {
                grid_reg_deadband
            },
            grid_reg_tol: if grid_reg_tol <= 0.0 {
                d.grid_reg_tol
            } else {
                grid_reg_tol
            },
        }
    }
}

/// Fast bar total extraction at 1x — used only as fallback.
/// For the boundary optimizer, use `compute_bar_total_from_scaled` instead.
pub fn slice_image_fast_total(
    img: &RgbImage,
    roi_x: u32,
    roi_y: u32,
    roi_width: u32,
    roi_height: u32,
) -> f64 {
    let (img_w, img_h) = img.dimensions();
    let roi_x = roi_x.min(img_w);
    let roi_y = roi_y.min(img_h);
    let roi_width = roi_width.min(img_w.saturating_sub(roi_x));
    let roi_height = roi_height.min(img_h.saturating_sub(roi_y));

    if roi_width < NUM_SLICES as u32 || roi_height < 2 {
        return 0.0;
    }

    let mut roi = image::imageops::crop_imm(img, roi_x, roi_y, roi_width, roi_height).to_image();
    darken_and_binarize(&mut roi);

    let h = roi_height as usize;
    let rw = roi_width as usize;
    let reset_limit = h.saturating_sub(LOWER_GRID_BUFFER).max(1);

    let raw = roi.as_raw();
    let stride = rw * 3;
    let mut total = 0.0f64;

    for s in 0..NUM_SLICES {
        let mid_col = ((2 * s + 1) * rw / (2 * NUM_SLICES)).min(rw - 1);
        // 1x path: the tolerance is in native pixels already.
        let start_after = bar_start_row(
            |y| {
                let idx = y * stride + mid_col * 3;
                raw[idx] >= 253 && raw[idx + 1] >= 253 && raw[idx + 2] >= 253
            },
            reset_limit,
            BAR_GAP_TOLERANCE_PX,
        );
        let counter = bar_span(
            |y| {
                let idx = y * stride + mid_col * 3;
                raw[idx] as u16 + raw[idx + 1] as u16 + raw[idx + 2] as u16 == 0
            },
            start_after,
            h,
        );
        total += (MAX_Y * counter as f64 / h as f64).floor();
    }
    total
}

/// Precompute a binarized + 4x-scaled image for the boundary optimizer.
///
/// The optimizer calls `compute_bar_total_from_scaled` ~1300 times.
/// By scaling the ENTIRE image once, each iteration only does a direct
/// buffer read — no per-iteration crop/resize/binarize.
pub fn preprocess_for_optimizer(img: &RgbImage) -> (Vec<u8>, u32, u32) {
    let (w, h) = img.dimensions();
    let mut binarized = img.clone();
    darken_and_binarize(&mut binarized);

    const SCALE: u32 = 4;
    let scaled = image::imageops::resize(
        &binarized,
        w * SCALE,
        h * SCALE,
        image::imageops::FilterType::Nearest,
    );
    let sw = w * SCALE;
    let sh = h * SCALE;
    (scaled.into_raw(), sw, sh)
}

/// Compute bar total directly from a pre-scaled buffer (zero allocation per call).
///
/// `scaled_data`: raw RGB bytes from `preprocess_for_optimizer`
/// `scaled_width`: width of the scaled image
/// roi coordinates are in ORIGINAL (1x) space — this function scales them.
pub fn compute_bar_total_from_scaled(
    scaled_data: &[u8],
    scaled_width: u32,
    roi_x: u32,
    roi_y: u32,
    roi_width: u32,
    roi_height: u32,
) -> f64 {
    const SCALE: u32 = 4;
    let sx = roi_x * SCALE;
    let sy = roi_y * SCALE;
    let sw = roi_width * SCALE;
    let sh = roi_height * SCALE;

    if sw < (NUM_SLICES as u32) || sh < 2 {
        return 0.0;
    }

    let h = sh as usize;
    let rw = sw as usize;
    // Canvas: analyzeBarHeight checks y < maxHeight - LOWER_GRID_BUFFER where maxHeight is
    // already 4x-scaled. So exclude LOWER_GRID_BUFFER pixels from the 4x image (not SCALE*BUFFER).
    let reset_limit = h.saturating_sub(LOWER_GRID_BUFFER).max(1);

    let stride = (scaled_width * 3) as usize;
    let mut total = 0.0f64;

    for s in 0..NUM_SLICES {
        let mid_col =
            (sx as usize + (2 * s + 1) * rw / (2 * NUM_SLICES)).min(scaled_width as usize - 1);
        let start_after = bar_start_row(
            |y| {
                let global_y = sy as usize + y;
                let idx = global_y * stride + mid_col * 3;
                idx + 2 < scaled_data.len()
                    && scaled_data[idx] >= 253
                    && scaled_data[idx + 1] >= 253
                    && scaled_data[idx + 2] >= 253
            },
            reset_limit,
            BAR_GAP_TOLERANCE_PX * SCALE as usize,
        );
        let counter = bar_span(
            |y| {
                let idx = (sy as usize + y) * stride + mid_col * 3;
                idx + 2 < scaled_data.len()
                    && scaled_data[idx] as u16
                        + scaled_data[idx + 1] as u16
                        + scaled_data[idx + 2] as u16
                        == 0
            },
            start_after,
            h,
        );
        total += (MAX_Y * counter as f64 / h as f64).floor();
    }
    total
}

/// Extract hourly usage values from the bar graph region.
///
/// Returns a Vec of 25 elements: 24 hourly values + total.
///
/// Port of Python `slice_image()`.
pub fn slice_image(
    img: &RgbImage,
    roi_x: u32,
    roi_y: u32,
    roi_width: u32,
    roi_height: u32,
) -> Vec<f64> {
    slice_image_with_residuals(img, roi_x, roi_y, roi_width, roi_height).0
}

/// [`slice_image`] for a chart whose y-axis tops out somewhere other than 60
/// minutes.
///
/// iOS scales the hourly chart's axis to the busiest hour: an "All Devices"
/// capture routinely prints `2h / 1h / 0` instead of `60 / 0`. The plot's full
/// height is then 120 minutes, and reading it as 60 reports exactly half of
/// every hour — silently, with a plausible-looking chart. Measured on
/// `tests/fixtures/images/ios26_light/IMG_7876.PNG`, which prints `2h 31m`
/// (151 minutes) and extracted 74.
///
/// `axis_max_minutes` is the value of the TOP gridline, which is where
/// `calculate_roi` puts the top of the ROI. Pass [`MAX_Y`] for an ordinary
/// chart; [`slice_image`] does exactly that.
pub fn slice_image_scaled(
    img: &RgbImage,
    roi_x: u32,
    roi_y: u32,
    roi_width: u32,
    roi_height: u32,
    axis_max_minutes: f64,
) -> Vec<f64> {
    slice_image_with_residuals_scaled(img, roi_x, roi_y, roi_width, roi_height, axis_max_minutes).0
}

/// Like [`slice_image`], but also returns the per-slice fractional remainder that
/// the integer `floor()` discarded (`60·counter/h − floor(60·counter/h)`, one per
/// of the 24 slices). The bar-sum systematically undershoots the true total by the
/// sum of these residuals, so [`apportion_to_total`] uses them to hand the OCR/bar
/// minute gap back to the bars that lost the most to flooring (largest-remainder).
///
/// Port of Python `slice_image_with_residuals()`.
pub fn slice_image_with_residuals(
    img: &RgbImage,
    roi_x: u32,
    roi_y: u32,
    roi_width: u32,
    roi_height: u32,
) -> (Vec<f64>, Vec<f64>) {
    slice_image_with_residuals_scaled(img, roi_x, roi_y, roi_width, roi_height, MAX_Y)
}

/// [`slice_image_with_residuals`] against a y-axis whose top gridline is
/// `axis_max_minutes` rather than the usual 60. See [`slice_image_scaled`].
pub fn slice_image_with_residuals_scaled(
    img: &RgbImage,
    roi_x: u32,
    roi_y: u32,
    roi_width: u32,
    roi_height: u32,
    axis_max_minutes: f64,
) -> (Vec<f64>, Vec<f64>) {
    // A non-positive or absurd ceiling would silently zero or explode every bar;
    // fall back to the ordinary axis rather than emitting garbage.
    let max_y = if axis_max_minutes.is_finite()
        && axis_max_minutes > 0.0
        && axis_max_minutes <= MAX_AXIS_MINUTES
    {
        axis_max_minutes
    } else {
        MAX_Y
    };

    // Clamp ROI to image bounds to prevent silent truncation
    let (img_w, img_h) = img.dimensions();
    let roi_x = roi_x.min(img_w);
    let roi_y = roi_y.min(img_h);
    let roi_width = roi_width.min(img_w.saturating_sub(roi_x));
    let roi_height = roi_height.min(img_h.saturating_sub(roi_y));

    if roi_width < NUM_SLICES as u32 || roi_height < 2 {
        // ROI too small to extract meaningful data — return zeros
        return (vec![0.0; NUM_SLICES + 1], vec![0.0; NUM_SLICES]);
    }

    // Extract ROI, process, then scale up 4x for sub-pixel precision.
    //
    // Sample fractional slice centres across the full ROI width at 4x precision.
    let mut roi_processed =
        image::imageops::crop_imm(img, roi_x, roi_y, roi_width, roi_height).to_image();
    darken_and_binarize(&mut roi_processed);

    // The measurement runs on the 4x nearest-neighbour upscale, but that image is
    // never built: at an exact 4x ratio `imageops::resize(.., Nearest)` copies
    // every source pixel into a 4x4 block (single tap, weight 1, no blending), so
    // upscaled pixel (x, y) IS source pixel (x / 4, y / 4). Reading the source at
    // quarter coordinates gives identical values without the 16x allocation.
    const SCALE: u32 = 4;
    const S: usize = SCALE as usize;

    let h = (roi_height * SCALE) as usize;
    let rw = (roi_width * SCALE) as usize;

    // Canvas: analyzeBarHeight checks y < maxHeight - LOWER_GRID_BUFFER where maxHeight is
    // already 4x-scaled. So 2 pixels excluded from 4x image, not 2*SCALE.
    let reset_limit = h.saturating_sub(LOWER_GRID_BUFFER).max(1);

    let mut row = Vec::with_capacity(NUM_SLICES + 1);
    let mut residuals = Vec::with_capacity(NUM_SLICES);

    // Use raw buffer for direct pixel access (3 bytes per pixel)
    let raw = roi_processed.as_raw();
    let stride = roi_width as usize * 3;

    for s in 0..NUM_SLICES {
        // Middle column of this slice
        let mid_col = ((2 * s + 1) * rw / (2 * NUM_SLICES)).min(rw - 1);

        // Bar top = below the lowest white run wider than the hairline tolerance
        // (scanning from bottom up). White check: all channels >= 253.
        let start_after = bar_start_row(
            |y| {
                let idx = (y / S) * stride + (mid_col / S) * 3;
                raw[idx] >= 253 && raw[idx + 1] >= 253 && raw[idx + 2] >= 253
            },
            reset_limit,
            BAR_GAP_TOLERANCE_PX * SCALE as usize,
        );

        // Count black pixels below start_after
        let counter = bar_span(
            |y| {
                let idx = (y / S) * stride + (mid_col / S) * 3;
                raw[idx] as u16 + raw[idx + 1] as u16 + raw[idx + 2] as u16 == 0
            },
            start_after,
            h,
        );

        let div = max_y * counter as f64 / h as f64;
        let value = div.floor();
        row.push(value);
        // Sub-minute fraction the floor threw away (in [0, 1)); apportionment
        // hands the OCR/bar gap to the slices with the largest of these.
        residuals.push(div - value);
    }

    // Append total
    let total: f64 = row.iter().sum();
    row.push(total);

    (row, residuals)
}

/// Slice the chart against a detected y-axis ceiling, keeping the ordinary
/// 60-minute reading unless the rescaled one demonstrably fits the OCR total
/// better.
///
/// Returns `(row, residuals, applied_axis_max, detected_axis_max)`.
///
/// `applied_axis_max` is the ceiling the returned values were actually measured
/// at — never a ceiling that was read but not used. `detected_axis_max` is what
/// the label said, whether or not it was believed, so a caller can tell "no
/// hour-scaled axis here" apart from "read one and rejected it".
///
/// The detected label is evidence, not proof — a misread ceiling would multiply
/// every bar by a wrong constant, which is exactly the class of silent damage
/// this whole change exists to remove. So the printed total arbitrates:
/// whichever ceiling puts the bar sum closer to it wins. `IMG_7876` prints 151
/// minutes and reads 74 at 60 (77 out) versus ~148 at 120 (~3 out), so the
/// rescale wins on evidence rather than on trust.
///
/// With NO printed total there is nothing to arbitrate against, and the label is
/// then deliberately NOT believed: `AXIS_LABEL_SCALE`'s own note records that a
/// `1h` label reads as `th`/`4h`, so trusting it unchecked would multiply every
/// bar by 4 on exactly the screenshots that have no cross-check — the same
/// silent-wrong-number failure in the opposite direction. Those fall back to the
/// ordinary 60-minute reading (what they got before this existed) and report the
/// unapplied ceiling so a reviewer sees the chart needs a human.
pub fn slice_with_axis_scale(
    img: &RgbImage,
    roi_x: u32,
    roi_y: u32,
    roi_width: u32,
    roi_height: u32,
    axis_max_minutes: Option<i32>,
    ocr_total_minutes: Option<i32>,
) -> (Vec<f64>, Vec<f64>, f64, Option<f64>) {
    let base = slice_image_with_residuals(img, roi_x, roi_y, roi_width, roi_height);
    // Validate ONCE, here, against the same bound `slice_image_with_residuals_scaled`
    // enforces internally. Without this the arbitration could hand back a ceiling
    // the slicer silently clamped away, and callers persist that number as review
    // evidence — a warning that lies about the scale the data was computed at.
    let Some(axis_max) = axis_max_minutes
        .map(|m| m as f64)
        .filter(|&m| m > MAX_Y && m <= MAX_AXIS_MINUTES)
    else {
        return (base.0, base.1, MAX_Y, None);
    };
    let Some(target) = ocr_total_minutes.filter(|&t| t > 0) else {
        return (base.0, base.1, MAX_Y, Some(axis_max));
    };
    let scaled =
        slice_image_with_residuals_scaled(img, roi_x, roi_y, roi_width, roi_height, axis_max);

    let sum = |row: &[f64]| row.iter().take(NUM_SLICES).sum::<f64>();
    let target = target as f64;
    if (sum(&scaled.0) - target).abs() < (sum(&base.0) - target).abs() {
        (scaled.0, scaled.1, axis_max, Some(axis_max))
    } else {
        (base.0, base.1, MAX_Y, Some(axis_max))
    }
}

/// Reconcile the per-slice bar values with the OCR total by handing back the
/// minutes the per-slice `floor()` discarded.
///
/// `slice_image` floors each bar to whole minutes, so the bar-sum systematically
/// lands a minute or two *under* the true total while the OCR total is ground
/// truth. When the gap `ocr_total_minutes − Σbars` is within
/// [`APPORTION_MAX_MINUTES`], the leftover minutes are added to the bars whose
/// floored-away [`residual`] was largest (the "least overlapping" bars — those the
/// rounding shortchanged most), one minute each, largest-remainder style. A
/// negative gap (bars over the OCR total, rare since `floor()` undershoots)
/// symmetrically removes a minute from the smallest-residual non-zero bars.
///
/// Mutates `hourly` in place and returns `true` iff it adjusted anything. A zero
/// gap, an out-of-tolerance gap, or a disabled `APPORTION_MAX_MINUTES` leave
/// `hourly` untouched. (The grid-registration gate was removed — see
/// [`apportion_to_total_cfg`].)
///
/// Port of Python `apportion_to_total()` — the two MUST stay behaviourally
/// identical (pinned by tests/unit/test_cross_impl_parity.py).
pub fn apportion_to_total(
    hourly: &mut [f64],
    residuals: &[f64],
    ocr_total_minutes: i32,
    grid_registration_score: f64,
) -> bool {
    apportion_to_total_cfg(
        hourly,
        residuals,
        ocr_total_minutes,
        grid_registration_score,
        APPORTION_MAX_MINUTES,
        APPORTION_MAX_PERCENT,
        APPORTION_MIN_REGISTRATION,
    )
}

/// [`apportion_to_total`] with the `max_minutes` tolerance and `min_registration`
/// gate supplied at runtime (from the Settings UI) instead of the compiled
/// constants. The no-arg version delegates here with the SSoT defaults, so the
/// behaviour — and the cross-impl parity pins — are unchanged when no override is set.
pub fn apportion_to_total_cfg(
    hourly: &mut [f64],
    residuals: &[f64],
    ocr_total_minutes: i32,
    _grid_registration_score: f64,
    max_minutes: i32,
    max_percent: f64,
    _min_registration: f64,
) -> bool {
    // The grid-registration gate was removed: the registration score proved
    // unreliable (false low scores blocked apportionment on screenshots that
    // extracted correctly), so apportionment now applies whenever the OCR total
    // is known and the gap is within the cap. The `grid_registration_score`
    // / `min_registration` params are retained for signature + WASM C-ABI
    // stability but no longer gate.
    //
    // The cap is the LARGER of the absolute `max_minutes` and `max_percent`% of
    // the OCR total (rounded to the nearest minute). A percentage alone scales
    // with the day, but it SHRINKS on short days: at 2%, a printed `9m` yields a
    // cap of 0.18 → 0, so a bar sum of 7 could never be corrected to the 9 the
    // screenshot prints. Measured on `ios26_light/IMG_7884.PNG`, which regressed
    // 9 → 7 when the percentage replaced the absolute cap instead of raising it.
    let percent_cap = if max_percent > 0.0 {
        ((max_percent / 100.0) * ocr_total_minutes as f64).round() as i32
    } else {
        0
    };
    // Third cap, and the only one derived from evidence rather than taste: the
    // minutes `floor()` actually threw away. The exact total is
    // `Σbars + Σresiduals`, so a gap no larger than `Σresiduals` is arithmetic
    // this function can undo exactly — it hands back minutes that were measured
    // and then discarded, and can never invent one that was not.
    //
    // Without it, a busy day sits just outside a percentage cap forever:
    // `darkmode_daily_03` prints 182, extracts 173, and discarded 9.00 minutes to
    // flooring; at 2% the cap is 3, so 9 real minutes stayed lost. Measured the
    // same way: `darkmode_daily_02` (gap 9, discarded 9.56), `IMG_7871` and
    // `IMG_7882` (gap 4, discarded 4.00), `IMG_7885` (gap 3, discarded 3.67).
    //
    // Never floored: two of those sums land on EXACTLY 9.00 and 4.00, so
    // `floor()` would hang on the last bit of a 24-term float addition and drop a
    // minute at random (see the ceiling below). A misread OCR total is still rejected — its gap is
    // nowhere near what flooring lost.
    //
    // It widens an ENABLED cap; it never re-enables a disabled one. Setting both
    // knobs to 0 in the Settings UI means "do not touch my bars", and evidence
    // that some minutes were floored away is not a reason to overrule that.
    //
    // It is also ONE-DIRECTIONAL, and that is the whole point. `floor()` can only
    // make a bar too SMALL, so Σresiduals justifies handing minutes BACK (a
    // positive gap) and says nothing whatever about an overshoot. Applying it to
    // `diff.abs()` would widen the SUBTRACT branch from a couple of minutes to
    // ~Σresiduals (10-20 on a busy 24-bar chart), so a printed total misread LOW
    // would sail through the cap and delete correctly measured minutes from bars
    // that flooring never touched — manufacturing a day that agrees perfectly
    // with a misread number. The configured knobs still bound both directions.
    let configured_cap = max_minutes.max(percent_cap);
    if configured_cap <= 0 {
        return false;
    }
    let bar_total: i32 = hourly.iter().sum::<f64>().round() as i32;
    let diff = ocr_total_minutes - bar_total;
    let cap = if diff > 0 {
        // Ceiling, not round: the discarded sum is itself good only to about a
        // pixel per bar, so a gap inside its next whole minute is the same
        // arithmetic. Measured on a participant capture that discarded 10.44 and
        // printed a gap of 11: rounding to 10 left a correctly read day flagged.
        // The epsilon keeps a sum that lands on 9.0000000002 at 9.
        let residual_cap = (residuals.iter().sum::<f64>() - 1e-6).ceil().max(0.0) as i32;
        configured_cap.max(residual_cap)
    } else {
        configured_cap
    };
    if diff == 0 || diff.abs() > cap {
        return false;
    }

    let n = hourly.len().min(residuals.len());
    if diff > 0 {
        // Add minutes to the bars the floor shortchanged most (largest residual);
        // a genuinely empty bar has residual 0 and is never picked (no phantom bars).
        let mut idx: Vec<usize> = (0..n).filter(|&i| residuals[i] > APPORTION_EPS).collect();
        idx.sort_by(|&a, &b| {
            residuals[b]
                .partial_cmp(&residuals[a])
                .unwrap_or(Ordering::Equal)
                .then(a.cmp(&b))
        });
        for &i in idx.iter().take(diff as usize) {
            hourly[i] += 1.0;
        }
    } else {
        // Remove minutes from the bars the floor shortchanged least (smallest
        // residual), among bars that still have a minute to give.
        let mut idx: Vec<usize> = (0..n).filter(|&i| hourly[i] >= 1.0).collect();
        idx.sort_by(|&a, &b| {
            residuals[a]
                .partial_cmp(&residuals[b])
                .unwrap_or(Ordering::Equal)
                .then(a.cmp(&b))
        });
        for &i in idx.iter().take((-diff) as usize) {
            hourly[i] -= 1.0;
        }
    }
    true
}

/// Residuals at or below this are treated as zero (an exactly-integer bar that the
/// floor did not shortchange) and are never chosen as apportionment recipients.
const APPORTION_EPS: f64 = 1e-9;

/// Compute alignment score between the visible bar graph and the computed values.
///
/// Returns a score from 0.0 to 1.0 where 1.0 = the values match the bars.
///
/// This is a *cross-check*, not a re-run of the extractor. It independently
/// re-measures each bar's height from the SAME robust binarization the real
/// extractor uses (`darken_and_binarize` — theme-agnostic, works in dark mode and
/// for any bar colour), but via the bar's TOP EDGE rather than `slice_image`'s
/// black-pixel count.
///
/// The two re-measured/stored series are then compared with **Earth Mover's
/// Distance** (1-D Wasserstein-1), not mean absolute error. MAE averaged the
/// per-hour gaps over all 24 bins, so on the sparse graphs typical of screen-time
/// data the many correctly-zero hours diluted real errors into the high-0.9s
/// (e.g. "every value zeroed while the bars are clearly present" scored ~0.94).
/// EMD instead measures the *work* to transform one bar distribution into the
/// other:
///
/// * `mass_sim` — total-minutes agreement as a ratio `min(Σm,Σv)/max(Σm,Σv)`;
///   drives "bars present but values zeroed/halved" toward 0 (halved → 0.5).
/// * `pos_sim` — 1-D Wasserstein on the mass-normalized distributions, the mean
///   hourly displacement, rescaled `1 - emd/POS_SATURATION_HOURS`; a 1-hour mean
///   shift → 0.5, ≥2-hour shift → 0.
///
/// The score is their product, both factors in `[0,1]`. The bands are good ≥0.85,
/// acceptable ≥0.70, warning ≥0.50, poor <0.50 (alignment_score_status).
///
/// Port of Python `compute_bar_alignment_score()` — the two MUST stay byte-for-byte
/// identical (enforced by tests/contract/test_server_wasm_parity.py).
pub fn compute_bar_alignment_score(roi: &RgbImage, hourly_values: &[f64]) -> f64 {
    compute_bar_alignment_score_scaled(roi, hourly_values, MAX_Y)
}

/// [`compute_bar_alignment_score`] for values measured against a y-axis that tops
/// out somewhere other than 60 minutes.
///
/// The cross-check re-measures bar heights and converts them to minutes, so it has
/// to use the SAME plot height the values were measured at. Left at a hard-coded
/// 60 it re-measured an hour-scaled chart at half scale and `mass_sim` came out at
/// `min/max = 0.5` — the exact "every value halved" signature the doc above
/// describes — so every chart the axis rescaling got RIGHT scored ~0.5 and told
/// the annotator "Poor Bar Alignment — adjust grid position" over correct data.
/// That is worse than a cosmetic warning: acting on it re-runs the bars-only path,
/// which is where a wrong ceiling can halve the data for real.
pub fn compute_bar_alignment_score_scaled(
    roi: &RgbImage,
    hourly_values: &[f64],
    axis_max_minutes: f64,
) -> f64 {
    let max_y = if axis_max_minutes.is_finite()
        && axis_max_minutes > 0.0
        && axis_max_minutes <= MAX_AXIS_MINUTES
    {
        axis_max_minutes
    } else {
        MAX_Y
    };
    let (roi_width, roi_height) = roi.dimensions();
    if roi_width < NUM_SLICES as u32 || roi_height < 2 {
        return 0.0;
    }

    // Ensure exactly 24 values
    let mut values = [0.0f64; NUM_SLICES];
    for (i, &v) in hourly_values.iter().take(NUM_SLICES).enumerate() {
        values[i] = v;
    }

    // Same binarization + 4x nearest scale as slice_image — proven pixel-identical
    // to the Python path, so this re-measurement stays in parity for free.
    let mut roi_processed = roi.clone();
    darken_and_binarize(&mut roi_processed);
    // Read the 4x upscale at quarter coordinates instead of building it; see
    // slice_image_with_residuals for why that is pixel-identical.
    const SCALE: u32 = 4;
    const S: usize = SCALE as usize;

    let h = (roi_height * SCALE) as usize;
    let rw = (roi_width * SCALE) as usize;
    let raw = roi_processed.as_raw();
    let stride = roi_width as usize * 3;
    // Exclude the bottom grid-line buffer when locating the bar top, exactly like
    // slice_image — so the baseline gridline isn't mistaken for the bar's top edge.
    let reset_limit = h.saturating_sub(LOWER_GRID_BUFFER).max(1);

    // Independently measure each bar's height by its TOP EDGE, anchored at the
    // baseline: scan UP from the bottom to the last white pixel (the gap above the
    // bar — same anchor slice_image uses), then take the height from there to the
    // bottom. Measuring the edge instead of counting black pixels makes this a
    // genuine cross-check (the two diverge on holey/garbled bars), while staying
    // robust to non-bar dark pixels (axis labels, gridlines) near the top.
    let mut measured = [0.0f64; NUM_SLICES];
    for (s, m) in measured.iter_mut().enumerate() {
        let mid_col = ((2 * s + 1) * rw / (2 * NUM_SLICES)).min(rw - 1);
        let start_after = bar_start_row(
            |y| {
                let idx = (y / S) * stride + (mid_col / S) * 3;
                raw[idx] >= 253 && raw[idx + 1] >= 253 && raw[idx + 2] >= 253
            },
            reset_limit,
            BAR_GAP_TOLERANCE_PX * SCALE as usize,
        );
        // start_after == reset_limit means the column is white all the way down to
        // the grid buffer — no bar on the baseline, so height 0 (not the 2px buffer).
        let bar_height = if start_after >= reset_limit {
            0.0
        } else {
            (h - start_after) as f64
        };
        // Floor to integer minutes exactly like slice_image's per-slice value, so a
        // clean solid bar (where top-edge height == black-pixel count) re-measures to
        // the SAME minute the extractor stored — no sub-minute quantization noise
        // inflating the EMD on correct extractions (e.g. a legitimate 1-minute bar).
        // Holey/garbled bars still diverge (black count < top-edge height), keeping
        // this an honest cross-check.
        *m = (max_y * bar_height / h as f64).floor();
    }

    let sum_m: f64 = measured.iter().sum();
    let sum_v: f64 = values.iter().sum();

    // Both empty (no visible bars, no stored values) → perfectly aligned.
    if sum_m == 0.0 && sum_v == 0.0 {
        return 1.0;
    }
    // One side carries all the mass while the other is empty → total disagreement,
    // and the EMD normalization below would divide by zero. (mass_sim is 0 here
    // anyway, so the product would be 0 regardless of pos_sim.)
    if sum_m == 0.0 || sum_v == 0.0 {
        return 0.0;
    }

    // Total-minutes agreement as a RATIO of the smaller total to the larger. A 2×
    // magnitude error (e.g. every value halved) lands on the 0.5 warning line —
    // significant for this use case — instead of the diluted 0.667 a
    // difference-over-sum gave. This is what drives "bars present but values
    // zeroed/halved" low. (sum_m, sum_v both > 0 here, so no divide-by-zero.)
    let mass_sim = sum_m.min(sum_v) / sum_m.max(sum_v);

    // 1-D Earth Mover's Distance (Wasserstein-1) between the two bar distributions,
    // normalized to unit mass so it measures *position*, not height. For 1-D
    // histograms EMD = Σ|CDFₘ - CDFᵥ|, which equals the MEAN hourly displacement of
    // mass — a k-hour shift costs k. Penalizing by how far the mass moved is the
    // property plain per-bin MAE lacked.
    let mut cum_m = 0.0f64;
    let mut cum_v = 0.0f64;
    let mut emd = 0.0f64;
    for i in 0..NUM_SLICES {
        cum_m += measured[i] / sum_m;
        cum_v += values[i] / sum_v;
        emd += (cum_m - cum_v).abs();
    }
    // Rescale by POS_SATURATION_HOURS (not the full NUM_SLICES-1 span): realistic
    // misalignment displaces mass 1-2 hours, not 23, so normalizing by 23 wasted the
    // range. A 1-hour mean shift → 0.5 (warning), ≥2 hours → 0 (poor).
    let pos_sim = (1.0 - emd / POS_SATURATION_HOURS).clamp(0.0, 1.0);

    (mass_sim * pos_sim).clamp(0.0, 1.0)
}

/// Compute a **structural grid-registration score** for a detected ROI (0.0–1.0).
///
/// This is a *value-independent* companion to `compute_bar_alignment_score`. The
/// alignment score re-slices the same ROI and compares to the stored values, so a
/// *coherent* framing error (the whole ROI placed too high/low, or scaled) corrupts
/// both the stored values AND the re-measurement identically — they still agree and
/// it scores ~1.0. That vertical-framing case is the alignment score's blind spot.
///
/// This score asks the orthogonal question — *"is the ROI framed on the chart
/// correctly?"* — using a signal that never touches the stored values: the
/// horizontal gridlines. After binarization a gridline is a near-full-width black
/// row (bars, ≤~60% of a slice with gaps, never are). The lines are tested against
/// the expected lattice {0, ¼, ½, ¾} of the ROI height:
///
/// * `ceiling_reg` — the topmost line (the "60" / top border) must sit at fraction
///   ~0; a vertical offset pulls it away and is penalized. This also breaks the
///   lattice-aliasing degeneracy where a full-quarter shift would otherwise look
///   on-pattern.
/// * `pattern_reg` — every detected line must sit near a lattice point (each
///   detected line → nearest expected, so a missing line is tolerated but an
///   off-lattice line from a scale/offset error is penalized).
///
/// The score is their product, both in `[0,1]`, with the same good ≥0.85 /
/// acceptable ≥0.70 / warning ≥0.50 / poor <0.50 bands as the alignment score.
///
/// Computed at 1× (no resize): the gridline test needs no sub-pixel precision, and
/// staying at 1× means the only preprocessing is the per-pixel `darken_and_binarize`
/// LUT — which is bit-identical to the Python path, so this needs no nearest-neighbor
/// resize-parity assumption. A horizontal bar-centering term was evaluated and
/// dropped for v1: at 1× the per-column mass is dominated by the gridlines, and
/// `slice_image`'s center-column sampling already surfaces damaging horizontal
/// offsets through the value cross-check, so vertical framing is the only true
/// blind spot left to cover.
///
/// Port of Python `compute_grid_registration_score()` — the two MUST stay
/// byte-for-byte identical (enforced by tests/contract/test_server_wasm_parity.py).
pub fn compute_grid_registration_score(roi: &RgbImage) -> f64 {
    compute_grid_registration_score_cfg(roi, GRID_REG_DEADBAND, GRID_REG_TOL)
}

/// [`compute_grid_registration_score`] with the `deadband` and `tol` sensitivity
/// knobs supplied at runtime (from the Settings UI). The no-arg version delegates
/// here with the SSoT defaults, keeping the cross-impl parity pins byte-identical
/// when no override is set.
pub fn compute_grid_registration_score_cfg(roi: &RgbImage, deadband: f64, tol: f64) -> f64 {
    let (roi_width, roi_height) = roi.dimensions();
    if roi_width < NUM_SLICES as u32 || roi_height < 2 {
        return 0.0;
    }

    // Binarize at 1× (no resize) — same per-pixel LUT slice_image uses, so the
    // black/white buffer is pixel-identical to Python with zero resize ambiguity.
    let mut roi_bin = roi.clone();
    darken_and_binarize(&mut roi_bin);
    let h = roi_height as usize;
    let rw = roi_width as usize;
    let raw = roi_bin.as_raw();
    let stride = rw * 3;

    // Per-row black-pixel counts (black == (0,0,0) after binarize).
    let mut row_black = vec![0u32; h];
    for (y, rb) in row_black.iter_mut().enumerate() {
        let base = y * stride;
        let mut count = 0u32;
        for x in 0..rw {
            let idx = base + x * 3;
            if raw[idx] == 0 && raw[idx + 1] == 0 && raw[idx + 2] == 0 {
                count += 1;
            }
        }
        *rb = count;
    }

    // Group contiguous full-width rows into single gridlines; take each run's center.
    let threshold = GRIDLINE_COVERAGE_PCT * rw as u32;
    let mut line_fracs: Vec<f64> = Vec::new();
    let denom = (h - 1) as f64;
    let mut y = 0usize;
    while y < h {
        if row_black[y] * 100 >= threshold {
            let y0 = y;
            while y < h && row_black[y] * 100 >= threshold {
                y += 1;
            }
            // y is one past the last full row, so the run is [y0, y-1].
            let center = (y0 + y - 1) as f64 / 2.0;
            line_fracs.push(center / denom);
        } else {
            y += 1;
        }
    }

    // No horizontal gridlines at all → the ROI isn't framed on a chart.
    if line_fracs.is_empty() {
        return 0.0;
    }

    // ceiling_reg: the topmost detected line should sit at fraction ~0.
    let mut f_top = f64::INFINITY;
    for &f in line_fracs.iter() {
        if f < f_top {
            f_top = f;
        }
    }
    let ceiling_eff = (f_top.abs() - deadband).max(0.0);
    let ceiling_reg = (1.0 - ceiling_eff / tol).clamp(0.0, 1.0);

    // pattern_reg: every detected line should land near a lattice point.
    let mut err_sum = 0.0f64;
    for &f in line_fracs.iter() {
        let mut best = f64::INFINITY;
        for &exp in EXPECTED_GRIDLINE_FRACS.iter() {
            let d = (f - exp).abs();
            if d < best {
                best = d;
            }
        }
        err_sum += (best - deadband).max(0.0);
    }
    let mean_err = err_sum / line_fracs.len() as f64;
    let pattern_reg = (1.0 - mean_err / tol).clamp(0.0, 1.0);

    (ceiling_reg * pattern_reg).clamp(0.0, 1.0)
}

/// Snap the ROI's top and bottom edges onto the chart's horizontal gridlines.
///
/// The OCR-anchor detector sometimes lands the ROI bottom on an *intermediate*
/// gridline (e.g. the 15m line) rather than the 0m baseline — it clips the bottom of
/// every bar and scales the heights against the wrong span, so the bar total reads
/// systematically short (the worse the taller the bars). The horizontal gridlines are
/// near-full-width black rows after [`darken_and_binarize`] (theme-agnostic — works in
/// dark mode), the same signal [`compute_grid_registration_score`] uses.
///
/// This scans a vertical window around `bounds` (extended by the ROI height above and
/// below so it reaches the 60m line just above the anchor top and the 0m baseline a
/// gridline-spacing below the anchor bottom), collects the gridline rows across the
/// ROI's x-span, finds the longest run of evenly-spaced lines that overlaps the anchor
/// ROI, and returns bounds spanning that run's outermost lines (top = 60m, bottom =
/// 0m). x bounds are preserved. If no clean ≥3-line evenly-spaced lattice is found it
/// returns `*bounds` unchanged, so it can never make framing worse than the anchor.
pub fn snap_roi_to_gridlines(img: &RgbImage, bounds: &GridBounds) -> GridBounds {
    let (img_w, img_h) = img.dimensions();
    let roi_x = bounds.roi_x().max(0) as u32;
    let roi_w = bounds.width().max(0) as u32;
    let roi_top = bounds.upper_left_y.max(0);
    let roi_bottom = bounds.lower_right_y.max(0);
    if roi_x >= img_w || roi_w < NUM_SLICES as u32 || roi_bottom - roi_top < 8 {
        return *bounds;
    }
    let roi_h = (roi_bottom - roi_top) as u32;

    // Search window: ±roi_h around the anchor, clamped to the image.
    let sy0 = (roi_top as u32).saturating_sub(roi_h);
    let sy1 = ((roi_bottom as u32) + roi_h).min(img_h);
    let sx0 = roi_x;
    let sx1 = (roi_x + roi_w).min(img_w);
    if sx1 <= sx0 || sy1 <= sy0 {
        return *bounds;
    }

    let strip_w = sx1 - sx0;
    let strip_h = sy1 - sy0;
    let mut strip = image::imageops::crop_imm(img, sx0, sy0, strip_w, strip_h).to_image();
    darken_and_binarize(&mut strip);
    let raw = strip.as_raw();
    let rw = strip_w as usize;
    let stride = rw * 3;
    let threshold = GRIDLINE_COVERAGE_PCT * rw as u32;

    let row_is_line = |y: usize| -> bool {
        let base = y * stride;
        let mut count = 0u32;
        for x in 0..rw {
            let idx = base + x * 3;
            if raw[idx] == 0 && raw[idx + 1] == 0 && raw[idx + 2] == 0 {
                count += 1;
            }
        }
        count * 100 >= threshold
    };

    // Collect gridline centers as absolute image-y, grouping contiguous full rows.
    let mut lines: Vec<i32> = Vec::new();
    let h = strip_h as usize;
    let mut y = 0usize;
    while y < h {
        if row_is_line(y) {
            let y0 = y;
            while y < h && row_is_line(y) {
                y += 1;
            }
            let center = (y0 + y - 1) / 2;
            lines.push(sy0 as i32 + center as i32);
        } else {
            y += 1;
        }
    }
    lines.sort_unstable();
    lines.dedup();
    if lines.len() < 3 {
        return *bounds;
    }

    // Median consecutive gap = the chart's gridline spacing (robust to stray lines
    // like a card divider or the weekly chart's lines caught in the window).
    let gaps: Vec<i32> = lines.windows(2).map(|w| w[1] - w[0]).collect();
    let mut sorted_gaps = gaps.clone();
    sorted_gaps.sort_unstable();
    let spacing = sorted_gaps[sorted_gaps.len() / 2];
    if spacing < 4 {
        return *bounds;
    }

    // Longest contiguous run whose every gap is within 30% of the spacing.
    let tol = (spacing as f64 * 0.30).max(3.0);
    let in_tol = |g: i32| ((g - spacing) as f64).abs() <= tol;
    let (mut best_start, mut best_len) = (0usize, 1usize);
    let (mut cur_start, mut cur_len) = (0usize, 1usize);
    for (i, &g) in gaps.iter().enumerate() {
        if in_tol(g) {
            cur_len += 1;
        } else {
            if cur_len > best_len {
                best_len = cur_len;
                best_start = cur_start;
            }
            cur_start = i + 1;
            cur_len = 1;
        }
    }
    if cur_len > best_len {
        best_len = cur_len;
        best_start = cur_start;
    }
    // best run covers lines[best_start ..= best_start + best_len - 1]
    let run_top = lines[best_start];
    let run_bottom = lines[best_start + best_len - 1];

    // Need a real lattice (≥3 lines) that brackets the anchor ROI (so we snap the
    // hourly chart, not the weekly one above it) and spans a plausible height.
    let anchor_center = (roi_top + roi_bottom) / 2;
    let brackets = run_top <= anchor_center && run_bottom >= anchor_center;
    let span = run_bottom - run_top;
    let plausible = span >= roi_h as i32 / 2 && span <= roi_h as i32 * 3;
    if best_len < 3 || !brackets || !plausible {
        return *bounds;
    }

    GridBounds::new(
        bounds.upper_left_x,
        run_top,
        bounds.lower_right_x,
        run_bottom,
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn review_slice_centres_span_full_width() {
        let mut img = RgbImage::from_pixel(100, 60, image::Rgb([255, 255, 255]));
        for y in 30..60 {
            for x in 97..100 {
                img.put_pixel(x, y, image::Rgb([0, 0, 0]));
            }
        }
        let (row, _) = slice_image_with_residuals(&img, 0, 0, 100, 60);
        assert_eq!(row[23], 30.0);
        assert_eq!(compute_bar_alignment_score(&img, &row[..24]), 1.0);
        assert_eq!(slice_image_fast_total(&img, 0, 0, 100, 60), 30.0);
        let (data, sw, _) = preprocess_for_optimizer(&img);
        assert_eq!(
            compute_bar_total_from_scaled(&data, sw, 0, 0, 100, 60),
            30.0
        );
    }

    // snap_roi_to_gridlines extends a mis-framed anchor ROI (bottom landing on an
    // intermediate gridline) out to the outermost evenly-spaced gridlines.
    #[test]
    fn snap_extends_to_outermost_gridlines() {
        // 200×400 white image, full-width black gridlines at y = 100,150,200,250,300.
        let mut img = RgbImage::from_fn(200, 400, |_, _| image::Rgb([255, 255, 255]));
        for &y in &[100u32, 150, 200, 250, 300] {
            for x in 0..200u32 {
                img.put_pixel(x, y, image::Rgb([0, 0, 0]));
            }
        }
        // Anchor mis-frames: top below the 100 line, bottom between the 200 & 250 lines.
        let anchor = GridBounds::new(10, 130, 190, 230);
        let snapped = snap_roi_to_gridlines(&img, &anchor);
        assert_eq!(snapped.upper_left_y, 100, "top snaps to the 60m line");
        assert_eq!(
            snapped.lower_right_y, 300,
            "bottom snaps to the 0m baseline"
        );
        assert_eq!(snapped.upper_left_x, 10, "x preserved");
        assert_eq!(snapped.lower_right_x, 190, "x preserved");
    }

    // Without a clean gridline lattice the anchor is returned unchanged (never worse).
    #[test]
    fn snap_returns_original_without_gridlines() {
        let img = RgbImage::from_fn(200, 400, |_, _| image::Rgb([255, 255, 255]));
        let anchor = GridBounds::new(10, 130, 190, 230);
        let snapped = snap_roi_to_gridlines(&img, &anchor);
        assert_eq!(snapped.upper_left_y, anchor.upper_left_y);
        assert_eq!(snapped.lower_right_y, anchor.lower_right_y);
    }

    #[test]
    fn test_slice_image_all_white() {
        // All white ROI → all values should be 0
        let img = RgbImage::from_fn(240, 100, |_, _| image::Rgb([255, 255, 255]));
        let result = slice_image(&img, 0, 0, 240, 100);
        assert_eq!(result.len(), 25);
        for &v in &result[..24] {
            assert!(v.abs() < 0.01, "Expected 0, got {v}");
        }
        assert!(result[24].abs() < 0.01);
    }

    #[test]
    fn test_slice_image_all_black() {
        // All black ROI → all values should be MAX_Y (60)
        let img = RgbImage::from_fn(240, 100, |_, _| image::Rgb([0, 0, 0]));
        let result = slice_image(&img, 0, 0, 240, 100);
        assert_eq!(result.len(), 25);
        for &v in &result[..24] {
            assert!((v - 60.0).abs() < 0.01, "Expected 60, got {v}");
        }
    }

    /// A ramp whose 24 columns rise left→right, half the ROI height at most, so
    /// every bar has room to double without clipping.
    fn ramp_roi() -> RgbImage {
        RgbImage::from_fn(240, 100, |x, y| {
            let col = x / 10;
            let bar_top = 100u32.saturating_sub(col * 2);
            if y >= bar_top {
                image::Rgb([0, 0, 0])
            } else {
                image::Rgb([255, 255, 255])
            }
        })
    }

    #[test]
    fn slice_image_scaled_reads_a_120_minute_axis_at_double() {
        // The same pixels mean twice as many minutes when the top gridline is
        // 2h instead of 60m. This is IMG_7876: printed 2h 31m, extracted 74.
        let img = ramp_roi();
        let at60 = slice_image(&img, 0, 0, 240, 100);
        let at120 = slice_image_scaled(&img, 0, 0, 240, 100, 120.0);
        for hour in 0..24 {
            // floor() is applied after scaling, so allow the one-minute slack it
            // can introduce rather than asserting exact doubling.
            let doubled = at60[hour] * 2.0;
            assert!(
                (at120[hour] - doubled).abs() <= 1.0,
                "hour {hour}: {} at 120 vs {doubled} expected",
                at120[hour]
            );
        }
        assert!(at120[24] > at60[24], "the 120-minute axis must read higher");
    }

    #[test]
    fn slice_image_scaled_falls_back_to_60_on_a_nonsense_ceiling() {
        // A misread ceiling multiplies every bar by a wrong constant, which is
        // the exact silent damage this feature exists to remove. Anything out of
        // range reads as the ordinary chart instead.
        let img = ramp_roi();
        let sane = slice_image(&img, 0, 0, 240, 100);
        for nonsense in [0.0, -120.0, f64::NAN, f64::INFINITY, 100_000.0] {
            assert_eq!(
                slice_image_scaled(&img, 0, 0, 240, 100, nonsense),
                sane,
                "ceiling {nonsense} should have fallen back to 60"
            );
        }
    }

    #[test]
    fn slice_with_axis_scale_believes_the_label_when_the_total_agrees() {
        let img = ramp_roi();
        let at120 = slice_image_scaled(&img, 0, 0, 240, 100, 120.0);
        let target = at120[24].round() as i32;
        let (row, _residuals, applied, detected) =
            slice_with_axis_scale(&img, 0, 0, 240, 100, Some(120), Some(target));
        assert_eq!(applied, 120.0);
        assert_eq!(detected, Some(120.0));
        assert_eq!(row, at120);
    }

    #[test]
    fn slice_with_axis_scale_lets_the_printed_total_overrule_the_label() {
        // The label is evidence, not proof. When the screenshot's own total
        // matches the ordinary 60-minute reading, a "2h" parse is a misread and
        // must not double every bar.
        let img = ramp_roi();
        let at60 = slice_image(&img, 0, 0, 240, 100);
        let target = at60[24].round() as i32;
        let (row, _residuals, applied, detected) =
            slice_with_axis_scale(&img, 0, 0, 240, 100, Some(120), Some(target));
        assert_eq!(applied, 60.0);
        // The rejected label is still reported, so the caller can flag a chart
        // that LOOKS hour-scaled even though the total voted the ceiling down.
        assert_eq!(detected, Some(120.0));
        assert_eq!(row, at60);
    }

    #[test]
    fn slice_with_axis_scale_is_a_no_op_without_a_detected_axis() {
        // Every ordinary screenshot takes this path: byte-identical to before.
        let img = ramp_roi();
        let at60 = slice_image_with_residuals(&img, 0, 0, 240, 100);
        for detected in [None, Some(60), Some(30)] {
            let (row, residuals, applied, reported) =
                slice_with_axis_scale(&img, 0, 0, 240, 100, detected, Some(400));
            assert_eq!(applied, 60.0);
            assert_eq!(reported, None);
            assert_eq!(row, at60.0);
            assert_eq!(residuals, at60.1);
        }
    }

    #[test]
    fn slice_with_axis_scale_refuses_an_unarbitrated_label() {
        // With no printed total there is nothing to check the label against, and
        // `AXIS_LABEL_SCALE`'s own note records that `1h` misreads as `4h`.
        // Trusting it here would multiply every bar by a wrong constant on
        // exactly the screenshots that have no cross-check, so the ordinary
        // 60-minute reading stands and the unapplied ceiling is reported instead.
        let img = ramp_roi();
        let at60 = slice_image(&img, 0, 0, 240, 100);
        let (row, _residuals, applied, detected) =
            slice_with_axis_scale(&img, 0, 0, 240, 100, Some(120), None);
        assert_eq!(applied, 60.0);
        assert_eq!(detected, Some(120.0));
        assert_eq!(row, at60);
    }

    #[test]
    fn slice_with_axis_scale_never_reports_a_ceiling_it_did_not_use() {
        // `slice_image_with_residuals_scaled` clamps an absurd ceiling back to 60
        // internally. If the arbiter reported the raw label anyway, callers would
        // persist "99h axis" as review evidence over data measured at 60 — a
        // warning that lies about the scale. Validate once, in one place.
        let img = ramp_roi();
        let at60 = slice_image(&img, 0, 0, 240, 100);
        for absurd in [MAX_AXIS_MINUTES as i32 + 1, 5940] {
            let (row, _residuals, applied, detected) =
                slice_with_axis_scale(&img, 0, 0, 240, 100, Some(absurd), Some(400));
            assert_eq!(applied, 60.0);
            assert_eq!(detected, None);
            assert_eq!(row, at60);
        }
    }

    #[test]
    fn test_slice_image_returns_25_elements() {
        let img = RgbImage::new(480, 200);
        let result = slice_image(&img, 0, 0, 480, 200);
        assert_eq!(result.len(), 25); // 24 hours + total
    }

    #[test]
    fn test_alignment_score_identical() {
        // Both extracted and computed are zero → perfect score
        let roi = RgbImage::from_fn(240, 100, |_, _| image::Rgb([255, 255, 255]));
        let values = vec![0.0; 24];
        let score = compute_bar_alignment_score(&roi, &values);
        assert!((score - 1.0).abs() < 0.01);
    }

    #[test]
    fn test_alignment_score_empty_roi() {
        let roi = RgbImage::new(0, 0);
        let score = compute_bar_alignment_score(&roi, &[0.0; 24]);
        assert!((score - 0.0).abs() < 0.01);
    }

    // Parity: each hourly value is Math.floor(60 * counter / height), not a float.
    // Canvas analyzeBarHeight: Math.floor((MAX_MINUTES * counter) / maxHeight)
    // This means partial bars are floored PER SLICE, not at the total.
    #[test]
    fn parity_slice_image_values_are_floored_integers() {
        // 240px wide / 24 slices = 10px per slice at 1x → 40px at 4x scale.
        // All-black 240x100 image: every slice is fully black.
        // counter=h (all black), value = floor(60 * h / h) = floor(60) = 60.
        let img = RgbImage::from_fn(240, 100, |_, _| image::Rgb([0, 0, 0]));
        let result = slice_image(&img, 0, 0, 240, 100);
        for &v in &result[..24] {
            assert_eq!(
                v,
                v.floor(),
                "hourly value must be an integer (floored), got {v}"
            );
        }
    }

    // Parity: total is sum of floored per-slice values, not floor of the continuous sum.
    // If each slice gives floor(60 * counter / h) and all counters = h, total = 24 * 60 = 1440.
    #[test]
    fn parity_slice_image_total_is_sum_of_floored_slices() {
        let img = RgbImage::from_fn(240, 100, |_, _| image::Rgb([0, 0, 0]));
        let result = slice_image(&img, 0, 0, 240, 100);
        let per_slice_sum: f64 = result[..24].iter().sum();
        assert!(
            (result[24] - per_slice_sum).abs() < 0.01,
            "result[24] must equal sum of result[..24]"
        );
    }

    // Parity: slice_image_fast_total floors per-slice to match optimizer's target comparison.
    // If total_text says "40m", bar total must be 40 (not 40.3) to converge optimizer.
    #[test]
    fn parity_fast_total_matches_slice_total() {
        let img = RgbImage::from_fn(240, 100, |_, _| image::Rgb([0, 0, 0]));
        let fast = slice_image_fast_total(&img, 0, 0, 240, 100);
        let slow: f64 = slice_image(&img, 0, 0, 240, 100)[..24].iter().sum();
        assert!(
            (fast - slow).abs() < 0.01,
            "fast_total={fast} must equal slice sum={slow}"
        );
    }

    // Solid bars matching full values → perfect score. An all-black ROI binarizes
    // to full-height bars in every column (measured = 60); values all 60 → MAE 0.
    #[test]
    fn alignment_full_bars_match_full_values() {
        let roi = image::RgbImage::from_fn(240, 100, |_, _| image::Rgb([0, 0, 0]));
        let values = vec![60.0f64; 24];
        let score = compute_bar_alignment_score(&roi, &values);
        assert!(
            (score - 1.0).abs() < 0.01,
            "full bars + full values must score ~1.0, got {score}"
        );
    }

    // Bars are clearly present (full-height) but the stored values say zero →
    // the cross-check must collapse the score. measured≈60, values 0 → MAE 60.
    #[test]
    fn alignment_bars_present_but_values_zero_is_zero() {
        let roi = image::RgbImage::from_fn(240, 100, |_, _| image::Rgb([0, 0, 0]));
        let score = compute_bar_alignment_score(&roi, &[0.0; 24]);
        assert!(
            score < 0.01,
            "full bars + zero values must score ~0.0, got {score}"
        );
    }

    // Uniform height mismatch is caught by the mass factor, not position. All-black
    // ROI (measured 60 in every slice) vs values all 30: both normalize to the same
    // uniform distribution → EMD 0 → pos_sim 1, but the totals differ 1440 vs 720 →
    // mass_sim = min/max = 720/1440 = 0.5 → score 0.5 (the warning line).
    #[test]
    fn alignment_uniform_height_mismatch_uses_mass() {
        let roi = image::RgbImage::from_fn(240, 100, |_, _| image::Rgb([0, 0, 0]));
        let values = vec![30.0f64; 24];
        let score = compute_bar_alignment_score(&roi, &values);
        assert!(
            (score - 0.5).abs() < 0.01,
            "all-black bars + all-30 values must score ~0.5 (2× mass mismatch), got {score}"
        );
    }

    // EMD penalizes positional displacement by distance. A 240×100 ROI black only in
    // its first slice gives measured = [60, 0, …]. Stored values with the same mass
    // placed at slice 0 (aligned), slice 1, and slice 5 must score monotonically
    // lower as the mass moves farther: aligned → 1.0, 1-hour shift → 0.5 (warning
    // line, 1 - 1/2), and a 5-hour shift saturates to 0.0 (≥2-hour → poor).
    #[test]
    fn alignment_emd_penalizes_shift_by_distance() {
        // Slice s samples original column s*10+5 (after the 4× scale), so painting
        // x<10 black makes ONLY slice 0 a full-height bar.
        let roi = image::RgbImage::from_fn(240, 100, |x, _| {
            if x < 10 {
                image::Rgb([0, 0, 0])
            } else {
                image::Rgb([255, 255, 255])
            }
        });

        let mut aligned = vec![0.0f64; 24];
        aligned[0] = 60.0;
        let mut shift1 = vec![0.0f64; 24];
        shift1[1] = 60.0;
        let mut shift5 = vec![0.0f64; 24];
        shift5[5] = 60.0;

        let s_aligned = compute_bar_alignment_score(&roi, &aligned);
        let s_shift1 = compute_bar_alignment_score(&roi, &shift1);
        let s_shift5 = compute_bar_alignment_score(&roi, &shift5);

        assert!(
            (s_aligned - 1.0).abs() < 0.01,
            "aligned single bar must score ~1.0, got {s_aligned}"
        );
        assert!(
            (s_shift1 - 0.5).abs() < 0.01,
            "1-hour shift must score ~0.5 (warning line), got {s_shift1}"
        );
        assert!(
            s_shift5 < 0.01,
            "5-hour shift saturates to ~0.0 (poor), got {s_shift5}"
        );
        assert!(
            s_aligned > s_shift1 && s_shift1 > s_shift5,
            "score must drop monotonically with shift distance: {s_aligned} > {s_shift1} > {s_shift5}"
        );
    }

    // Paint a `w×h` white ROI with full-width dark gridlines at the given rows.
    // After darken_and_binarize the dark rows (luma ≤ threshold) become full-width
    // black → detected gridlines; everything else stays white.
    fn roi_with_gridlines(w: u32, h: u32, rows: &[u32]) -> image::RgbImage {
        image::RgbImage::from_fn(w, h, |_, y| {
            if rows.contains(&y) {
                image::Rgb([100, 100, 100])
            } else {
                image::Rgb([255, 255, 255])
            }
        })
    }

    // A ROI whose gridlines sit on the expected {0, ¼, ½, ¾} lattice registers ~1.0.
    #[test]
    fn grid_registration_clean_lattice_scores_high() {
        // h=120: rows 0,30,60,90 → fracs 0, .252, .504, .756 (within deadband of lattice).
        let roi = roi_with_gridlines(240, 120, &[0, 30, 60, 90]);
        let score = compute_grid_registration_score(&roi);
        assert!(
            score > 0.95,
            "clean lattice gridlines must register ~1.0, got {score}"
        );
    }

    // Shift every gridline down by 12px (10% of height) → the ceiling leaves row 0
    // and the lattice breaks → strongly flagged.
    #[test]
    fn grid_registration_vertical_offset_penalized() {
        let clean =
            compute_grid_registration_score(&roi_with_gridlines(240, 120, &[0, 30, 60, 90]));
        let offset =
            compute_grid_registration_score(&roi_with_gridlines(240, 120, &[12, 42, 72, 102]));
        assert!(
            offset < 0.5,
            "a 10% vertical grid offset must read poor, got {offset}"
        );
        assert!(
            clean > offset,
            "offset must score below clean: clean={clean} offset={offset}"
        );
    }

    // No full-width gridlines at all (blank ROI) → unregistered → 0.0.
    #[test]
    fn grid_registration_no_gridlines_is_zero() {
        let roi = image::RgbImage::from_fn(240, 120, |_, _| image::Rgb([255, 255, 255]));
        let score = compute_grid_registration_score(&roi);
        assert!(
            score.abs() < 1e-9,
            "blank ROI must register 0.0, got {score}"
        );
    }

    // Degenerate ROI (too few columns / rows) → 0.0, like the alignment score.
    #[test]
    fn grid_registration_degenerate_roi_is_zero() {
        let roi = image::RgbImage::from_fn(10, 1, |_, _| image::Rgb([100, 100, 100]));
        assert_eq!(compute_grid_registration_score(&roi), 0.0);
    }

    // Cross-impl parity pin: a mild (~3.4%) vertical offset produces a specific
    // fractional score. The identical synthetic + constant is asserted on the Python
    // side (tests/unit/test_cross_impl_parity.py) so the two engines are locked
    // together on a non-trivial value, not just the all-1.0 fixtures.
    #[test]
    fn grid_registration_mild_offset_parity_value() {
        let roi = roi_with_gridlines(240, 120, &[4, 34, 64, 94]);
        let score = compute_grid_registration_score(&roi);
        assert!(
            (score - 0.898663).abs() < 1e-6,
            "mild-offset registration must equal the pinned cross-impl value 0.898663, got {score}"
        );
    }

    // Parity: preprocess_for_optimizer scales by exactly 4×.
    // Each iteration of the boundary optimizer reads from this buffer — scaling must be exact.
    #[test]
    fn parity_preprocess_for_optimizer_is_4x_scale() {
        let img = image::RgbImage::new(100, 80);
        let (data, sw, sh) = preprocess_for_optimizer(&img);
        assert_eq!(sw, 400, "scaled width must be 4×100");
        assert_eq!(sh, 320, "scaled height must be 4×80");
        assert_eq!(
            data.len(),
            (400 * 320 * 3) as usize,
            "buffer size must be sw*sh*3"
        );
    }

    // Parity: compute_bar_total_from_scaled returns 0.0 when scaled ROI width < NUM_SLICES.
    // At 4× scale: roi_width=5 → sw=20 < 24 → 0.0.
    #[test]
    fn parity_compute_bar_total_scaled_too_narrow_returns_zero() {
        let img = image::RgbImage::from_fn(100, 100, |_, _| image::Rgb([0, 0, 0]));
        let (data, sw, _) = preprocess_for_optimizer(&img);
        let total = compute_bar_total_from_scaled(&data, sw, 0, 0, 5, 50);
        assert_eq!(total, 0.0, "scaled width=20 < 24 slices must return 0.0");
    }

    // Parity: all-black image bar total via scaled path matches 1× path.
    // Both must agree that every slice is fully black → 60 per slice × 24 = 1440.
    #[test]
    fn parity_compute_bar_total_scaled_matches_1x_all_black() {
        let img = image::RgbImage::from_fn(240, 100, |_, _| image::Rgb([0, 0, 0]));
        let (data, sw, _) = preprocess_for_optimizer(&img);
        let scaled_total = compute_bar_total_from_scaled(&data, sw, 0, 0, 240, 100);
        let slow_total = slice_image_fast_total(&img, 0, 0, 240, 100);
        assert!(
            (scaled_total - slow_total).abs() < 1.0,
            "scaled total={scaled_total} must be within 1 of 1× total={slow_total}"
        );
    }

    // Parity: LOWER_GRID_BUFFER is applied in 4x-scaled coordinates (not multiplied by SCALE).
    // Canvas analyzeBarHeight: `y < maxHeight - LOWER_GRID_BUFFER` where maxHeight is 4x-scaled.
    // So only the bottom 2 pixels of the 4x image are the buffer zone, NOT bottom 8.
    // Verify: a white pixel in positions [h-2, h-1] of the 4x image does not reset start_after.
    #[test]
    fn parity_lower_grid_buffer_applied_in_scaled_coords() {
        // 240×10 all-black image, then place white in the bottom 2 rows of the 4x-scaled result.
        // After 4x scale (nearest): rows h-2=38 and h-1=39 are white.
        // With LOWER_GRID_BUFFER=2, reset_limit = 40-2=38, so the scan is (0..38).rev().
        // White at rows 38-39 is outside the scan → start_after=0 → all blacks counted.
        // If we used LOWER_GRID_BUFFER*SCALE=8: reset_limit=32, scan (0..32).rev().
        // Under the old (wrong) formula the bottom-8 4x pixels would be excluded but that
        // changes counts on smaller ROIs. Here we just verify we don't crash and return non-zero.
        let img = image::RgbImage::from_fn(240, 10, |_, _| image::Rgb([0, 0, 0]));
        let result = slice_image(&img, 0, 0, 240, 10);
        // All-black: every slice should be 60.
        assert_eq!(result[0], 60.0, "all-black 240×10 first slice must be 60");
    }

    // iOS draws a 1-px background hairline between a bar's stacked category
    // segments. The bar top must be found ABOVE it — the old "lowest white pixel"
    // anchor counted only the segment below the line, reading real bars 11-36
    // minutes short with the review flag lit no matter where the grid sat.
    // Mirrors tests/unit/test_bar_extraction.py::test_hairline_inside_a_stacked_bar_does_not_truncate_it.
    #[test]
    fn hairline_inside_a_stacked_bar_does_not_truncate_it() {
        // 240×100: bar = rows 50..100 (30 min), with row 75 white.
        let img = RgbImage::from_fn(240, 100, |_, y| {
            if (50..100).contains(&y) && y != 75 {
                image::Rgb([0, 0, 0])
            } else {
                image::Rgb([255, 255, 255])
            }
        });
        let row = slice_image(&img, 0, 0, 240, 100);
        // The hairline is inside the bar, so the bar is all 50 rows: 30 min
        // (a truncated read is 14; counting only black rows read 29).
        assert!(row[..NUM_SLICES].iter().all(|&v| v == 30.0), "{row:?}");
        // Same span on the 1x fast path: 50 of 100 → 30 per slice.
        assert_eq!(slice_image_fast_total(&img, 0, 0, 240, 100), 30.0 * 24.0);
    }

    // slice_image_with_residuals and compute_bar_alignment_score read the 4x
    // nearest upscale at quarter coordinates instead of building it. That is only
    // valid while `imageops::resize(.., Nearest)` at an exact 4x ratio is a pure
    // 4x4 block copy; pin it so an image-crate upgrade cannot change it silently.
    #[test]
    fn a_4x_nearest_upscale_is_a_block_copy_of_the_source() {
        for (w, h, seed) in [(1u32, 1u32, 1u32), (7, 3, 2), (61, 29, 3), (686, 212, 4)] {
            let src = RgbImage::from_fn(w, h, |x, y| {
                let v = (x.wrapping_mul(2654435761) ^ y.wrapping_mul(40503) ^ seed) as u8;
                image::Rgb([v, v.wrapping_mul(3), v.wrapping_add(seed as u8)])
            });
            let up =
                image::imageops::resize(&src, w * 4, h * 4, image::imageops::FilterType::Nearest);
            for (x, y, p) in up.enumerate_pixels() {
                assert_eq!(p, src.get_pixel(x / 4, y / 4), "{w}x{h} at ({x},{y})");
            }
        }
    }

    // A 2-px-tall white ROI scans fewer rows than the gap tolerance; that must
    // still read as "no bar" (alignment 1.0 against zeros), not "bar from the top".
    #[test]
    fn all_white_roi_shorter_than_the_tolerance_is_still_empty() {
        let img = RgbImage::from_fn(240, 2, |_, _| image::Rgb([255, 255, 255]));
        let row = slice_image(&img, 0, 0, 240, 2);
        assert!(row[..NUM_SLICES].iter().all(|&v| v == 0.0), "{row:?}");
        assert_eq!(compute_bar_alignment_score(&img, &[0.0; NUM_SLICES]), 1.0);
    }

    // Bridging is bounded: a 3-px gap (> BAR_GAP_TOLERANCE_PX) is a real gap, so
    // the bar is the segment below it.
    #[test]
    fn gap_wider_than_tolerance_still_ends_the_bar() {
        let img = RgbImage::from_fn(240, 100, |_, y| {
            if (50..100).contains(&y) && !(75..78).contains(&y) {
                image::Rgb([0, 0, 0])
            } else {
                image::Rgb([255, 255, 255])
            }
        });
        let row = slice_image(&img, 0, 0, 240, 100);
        // rows 78..100 = 22 × 4 = 88 of 400 → floor(13.2) = 13.
        assert!(row[..NUM_SLICES].iter().all(|&v| v == 13.0), "{row:?}");
    }

    // slice_image is exactly slice_image_with_residuals().0, and the residuals are
    // the 24 sub-minute fractions floor() discarded — each in [0, 1).
    #[test]
    fn slice_image_with_residuals_agrees_with_slice_image() {
        let img = RgbImage::from_fn(247, 100, |x, y| {
            if (x + y) % 3 == 0 {
                image::Rgb([0, 0, 0])
            } else {
                image::Rgb([255, 255, 255])
            }
        });
        let plain = slice_image(&img, 0, 0, 247, 100);
        let (row, residuals) = slice_image_with_residuals(&img, 0, 0, 247, 100);
        assert_eq!(
            plain, row,
            "slice_image must equal slice_image_with_residuals().0"
        );
        assert_eq!(residuals.len(), NUM_SLICES);
        for &r in &residuals {
            assert!((0.0..1.0).contains(&r), "residual {r} must be in [0, 1)");
        }
        // Each stored bar + its residual reconstructs the unfloored measurement, so
        // the true (continuous) total is Σbars + Σresiduals.
        let floored: f64 = row[..NUM_SLICES].iter().sum();
        let residual_sum: f64 = residuals.iter().sum();
        assert!(residual_sum >= 0.0 && floored + residual_sum >= floored);
    }

    /// The classic absolute-mode cap (`APPORTION_MAX_MINUTES`, no percentage).
    ///
    /// The SSoT default is percentage mode — 2% of the OCR total — and `percent > 0`
    /// takes precedence over the minutes cap, so a test that means "cap = 2 minutes"
    /// has to switch the percentage off rather than lean on the default.
    fn absolute_mode(
        hourly: &mut [f64],
        residuals: &[f64],
        ocr_total_minutes: i32,
        grid_registration_score: f64,
    ) -> bool {
        apportion_to_total_cfg(
            hourly,
            residuals,
            ocr_total_minutes,
            grid_registration_score,
            APPORTION_MAX_MINUTES,
            0.0,
            APPORTION_MIN_REGISTRATION,
        )
    }

    // The discarded sum is good to about a pixel per bar, so its cap is a ceiling:
    // 10.44 floored away covers a gap of 11 and not 12. Mirrored in
    // tests/unit/test_cross_impl_parity.py::test_gap_inside_the_next_minute_of_the_floored_sum_is_recovered.
    #[test]
    fn apportion_covers_a_gap_inside_the_next_minute_of_the_floored_sum() {
        let residuals = [0.58; 18]; // Σ = 10.44
        let mut eleven = vec![10.0; 18]; // Σ = 180, 2% cap = 4
        assert!(apportion_to_total(&mut eleven, &residuals, 191, 1.0));
        assert_eq!(eleven.iter().sum::<f64>() as i32, 191);

        let mut twelve = vec![10.0; 18];
        assert!(!apportion_to_total(&mut twelve, &residuals, 192, 1.0));
        assert_eq!(twelve, vec![10.0; 18]);
    }

    // The compiled default scales with the day: 2% of 400 = 8 minutes, so a gap of
    // 8 closes and a gap of 9 does not. Mirrored in
    // tests/unit/test_cross_impl_parity.py::test_default_cap_is_two_percent_of_the_ocr_total.
    #[test]
    fn apportion_default_cap_is_two_percent_of_the_ocr_total() {
        let residuals = [0.1, 0.9, 0.5, 0.3, 0.7, 0.6, 0.4, 0.2];

        let mut eight = vec![50.0; 8]; // Σ = 400, OCR 408 → gap 8 == cap
        assert!(apportion_to_total(&mut eight, &residuals, 408, 1.0));
        assert_eq!(eight.iter().sum::<f64>() as i32, 408);

        let mut nine = vec![50.0; 8]; // gap 9 > cap 8
        assert!(!apportion_to_total(&mut nine, &residuals, 409, 1.0));
        assert_eq!(nine, vec![50.0; 8]);
    }

    // Cross-impl pin (mirrored in tests/unit/test_cross_impl_parity.py): a +2 gap
    // adds one minute each to the two largest-residual bars (indices 1 and 2).
    #[test]
    fn apportion_adds_to_largest_remainder_bars() {
        let mut hourly = vec![10.0, 10.0, 10.0, 10.0];
        let residuals = [0.1, 0.9, 0.5, 0.3];
        let changed = absolute_mode(&mut hourly, &residuals, 42, 1.0);
        assert!(changed);
        assert_eq!(hourly, vec![10.0, 11.0, 11.0, 10.0]);
        assert_eq!(hourly.iter().sum::<f64>() as i32, 42);
    }

    // Cross-impl pin: a −2 gap removes a minute from the two smallest-residual bars
    // that still have a minute to give (indices 0 and 3).
    #[test]
    fn apportion_removes_from_smallest_remainder_bars() {
        let mut hourly = vec![10.0, 10.0, 10.0, 10.0];
        let residuals = [0.1, 0.9, 0.5, 0.3];
        let changed = absolute_mode(&mut hourly, &residuals, 38, 1.0);
        assert!(changed);
        assert_eq!(hourly, vec![9.0, 10.0, 10.0, 9.0]);
        assert_eq!(hourly.iter().sum::<f64>() as i32, 38);
    }

    // A gap larger than APPORTION_MAX_MINUTES is left alone (the optimizer didn't
    // converge — don't paper over a real mismatch).
    #[test]
    fn apportion_skips_out_of_tolerance_gap() {
        let mut hourly = vec![10.0, 10.0, 10.0, 10.0];
        let residuals = [0.1, 0.9, 0.5, 0.3];
        // Σ = 40, OCR = 45 → gap 5 > max 2.
        let changed = absolute_mode(&mut hourly, &residuals, 45, 1.0);
        assert!(!changed);
        assert_eq!(hourly, vec![10.0, 10.0, 10.0, 10.0]);
    }

    // The grid-registration gate was removed: a low registration score no longer
    // blocks apportionment (the score proved unreliable). A gap within tolerance is
    // closed regardless of grid framing.
    #[test]
    fn apportion_ignores_grid_registration_score() {
        let mut hourly = vec![10.0, 10.0, 10.0, 10.0];
        let residuals = [0.1, 0.9, 0.5, 0.3];
        // Grid score 0.0 used to block this; now the +2 gap is still apportioned.
        let changed = absolute_mode(&mut hourly, &residuals, 42, 0.0);
        assert!(changed);
        assert_eq!(hourly, vec![10.0, 11.0, 11.0, 10.0]);
        assert_eq!(hourly.iter().sum::<f64>() as i32, 42);
    }

    // Empty bars (residual 0) are never handed a minute — no phantom bars appear.
    #[test]
    fn apportion_never_creates_phantom_bars() {
        let mut hourly = vec![5.0, 0.0, 3.0, 0.0];
        let residuals = [0.2, 0.0, 0.8, 0.0];
        // Σ = 8, OCR = 10 → gap 2; only indices 0 and 2 are eligible.
        let changed = absolute_mode(&mut hourly, &residuals, 10, 1.0);
        assert!(changed);
        assert_eq!(hourly, vec![6.0, 0.0, 4.0, 0.0]);
    }

    // An exact match is a no-op.
    #[test]
    fn apportion_zero_gap_is_noop() {
        let mut hourly = vec![10.0, 10.0, 10.0, 10.0];
        let residuals = [0.1, 0.9, 0.5, 0.3];
        let changed = apportion_to_total(&mut hourly, &residuals, 40, 1.0);
        assert!(!changed);
        assert_eq!(hourly, vec![10.0, 10.0, 10.0, 10.0]);
    }

    // ── Runtime-override (Settings UI) behaviour ─────────────────────────────

    // max_minutes = 0 disables apportionment even for a 1-minute gap the default
    // (=2) would close. Mirrors the Python override test.
    #[test]
    fn apportion_cfg_max_minutes_zero_disables() {
        let mut hourly = vec![10.0, 10.0, 10.0, 10.0];
        let residuals = [0.1, 0.9, 0.5, 0.3];
        // max_minutes = 0 AND max_percent = 0 → cap 0 → disabled.
        let changed = apportion_to_total_cfg(&mut hourly, &residuals, 41, 1.0, 0, 0.0, 0.5);
        assert!(!changed);
        assert_eq!(hourly, vec![10.0, 10.0, 10.0, 10.0]);
    }

    // The minutes flooring discarded are recoverable even when both configured
    // caps are far smaller. darkmode_daily_03 is this shape: 15 non-zero bars,
    // 9.00 minutes floored away, printed total 9 above the bar sum, 2% cap = 3.
    #[test]
    fn apportion_recovers_a_gap_that_flooring_fully_explains() {
        let mut hourly = vec![10.0; 12];
        // 12 × 0.75 = 9.00 exactly — the same float-sum edge the real fixtures hit.
        let residuals = [0.75; 12];
        let changed = apportion_to_total_cfg(&mut hourly, &residuals, 129, 1.0, 2, 2.0, 0.5);
        assert!(
            changed,
            "a 9-minute gap backed by 9 floored-away minutes is recoverable"
        );
        assert_eq!(hourly.iter().sum::<f64>(), 129.0);
    }

    // The evidence cap is a ceiling, not a licence: a gap larger than flooring
    // can account for is a misread total or a mis-framed grid, not rounding.
    #[test]
    fn apportion_rejects_a_gap_larger_than_flooring_can_explain() {
        let mut hourly = vec![10.0; 12];
        let residuals = [0.75; 12];
        let before = hourly.clone();
        // 9.00 minutes were floored away; this asks for 30.
        let changed = apportion_to_total_cfg(&mut hourly, &residuals, 150, 1.0, 2, 2.0, 0.5);
        assert!(!changed);
        assert_eq!(hourly, before);
    }

    // Turning both knobs to 0 in Settings means "do not touch my bars". Evidence
    // that minutes were floored away must not overrule that.
    #[test]
    fn apportion_evidence_cap_never_reenables_a_disabled_apportionment() {
        let mut hourly = vec![10.0; 12];
        let residuals = [0.75; 12];
        let before = hourly.clone();
        let changed = apportion_to_total_cfg(&mut hourly, &residuals, 129, 1.0, 0, 0.0, 0.5);
        assert!(!changed);
        assert_eq!(hourly, before);
    }

    #[test]
    fn apportion_evidence_cap_never_widens_the_subtract_direction() {
        // `floor()` can only make a bar too SMALL, so Σresiduals justifies handing
        // minutes back and says NOTHING about an overshoot. Applied to `diff.abs()`
        // it would widen the removal path to ~Σresiduals — here 9 — so a total
        // misread LOW would pass and delete correctly measured minutes from bars
        // flooring never touched, manufacturing a day that agrees with the misread.
        let mut hourly = vec![10.0; 12];
        let residuals = [0.75; 12]; // Σ = 9
        let before = hourly.clone();
        // Σbars = 120, target 113 → diff = -7. Beyond the configured cap (2), and
        // the 9 minutes flooring lost are not evidence for removing 7.
        let changed = apportion_to_total_cfg(&mut hourly, &residuals, 113, 1.0, 2, 0.0, 0.5);
        assert!(!changed, "residual evidence must not license a subtraction");
        assert_eq!(hourly, before);

        // Same magnitude in the ADD direction is exactly what the evidence covers.
        let mut hourly = vec![10.0; 12];
        let changed = apportion_to_total_cfg(&mut hourly, &residuals, 127, 1.0, 2, 0.0, 0.5);
        assert!(changed);
        assert_eq!(hourly.iter().sum::<f64>() as i32, 127);
    }

    // A widened max_minutes closes a gap the default (=2) rejects.
    #[test]
    fn apportion_cfg_wider_tolerance_closes_larger_gap() {
        let mut hourly = vec![10.0, 10.0, 10.0, 10.0];
        let residuals = [0.1, 0.9, 0.5, 0.3];
        // Σ = 40, OCR = 43 → gap 3 > default 2, but max_minutes = 5 allows it (percent off).
        let changed = apportion_to_total_cfg(&mut hourly, &residuals, 43, 1.0, 5, 0.0, 0.5);
        assert!(changed);
        assert_eq!(hourly, vec![10.0, 11.0, 11.0, 11.0]);
        assert_eq!(hourly.iter().sum::<f64>() as i32, 43);
    }

    // Percentage mode RAISES the cap; it never lowers it below max_minutes.
    #[test]
    fn apportion_cfg_percentage_mode_widens_the_cap() {
        // Σ = 40, OCR = 43 → gap 3. max_minutes = 1 alone would reject, but 10% of
        // 43 = 4.3 → round 4 ≥ 3, so the percentage opens it up.
        let mut hourly = vec![10.0, 10.0, 10.0, 10.0];
        let residuals = [0.1, 0.9, 0.5, 0.3];
        let changed = apportion_to_total_cfg(&mut hourly, &residuals, 43, 1.0, 1, 10.0, 0.5);
        assert!(changed);
        assert_eq!(hourly.iter().sum::<f64>() as i32, 43);

        // A percentage that computes SMALLER than max_minutes must not tighten it:
        // 5% of 43 = 2.15 → round 2, but max_minutes = 100 still allows the gap.
        let mut hourly2 = vec![10.0, 10.0, 10.0, 10.0];
        let changed2 = apportion_to_total_cfg(&mut hourly2, &residuals, 43, 1.0, 100, 5.0, 0.5);
        assert!(changed2);
        assert_eq!(hourly2.iter().sum::<f64>() as i32, 43);
    }

    /// The short-day case that regressed when the percentage REPLACED the absolute
    /// cap: `ios26_light/IMG_7884.PNG` prints `9m`, its bars sum to 7, and 2% of 9
    /// rounds to 0 — so a percentage-only cap silently left it 2 minutes short.
    #[test]
    fn apportion_cfg_short_day_still_uses_the_absolute_cap() {
        let mut hourly = vec![4.0, 3.0, 0.0];
        let residuals = [0.6, 0.4, 0.0];
        let changed = apportion_to_total_cfg(&mut hourly, &residuals, 9, 1.0, 2, 2.0, 0.5);
        assert!(changed);
        assert_eq!(hourly.iter().sum::<f64>() as i32, 9);
    }

    // Sentinel (negative) overrides fall back to the compiled SSoT defaults;
    // non-sentinel values pass through; a non-positive tol falls back (it's a divisor).
    #[test]
    fn scoring_config_from_overrides_sentinels() {
        let d = ScoringConfig::default();
        let all_default = ScoringConfig::from_overrides(-1, -1.0, -1.0, -1.0, -1.0);
        assert_eq!(all_default, d);

        let custom = ScoringConfig::from_overrides(0, 5.0, 0.3, 0.0, 0.2);
        assert_eq!(custom.apportion_max_minutes, 0); // 0 is a real value (off), not a sentinel
        assert_eq!(custom.apportion_max_percent, 5.0); // percentage mode value passes through
        assert_eq!(custom.apportion_min_registration, 0.3);
        assert_eq!(custom.grid_reg_deadband, 0.0); // 0 deadband is valid, not a sentinel
        assert_eq!(custom.grid_reg_tol, 0.2);

        // negative max_percent is the sentinel → falls back to the default (0.0 = off).
        let pct_default = ScoringConfig::from_overrides(2, -1.0, -1.0, -1.0, -1.0);
        assert_eq!(pct_default.apportion_max_percent, d.apportion_max_percent);

        // tol = 0 would divide by zero in the scorer → falls back to the default.
        let zero_tol = ScoringConfig::from_overrides(-1, -1.0, -1.0, -1.0, 0.0);
        assert_eq!(zero_tol.grid_reg_tol, d.grid_reg_tol);
    }
}
