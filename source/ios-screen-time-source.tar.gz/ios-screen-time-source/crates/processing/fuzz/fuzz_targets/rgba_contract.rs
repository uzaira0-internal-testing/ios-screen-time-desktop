#![no_main]

use arbitrary::Arbitrary;
use ios_screen_time_image_pipeline::{
    image_utils::rgba_to_rgb_image,
    redaction::{RedactRegion, RedactionMethod, redact_regions_rgba},
};
use libfuzzer_sys::fuzz_target;

#[derive(Debug, Arbitrary)]
struct Input {
    width: u32,
    height: u32,
    #[arbitrary(with = |u: &mut arbitrary::Unstructured| {
        let len = u.int_in_range(0..=u.len().min(256 * 1024))?;
        u.bytes(len).map(<[u8]>::to_vec)
    })]
    rgba: Vec<u8>,
    region: Region,
    method: u8,
    padding: i32,
}

#[derive(Debug, Arbitrary)]
struct Region {
    x: i32,
    y: i32,
    w: i32,
    h: i32,
}

fuzz_target!(|input: Input| {
    let Input {
        width,
        height,
        mut rgba,
        region,
        method,
        padding,
    } = input;
    let _ = rgba_to_rgb_image(&rgba, width, height);
    let method = match method % 3 {
        0 => RedactionMethod::RedBox,
        1 => RedactionMethod::BlackBox,
        _ => RedactionMethod::Pixelate,
    };
    let _ = redact_regions_rgba(
        &mut rgba,
        width,
        height,
        &[RedactRegion {
            x: region.x,
            y: region.y,
            w: region.w,
            h: region.h,
        }],
        method,
        padding,
    );
});
