#![no_main]

use arbitrary::Arbitrary;
use ios_screen_time_image_pipeline::{
    bar_extraction::{compute_grid_registration_score, slice_image},
    grid_detection,
    image_utils::{convert_dark_mode, rgba_to_rgb_image},
    types::DetectionMethod,
};
use libfuzzer_sys::fuzz_target;

#[derive(Debug, Arbitrary)]
struct Input {
    width: u8,
    height: u8,
    fill: [u8; 4],
    noise: Vec<u8>,
}

fuzz_target!(|input: Input| {
    let width = u32::from(input.width % 96) + 1;
    let height = u32::from(input.height % 96) + 1;
    let mut rgba = vec![0_u8; width as usize * height as usize * 4];
    for (index, pixel) in rgba.chunks_exact_mut(4).enumerate() {
        pixel.copy_from_slice(&input.fill);
        if !input.noise.is_empty() {
            pixel[index % 3] ^= input.noise[index % input.noise.len()];
        }
    }
    let mut image = rgba_to_rgb_image(&rgba, width, height).unwrap();
    convert_dark_mode(&mut image);
    let _ = grid_detection::detect_grid(&image, DetectionMethod::LineBased);
    let values = slice_image(&image, 0, 0, width, height);
    assert!(values.iter().all(|value| value.is_finite()));
    assert!(compute_grid_registration_score(&image).is_finite());
});
