#![no_main]

use arbitrary::Arbitrary;
use ios_screen_time_image_pipeline::{boundary_optimizer::parse_ocr_total, ocr};
use libfuzzer_sys::fuzz_target;

#[derive(Debug, Arbitrary)]
struct Input {
    text: String,
    #[arbitrary(with = |u: &mut arbitrary::Unstructured| {
        let len = u.int_in_range(0..=64)?;
        (0..len)
            .map(|_| u.arbitrary::<String>())
            .collect::<arbitrary::Result<Vec<_>>>()
    })]
    words: Vec<String>,
}

fuzz_target!(|input: Input| {
    if input.text.len() > 64 * 1024 {
        return;
    }
    let normalized = ocr::normalize_ocr_digits(&input.text);
    let _ = ocr::extract_time_from_text(&normalized);
    let _ = ocr::has_time_pattern(&normalized);
    let _ = parse_ocr_total(&normalized);
    let _ = ocr::is_daily_total_page(&input.words);
});
