# Handoff: WASM UI, Annotation Route, and Traefik Routing

Date: 2026-05-18

This handoff covers the current state of the iOS Screen Time Screenshot Processing app after the WASM UI/layout work, annotation-route restoration, and public HTTP routing fixes.

## Current Access URLs

- Server mode: `http://cnrc-deni-p001.cnrc.bcm.edu/ios-screen-time-screenshot-processing/`
- WASM mode: `http://cnrc-deni-p001.cnrc.bcm.edu/ios-screen-time-screenshot-processing-wasm/`
- WASM annotation page: `http://cnrc-deni-p001.cnrc.bcm.edu/ios-screen-time-screenshot-processing-wasm/annotate`

Do not add HTTPS routing for this app. The active routes use Traefik `entrypoints=web`.

## Running Containers

Expected relevant containers:

- `ios-screen-time-screenshot-processing-backend-dev` - server API, healthy
- `ios-screen-time-screenshot-processing-frontend-dev` - server frontend
- `ios-screen-time-screenshot-processing-postgres-dev` - server database, healthy
- `ios-screen-time-screenshot-processing-worker-dev` - preprocessing worker, healthy
- `ios-screen-time-screenshot-processing-wasm` - WASM frontend, healthy
- `ios-screen-time-screenshot-processing-server-route` - HTTP-only bridge for server route
- `chronicle-traefik` - public Traefik on `10.23.4.137:80`

Check status:

```bash
docker ps --filter name=ios-screen-time-screenshot-processing --format 'table {{.Names}}\t{{.Status}}'
```

## Traefik Situation

The public Traefik container is `chronicle-traefik`. Its active config is mounted from:

```text
/home/opt/chronicle/docker/traefik/traefik.yml
```

That file contains:

```yaml
providers:
  docker:
    exposedByDefault: false
    endpoint: tcp://docker-socket-proxy:2375
    constraints: "Label(`com.docker.compose.project`, `chronicle`)"
```

This means Chronicle Traefik ignores Docker labels on containers whose Compose project is not `chronicle`. The server dev stack runs as project `ios-screen-time`, so its Traefik labels are ignored by public Traefik even though the containers are attached to `traefik-apps`.

Short-term fix now in place: `docker/docker-compose.server-bridge.yml` launches a tiny Nginx bridge as project `chronicle`. It forwards `/ios-screen-time-screenshot-processing/` to `ios-screen-time-screenshot-processing-frontend-dev:5173` over `traefik-apps`.

Start or restart the bridge:

```bash
docker compose -p chronicle -f docker/docker-compose.server-bridge.yml up -d
```

Long-term cleaner fix: add static file-provider routes in Chronicle Traefik's `dynamic/local-apps.yml`, similar to the existing `/sleep-scoring` and `/flash` routes, instead of maintaining bridge containers.

## WASM Deployment

The WASM compose must be launched with project `chronicle` on this host so Chronicle Traefik can discover it:

```bash
docker compose -p chronicle -f docker/docker-compose.wasm.yml up -d --build
```

Important labels in `docker/docker-compose.wasm.yml`:

- `PathPrefix(/ios-screen-time-screenshot-processing-wasm)`
- `entrypoints=${TRAEFIK_ENTRYPOINT:-web}`
- no `tls`
- no `websecure`

The container also has a direct host port:

```text
9000 -> 80
```

## UI and Route Changes

Key user-facing changes:

- Removed teal/emerald theme accents in favor of neutral zinc/slate styling.
- Made local WASM layout more compact and closer to the Chronicle raw-data preprocessor.
- Added local-mode top navigation: Load, Process, Annotate, Export.
- Restored `/annotate` and `/annotate/:id` in WASM local mode.
- Fixed local-mode auth guard so annotation no longer redirects to login.
- Replaced the oversized annotation empty state with compact local-mode guidance.
- Restored upload folder affordances:
  - recommended folder layout hint
  - scanning-folder state
  - image/file/folder counts
  - current path
  - files/sec during scan and load

Most relevant files:

- `frontend/src/pages/HomePage.tsx`
- `frontend/src/pages/PreprocessingPage.tsx`
- `frontend/src/components/layout/Header.tsx`
- `frontend/src/components/routing/AppRouter.tsx`
- `frontend/src/hooks/useAuth.ts`
- `frontend/src/components/annotation/AnnotationWorkspace.tsx`
- `docker/docker-compose.wasm.yml`
- `docker/docker-compose.server-bridge.yml`
- `docker/nginx/server-route-bridge.conf`

## Verification Commands

Frontend typecheck:

```bash
cd frontend
bun run typecheck
```

Full frontend check:

```bash
cd frontend
bun run check
```

Known state: `bun run check` exits successfully but reports existing warnings.

Whitespace check:

```bash
git diff --check
```

Route checks:

```bash
curl -I --max-time 10 http://cnrc-deni-p001.cnrc.bcm.edu/ios-screen-time-screenshot-processing/
curl -I --max-time 10 http://cnrc-deni-p001.cnrc.bcm.edu/ios-screen-time-screenshot-processing-wasm/
curl -I --max-time 10 http://cnrc-deni-p001.cnrc.bcm.edu/ios-screen-time-screenshot-processing-wasm/annotate
curl -i --max-time 10 http://cnrc-deni-p001.cnrc.bcm.edu/ios-screen-time-screenshot-processing/api/v1/auth/status
```

Expected:

- server route returns `200`
- WASM route returns `200`
- WASM annotation route returns `200`
- auth status returns JSON like `{"password_required":true}`

Browser screenshots used during verification:

```bash
npx playwright screenshot --wait-for-timeout=3000 --viewport-size=1440,900 \
  http://cnrc-deni-p001.cnrc.bcm.edu/ios-screen-time-screenshot-processing/ \
  output/playwright/http-server-route-restored.png

npx playwright screenshot --wait-for-timeout=3000 --viewport-size=1440,900 \
  http://cnrc-deni-p001.cnrc.bcm.edu/ios-screen-time-screenshot-processing-wasm/annotate \
  output/playwright/http-traefik-annotate-final.png
```

## Current Caveats

- Browser folder-picker progress cannot display while the native OS picker dialog is open. The app now shows scan progress immediately after the user selects a folder.
- The server route bridge is operational but should be treated as a routing workaround, not ideal final architecture.
- Do not use `docker compose --remove-orphans` under project `chronicle`; it may remove unrelated Chronicle containers.
- Several existing lint warnings remain unrelated to this work.

## Recommended Next Steps

1. Move `/ios-screen-time-screenshot-processing` and `/ios-screen-time-screenshot-processing-wasm` into Chronicle Traefik static file-provider routes.
2. Remove the bridge container once static routes are confirmed.
3. Keep the WASM path HTTP-only unless server infrastructure requirements change.
4. Run a real large-folder upload test from the browser to validate scan/load progress under production-sized input.
5. Review current uncommitted changes and split into commits by concern: docs, routing, WASM deploy, local UI, annotation restoration.
