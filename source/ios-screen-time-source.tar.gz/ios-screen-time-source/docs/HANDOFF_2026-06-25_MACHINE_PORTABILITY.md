# Handoff: Continuing This Project on Another Machine

Date: 2026-06-25
Repo: https://github.com/uzaira0/ios-screen-time-screenshot-processing
Live site: https://uzaira0.github.io/ios-screen-time-screenshot-processing/

**Short answer: yes, you can move to another machine right now.** All source and
history are pushed, the working tree is clean (no uncommitted work), and the live
site is in sync with `main`. A fresh clone plus the bootstrap below gives you a
working dev environment. The only non-trivial step is the gitignored WASM blob
(rebuild it in Docker, or copy it over).

## Current state (the point you're resuming from)

| | |
|---|---|
| `main` tip | `044581e` — `chore(pyo3): migrate to PyO3 0.29 + tree hygiene & green the fast gate (#81)` |
| `gh-pages` (live) | `b591bbd` — serving `assets/main-v3qkpwde.js` |
| Live WASM pipeline | `pipeline-em` content-hash `82335587` (unchanged since #77) |
| Open PRs | none |
| `ci.sh fast` | green (lint+types+semgrep+ast-grep+contracts+tests, 1880 passed / 0 failed) |
| `rust-parity` | green (13/13, wheel builds against PyO3 0.29) |
| Working tree | clean — nothing to stash or carry by hand |

## What is in git vs what you rebuild on the new machine

Everything needed to rebuild is in git: all source (`frontend/src`, `src/`,
`crates/`, `rust-python/`, `shared/`, `scripts/`, `tests/`, `docker/`, `docs/`),
**all four** Cargo.lock files, `bun.lock`, `pyproject.toml`, `uv.lock`.

**Gitignored — recreate or rebuild on the new machine (verified 2026-06-25):**

| Path | How to get it back |
|------|--------------------|
| `frontend/public/pipeline-em/*` (5.7 MB WASM + `eng.traineddata`) | **Rebuild in Docker** (host can't run `emcc`): `docker run --rm -v $(pwd):/app ios-screen-time-wasm-builder scripts/build-wasm-emscripten.sh` (build the image first from `docker/wasm-build/Dockerfile`). **Or** just `scp` the directory from this machine — it's a build artifact, byte-stable until a `crates/processing` change. |
| `.env`, `frontend/.env` | Copy from the `.env.example` files; fill in secrets. The "Block .env edits" hook means you edit `.env.example` and update `.env` by hand. WASM-only mode needs **no** backend env at all (just omit `VITE_API_BASE_URL`). |
| `.venv`, `node_modules`, `frontend/node_modules` | `pip install -e ".[web,dev]"` (or `uv sync`) and `cd frontend && bun install`. |
| `frontend/dist`, `target/` | Produced by builds — never committed. |

## Bootstrap on a fresh machine

```bash
git clone https://github.com/uzaira0/ios-screen-time-screenshot-processing.git
cd ios-screen-time-screenshot-processing

# Python (backend + the pipeline parity reference + tests)
pip install -e ".[web,dev]"          # or: uv sync

# Frontend
cd frontend && bun install && cd ..

# Rust native (no OCR feature — host has no libtesseract)
cargo build --no-default-features

# WASM blob for offline mode + deploys (host can't run emcc):
#   build the docker/wasm-build image once, then:
#   docker run --rm -v $(pwd):/app ios-screen-time-wasm-builder scripts/build-wasm-emscripten.sh
#   (or scp frontend/public/pipeline-em/ from the old machine)

# Run the WASM dev app (no backend):
cd frontend && bun run dev          # http://localhost:5173
```

**Toolchain the new machine needs:** git, `bun` (`~/.bun/bin/bun`), cargo
(nightly is what's pinned here), Python 3.12+ (this host's venv is 3.14 — fine
now that PyO3 is 0.29; 0.24 used to cap at 3.13), and **Docker** for the WASM
build and the CI capability gates. The user's global shell tools (`astg`, `rg`,
`fd`, `yq`, `sd`, `delta`) are a separate per-user setup, not part of this repo.

## Verifying the new machine is healthy

```bash
./scripts/ci.sh fast          # no Docker/browser — lint, types, semgrep, ast-grep, contracts, tests
./scripts/ci.sh rust-parity   # needs Docker — builds the PyO3 0.29 wheel + Python↔Rust parity
./scripts/ci.sh all           # every gate except mutation (needs Docker + Chromium)
```

`fast` is the quickest "is my environment wired up" check. The capability gates
(`rust-parity`, `wasm-*`, `bundle`, `db-tests`, `persona`) **skip visibly** when
Docker / a browser is absent rather than failing.

## Things that do NOT move with the code

- **Your local app data.** WASM mode keeps screenshots in **IndexedDB + OPFS**,
  per-browser on *this* machine. Cloning the repo elsewhere does not bring that
  data. To move actual screenshots/annotations, use the in-app **workspace ZIP
  export** on this machine and **import** it in the browser on the new one.
- **`.env` secrets** (see above) — never committed.
- **The gitignored WASM blob** (see above) — rebuild or copy.

## Deploying from the new machine (when you next ship)

Same recipe as always (also in `docs/HANDOFF_2026-06-25_FAILURE_SURFACING_AND_TREE_HYGIENE.md` §5):

```bash
cd frontend
BASE_PATH=/ios-screen-time-screenshot-processing bun run build   # dist/ must include pipeline-em/*
cd dist && touch .nojekyll && rm -rf .git && git init -b gh-pages \
  && git add -A && git commit -m "deploy" \
  && git push -f <repo-url> gh-pages && rm -rf .git
gh api -X POST repos/:owner/:repo/pages/builds      # then poll /pages/builds/latest until "built"
```

- Pages `build_type` MUST stay `legacy` (the workflow is frozen; flipping it once froze the site).
- Deploy commits use the ambient git identity — **no** `-c user.*`.
- A **frontend-only** deploy keeps the SAME wasm content-hash so returning users hit no ABI skew. The wasm changes only when `crates/processing` does (then rebuild it in Docker + mirror the change in Python `core/` for parity, same PR).

## Where to read more

- `CLAUDE.md` — full dev commands, architecture, CI gate list, conventions.
- `docs/HANDOFF_2026-06-25_FAILURE_SURFACING_AND_TREE_HYGIENE.md` — the most recent work (PR #80/#81), the failure-surfacing invariant, the PyO3 0.29 migration, CI map.
- `docs/roadmap.md` — the live plan; remaining open forks are server-only/host-constrained, parked under the WASM-offline focus.
- `docs/adr/` — the five load-bearing architecture decisions.
