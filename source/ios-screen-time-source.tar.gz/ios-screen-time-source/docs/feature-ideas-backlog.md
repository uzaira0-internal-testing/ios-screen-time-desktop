# Feature Ideas — Parking Lot

A brainstormed list of **orthogonal** feature directions (each independent of the others),
captured for later triage. **This is not a roadmap** — `docs/roadmap.md` is. Some of these
already exist effectively, some overlap with shipped behavior, and some may be nonsense.
Nothing here is committed work.

**Triage convention** — set `Status` per row as we review:
`untriaged` · `exists` (already shipped) · `overlap` (partially covered) · `nope` (not worth it) · `build` (greenlit → promote to roadmap).

**Mode tags:** **[W]** WASM-offline-friendly · **[S]** server-mode · **[B]** both.

---

## Accuracy & pipeline QA

| # | Idea | Mode | Status | Notes |
|---|------|------|--------|-------|
| 1 | **Per-bar confidence scores** — surface existing per-column fill-ratio/residual uncertainty as a 0–1 confidence on each of the 24 hours. | B | untriaged | Reuses residuals already computed by `slice_image_with_residuals`. |
| 2 | **Auto-triage "needs review" queue** — gate screenshots into a review lane when alignment score is low *or* the OCR-total↔Σbars gap exceeds the apportionment cap. | B | untriaged | Pure reuse of scores already computed. |
| 3 | **Direct per-hour bar editing** — click a bar, drag/type its height, live-recompute the total. | B | untriaged | Fix one wrong hour without re-annotating the whole image. |
| 4 | **Total double-read cross-check** — re-OCR the printed total at 2× upscale; require agreement before accepting. | B | untriaged | Independent confirmation of the reconciliation anchor. |
| 5 | **Detection overlay inspector** — translucent grid + bar-box overlay on the original screenshot for visual spot-checking. | B | untriaged | Makes every other accuracy fix human-verifiable. |

## Research data workflow

| # | Idea | Mode | Status | Notes |
|---|------|------|--------|-------|
| 6 | **Longitudinal timeline view** — stitch one participant's daily-totals into a multi-day usage chart. | B | untriaged | App extracts per-image; nothing aggregates across days yet. |
| 7 | **Cross-screenshot outlier detector** — flag a participant-day far from their own median. | B | untriaged | Catches mis-extractions / wrong-image uploads. |
| 8 | **Inter-rater reliability report** — Krippendorff's α / ICC over consensus annotations. | S | untriaged | A defensible reliability stat, not just "they disagree." |
| 9 | **Batch metadata tagging** — apply participant ID / study arm / date across a multi-select. | B | untriaged | |
| 10 | **Codebook export** — machine-readable data dictionary alongside the CSV. | B | untriaged | Self-documents columns/units/ranges for downstream stats. |

## Export & interop

| # | Idea | Mode | Status | Notes |
|---|------|------|--------|-------|
| 11 | **Apple Screen Time XML import** — ingest real iOS Screen Time export as ground truth to score the pipeline. | B | untriaged | Turns accuracy into a measurable number. |
| 12 | **Clipboard paste-to-ingest** — paste a screenshot from the clipboard instead of the file picker. | W | untriaged | Biggest day-to-day throughput win. |
| 13 | **REDCap-shaped export** — CSV in the exact import format research EDC systems expect. | B | untriaged | |
| 14 | **Parquet export** — columnar output for big cross-validation runs (JS parquet writer keeps it offline). | W | untriaged | Server-side Parquet already noted in roadmap. |
| 15 | **Per-screenshot PDF report** — image + extracted table + total + confidence, one page each. | W | untriaged | Archival / audit trail. |

## UX & accessibility

| # | Idea | Mode | Status | Notes |
|---|------|------|--------|-------|
| 16 | **Keyboard annotation mode** — hotkeys for accept / skip / correct / next. | B | untriaged | Speed for power annotators. |
| 17 | **Undo/redo stack** — annotations, manual crops, bar edits. | B | untriaged | Crop is currently destructive. |
| 18 | **Colorblind-safe overlay palette** — patterns + distinct hues for the bar/grid overlay. | W | untriaged | Overlay QA relies on color today. |
| 19 | **12h/24h + locale formatting** — render extracted times/dates per researcher locale. | B | untriaged | |
| 20 | **Thumbnail queue grid** — virtualized thumbnail wall for the screenshot queue. | B | untriaged | Browsable large studies vs one-at-a-time stepper. |

## New input types & pipeline robustness

| # | Idea | Mode | Status | Notes |
|---|------|------|--------|-------|
| 21 | **Android Digital Wellbeing detector** — second detector profile for Android's hourly bar chart. | B | untriaged | Doubles addressable screenshot types. |
| 22 | **Deskew / auto-rotate for photos-of-screens** — perspective/rotation correction stage. | B | untriaged | Recovers photographed-second-phone images. |
| 23 | **Locale-aware time-unit parsing** — "1 Std. 24 Min." / "1 h 24 min" etc. in total OCR. | B | untriaged | Documented future in `docs/guides/INPUT_REQUIREMENTS.md` (capture is en-US today; grid/bars already locale-independent). |
| 24 | **Battery-graph extraction mode** — the project name says battery *and* screen time; pipeline is screen-time-only. | B | untriaged | Same grid+bar machinery, parallel chart type. |
| 25 | **Weekly-view (7-bar) extraction** — distinct path for the weekly summary screen (currently rejected as non-hourly). | B | untriaged | Weekly is now **positively rejected** with a clear message (see `docs/guides/INPUT_REQUIREMENTS.md`); this row would instead *parse* it. |
