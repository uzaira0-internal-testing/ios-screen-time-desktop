# Test Skip / xfail Audit — 2026-06-04

Roadmap item **#2**. Goal: categorize every test skip and prove none hide a silently-dead
test, so the suite's pass count reflects real coverage.

## Method

Enumerated all skip mechanisms in `tests/`:
- `@requires_full_db` (a `skipif` on `test_engine.dialect.name != "postgresql"`)
- runtime `pytest.skip(...)` calls inside test bodies
- bare `@pytest.mark.skip(...)` / `@pytest.mark.xfail` (unconditional — these are the ones
  that hide dead tests)

## Findings

| Mechanism | Count | Verdict |
|---|---|---|
| Bare `@pytest.mark.skip` / `@pytest.mark.xfail` (unconditional) | **0** | ✅ none — no silently-dead tests |
| `@requires_full_db` (Postgres capability gate) | 40 | ✅ legit — **run** on the `db-tests` gate (0 skipped) |
| Runtime `pytest.skip(...)` | 55 | ✅ all justified (breakdown below) |

### Runtime `pytest.skip(...)` breakdown

| Category | Count | Why it's legitimate |
|---|---|---|
| Optional dependency / engine / import missing (Tesseract, PaddleOCR, schemathesis, optional submodules) | 28 | Capability gate — the path runs where the dep is installed (e.g. the rust-parity / Postgres containers) |
| `UPLOAD_API_KEY` not set in env | 20 | Capability gate — runs when the upload key is configured |
| PHI / test images absent | 5 | Source screenshots are intentionally **not committed** (PHI); can't run in CI without the data |
| Snapshot / golden baseline first-run | 2 | Fires only when creating the baseline; passes on every subsequent run |

## Conclusion

The suite has **no silently-dead tests**. Every skip is a runtime guard on a genuinely
absent capability (OCR engine, optional dependency, upload key), absent **uncommitted PHI
fixtures**, or a one-time snapshot/golden bootstrap. The 40 `@requires_full_db` cases are not
"skipped coverage" — they execute on the `db-tests` gate against real Postgres, which reports
**0 skipped** (the SQLite `tests` gate skips them by design and prints the count).

## Guard (regression prevention)

`scripts/ci/check-test-skips.sh` enforces the invariant found here: **0 bare unconditional
`@pytest.mark.skip` / `@pytest.mark.xfail`** in `tests/`. A new unconditional skip — the kind
that quietly removes a test from coverage — fails the check. Conditional skips (`skipif`,
runtime `pytest.skip` behind an `if`) remain allowed, since they self-document their gate.
Wired into the `tests` gate (`scripts/ci/tests.sh`).
