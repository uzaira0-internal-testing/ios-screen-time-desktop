# Handoff: WASM Failure Surfacing, Weekly Hard-Reject, and Branch/Tree Hygiene

Date: 2026-06-25
Mode: WASM (offline) — verified against the GitHub Pages build
Live site: https://uzaira0.github.io/ios-screen-time-screenshot-processing/

This handoff captures the state of `main` after the failure-surfacing work
(PR #80) and the repository hygiene pass that deleted the already-merged
branches and dispositioned the one open dependency PR. It is written for a
maintainer picking the project up cold: where the live app is, what the last
batch of changes did, how CI works, and what is genuinely open.

## 1. Where things stand right now

| Fact | Value |
|------|-------|
| Default branch | `main` |
| Tip of `main` | `5b483b5` — `fix(wasm): surface OCR/grid failures as failed + hard-reject weekly views (#80)` |
| Live bundle (gh-pages) | `main-7qjg17ep.js` (preprocessing chunk `chunk-yp8gj0ej.js`) |
| Live `gh-pages` commit | `fb05f0a` |
| Live WASM pipeline | `pipeline-em` sha `82335587` — **unchanged since PR #77**; #78/#79/#80 were frontend-only |
| Open PRs | none (the dependabot PyO3 bump was migrated + merged — see §6) |
| Working tree | clean |

The application is **100% client-side WASM-offline**: React + IndexedDB (Dexie) +
OPFS blobs + a service worker, no backend. The OCR pipeline is the Rust crate
`crates/processing` compiled to `pipeline-em/*.wasm` via Emscripten (leptess /
libtesseract under the hood — **not** Tesseract.js). The Python package under
`src/screenshot_processor/` is the server-mode path and the parity reference; it
is descoped for the current WASM-only focus but must stay byte-parity-correct
because gates enforce it.

## 2. The last functional change — failure surfacing + weekly hard-reject (PR #80)

All three fixes are in
`frontend/src/core/implementations/wasm/preprocessing/WASMPreprocessingService.ts`
and are frontend-only (no WASM rebuild — the live `82335587` wasm is unchanged).

### The silent-failure invariant (load-bearing — do not regress)

`addEvent(pp, stage, status, result)` ONLY writes the nested
`processing_metadata.preprocessing` blob (`stage_status[stage]` + `event.result`).
It does **not** touch the top-level `screenshot.processing_status` column. So a
terminal failure must do **both**:

1. `addEvent(..., SS.FAILED, ...)` — marks the stage, and
2. `updateScreenshot(id, { processing_status: "failed", processing_issues, has_blocking_issues })`
   — marks the row.

This mirrors what the `device_detection` landscape guard and `recordMissingBlob`
already do. Two OCR-stage paths violated it (grid-detection-failure block and the
`processImage` catch), masking hard failures as `SS.COMPLETED` with an unchanged
top-level status — invisible to status counts and the "failed" filter. Both now
set `SS.FAILED` **and** top-level `processing_status: "failed"`. The unique
issue_type `ocr_processing_failed` (catch path) is the live-verify token.

### Weekly views → "Failed", not "Needs attention" (the reported bug)

`needsAttention()` (`IndexedDBStorageService.ts`) requires
`processing_status === "completed"`. A weekly Screen Time chart was reaching
**completed** because the live OCR stage orchestrates grid detection in JS:
`primary = detectGrid("line_based")`, then a fallback `detectGrid("ocr_anchored")`.
`line_based` (PR #77) flags weekly via `is_weekly` but returns no grid, so the JS
fell through to the OcrAnchored fallback, which anchored a wrong ROI and returned
a grid → `processImage` "succeeded" with garbage bars → completed-with-mismatch →
"Needs attention". **Fix:** `if (!grid && !primary.isWeekly)` — a positive weekly
signal hard-rejects and **skips** the OcrAnchored fallback, so the weekly lands in
the grid-fail block → failed. (Rust `pipeline_process` already skips OcrAnchored on
`is_weekly`; the live path uses `pipeline_detect_grid` + `processImage`, not
`pipeline_process`'s internal ordering, so the Rust guard didn't cover it.)

> **Caveat for the user:** weeklies ALREADY sitting in "Needs attention" are
> stored as completed rows. They re-categorize to failed only on **reprocess**
> (re-run OCR). New/reprocessed uploads go straight to failed.

### OOM defense (F5)

The `device_detection` header-parse fallback decode (`safeDecodeBitmap`, fires
only when `readImageDimensions` can't parse a header) was ungated at the raised
`DEVICE_CROP_CONCURRENCY` (lowMem ? 8 : 12). It is now wrapped in
`getCropDecodeGate().run()` (semaphore 3/6) so a batch of unparseable-header
images can't OOM.

### New regression gate

`frontend/tests/persona-wasm-input-contract.spec.ts` (real Chromium,
`playwright.persona-wasm.config.ts`). Two input-contract personas: a 900×600
landscape → `device_detection` failed; a 1170×2532 blank (real iPhone res, so
device+crop complete) → OCR grid-fail → asserts the stage is `failed`,
`processing_status` is `failed`, `has_blocking_issues` is set. **Negative-control
proven** (reverting the fix made the test fail at `expect(ocr).toBe("failed")`).
The `wasm-persona` gate is now **9** tests. Run it with
`scripts/ci/run_wasm_persona_tests.sh` (does `BASE_PATH= bun run build` first).

## 3. The preceding batch (context for the above)

- **#77** `feat(pipeline)` — title INFO-card recovery + weekly/portrait input
  guards. **This is the build that produced the live `82335587` wasm.** It is the
  last change that touched `crates/processing` / `pipeline_em.rs`, so on `main`
  the Rust source and the live wasm are in sync (no undeployed pipeline work).
- **#78** `feat(frontend)` — boot resilience (OOM/wedge lifeboat, storage-pressure
  banner, RAM-scaled blob-URL cap, coalesced group aggregation), non-destructive
  crop undo/redo (rect-replay, no image snapshots), three-state totals.
- **#79** `fix(frontend)` — crop-grid coordinate-frame drift fix + accessibility
  sweep (shared `useFocusTrap`, sortable-th buttons, live regions).
- **#80** — this session (§2).

## 4. CI — runs LOCALLY, never GitHub Actions

`scripts/ci.sh` is the canonical entrypoint; sub-gates live in `scripts/ci/*.sh`.
Do **not** add jobs to `.github/workflows/*.yml` (project policy / ADR-0004).

```bash
./scripts/ci.sh fast    # lint + types + semgrep + ast-grep + contracts + tests (no Docker/browser)
./scripts/ci.sh all     # every gate except mutation
```

Capability gates skip **visibly** when Docker / cargo / a browser is absent:
`rust-parity`, `rust-redaction`, `phi-redaction`, `wasm-redaction`,
`wasm-workspace`, `wasm-cropundo`, `wasm-persona`, `bundle`, `backup-drill`,
`db-tests`, `persona`. The WASM-relevant gates for offline-mode work are the
`wasm-*` ones plus `fast`.

Static green for the §2 work: `tsc` 0, `eslint` 0, `bun test src/` 182 pass,
`wasm-persona` 9/9.

## 5. Deploy recipe (frontend-only, gh-pages)

Pages `build_type` MUST stay `legacy` (the GitHub workflow is frozen; flipping it
froze the site once). Deploy is an orphan push to `gh-pages`:

```bash
# from frontend/
BASE_PATH=/ios-screen-time-screenshot-processing bun run build
# inject the gitignored pipeline-em/*.wasm into dist/ if it isn't already there
cd dist && touch .nojekyll && rm -rf .git && git init -b gh-pages \
  && git add -A && git commit -m "deploy" \
  && git push -f <repo-url> gh-pages && rm -rf .git
gh api -X POST repos/:owner/:repo/pages/builds   # trigger build
# poll repos/:owner/:repo/pages/builds/latest until status == "built", then
# verify the LIVE served bundle hash, not just the push
```

- Deploy commits must **not** use `-c user.*` (use the ambient git identity).
- A **frontend-only** deploy keeps the SAME wasm (`82335587`) so returning users
  never hit ABI skew between a cached wasm and a new JS bundle.
- A `crates/processing` change reaches the live app ONLY after rebuilding the
  wasm via the `docker/wasm-build` Emscripten image (the host can't run `emcc`);
  mirror the change in Python `core/` for parity in the same PR.

## 6. PyO3 0.24 → 0.29 migration (was dependabot #68) — DONE

`rust-python/` (the server-side `screenshot_processor_rs` PyO3 wheel) pinned
`pyo3 = "0.24"`. Dependabot #68 bumped only the manifest/lock, which does **not**
compile — PyO3 0.23+ replaced the conversion traits. The binding was migrated and
the bump merged in this session; #68 was closed as superseded.

What broke and how it was fixed (`rust-python/src/lib.rs`):

| 0.29 break | Fix |
|------------|-----|
| `PyObject` removed entirely (no `pub type PyObject`) — E0425 at 5 sites | Stopped using `PyObject`; the heterogeneous-value functions now build and return a real `Py<PyDict>` |
| `Python::with_gil` removed — E0599 at 2 sites | `Python::attach` (its 0.29 replacement) |
| `#[pyfunction]` return conversion of `HashMap<String, PyObject>` was ambiguous (`IntoPyObjectConverter<Result<T,E>>` vs `<T>`) — E0034 at 4 sites | Returning `Py<PyDict>` / `Vec<Py<PyDict>>` built with `PyDict::new(py)` + `set_item` is unambiguous and idiomatic for 0.29 |

The Python-visible result is identical (same dict keys/values), so parity holds.
Verified with `scripts/ci/run_rust_parity_tests.sh` (builds the wheel against
libtesseract in a python:3.12 container — the host 3.14 venv can't, which is also
the motivation: 0.24 caps at CPython 3.13, 0.29 lifts that): **wheel built,
13/13 parity + fuzz tests passed**. `[workspace.lints.rust]` is empty (no
`deny(warnings)`), but no deprecation warnings remain either.

## 7. Branch / tree hygiene (this session)

Every local and remote feature branch except `main` and `gh-pages` corresponded
to an **already squash-merged** PR (#30–#80). Because squash-merge does not make
the branch commits ancestors of `main`, `git branch --merged` does not list them
— the authoritative signal is the merged-PR list (`gh pr list --state merged`).
These stale branches were deleted (local + remote); none were re-merged (doing so
would reintroduce superseded code).

## 8. Standing constraints (must persist)

- CI is **local only** — never add to `.github/workflows/*.yml`.
- **Pydantic is the single source of truth** for API contracts; regenerate TS
  types from the OpenAPI spec, never hand-write them.
- `shared/*.json` are the SSoT for cross-language constants; edit those + run
  `scripts/generate-shared-constants.py`, never the generated files.
- **PHI is person-name-only by design** (EMAIL/PHONE/DATE intentionally dropped);
  not a HIPAA gap.
- No network / no second SW registration / no network-first SW.
- Pages `build_type` stays `legacy`.
- A `crates/processing` edit is not live until the wasm is rebuilt via the
  `docker/wasm-build` image and deployed.

## 9. Open items / possible next steps

- **Real weekly fixture** — the new persona proves the failure-surfacing path but
  could not synthesize an image that trips the real weekly detector (it needs
  genuine chart structure: 4+ evenly-spaced horizontal-line groups + 6–10
  vertical lines at ≈width/7). Weekly *detection* is covered by #77's Rust unit
  test `test_weekly_pattern_seven_columns`. If a real de-identified weekly
  screenshot becomes available, add it as a golden/persona fixture.
- **Roadmap** — `docs/roadmap.md` is the live plan; the remaining open forks
  (#19, #8, #21-Parquet) are server-only/host-constrained and parked under the
  WASM-offline focus.
