# Suppression Burndown Audit — 2026-06-04 (roadmap #16)

Triage of every lint/type suppression in owned code (`src/**`, `frontend/src/**`;
vendored `docker/backend/packages/*` self-govern and are out of scope). Verdict
for each: **removed** (the underlying issue was fixed), or **kept + justified**
(load-bearing; carries a code and a reason). Going forward the
`scripts/ci/check-suppressions.sh` guard (wired into `ci.sh lint`) keeps every
suppression coded and justified.

## Outcome

| | Before | Removed | Kept (justified) |
|---|---|---|---|
| Python `# type: ignore` | 5 | 1 | 4 |
| Python `# noqa` | 15 | 0 | 15 |
| TS `eslint-disable*` | 21 | 0 | 21 (2 gained a reason) |
| TS `@ts-expect-error` | 1 | 0 | 1 |

No suppression was *unjustified-and-kept*. One blanket mute was removed; two TS
disables that lacked a written reason now carry one.

## Changes made

1. **Removed** the only blanket `# type: ignore` — `core/ocr_provider.py:71`. The
   cached getter returned `IOCREngine | None` where the contract is `IOCREngine`.
   Replaced the blanket mute with `assert self._engine is not None`, which narrows
   the type (basedpyright clean) **and** documents the invariant. A blanket
   `# type: ignore` (no code) hides *every* future error on that line — strictly
   worse than a checked assert.
2. **Justified** two `eslint-disable @typescript-eslint/no-explicit-any` in
   `…/emscripten/pipelineLoader.ts` (lines 75, 224) that had no `-- reason`: the
   Emscripten glue module and the UMD `globalThis` factory are generated, untyped
   JS; the shape is validated at the call sites / narrowed on the same line.

## Kept — load-bearing (representative)

- **Python `# type: ignore[attr-defined]`** — Temporal dynamic attribute assignment
  (`workflows/engine/registry.py`), SQLAlchemy `.rowcount` stub gap
  (`repositories/screenshot_repository.py`). `[import-not-found]` for the optional
  PaddleOCR dependency (`core/ocr_engines/paddleocr_engine.py`).
- **Python `# noqa: E402`** — intentional deferred imports placed after
  conditional setup (`web/api/main.py`, `celery_app.py`, `processing_service.py`,
  `models.py`). Reordering would re-introduce the import-order hazard the deferral
  avoids, so these are documented, not "fixed".
- **Python `# noqa: E712`** — SQLAlchemy `Column == True/False` inside `case()` /
  filter expressions (`repositories/{screenshot,queue,consensus}_repository.py`).
  `== True` and `.is_(True)` are **not** NULL-equivalent and `.is_()` does not
  compose the same way inside `case()`; the SQLAlchemy idiom stays.
- **Python `# noqa: F401`** — re-exports / side-effect registration imports
  (`schemas.py`, `models.py`, `workflows/worker_main.py`).
- **TS `eslint-disable no-await-in-loop`** — sequential awaits inside a single
  Dexie read-write transaction (`IndexedDBStorageService.ts`); parallelizing would
  lose updates / break crash-recovery determinism.
- **TS `eslint-disable require-atomic-updates`** — idempotent singleton init on
  cached module-load / OPFS directory handles (`opfsBlobStorage.ts`,
  `imageProcessor.worker.emscripten.ts`); concurrent calls are benign.
- **TS `eslint-disable no-console`** — dev-only diagnostics gated by
  `runtimeConfig.isDev` (`di/bootstrap.ts`, `di/bootstrapWasm.ts`).
- **TS `@ts-expect-error`** — `navigator.storage.getDirectory().entries()` lacks
  iterator typing in the current TS lib (`pages/SettingsPage.tsx`).

## Guard

`scripts/ci/check-suppressions.sh` (in `ci.sh lint`) fails on: a bare
`# type: ignore` (no `[code]`), a bare `# noqa` (no code), an `eslint-disable*`
with no ` -- reason`, any `@ts-ignore`, and an `@ts-expect-error` with no reason.
Coded + justified suppressions pass.
