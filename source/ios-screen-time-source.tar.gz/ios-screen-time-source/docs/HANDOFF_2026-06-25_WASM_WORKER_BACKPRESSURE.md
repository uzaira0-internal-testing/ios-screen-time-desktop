# Handoff: WASM Worker Backpressure

Date: 2026-06-25
Repo: `uzaira0/ios-screen-time-screenshot-processing`
Scope: WASM OCR/device-detection pipeline and GitHub Pages deployment readiness

## Baseline

- Current work builds on the resource-sized WASM OCR pool from PR #85.
- The public WASM bundle under `frontend/public/pipeline-em/` was not changed by this tranche.
- The change is frontend TypeScript only, plus this handoff.

## What Changed

- `WASMProcessingService` now owns an explicit FIFO dispatch queue.
- A worker receives at most one posted non-initialization job while it is busy.
- Jobs are dispatched only to workers that are initialized and marked ready.
- Worker message timeouts start when the job is posted to a worker, not while it waits in the service queue.
- `terminate()` rejects both queued and in-flight jobs before respawning the pool.
- Replacement workers are initialized with shared tessdata and the shared compiled WASM module before queued image work can drain into them.

This keeps backpressure on the main service instead of allowing hidden queues to accumulate inside each worker mailbox. It is a memory-control improvement for constrained devices and makes the worker-pool behavior easier to benchmark.

## Verification

Completed on this machine:

```bash
cd frontend && bun run typecheck
```

Result: passed.

```bash
cd frontend && bun test \
  src/core/implementations/wasm/__tests__/workerSizing.test.ts \
  src/core/implementations/wasm/processing/emscripten/__tests__/pipelineLoaderUrl.test.ts
```

Result: 6 passed, 0 failed, 20 expect calls.

```bash
cd frontend && bunx playwright test \
  --config playwright.wasm.config.ts \
  --project=chromium \
  --project=firefox \
  --project=webkit
```

Result: 134 passed, 13 skipped, 0 failed.

The WebKit skips are the existing directory-upload limitations in the WASM Playwright suite.

## Deployment Notes

For GitHub Pages, build the frontend with the repository base path and push `frontend/dist` to `gh-pages`:

```bash
cd frontend
BASE_PATH=/ios-screen-time-screenshot-processing bun run build
cd dist
touch .nojekyll
rm -rf .git
git init -b gh-pages
git add -A
git commit -m "deploy"
git push -f git@github.com:uzaira0/ios-screen-time-screenshot-processing.git gh-pages
rm -rf .git
gh api -X POST repos/uzaira0/ios-screen-time-screenshot-processing/pages/builds
```

Then verify the latest Pages build:

```bash
gh api repos/uzaira0/ios-screen-time-screenshot-processing/pages/builds/latest --jq '.status, .commit'
```

## Next Optimization Tranche

- Add scheduler telemetry: queue depth, queue wait time, worker run time, and replacement-worker recovery time.
- Add unit coverage for worker crash/replacement with queued work using a mock Worker.
- Profile large fixture batches under synthetic 1 GB, 2 GB, and 4 GB memory budgets.
- Compare ROI crop dimensions and OCR payload sizes before and after each pipeline stage.
