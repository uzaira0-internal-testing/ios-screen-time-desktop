# Screenshot Input Requirements (Capture Contract)

**Status:** Enforced · **Last updated:** 2026-06-22

This is the **input contract** for the Screen Time pipeline: the conditions a
screenshot must satisfy for the OCR/grid/bar extraction to produce correct
numbers. It exists so the "we handle it by how we capture" practice is written
down and **enforced** — inputs that violate it fail *loudly with an actionable
message* instead of silently producing wrong values.

The pipeline reads the **personal daily (24-hour) Screen Time chart** — the
hourly bar graph under Settings → Screen Time → See All Activity → **Day**. It is
*not* a general screenshot parser.

## Required capture conditions

| Requirement | Why | If violated |
|-------------|-----|-------------|
| **Daily (Day) view** — the 24-hour hourly bar chart | The whole pipeline is built around 24 hourly bars + a 0/60 axis | **Rejected.** The weekly (7-column) view is positively detected and rejected with "Weekly view detected — capture the daily chart". |
| **Portrait orientation** (taller than wide) | Every iOS Screen Time chart — iPhone *and* iPad — is laid out in portrait; landscape is a rotated/invalid capture | **Rejected** at the first stage with "Landscape orientation — capture in portrait". |
| **Standard display zoom** (not "Zoomed") | Display Zoom keeps the same pixel dimensions but scales the layout ~13%, so the resolution-keyed grid lookup mis-frames the chart | Not auto-rejected (same pixels → undetectable by dimensions). A **low grid-registration score** flags the geometric deviation. **Capture with Standard zoom.** |
| **en-US locale, 12-hour clock** | The axis anchors ("12 AM" / "60") and total-time text ("4h 36m") OCR are en-US today. Grid/bar *geometry* is locale-independent (pixel-based), so bars still extract in any locale — only the text reads are en-US-bound | Bars still extract; the title/total text may be missed in other locales. **Capture in en-US.** |
| **Light or dark mode** — either is fine | The detector is theme-aware (dark-mode grid-line classifier + dark-mode OCR rescue) | Supported. |
| **Any current iPhone or iPad** | Resolution coverage is exhaustive (exact lookup + proportional fallback for off-table devices) | Supported. New, never-seen resolutions fall back proportionally. |

## What the pipeline enforces vs. what it only signals

**Hard guards (rejected with a clear message):**
- **Weekly view** — `crates/processing/src/grid_detection/line_based.rs`
  positively classifies the 7-column weekly view (vertical-line count in the
  weekly band, disjoint from the daily 3-5) and returns `is_weekly`; the WASM
  entry (`pipeline_em.rs`) then skips the OcrAnchored fallback and the frontend
  surfaces "Weekly view detected — capture the daily chart". Mirrored in Python
  (`line_based_detection/strategies/combined.py`) for parity.
- **Landscape orientation** — guarded at the earliest frontend stage
  (`WASMPreprocessingService` `device_detection`, using the already-computed
  `orientation`) which halts the pipeline, **and** in the Rust entry points
  (`pipeline_process` / `pipeline_detect_grid`, `width >= height`) as defense in
  depth.

**Soft signals (surfaced, not rejected):**
- **Grid-registration score** (PR #52/#53) — value-independent measure of how
  well the ROI frames the chart gridlines. A low score is the practical signal
  for a Display-Zoomed or otherwise mis-framed capture.
- **Bar-alignment score** — flags grids that don't line up with the bars.

## Out of scope today (documented for the future)

These are deliberately *not* built — the controlled-capture contract above makes
them unnecessary. They are the path to take only if inputs ever broaden beyond
controlled en-US / portrait / Standard-zoom capture:

- **Resolution-independent "visual seed"** — derive the chart x/width from the
  detected gridline lattice instead of the resolution-key lookup. This is the
  durable fix that would make Display Zoom a non-issue automatically. (Backlog:
  the off-table proportional fallback already covers unknown *resolutions*; this
  would cover unknown *layouts*.)
- **Locale-aware time parsing** — backlog #23 ("1 Std. 24 Min." / "1 h 24 min").
  Grid/bar geometry already works in any locale; only `total_text` /
  `is_daily_total` text reads would need extending.
- **Weekly-view (7-bar) extraction** — backlog #25. We *reject* weekly by
  design ("we do not want weekly"); this would instead parse it.
- **Deskew / auto-rotate** — backlog #22, for photographed-second-phone images.

## Related

- ADR `docs/adr/0003-rust-accelerator-and-wasm-pipeline.md` — the Rust/WASM pipeline.
- `crates/processing/src/grid_detection/` — grid detectors (line-based primary, OCR-anchored fallback).
- `shared/lookup_table.json` — the resolution → grid-bounds SSoT.
