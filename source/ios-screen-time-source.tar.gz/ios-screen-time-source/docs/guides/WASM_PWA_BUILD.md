# WASM PWA Build

This app's public browser build is a local-first PWA. It runs without the
FastAPI backend and keeps screenshots in browser storage.

## Architecture

The primary browser processing path is **Path B**:

1. `scripts/build-wasm-emscripten.sh` builds `crates/processing` for
   `wasm32-unknown-emscripten` with the `wasm-emscripten` feature.
2. The build links Emscripten-built leptonica and tesseract, then stages:
   - `frontend/public/pipeline-em/IosScreenTimePipeline.js`
   - `frontend/public/pipeline-em/IosScreenTimePipeline.wasm`
   - `frontend/public/pipeline-em/eng.traineddata`
3. `frontend/src/core/implementations/wasm/processing/emscripten/pipelineLoader.ts`
   loads those artifacts, mounts tessdata, and wraps the C ABI exports.
4. `WASMProcessingService` uses `imageProcessor.worker.emscripten.ts`, so OCR,
   grid detection, and bar extraction run in the Rust pipeline.

The older `wasm-pack`/`wasm32-unknown-unknown` path is retained for benchmark
comparison and fallback only. Do not add new primary product behavior to the
Canvas ports unless the Emscripten path is intentionally bypassed.

## Local Build

Build or refresh Path B artifacts:

```bash
docker build -t ios-screen-time-wasm-builder docker/wasm-build
docker run --rm -v "$PWD:/app" ios-screen-time-wasm-builder bash -lc "scripts/build-wasm-emscripten.sh"
```

The script links Cargo release artifacts with Emscripten `-O0` on purpose:
emsdk 3.1.73's bundled Binaryen cannot run `wasm-opt` on Rust 1.94 output that
advertises the `bulk-memory-opt` target feature. Keep Rust, Emscripten, and
Binaryen upgrades together and re-run the benchmark before changing this.

Build the PWA:

```bash
cd frontend
bun run build
```

The custom build script bundles worker chunks, builds `src/service-worker.ts`
into `dist/sw.js`, copies `pipeline-em/`, generates `manifest.json`, and writes
`sw-precache.json`. Do not use raw `vite build` for deployment.

Browser WASM does not enable PHI/NER, so the public build omits the NER worker.
Packaging a PHI-enabled non-browser frontend must set `ENABLE_PHI_WORKER=1`.

## GitHub Pages

Pages uses the legacy static `gh-pages` publication path. Build the exact
artifact locally with:

```bash
BASE_PATH="/ios-screen-time-screenshot-processing" REQUIRE_PIPELINE_WASM=1 bun run build
```

This keeps subpath routing, PWA manifest URLs, and service worker cache entries
aligned with GitHub Pages. Keep Pages `build_type=legacy`.

`scripts/ci.sh wasm-persona` builds a root-served artifact into
`frontend/.cache/wasm-persona-dist`; it does not validate or overwrite the
Pages-ready `frontend/dist`. Build with `BASE_PATH` as the final action before
publication, then inspect `dist/config.js` and `<base href>`. The hashed JS
bundle can be identical even when those deployment-critical values are wrong.

## Verification

Run the benchmark after changing Rust, Emscripten build files, the worker, or
OCR loading:

```bash
node scripts/benchmark-wasm-paths.mjs --iterations 10
```

The benchmark exits non-zero if Path B reports any `ocr_error`. Use
`--allow-ocr-errors` only when intentionally measuring grid-only behavior during
toolchain repair.

For browser verification:

```bash
scripts/ci.sh wasm-persona
scripts/ci.sh ocr-corpus
```

The optional WebGPU pixel-threshold experiment is deliberately outside the
production pipeline. It benchmarks upload + compute + readback, compares every
result against the integer CPU implementation, and returns the CPU result on
unavailability, device loss, or any parity mismatch:

```bash
scripts/ci.sh wasm-webgpu
```
