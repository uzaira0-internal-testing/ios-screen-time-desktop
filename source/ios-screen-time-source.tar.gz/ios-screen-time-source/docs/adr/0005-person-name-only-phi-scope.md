# 0005 — PHI redaction is scoped to person names only

- **Status:** Accepted
- **Date:** 2026-06-05

## Context

The platform handles iOS Screen Time / battery screenshots in a HIPAA-relevant research
context, so it must offer PHI redaction before data is shared. A general PHI detector
recognises many entity classes — person names, emails, phone numbers, dates, addresses,
etc. Applying all of them to *this* corpus would flag and destroy data that is not PHI in
these screenshots (e.g. a "Screenshot Date", a "12:30" time label) and add noise without
reducing real risk.

## Decision

**PHI redaction is scoped to person names only.** Other detector categories
(EMAIL / PHONE / DATE / …) are intentionally **dropped on detection and on read** — this
is a deliberate scope decision, ratified by the maintainer, based on the observation that
screen-time/battery screenshots do not surface emails, phone numbers, or dates *as PHI*
(the dates present are usage dates, not patient identifiers).

The redaction itself is **irreversible by construction** and verified as such: redbox /
blackbox collapse the padded region to a single fill colour so no original pixel survives,
nothing outside the box changes, and (on the server path) EXIF is stripped with no source
bytes embedded. This is enforced by gates on **both** paths — server
(`ci.sh phi-redaction`) and the offline client (`ci.sh wasm-redaction`, driving the real
`redactImage` + IndexedDB in real Chromium; roadmap #9). Pixelate is pinned as
*lossy-but-not-zero-information* and therefore **not** accepted as PHI removal.

## Consequences

**Good**
- Redaction targets the one entity class that is actually PHI in this corpus; fewer false
  positives destroying legitimate data.
- Irreversibility is a tested invariant, not an assumption, on both the server and offline
  paths.
- The scope is documented, so a future reviewer does not mistake the dropped categories
  for a HIPAA gap and "fix" it.

**Bad / costs**
- If a future screenshot source *did* contain emails/phones as PHI, the current scope would
  miss them — the decision is corpus-specific and must be revisited if the input domain
  changes.
- The narrowing happens at both detection and read time, so widening the scope later is a
  code change, not a config toggle.

## Notes

Recorded in project memory as *"PHI is PERSON-name-only by design … not a HIPAA gap, don't
re-flag."* Revisit this ADR (supersede, don't edit) if the screenshot source domain
broadens.
