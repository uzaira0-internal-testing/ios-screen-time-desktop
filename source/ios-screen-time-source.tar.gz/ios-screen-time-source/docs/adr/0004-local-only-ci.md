# 0004 — CI runs locally via shell scripts, never GitHub Actions

- **Status:** Accepted
- **Date:** 2026-06-05

## Context

This is an internal research tool processing screenshots that may contain PHI. Running CI
on a hosted runner (GitHub Actions) would push the codebase, fixtures, and any
test-captured data through third-party infrastructure, and tie the project's verification
to a remote service's availability and configuration. The team wants every gate runnable,
auditable, and identical whether on a developer laptop, a pre-commit hook, or a manual
check — with no dependency on a cloud CI provider.

## Decision

**All CI gates run locally**, orchestrated by `scripts/ci.sh` with sub-gates in
`scripts/ci/*.sh`. New gates (lint, type-check, semgrep, ast-grep, contracts, tests,
parity, redaction, bundle budget, persona, security, …) are added as local scripts and
wired into `ci.sh` targets and the `all` aggregate.

**No new jobs are added to `.github/workflows/*.yml`.** Existing workflow files may remain
for legacy/Pages-deploy purposes, but they are not the verification path. `.githooks/`
(via `core.hooksPath`) run the relevant gates on commit/push.

## Consequences

**Good**
- Verification runs the same way everywhere; no "works in CI, fails locally" skew.
- No source, fixtures, or PHI-adjacent test data leave the local/controlled environment.
- Gates are fast to iterate on — edit a shell script, re-run; no push-and-wait loop.
- The full suite is one command (`./scripts/ci.sh`) and self-documenting via its targets.

**Bad / costs**
- No automatic enforcement on pull requests from the forge side — green-before-merge is a
  discipline (and the hooks), not a server-enforced branch-protection check.
- Each contributor must have the local toolchain (Python venv, bun, Docker for the
  container gates) to run the full suite; some gates skip visibly when a tool is absent.
- Onboarding relies on the scripts being kept current, since there is no hosted pipeline
  as a second source of truth.

## Notes

Treated as a hard rule in `CLAUDE.md` and the project memory: *"CI must run LOCALLY via
shell scripts, NEVER via GitHub Actions."*
