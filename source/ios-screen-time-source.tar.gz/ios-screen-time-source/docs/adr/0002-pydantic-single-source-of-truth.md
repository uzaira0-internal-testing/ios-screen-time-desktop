# 0002 — Pydantic schemas are the single source of truth for API contracts

- **Status:** Accepted
- **Date:** 2026-06-05

## Context

The frontend (TypeScript) and backend (Python) must agree on every request/response
shape. If types are hand-written on both sides, they drift silently: a backend field
rename or a new nullable field ships without the frontend knowing, and the bug only
surfaces at runtime in production.

## Decision

**Pydantic schemas are the single, authoritative definition of every API contract.** The
type flow is one-directional:

```
Pydantic schemas (web/database/schemas.py)
  → FastAPI auto-generates the OpenAPI spec
    → bun run generate:api-types (openapi-typescript)
      → frontend/src/types/api-schema.ts
```

The frontend **never** hand-defines an interface that mirrors a backend model; it imports
`components["schemas"]["…"]` from the generated `api-schema.ts` and calls endpoints through
the typed `apiClient`. The same JSON-driven generation produces shared enums/constants
(`shared/*.json` → generated Python + TS + Rust constants) so cross-language values can't
diverge either.

## Consequences

**Good**
- A schema change propagates to the frontend types mechanically; drift becomes a build
  failure, not a runtime surprise.
- One place to read the contract; reviewers check `schemas.py`, not three copies.
- Shared enums (processing/annotation statuses, export columns) stay identical across
  Python, TypeScript, and Rust.

**Bad / costs**
- After any `schemas.py` change the generated types must be regenerated and committed; a
  PostToolUse reminder and the contract checks guard this.
- Endpoints that return a plain `dict` (e.g. the export endpoints) carry no generated
  type — by design, but it means not *every* response is typed end-to-end.
- The frontend is coupled to the generator toolchain (`openapi-typescript`).

## Notes

This decision is treated as **non-negotiable** in `CLAUDE.md`. Defining a frontend
interface that duplicates a backend model is a review-blocking anti-pattern.
