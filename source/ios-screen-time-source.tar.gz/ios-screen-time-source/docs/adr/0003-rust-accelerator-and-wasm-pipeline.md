# 0003 — Rust accelerator (`screenshot_processor_rs`) + Emscripten WASM pipeline

- **Status:** Accepted
- **Date:** 2026-06-05

## Context

The core image pipeline — grid detection, ROI extraction, and per-hour bar-height
sampling (`slice_image`) — is numerically heavy and runs on every screenshot. It must run:

- on the **server** (Python) fast enough for batch reprocessing, and
- in the **browser** for the offline WASM mode, where there is no backend to offload to.

A pure-Python hot path is too slow for client-side processing, and re-implementing the
same algorithm a third time in hand-written JavaScript would create yet another copy to
keep in parity.

## Decision

Implement the hot path **once in Rust** (`screenshot_processor_rs`) and ship it two ways:

- **Server:** a PyO3 extension wheel, built in a workspace-rooted container (both backend
  Dockerfiles build the wheel under a temp `[workspace]` root because the crate uses
  `lints.workspace = true`).
- **WASM:** compiled via Emscripten to `pipeline-em/*.wasm` (~5.7 MB), loaded by the
  offline client. This blob is **intentionally excluded** from the frontend bundle budget
  (ADR-adjacent: roadmap #5) — it changes only when the Rust accelerator changes, not with
  app code.

Correctness across the implementations is pinned by tests, not trust: a Python↔Rust parity
gate (`ci.sh rust-parity`, run in a `python:3.12` container with the extension built) and a
pure-Python ↔ Rust-golden parity harness (roadmap #3) assert identical grid bounds, hourly
values, totals, and alignment on real fixtures.

## Consequences

**Good**
- One authoritative algorithm; the server and the offline browser pipeline produce
  byte-identical results, enforced by the parity gates.
- The browser pipeline is fast enough to process locally with no backend.
- The parity harness has already caught a real silent-data-loss bug (a missing 4× scale-up
  in the pure-Python `slice_image`; see roadmap #3).

**Bad / costs**
- The Rust toolchain cannot build natively on the dev host (missing GTK/glib syslibs for
  the Tauri crate; the PyO3 crate needs the `python:3.12` container) — so Rust changes are
  gated in containers, not on the bare host.
- The 5.7 MB WASM blob is a large download for first-time offline users.
- Three surfaces (Python wheel, Emscripten WASM, the parity goldens) must be rebuilt
  together when the algorithm changes.
