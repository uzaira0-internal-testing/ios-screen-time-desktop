# 0001 — Dual-mode (server / WASM) via a DI service container

- **Status:** Accepted
- **Date:** 2026-06-05

## Context

The platform must serve two mutually exclusive deployments from one frontend codebase:

- **Server mode** — FastAPI + PostgreSQL backend, multi-user collaboration, server-side
  filesystem storage and OCR.
- **WASM mode** — 100% client-side and **fully offline by design**: no backend, no
  network, IndexedDB + OPFS storage, Tesseract.js OCR in a Web Worker.

The two modes differ in storage, processing, networking, and identity, but must present
the **same UI and behaviour**. Branching on the mode inside components (`if (isWasm) …`)
would scatter mode logic across the whole tree and make each path impossible to test in
isolation.

## Decision

Define **service interfaces** (`frontend/src/core/interfaces/I*.ts` —
`IScreenshotService`, `IAnnotationService`, `IStorageService`, `IProcessingService`,
`IConsensusService`) and provide **two implementations** of each under
`core/implementations/server/` and `core/implementations/wasm/`.

A generic **DI container** (`core/di/Container.ts`) is populated at startup by
`core/di/bootstrap.ts`, which picks the implementation set from a single **mode-detection
signal: the presence of the `VITE_API_BASE_URL` env var** (set → server, absent → WASM).
Components consume services only through the `useServices` hook (`core/hooks/`), never by
importing a concrete class.

Cross-implementation correctness is enforced by tests, not convention: a behavioural
contract suite runs *both* implementations headless (roadmap #14), and a Python↔WASM
parity harness pins the two processing pipelines to the same golden outputs (roadmap #3).

## Consequences

**Good**
- Components are mode-agnostic; a single component tree serves both deployments.
- Each implementation is unit-testable in isolation; the WASM path is testable in real
  Chromium against real OPFS/IndexedDB via Bun-bundled harnesses.
- Adding a capability means adding a method to the interface + both impls — the compiler
  forces parity (a missing method fails `tsc`).

**Bad / costs**
- Every new service method must be implemented twice, even when one mode is a no-op
  (e.g. `updateGridCoords` is a no-op server-side).
- Behavioural drift between the two impls is possible and must be guarded by the contract
  and parity suites rather than the type system alone.
- Mode is a build-time decision (the env var), not a runtime toggle.
