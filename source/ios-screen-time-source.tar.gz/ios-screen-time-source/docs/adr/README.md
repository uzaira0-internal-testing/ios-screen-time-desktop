# Architecture Decision Records

This directory captures the **load-bearing decisions** behind the iOS Screen Time
Screenshot Processing platform — the choices that shape everything else and would be
expensive to reverse. Each record states the context, the decision, and the
consequences (good and bad) so a future contributor understands *why*, not just *what*.

Format is a lightweight [MADR](https://adr.github.io/madr/): **Status · Context ·
Decision · Consequences**. ADRs are immutable once `Accepted` — to change a decision,
add a new ADR that supersedes the old one (don't edit history).

This is roadmap **#25** ("capture the load-bearing decisions, then one per subsystem as
waves touch them"). The five foundational ADRs are recorded first; subsequent ADRs are
added as new subsystems land.

## Index

| ADR | Title | Status |
|-----|-------|--------|
| [0001](0001-dual-mode-di-container.md) | Dual-mode (server / WASM) via a DI service container | Accepted |
| [0002](0002-pydantic-single-source-of-truth.md) | Pydantic schemas are the single source of truth for API contracts | Accepted |
| [0003](0003-rust-accelerator-and-wasm-pipeline.md) | Rust accelerator (`screenshot_processor_rs`) + Emscripten WASM pipeline | Accepted |
| [0004](0004-local-only-ci.md) | CI runs locally via shell scripts, never GitHub Actions | Accepted |
| [0005](0005-person-name-only-phi-scope.md) | PHI redaction is scoped to person names only | Accepted |
| [0006](0006-desktop-packaging-repo-on-hosted-ci.md) | Desktop installers are built on GitHub Actions in a separate public repo | Accepted |

## Writing a new ADR

1. Copy the structure of an existing record; number it sequentially.
2. Keep it short — the decision and its consequences, not a tutorial.
3. Set `Status: Proposed` until agreed, then `Accepted`.
4. Add a row to the index above.
