# Handoff: Annotation Queue Navigation, Crop Editor, and Hourly-Plot Fixes

Date: 2026-06-05
Mode: WASM (offline) — verified against the GitHub Pages build
Live site: https://uzaira0.github.io/ios-screen-time-screenshot-processing/

This handoff covers four user-reported annotation-workspace bugs plus the
"Needs attention" (`totals_mismatch`) filter that was never implemented in
WASM mode. All changes are WASM-offline-safe (no network) and preserve the
server-mode paths.

## Summary of fixes

| # | Symptom | Root cause | Fix |
|---|---------|-----------|-----|
| 1 | Crop-adjust view from annotation is tiny / not scaled | `CropAdjustModal` computed its fit-scale from `canvasRef.parentElement` — the `role="application"` wrapper, which shrinks to the default 300px canvas — and only on image-load | Measure the real canvas-area container via a ref; recompute on `ResizeObserver` + window-resize (also covers the modal open-transition timing) |
| 2 | 1px blue sliver at the base of every empty hour column (separate-mode plot); bars too dark | `HourlyUsageEditor` rendered a zero-height bar with an always-on `border-t border-eq-info` | Render the bar only when `value > 0` (matches the overlay); both editors now use the new lighter-blue token `--eq-chart-bar` |
| 3 | "Needs attention" queue population wrong + can't advance | (a) WASM dropped the `totals_mismatch` filter everywhere — queue was unfiltered; (b) see #4-advance | Ported the server's needs-attention rule to WASM (`needsAttention()`), wired through list + navigation + the homepage group-card count |
| 4a | Can't advance past the first screenshot in any non-"all" filter | The URL-sync effect rewrites the route to `/annotate/:id` on every step → `initialScreenshotId` changed → the queue-init effect re-fired → `setVerificationFilter` snapped back to item #1 | Init effect reads the deep-link target/filter from **refs**; deps are only `[groupId, processingStatus]` + stable actions, so it fires once per queue identity |
| 4b | Stuck on "No screenshots to annotate" after switching from an empty filter to a populated one | `loadScreenshot` never cleared `noScreenshots` (unlike `loadNextScreenshot`) | Clear `noScreenshots: false` on successful load |

## Files changed

Source (frontend):
- `src/components/annotation/AnnotationWorkspace.tsx` — init-effect ref refactor (#4a)
- `src/components/annotation/HourlyUsageEditor.tsx` — sliver fix + chart-bar token (#2)
- `src/components/annotation/HourlyUsageOverlay.tsx` — chart-bar token (#2)
- `src/components/preprocessing/CropAdjustModal.tsx` — canvas-area ref + ResizeObserver (#1)
- `src/store/slices/screenshotSlice.ts` — `noScreenshots: false` on load (#4b)
- `src/core/interfaces/IStorageService.ts` — `totals_mismatch` on params; `totals_mismatch` count on `GroupAggregateRow` (#3)
- `src/core/implementations/wasm/WASMScreenshotService.ts` — forward `totals_mismatch` in `getList`/`navigate`; surface group count (#3)
- `src/core/implementations/wasm/preprocessing/WASMPreprocessingService.ts` — surface group count (#3)
- `src/core/implementations/wasm/storage/IndexedDBStorageService.ts` — `needsAttention()` predicate; `applyVerificationFilter` branch; `navigateScreenshots` `hasJsFilter` + cache key; group-aggregation count (#3)
- `src/equal-research-ui/tokens.css` — `--eq-chart-bar` (light `#4f9cee`, dark `#5ea8f5`) (#2)
- `src/index.css` — `--color-eq-chart-bar` `@theme` mapping (required for the Tailwind utility) (#2)

Test (new):
- `src/core/implementations/wasm/storage/__tests__/needsAttention.test.ts` — locks WASM↔server parity for the needs-attention predicate

## The "Needs attention" (`totals_mismatch`) port — detail

WASM previously ignored `totals_mismatch` entirely (the count was hardcoded
`0`, so the homepage badge never even appeared). `needsAttention(s)` in
`IndexedDBStorageService.ts` is the offline port of the server's
`_NEEDS_ATTENTION_WHERE_SQL` / `needs_attention_conditions()`
(`screenshot_repository.py`):

A `completed` screenshot needs attention when it has hourly data AND either:
- **missing title** (app name never extracted), or
- **bar/OCR total mismatch ≥ 1 minute**, where the OCR total has an `h`/`m`
  component (seconds-only like `"9s"` is excluded — `parseOcrTotalMinutes`
  returns `null`), summing **raw** hourly values over numeric (`^\d+$`) keys.

It's reused in three places so they can't drift: `getScreenshotsPaginated`
(the list), `navigateScreenshots` (next/prev), and `getGroupAggregation` (the
homepage count). `parseOcrTotalMinutes` (`@/utils/formatters`) matches the
server regex exactly — do not rewrite it.

## Verification status (read this before claiming "fixed")

**Statically verified / no-regression — green:**
- `bunx tsc --noEmit` — 0 errors
- `bunx eslint` (all touched files) — 0
- `bun test src/` — 108 pass (incl. the new `needsAttention` parity test)
- `bun run test:e2e:wasm` (WASM smoke gate) — 49/49 against the rebuilt
  root-base dist, incl. "no uncaught JS errors during navigation"
- Production build clean; `bg-eq-chart-bar` confirmed compiled into the bundle CSS

**NOT yet demonstrated end-to-end in a browser:** the three symptom-flips
(advance-works, needs-attention-populates-correctly, empty→populated-clears).
The smoke suite has no multi-item filtered queue and no seeded mismatch data,
so it can't show them. The needs-attention *predicate* is unit-tested, and the
filter/navigate plumbing reuses the same machinery the working
`verified_by_me`/`verified_by_others` filters already use — but the decisive
check is **real data on the live site**.

**Do NOT use `tests/wasm-annotate.spec.ts` (`test:e2e:annotate`) to verify
this.** It is pre-existing-broken for WASM at the harness level: its `login()`
helper is a server-mode artifact (`"Username (optional)"` / "Get Started"
selectors that no longer exist; in local mode `LoginForm` auto-redirects off
`/login` — there is no form). Even a WASM-correct rewrite (byte-identical to the
smoke suite's working `wasmLogin`) `ERR_ABORTED`s on the first `goto`, i.e. the
breakage is harness/SW-state level, not the selector. The **WASM smoke suite is
the WASM e2e gate.** (Left untouched this session.)

## Deploy

Shipped via PR to `main`, then the Pages-base dist published to the `gh-pages`
orphan branch. GitHub Pages `build_type` MUST stay `legacy` (the workflow is
frozen). Recipe:

```bash
# from frontend/
BASE_PATH=/ios-screen-time-screenshot-processing bun run build
# publish dist/ to gh-pages (orphan), then:
gh api -X POST repos/:owner/:repo/pages/builds
# poll repos/:owner/:repo/pages/builds/latest until status == "built"
```

After deploy, the service worker means users need a **hard reload** (or the
update banner) to pick up the new bundle.

## Known gaps / possible next steps

- **End-to-end coverage for the queue filters.** The proportionate way to close
  the empirical gap without the dead annotate harness is a storage-level seeded
  test on the Bun-harness pattern (`tests/harness/`, see the `wasm-redaction`/
  `wasm-workspace` configs): seed a few needs-attention + clean rows via
  `page.evaluate`, then assert `getScreenshotsPaginated` + `navigateScreenshots`
  under `totals_mismatch`. Not done this session (net-new harness; optional).
- **Minor parity nuance:** `needsAttention` treats `extracted_hourly_data === {}`
  as "no data" → not flagged; the server treats a non-null `{}` as present. A
  completed screenshot with an empty `{}` essentially never occurs; the unit
  test locks the current behavior.
- **Redacted screenshots** never appear in "needs attention" — redaction moves
  `processing_status` away from `completed`, which the rule requires. Intended.
