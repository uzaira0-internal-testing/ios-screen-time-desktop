# Browser WASM/PWA Architecture

## Status and scope

This document describes the product that is built, tested, and published: the
offline browser application under `frontend/`, backed by the Rust processing
crate compiled to WebAssembly.

FastAPI, PostgreSQL, WebSocket, and Tauri code remains in the repository for
reference, parity work, and optional experiments. It is not part of the public
GitHub Pages runtime and is deliberately outside this architecture boundary.

## Runtime topology

```text
GitHub Pages
  └── static application shell
      ├── React 19 routes and Equal design tokens
      ├── Zustand UI/settings state
      ├── service interfaces resolved by the WASM DI bootstrap
      ├── IndexedDB + OPFS persistence
      ├── service worker and integrity manifest
      └── bounded Web Worker pool
          └── Emscripten module
              └── crates/processing + Leptonica + Tesseract
```

There are no authenticated users, REST calls, WebSocket connections, or shared
server database in the public product. A workspace belongs to one browser
profile and can be moved explicitly through workspace export/import.

## Build artifacts

The primary processing path is `wasm32-unknown-emscripten` (“Path B”). The WASM
builder stages these files under `frontend/public/pipeline-em/`:

- `IosScreenTimePipeline.js` — Emscripten loader
- `IosScreenTimePipeline.wasm` — Rust processing binary
- `eng.traineddata` — default OCR language data
- `pipeline-build.json` — source fingerprint, schema, hashes, and build metadata

`frontend/server/build.ts` verifies artifact completeness, pipeline schema,
tessdata digest, and current source fingerprint when Rust sources are present.
The production build emits hashed application/worker chunks, `index.html`,
`config.js`, the PWA manifest, service worker, precache index, and pipeline.

The old `wasm-pack`/Canvas paths are comparison or fallback implementations;
new product behavior belongs in the Emscripten path unless a fallback is being
added intentionally.

## Application layers

### Presentation

Routes live in `frontend/src/pages/` and reusable UI in
`frontend/src/components/`. Routes are lazy-loaded. `Layout` owns navigation,
focus movement, update status, and onboarding. The tour auto-opens only on the
Load route; Help/Header can replay it explicitly elsewhere.

### Service boundary

React resolves interfaces through `frontend/src/core/di/`. Browser mode
registers local implementations:

- `WASMScreenshotService` — bounded import, hashing, duplicates, image records
- `WASMProcessingService` — worker pool and Rust pipeline IPC
- `WASMPreprocessingService` — device detection, crop, OCR orchestration
- `WASMAnnotationService` — local annotation lifecycle
- `WASMConsensusService` — local verification and aggregation
- `IndexedDBStorageService` — persistence facade

Scheduler/cancellation primitives are isolated from preprocessing behavior in
`preprocessingStageRuntime.ts`. Continue extracting cohesive boundaries rather
than growing orchestration classes with unrelated helpers.

### Processing workers

Image decoding and OCR run outside the main thread. Worker counts and per-stage
concurrency are bounded by CPU and memory budgets from `resourceBudget.ts`.
Abort signals propagate through queued and in-flight work. Scheduler diagnostics
are exposed only for development/localhost test probes.

The Rust/TypeScript IPC schema is versioned. A mismatch is fatal and triggers
bounded stale-cache recovery rather than interpreting an old result with new
defaults.

### Storage

IndexedDB stores groups, screenshot records, annotations, processing metadata,
and workflow state. OPFS stores large image blobs, optional language packs, and
pre-migration backups when supported.

Important invariants:

- imports are bounded; folder size does not become promise fan-out
- content hashes identify exact duplicates
- original images survive derived crop operations
- migrations create a backup before changing durable data
- object URLs have bounded residency and are revoked on eviction
- reset and recovery cleanup have explicit resource budgets

### Offline and updates

The service worker precaches the shell and pipeline. Pipeline executables are
checked against the build integrity index before persistence. A mismatched
asset is never cached or served as trusted pipeline code.

ABI-skew recovery clears relevant caches and the service worker, then reloads
at most once per session. It does not do this while offline because that could
strand the user without a cached shell.

## Import compatibility

Chromium can use the File System Access API for recursive directory scanning.
Browsers without it use `webkitdirectory` where available. A normal multi-file
picker is always exposed as the compatibility path, including Safari/WebKit
environments that cannot select or automate directories.

Folder-relative paths improve participant/date inference but are not required.
Files selected through the compatibility picker receive unknown folder metadata
unless supplied separately by the workflow.

## PHI boundary

Pure browser WASM passes `phiDetection=false` during bootstrap. It does not load
the optional NER worker or download the Hugging Face model. The public pipeline
is device detection → cropping → OCR.

Tauri may enable PHI stages separately. Any future browser PHI feature needs an
explicit offline model/install design and must not silently introduce a large
cross-origin first-run download.

## Source-of-truth contracts

- `shared/*.json` → generated Python/TypeScript/Rust constants
- Rust pipeline schema → loader-required schema version
- `pipeline-build.json` → exact staged artifact identity
- `sw-precache.json` → production cache inventory and hashes
- workspace schema/migrations → durable browser-data compatibility

Generated Rust is formatted through `rustup which rustfmt` from the repository
root, honoring `rust-toolchain.toml` instead of an unrelated PATH binary.

## Testing model

The principal gates are local:

- TypeScript/ESLint plus custom Semgrep and ast-grep rules
- Bun unit and contract tests
- Rust/Python cross-implementation parity
- real Chromium PWA/persona, OCR corpus, workspace, and recovery suites
- on-demand Firefox and WebKit persona compatibility
- bundle and worker-size budgets

Semgrep configuration is validated before scanning so a malformed rule cannot
silently reduce the enforced rule set.

## Deployment invariant

GitHub Pages serves from `/ios-screen-time-screenshot-processing/`. The publish
build must set the matching `BASE_PATH`. Local persona gates build to
`frontend/.cache/wasm-persona-dist` with an empty base path and must never replace
the Pages-ready `frontend/dist`.

Before publishing, verify:

1. `config.js` contains the repository base path.
2. `<base href>` contains the repository base path.
3. Pipeline schema and source fingerprint match.
4. Persona tests ran against their isolated local dist.
5. The live persona gate and live WASM digest match after publication.

GitHub Pages `build_type` remains `legacy`; deployment publishes an already
verified static artifact, not a server application.
