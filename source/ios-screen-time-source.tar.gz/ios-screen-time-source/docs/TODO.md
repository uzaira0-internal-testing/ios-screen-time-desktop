# TODO

## WASM/PWA Development Roadmap

The browser app should continue on the **Path B** architecture: the
Rust `crates/processing` pipeline compiled with Emscripten so the public WASM
app uses Rust + leptess/libtesseract for OCR, grid detection, and bar
extraction. The TypeScript Canvas ports and Path A `wasm-pack` build are
fallback/reference tools, not the primary product path.

### Current Primary Path

- [x] Compile Rust + leptess to `wasm32-unknown-emscripten`.
- [x] Load `IosScreenTimePipeline.js`, `.wasm`, and `eng.traineddata` from `frontend/public/pipeline-em/`.
- [x] Route `WASMProcessingService` through the Emscripten worker.
- [x] Use the same Emscripten OCR path for PHI word extraction.
- [x] Generate a PWA service worker and `sw-precache.json` from the custom Bun build.
- [x] Deploy GitHub Pages from Path B artifacts instead of the older raw Vite/Path A build.

### Near-Term Work

- [ ] Run `scripts/benchmark-wasm-paths.mjs --iterations 10` after each Emscripten build and require no Path B `ocr_error` values.
- [ ] Keep `frontend/public/pipeline-em/` generated, not committed; CI must rebuild it before `bun run build`.
- [ ] Run `cd frontend && bun run build` before public deploys to verify worker chunk rewrites and service worker precache generation.
- [ ] Collapse duplicate third-party native builds by either removing unused Dockerfile leptonica/tesseract layers or teaching `scripts/build-wasm-emscripten.sh` to reuse them.
- [ ] Keep Canvas processing modules covered by parity tests, but avoid adding new product behavior there unless it is a deliberate fallback.
- [ ] Add a focused Playwright smoke that loads the built PWA, processes one fixture, and confirms title/total/grid/hourly values are non-empty where expected.

### Deferred

- [ ] Revisit Path A only for apples-to-apples benchmark comparisons or as a lightweight fallback if Emscripten support regresses.
- [ ] Consider packaging the same Path B pipeline in Tauri only if it simplifies distribution; native Tauri already uses the Rust crate directly.
