# Repository Guidelines

## Project Structure & Module Organization

This repository combines a Python FastAPI backend, Rust processing crates, and a React/Tauri frontend.

- `src/screenshot_processor/` contains the Python package: `core/` for OCR/image processing, `web/` for FastAPI routes, services, repositories, database models, and WebSockets, and `gui/` for the optional PyQt GUI.
- `frontend/src/` contains the React + TypeScript app: `components/`, `pages/`, `store/`, `services/`, and `core/implementations/`.
- `crates/processing/` and `rust-python/` are Rust workspace members; `frontend/src-tauri/` is a standalone crate, the desktop shell around the web build.
- `tests/` holds Python unit, integration, and golden tests. `frontend/tests/` holds Playwright and WASM-focused tests.
- `alembic/` stores database migrations, `docker/` stores compose and container files, and `scripts/` stores project utilities.

## Build, Test, and Development Commands

- `uv sync` installs Python dependencies from `pyproject.toml` and `uv.lock`.
- `docker compose -f docker/docker-compose.dev.yml up -d` starts local development services.
- `alembic upgrade head` applies database migrations.
- `uvicorn src.screenshot_processor.web.api.main:app --reload --host 127.0.0.1 --port 8002` runs the backend API.
- `pytest` runs the Python test suite; use `pytest tests/unit` or `pytest tests/integration` for focused runs.
- `ruff check src tests` lints Python code.
- `cargo test --workspace` runs Rust tests; `cargo fmt --all` formats Rust code.
- From `frontend/`, use `bun run dev`, `bun run build`, `bun run check`, and `bun run test:e2e` for the dev server, build, TypeScript/ESLint checks, and Playwright tests.

## Coding Style & Naming Conventions

Python targets 3.11 with Ruff line length `120`. Keep modules snake_case, classes PascalCase, and tests named `test_*.py`. Prefer service and repository boundaries over cross-layer imports. Rust uses the workspace toolchain and `rustfmt.toml`. Frontend components use PascalCase, hooks use `use*`, and shared API types are generated into `frontend/src/types/api-schema.ts`.

## Testing Guidelines

Add or update tests near the changed surface: backend units in `tests/unit/`, API workflows in `tests/integration/`, schema snapshots in `tests/golden/`, Rust tests under each crate, and browser flows in `frontend/tests/e2e/`. Regenerate API types with `bun run generate:api-types` when backend schemas change.

## Commit & Pull Request Guidelines

Follow the existing conventional style: `feat:`, `fix:`, `chore:`, `style:`, or scoped forms such as `feat(wasm):` and `fix(rust):`. PRs should describe the behavior change, list verification commands run, link related issues, and include screenshots for visible frontend changes. Note schema, migration, or generated-file updates explicitly.

## Security & Configuration Tips

Do not commit secrets or local data. Start from `.env.example`, keep runtime uploads in gitignored storage, and run `docker/validate-secrets.sh` or relevant security checks before deployment-oriented changes.
